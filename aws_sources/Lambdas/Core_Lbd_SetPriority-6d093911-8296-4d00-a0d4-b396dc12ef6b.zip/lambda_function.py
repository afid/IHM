import json
import boto3
import os
from botocore.exceptions import ClientError

# Initialisation du client Connect
client = boto3.client('connect')

# Récupération de l'instanceID depuis les variables d'environnement
INSTANCE_ID = os.environ.get('CONNECT_INSTANCE_ID', '0f3658fc-4902-45ad-9575-1baf3529f440')

# Plage de priorité valide pour Amazon Connect
MIN_PRIORITY = 1
MAX_PRIORITY = 9223372036854775807  # Valeur maximale d'un long 64 bits

def lambda_handler(event, context):
    try:
        # Validation de la structure de l'événement
        contact_data = event.get("Details", {}).get("ContactData", {})
        if not contact_data:
            return error_response("Structure d'événement invalide", 400)
        
        contact_id = contact_data.get("ContactId")
        if not contact_id:
            return error_response("ContactId manquant", 400)
        
        # Récupération de l'attribut UC_Priorite
        attributes = contact_data.get("Attributes", {})
        uc_priorite = attributes.get("UC_Priorite")
        
        if uc_priorite is None:
            return error_response("L'attribut UC_Priorite n'est pas défini", 400)
        
        # Validation et conversion de la priorité
        try:
            nouvelle_priorite = int(uc_priorite)
        except ValueError:
            return error_response(f"UC_Priorite doit être un nombre entier, reçu: {uc_priorite}", 400)
        
        # Validation de la plage de priorité
        if not MIN_PRIORITY <= nouvelle_priorite <= MAX_PRIORITY:
            return error_response(
                f"La priorité doit être entre {MIN_PRIORITY} et {MAX_PRIORITY}, reçu: {nouvelle_priorite}", 
                400
            )
        
        print(f"Contact ID: {contact_id}")
        print(f"Mise à jour de la priorité à: {nouvelle_priorite}")
        
        # Mise à jour de la priorité
        update_contact_priority(contact_id, nouvelle_priorite)
        
        print(f"Priorité mise à jour avec succès pour le contact: {contact_id}")
        
        return {
            'statusCode': 200,
            'priorite': nouvelle_priorite,
            'message': 'Priorité mise à jour avec succès'
        }
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        print(f"Erreur AWS: {error_code} - {error_message}")
        return error_response(f"Erreur AWS: {error_message}", 500)
    
    except Exception as e:
        print(f"Erreur inattendue: {str(e)}")
        return error_response(f"Erreur interne: {str(e)}", 500)

def update_contact_priority(contact_id, priority):
    """Met à jour la priorité de routage d'un contact"""
    response = client.update_contact_routing_data(
        InstanceId=INSTANCE_ID,
        ContactId=contact_id,
        QueuePriority=priority
    )
    return response

def error_response(message, status_code):
    """Retourne une réponse d'erreur formatée"""
    print(f"Erreur: {message}")
    return {
        'statusCode': status_code,
        'error': message
    }

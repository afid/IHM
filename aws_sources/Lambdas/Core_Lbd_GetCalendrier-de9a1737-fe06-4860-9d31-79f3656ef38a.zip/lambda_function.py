# CRED : Marie DUMBO
# SEE : https://confluence.covea.priv/pages/viewpage.action?pageId=2325133805

import boto3
import json
from botocore.exceptions import ClientError
import logging
import os

# Config log
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Config dynamo
dynamodb = boto3.resource('dynamodb')
nom_table = os.environ.get('SEGMENT_TABLE_NAME')

def get_calendrier(segment, situation):

    logger.info(f'Interrogaiton de la Dynamo {nom_table} avec la clés {segment}')
    
    # Init resultat
    calendrier = None

    try:
        # Interrogation de la DynamoDB
        ddb_table = dynamodb.Table(nom_table)
        response = ddb_table.get_item(Key={'Segment': segment}, AttributesToGet=['Calendriers','Groupement'])

        if not response.get('Item') : 
            logger.error(f"Dans la Dynamo DB {nom_table}, aucune clés {segment} avec attributes 'Calendriers' ou 'Groupement'")
            raise Exception(f'NOT_FOUND : clès dynamo {segment} avec Calendriers et/ou Groupement')

        calendriers = response["Item"].get('Calendriers')

        if not calendriers :

            if not response["Item"].get('Groupement') :
                logger.error(f"Dans la Dynamo DB {nom_table}, aucun calendrier pour la clés {segment}")
                raise Exception(f'NOT_FOUND : calendrier pour {segment}')

            else :
                # Recherche du calendrier dans le Groupement de Segment                
                return get_calendrier(response["Item"]['Groupement'], situation)
        
        # Recherche calendrier de la situation active selon priorité
        while len(situation) != 0 and not calendrier :

            important_situation = get_important_situation(situation)

            if important_situation in calendriers :
                calendrier = calendriers[important_situation]

            # Suppression de la situation traitée
            del situation[important_situation]

        return calendrier 

    except ClientError as cli_err:
        logger.error(f"Erreur DynamoDB : {cli_err}")
        raise Exception('TECHNICAL_ERROR : Erreur Dynamo DB')

def get_important_situation(situation_prepond):

    # Init avec valeur par défaut
    important_situation = 'NORMALE'
    min_preponderance = situation_prepond.get(important_situation, 99)

    # Recherche situation avec plus petite preponderance (la plus prioritaire)
    for situation in situation_prepond :

        if situation_prepond[situation] < min_preponderance :

            min_preponderance = situation_prepond[situation]
            important_situation = situation

    return important_situation

def lambda_handler(event, context):
    
    try:
        # Extraction des paramètres d'entrée dans les contacts attributes
        uc_segment = event['Details']['ContactData']['Attributes'].get('UC_Segment')
        uc_situation = event['Details']['ContactData']['Attributes'].get('UC_Situation')
       
        # Validation des paramètres
        if not uc_segment :
            logger.error("Paramétre requis absent : UC_Segment")

            return {
                "error": "PARAMATER_REQUIERED : Paramétre UC_Segment"
            }
        
        if not uc_situation :
            logger.error("Paramétre requis absent : UC_Situation")

            return {
                "error": "PARAMATER_REQUIERED : Paramétre UC_Situation"
            }
        else : 
            uc_situation = json.loads(uc_situation.replace("'", '"'))

        logger.info(f"Paramétre entrée en contact attributs : UC_Segment = {uc_segment}, UC_Situation = {uc_situation}")

        # Interrogation de la DynamoDB pour avoir le calendrier de distribution
        calendrier = get_calendrier(uc_segment, uc_situation)

        if not calendrier :
            logger.error("Aucun calendrier trouvé pour les situations en entrée")
            return {
                "error": "NOT_FOUND : calendrier pour les situations"
            }
        
        else :
            logger.info(f"Succès recupération du calendrier. Résultat : {calendrier}")
            return {
                "calendrier": calendrier
            }

    except Exception as exc :
        return {
            "error": str(exc)
        }
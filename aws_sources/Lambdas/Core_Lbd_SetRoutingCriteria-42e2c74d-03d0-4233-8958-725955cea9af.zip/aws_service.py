import json
import boto3
import logging
from constants import JOURNEYS_TABLE_NAME
from typing import Union, Dict, Any, List

from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError


def updateContactRoutingData(instance_id: str, connect: boto3.client, contact_id: str, queuePriority: int, routingCriteria: Dict[str, Any], logger: logging.Logger) -> Dict[str, Any]:
    try:
        response = connect.update_contact_routing_data(
            InstanceId=instance_id,
            ContactId=contact_id,        
            QueuePriority=queuePriority,
            RoutingCriteria=routingCriteria
        )
        return response
    except ClientError as e:
        logger.error(f"[{contact_id}] Failed to update routing data: {e}")
        raise

def updateContactAttributes(instance_id: str, connect: boto3.client, contact_id: str, routingCriteria: Dict[str, Any], logger: logging.Logger) -> Dict[str, Any]:
    try:
        response = connect.update_contact_attributes(
                        InitialContactId=contact_id,
                        InstanceId=instance_id,
                        Attributes={
                            "routingCustomCriteria": routingCriteria                                                   
                        }
        )
        return response
    except ClientError as e:
        logger.error(f"[{contact_id}] Failed to update routing data: {e}")
        raise

def getItemsFromDynamoDB(dynamodb: boto3.resource, journeyName: str, logger: logging.Logger = None, contact_id: str = None) -> Dict[str, Any]:
    try:
        table = dynamodb.Table(JOURNEYS_TABLE_NAME)
        
        response = table.query(
            KeyConditionExpression=Key('Parcours').eq(journeyName)
        )
        
        items = response['Items'][0]
        return items

    except ClientError as e:
        if logger and contact_id:
            logger.error(f"[{contact_id}] DynamoDB error: {e}")
        raise

def getUserIdFromUsername(contact_id: str, instance_id: str, connect: boto3.client, username: str, logger: logging.Logger) -> str:
    """
    Récupère l'User ID (UUID) à partir du username (login).
    
    Returns:
        User ID (UUID) ou None si non trouvé
    """
    try:
        response = connect.search_users(
            InstanceId=instance_id,
            SearchCriteria={
                'StringCondition': {
                    'FieldName': 'Username',
                    'Value': username,
                    'ComparisonType': 'EXACT'
                }
            },
            MaxResults=1
        )
        
        users = response.get('Users', [])
        if users:
            user_id = users[0].get('Id')
            return user_id
        else:
            logger.warning(f"[{contact_id}] Username {username} not found")
            return None
            
    except ClientError as e:
        logger.error(f"[{contact_id}] search_users error for {username}: {e}")
        return None

def getAgentAvailability(contact_id: str, instance_id: str, connect: boto3.client, agent_usernames: List[str], logger: logging.Logger) -> Dict[str, bool]:
    """
    Vérifie la disponibilité des agents spécifiques via GetCurrentUserData API.
    
    Args:
        agent_usernames: Liste des usernames (logins) des agents
    
    Returns:
        Dict avec username comme clé et True/False selon disponibilité
    """
    try:
        agent_availability = {}
        
        # Convertir les usernames en User IDs
        agent_ids = []
        username_to_id = {}
        for username in agent_usernames:
            user_id = getUserIdFromUsername(contact_id, instance_id, connect, username, logger)
            if user_id:
                agent_ids.append(user_id)
                username_to_id[user_id] = username
            else:
                # Si on ne trouve pas l'user ID, considérer l'agent comme non disponible
                agent_availability[username] = False
        
        if not agent_ids:
            logger.warning(f"[{contact_id}] Aucun User ID trouvé pour les usernames: {agent_usernames}")
            return agent_availability
        
        # Appel à GetCurrentUserData pour obtenir le statut des agents
        response = connect.get_current_user_data(
            InstanceId=instance_id,
            Filters={
                'Agents': agent_ids
            },
            MaxResults=100
        )
        
        user_data_list = response.get('UserDataList', [])
        
        for user_data in user_data_list:
            user_id = user_data.get('User', {}).get('Id')
            username = username_to_id.get(user_id, user_id)
            status = user_data.get('Status', {})
            status_name = status.get('StatusName', '')
            
            # Un agent est considéré disponible s'il a le statut "Available"
            # Même s'il est en communication, il pourrait se libérer pendant le délai d'expiration
            is_available = (status_name == 'Available')
            
            available_slots = user_data.get('AvailableSlotsByChannel', {})
            agent_availability[username] = is_available
        
        # Pour les agents non retournés par l'API, on considère qu'ils ne sont pas disponibles
        for username in agent_usernames:
            if username not in agent_availability:
                agent_availability[username] = False
        
        return agent_availability
        
    except ClientError as e:
        logger.error(f"[{contact_id}] get_current_user_data error: {e}")
        # En cas d'erreur, on retourne tous les agents comme non disponibles
        return {username: False for username in agent_usernames}

def convertAgentUsernamesToIds(contact_id: str, instance_id: str, connect: boto3.client, routing_criteria: Dict[str, Any], logger: logging.Logger) -> Dict[str, Any]:
    """
    Convertit les usernames des agents en User IDs dans les routing criteria.
    
    Returns:
        routing_criteria avec les User IDs au lieu des usernames
    """
    steps_converted = 0
    for idx, step in enumerate(routing_criteria.get('Steps', []), start=1):
        expr = step.get('Expression', {})
        
        attr_condition = expr.get('AttributeCondition', {})
        if not attr_condition:
            continue
            
        match_criteria = attr_condition.get('MatchCriteria', {})
        if not match_criteria:
            continue
            
        agents_criteria = match_criteria.get('AgentsCriteria', {})
        if not agents_criteria:
            continue
        
        if 'AgentIds' in agents_criteria:
            usernames = agents_criteria['AgentIds']
            user_ids = []
            
            for username in usernames:
                user_id = getUserIdFromUsername(contact_id, instance_id, connect, username, logger)
                if user_id:
                    user_ids.append(user_id)
                else:
                    logger.warning(f"[{contact_id}] Cannot convert username {username} to User ID, skipping")
            
            # Remplacer les usernames par les User IDs
            agents_criteria['AgentIds'] = user_ids
            steps_converted += 1
    
    return routing_criteria

def getGetCurrentMetricDataAgentsOnline(contact_id: str, instance_id: str, connect: boto3.client, queue_id: str, routing_criteria: Dict[str, Any], logger: logging.Logger) -> Dict[str, Union[int, float]]:
    try:
        agents_online = {}
        routing_step_expression = []
        agent_steps = {}  # Pour tracker les steps avec AgentsCriteria
        total_steps = len(routing_criteria.get('Steps', []))

        for idx, rc in enumerate(routing_criteria['Steps'], start=1):                        
            expr = rc['Expression']
            
            # Vérifier si c'est une step avec AgentsCriteria
            attr_condition = expr.get('AttributeCondition', {})
            match_criteria = attr_condition.get('MatchCriteria', {})
            agents_criteria = match_criteria.get('AgentsCriteria', {})
            
            if agents_criteria and 'AgentIds' in agents_criteria:
                # Stocker les agent usernames pour vérification ultérieure
                agent_usernames = agents_criteria['AgentIds']
                agent_steps[idx] = agent_usernames
                continue
            
            # Ignorer les steps SDA (pas de critères de routage agent)
            if rc.get('SDA'):
                continue
            
            expr_str = json.dumps(expr)
            expr_str = (expr_str
                        .replace("OrExpression", "orExpression")
                        .replace("AndExpression", "andExpression")
                        .replace("AttributeCondition", "attributeCondition")
                        .replace("ComparisonOperator", "comparisonOperator")
                        .replace("Name", "name")
                        .replace("ProficiencyLevel", "proficiencyLevel")
                        .replace("Value", "value"))
            routing_step_expression.append(json.loads(expr_str))
        
        index_routing_step_expression = list(routing_step_expression)
        
        # Vérifier la disponibilité des agents spécifiques
        if agent_steps:
            all_agent_usernames = []
            for agent_usernames in agent_steps.values():
                all_agent_usernames.extend(agent_usernames)
            
            if all_agent_usernames:
                agent_availability = getAgentAvailability(contact_id, instance_id, connect, all_agent_usernames, logger)
                
                # Pour chaque step avec agents, compter combien sont disponibles
                for step_num, agent_usernames in agent_steps.items():
                    available_count = sum(1 for username in agent_usernames if agent_availability.get(username, False))
                    agents_online[f"Step{step_num}"] = available_count
        
        if len(routing_step_expression) > 0:
            resp_current = connect.get_current_metric_data(
                InstanceId=instance_id,
                Filters={
                    "Queues": [queue_id],
                    "Channels": ["VOICE"],
                    "RoutingStepExpressions": [json.dumps(e) for e in routing_step_expression],
                },
                Groupings=["ROUTING_STEP_EXPRESSION"],
                CurrentMetrics=[                        
                    {"Name": "AGENTS_STAFFED", "Unit": "COUNT"}
                ],
                MaxResults=1,
            )        
            metric_results = resp_current.get('MetricResults', [])
            if metric_results:
                for result in metric_results:
                    dim_expr_raw = result.get('Dimensions', {}).get('RoutingStepExpression')
                    normalized_result_expr = json.dumps(json.loads(dim_expr_raw))

                    for metric in result.get('Collections', []):
                        name = metric.get('Metric', {}).get('Name')
                        value = metric.get('Value')
                        if value is None:
                            continue

                        for idx, key in enumerate(index_routing_step_expression, start=1):
                            normalized_key = json.dumps(key)
                            if json.loads(normalized_result_expr) == json.loads(normalized_key):
                                if name == 'AGENTS_STAFFED':
                                    agents_online[f"Step{idx}"] = value
                                break
        
        # Build statistics result per step
        statistics_result = {}
        for idx in range(1, total_steps + 1):
            step_key = f"Step{idx}"
            statistics_result[f"step{idx}_AgentsOnline"] = agents_online.get(step_key, 0)
        
        logger.info(f"[{contact_id}] statistics_result : {json.dumps(statistics_result)}")
        return statistics_result        
    except ClientError as e:
        logger.error(f"[{contact_id}] get_current_metric_data error: {e}")
        raise

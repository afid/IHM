"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
/**
 * **Feature: decision-engine, Property 5: Cache refresh consistency**
 * **Validates: Requirements 2.5, 4.3**
 *
 * Property: For any rule update operation, the in-memory cache should reflect
 * the updated rules in subsequent decision processes
 */
// Mock DynamoDB for property testing
const mockSend = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => ({
    DynamoDBClient: jest.fn().mockImplementation(() => ({}))
}));
jest.mock('@aws-sdk/lib-dynamodb', () => ({
    DynamoDBDocumentClient: {
        from: jest.fn().mockReturnValue({ send: mockSend })
    },
    ScanCommand: jest.fn().mockImplementation((params) => params)
}));
describe('Property Test: Cache Refresh Consistency', () => {
    beforeEach(() => {
        // Reset mocks before each test
        jest.clearAllMocks();
        mockSend.mockReset();
    });
    /**
     * Property: Cache refresh consistency
     * For any rule update operation, calling refreshCache() should ensure that
     * subsequent loadAllRules() calls reflect the updated state from the database
     */
    test('should refresh cache consistently after rule updates', async () => {
        // Manual property testing: Generate multiple test scenarios
        const generateRule = (id, weight, segment) => ({
            id,
            name: `Test Rule ${id}`,
            expression: `Criterion${id} == true`,
            weight,
            distributionSegment: segment,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
        // Test scenarios representing different cache refresh situations
        const testScenarios = [
            // Scenario 1: Empty cache to populated cache
            {
                initialRules: [],
                updatedRules: [generateRule('1', 10, 'segment-1')]
            },
            // Scenario 2: Single rule to multiple rules
            {
                initialRules: [generateRule('1', 10, 'segment-1')],
                updatedRules: [
                    generateRule('1', 10, 'segment-1'),
                    generateRule('2', 20, 'segment-2'),
                    generateRule('3', 15, 'segment-3')
                ]
            },
            // Scenario 3: Rule weight changes
            {
                initialRules: [generateRule('1', 10, 'segment-1'), generateRule('2', 20, 'segment-2')],
                updatedRules: [generateRule('1', 25, 'segment-1'), generateRule('2', 5, 'segment-2')]
            },
            // Scenario 4: Rule removal
            {
                initialRules: [
                    generateRule('1', 10, 'segment-1'),
                    generateRule('2', 20, 'segment-2'),
                    generateRule('3', 15, 'segment-3')
                ],
                updatedRules: [generateRule('2', 20, 'segment-2')]
            },
            // Scenario 5: Complete rule replacement
            {
                initialRules: [generateRule('old1', 10, 'old-segment')],
                updatedRules: [generateRule('new1', 30, 'new-segment')]
            },
            // Scenario 6: Large rule set changes
            {
                initialRules: Array.from({ length: 5 }, (_, i) => generateRule(`old-${i}`, i * 10, `old-segment-${i}`)),
                updatedRules: Array.from({ length: 8 }, (_, i) => generateRule(`new-${i}`, i * 5 + 10, `new-segment-${i}`))
            }
        ];
        // Run property test for each scenario (100 iterations as specified)
        for (let iteration = 0; iteration < 100; iteration++) {
            const scenarioIndex = iteration % testScenarios.length;
            const scenario = testScenarios[scenarioIndex];
            // Setup mock for initial cache population
            mockSend.mockResolvedValueOnce({
                Items: scenario.initialRules
            });
            // Setup mock for cache refresh (updated rules)
            mockSend.mockResolvedValueOnce({
                Items: scenario.updatedRules
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Step 1: Load initial rules (populate cache)
            const initialLoadedRules = await repository.loadAllRules();
            // Property 1: Initial load should match initial rules (sorted by weight)
            const expectedInitialRules = [...scenario.initialRules].sort((a, b) => b.weight - a.weight);
            expect(initialLoadedRules).toEqual(expectedInitialRules);
            // Step 2: Refresh cache (simulating rule updates in database)
            await repository.refreshCache();
            // Step 3: Load rules after refresh
            const refreshedLoadedRules = await repository.loadAllRules();
            // Property 2: Refreshed rules should match updated rules (sorted by weight)
            const expectedUpdatedRules = [...scenario.updatedRules].sort((a, b) => b.weight - a.weight);
            expect(refreshedLoadedRules).toEqual(expectedUpdatedRules);
            // Property 3: Cache should reflect the updated state, not the initial state
            if (scenario.initialRules.length !== scenario.updatedRules.length) {
                expect(refreshedLoadedRules.length).not.toBe(initialLoadedRules.length);
            }
            // Property 4: Database should be called twice (initial load + refresh)
            expect(mockSend).toHaveBeenCalledTimes(2);
            // Property 5: Both calls should use correct table name and filter
            expect(mockSend).toHaveBeenNthCalledWith(1, expect.objectContaining({
                TableName: 'test-table',
                FilterExpression: 'attribute_not_exists(active) OR active = :active',
                ExpressionAttributeValues: { ':active': 'true' }
            }));
            expect(mockSend).toHaveBeenNthCalledWith(2, expect.objectContaining({
                TableName: 'test-table',
                FilterExpression: 'attribute_not_exists(active) OR active = :active',
                ExpressionAttributeValues: { ':active': 'true' }
            }));
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Cache invalidation completeness
     * After refreshCache(), the cache should be completely invalidated and
     * the next loadAllRules() should always fetch from database
     */
    test('should completely invalidate cache on refresh', async () => {
        const initialRules = [
            {
                id: 'rule1',
                name: 'Initial Rule',
                expression: 'Initial == true',
                weight: 10,
                distributionSegment: 'initial-segment',
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            }
        ];
        // Test cache invalidation completeness (50 iterations)
        for (let iteration = 0; iteration < 50; iteration++) {
            // Mock initial load
            mockSend.mockResolvedValueOnce({
                Items: initialRules
            });
            // Mock load after refresh (could be same or different rules)
            mockSend.mockResolvedValueOnce({
                Items: initialRules
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Load rules to populate cache
            await repository.loadAllRules();
            // Verify cache is populated (second call should not hit database)
            await repository.loadAllRules();
            expect(mockSend).toHaveBeenCalledTimes(1); // Only one DB call so far
            // Refresh cache (should invalidate)
            await repository.refreshCache();
            // Property: After refresh, cache should be invalidated
            const cacheStats = repository.getCacheStats();
            expect(cacheStats.isCached).toBe(true); // refreshCache() loads new data
            expect(cacheStats.lastRefresh).not.toBeNull();
            // Property: Database should have been called twice (initial + refresh)
            expect(mockSend).toHaveBeenCalledTimes(2);
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Cache refresh error handling
     * When refreshCache() encounters database errors, it should handle them gracefully
     * and maintain system stability
     */
    test('should handle refresh errors gracefully', async () => {
        const initialRules = [
            {
                id: 'rule1',
                name: 'Initial Rule',
                expression: 'Initial == true',
                weight: 10,
                distributionSegment: 'initial-segment',
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            }
        ];
        // Different error types to test
        const errorTypes = [
            new Error('Network timeout during refresh'),
            new Error('Access denied on refresh'),
            new Error('Table not found during refresh'),
            new Error('ThrottlingException during refresh'),
            new Error('ServiceUnavailableException during refresh')
        ];
        // Test error handling (25 iterations)
        for (let iteration = 0; iteration < 25; iteration++) {
            const errorIndex = iteration % errorTypes.length;
            const error = errorTypes[errorIndex];
            // Mock successful initial load
            mockSend.mockResolvedValueOnce({
                Items: initialRules
            });
            // Mock error on refresh
            mockSend.mockRejectedValueOnce(error);
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Load initial rules successfully
            const initialLoadedRules = await repository.loadAllRules();
            expect(initialLoadedRules).toHaveLength(1);
            // Property: refreshCache() should throw meaningful error when database fails
            await expect(repository.refreshCache()).rejects.toThrow(expect.stringContaining('Failed to load qualification rules'));
            // Property: System should remain stable after refresh error
            // (Cache should be cleared but system should not crash)
            const cacheStats = repository.getCacheStats();
            expect(cacheStats.isCached).toBe(false); // Cache should be cleared on error
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Cache refresh timing consistency
     * Multiple rapid calls to refreshCache() should be handled consistently
     * without race conditions or inconsistent state
     */
    test('should handle rapid refresh calls consistently', async () => {
        const testRules = [
            {
                id: 'rule1',
                name: 'Test Rule',
                expression: 'Test == true',
                weight: 15,
                distributionSegment: 'test-segment',
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            }
        ];
        // Test rapid refresh calls (20 iterations)
        for (let iteration = 0; iteration < 20; iteration++) {
            // Mock multiple successful responses for rapid calls
            for (let i = 0; i < 5; i++) {
                mockSend.mockResolvedValueOnce({
                    Items: testRules
                });
            }
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Property: Multiple rapid refresh calls should all succeed
            const refreshPromises = [
                repository.refreshCache(),
                repository.refreshCache(),
                repository.refreshCache()
            ];
            // All refreshes should complete without error
            await expect(Promise.all(refreshPromises)).resolves.not.toThrow();
            // Property: Final state should be consistent
            const finalRules = await repository.loadAllRules();
            expect(finalRules).toEqual(testRules);
            // Property: Cache should be in valid state
            const cacheStats = repository.getCacheStats();
            expect(cacheStats.isCached).toBe(true);
            expect(cacheStats.lastRefresh).not.toBeNull();
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Cache refresh preserves rule ordering
     * After refreshCache(), rules should maintain proper weight-based ordering
     */
    test('should preserve rule ordering after refresh', async () => {
        // Generate test cases with various rule orderings
        const generateUnorderedRules = (count) => {
            const rules = [];
            for (let i = 0; i < count; i++) {
                rules.push({
                    id: `rule-${i}`,
                    name: `Rule ${i}`,
                    expression: `Criterion${i} == true`,
                    weight: Math.floor(Math.random() * 100) + 1, // Random weight 1-100
                    distributionSegment: `segment-${i}`,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                });
            }
            return rules;
        };
        // Test ordering preservation (50 iterations)
        for (let iteration = 0; iteration < 50; iteration++) {
            const ruleCount = Math.floor(Math.random() * 8) + 2; // 2-9 rules
            const unorderedRules = generateUnorderedRules(ruleCount);
            // Mock database returning unordered rules
            mockSend.mockResolvedValueOnce({
                Items: unorderedRules
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Refresh cache with unordered rules
            await repository.refreshCache();
            // Load rules after refresh
            const orderedRules = await repository.loadAllRules();
            // Property: Rules should be ordered by weight descending
            for (let i = 0; i < orderedRules.length - 1; i++) {
                expect(orderedRules[i].weight).toBeGreaterThanOrEqual(orderedRules[i + 1].weight);
            }
            // Property: All original rules should be present
            expect(orderedRules).toHaveLength(unorderedRules.length);
            // Property: Rule content should be preserved (only order changed)
            const originalIds = unorderedRules.map(r => r.id).sort();
            const orderedIds = orderedRules.map(r => r.id).sort();
            expect(orderedIds).toEqual(originalIds);
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUtcmVmcmVzaC5wcm9wZXJ0eS50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3Rlc3RzL2RlY2lzaW9uLWVuZ2luZS9jYWNoZS1yZWZyZXNoLnByb3BlcnR5LnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxrRkFBK0U7QUFHL0U7Ozs7OztHQU1HO0FBRUgscUNBQXFDO0FBQ3JDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLDBCQUEwQixFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDM0MsY0FBYyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3pELENBQUMsQ0FBQyxDQUFDO0FBQ0osSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLHNCQUFzQixFQUFFO1FBQ3RCLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsZUFBZSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsV0FBVyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDO0NBQzlELENBQUMsQ0FBQyxDQUFDO0FBRUosUUFBUSxDQUFDLDBDQUEwQyxFQUFFLEdBQUcsRUFBRTtJQUN4RCxVQUFVLENBQUMsR0FBRyxFQUFFO1FBQ2QsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDdkIsQ0FBQyxDQUFDLENBQUM7SUFFSDs7OztPQUlHO0lBQ0gsSUFBSSxDQUFDLHNEQUFzRCxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQ3RFLDREQUE0RDtRQUM1RCxNQUFNLFlBQVksR0FBRyxDQUFDLEVBQVUsRUFBRSxNQUFjLEVBQUUsT0FBZSxFQUFxQixFQUFFLENBQUMsQ0FBQztZQUN4RixFQUFFO1lBQ0YsSUFBSSxFQUFFLGFBQWEsRUFBRSxFQUFFO1lBQ3ZCLFVBQVUsRUFBRSxZQUFZLEVBQUUsVUFBVTtZQUNwQyxNQUFNO1lBQ04sbUJBQW1CLEVBQUUsT0FBTztZQUM1QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1NBQ3BDLENBQUMsQ0FBQztRQUVILGlFQUFpRTtRQUNqRSxNQUFNLGFBQWEsR0FBRztZQUNwQiw2Q0FBNkM7WUFDN0M7Z0JBQ0UsWUFBWSxFQUFFLEVBQUU7Z0JBQ2hCLFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2FBQ25EO1lBQ0QsNENBQTRDO1lBQzVDO2dCQUNFLFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUNsRCxZQUFZLEVBQUU7b0JBQ1osWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxDQUFDO29CQUNsQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUM7b0JBQ2xDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQztpQkFDbkM7YUFDRjtZQUNELGtDQUFrQztZQUNsQztnQkFDRSxZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDdEYsWUFBWSxFQUFFLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7YUFDdEY7WUFDRCwyQkFBMkI7WUFDM0I7Z0JBQ0UsWUFBWSxFQUFFO29CQUNaLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQztvQkFDbEMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxDQUFDO29CQUNsQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUM7aUJBQ25DO2dCQUNELFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2FBQ25EO1lBQ0Qsd0NBQXdDO1lBQ3hDO2dCQUNFLFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2dCQUN2RCxZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQzthQUN4RDtZQUNELHFDQUFxQztZQUNyQztnQkFDRSxZQUFZLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN2RyxZQUFZLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUM1RztTQUNGLENBQUM7UUFFRixvRUFBb0U7UUFDcEUsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUcsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3JELE1BQU0sYUFBYSxHQUFHLFNBQVMsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3ZELE1BQU0sUUFBUSxHQUFHLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUU5QywwQ0FBMEM7WUFDMUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3QixLQUFLLEVBQUUsUUFBUSxDQUFDLFlBQVk7YUFDN0IsQ0FBQyxDQUFDO1lBRUgsK0NBQStDO1lBQy9DLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxZQUFZO2FBQzdCLENBQUMsQ0FBQztZQUVILE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVwRCw4Q0FBOEM7WUFDOUMsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUUzRCx5RUFBeUU7WUFDekUsTUFBTSxvQkFBb0IsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVGLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBRXpELDhEQUE4RDtZQUM5RCxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVoQyxtQ0FBbUM7WUFDbkMsTUFBTSxvQkFBb0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUU3RCw0RUFBNEU7WUFDNUUsTUFBTSxvQkFBb0IsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVGLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBRTNELDRFQUE0RTtZQUM1RSxJQUFJLFFBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxLQUFLLFFBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2xFLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzFFLENBQUM7WUFFRCx1RUFBdUU7WUFDdkUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTFDLGtFQUFrRTtZQUNsRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDbEUsU0FBUyxFQUFFLFlBQVk7Z0JBQ3ZCLGdCQUFnQixFQUFFLGtEQUFrRDtnQkFDcEUseUJBQXlCLEVBQUUsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFO2FBQ2pELENBQUMsQ0FBQyxDQUFDO1lBQ0osTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ2xFLFNBQVMsRUFBRSxZQUFZO2dCQUN2QixnQkFBZ0IsRUFBRSxrREFBa0Q7Z0JBQ3BFLHlCQUF5QixFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRTthQUNqRCxDQUFDLENBQUMsQ0FBQztZQUVKLGdDQUFnQztZQUNoQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQywrQ0FBK0MsRUFBRSxLQUFLLElBQUksRUFBRTtRQUMvRCxNQUFNLFlBQVksR0FBRztZQUNuQjtnQkFDRSxFQUFFLEVBQUUsT0FBTztnQkFDWCxJQUFJLEVBQUUsY0FBYztnQkFDcEIsVUFBVSxFQUFFLGlCQUFpQjtnQkFDN0IsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsbUJBQW1CLEVBQUUsaUJBQWlCO2dCQUN0QyxTQUFTLEVBQUUsMEJBQTBCO2dCQUNyQyxTQUFTLEVBQUUsMEJBQTBCO2FBQ3RDO1NBQ0YsQ0FBQztRQUVGLHVEQUF1RDtRQUN2RCxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDcEQsb0JBQW9CO1lBQ3BCLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0IsS0FBSyxFQUFFLFlBQVk7YUFDcEIsQ0FBQyxDQUFDO1lBRUgsNkRBQTZEO1lBQzdELFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0IsS0FBSyxFQUFFLFlBQVk7YUFDcEIsQ0FBQyxDQUFDO1lBRUgsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRXBELCtCQUErQjtZQUMvQixNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVoQyxrRUFBa0U7WUFDbEUsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDaEMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsMEJBQTBCO1lBRXJFLG9DQUFvQztZQUNwQyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVoQyx1REFBdUQ7WUFDdkQsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzlDLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZ0NBQWdDO1lBQ3hFLE1BQU0sQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBRTlDLHVFQUF1RTtZQUN2RSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFMUMsZ0NBQWdDO1lBQ2hDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSDs7OztPQUlHO0lBQ0gsSUFBSSxDQUFDLHlDQUF5QyxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQ3pELE1BQU0sWUFBWSxHQUFHO1lBQ25CO2dCQUNFLEVBQUUsRUFBRSxPQUFPO2dCQUNYLElBQUksRUFBRSxjQUFjO2dCQUNwQixVQUFVLEVBQUUsaUJBQWlCO2dCQUM3QixNQUFNLEVBQUUsRUFBRTtnQkFDVixtQkFBbUIsRUFBRSxpQkFBaUI7Z0JBQ3RDLFNBQVMsRUFBRSwwQkFBMEI7Z0JBQ3JDLFNBQVMsRUFBRSwwQkFBMEI7YUFDdEM7U0FDRixDQUFDO1FBRUYsZ0NBQWdDO1FBQ2hDLE1BQU0sVUFBVSxHQUFHO1lBQ2pCLElBQUksS0FBSyxDQUFDLGdDQUFnQyxDQUFDO1lBQzNDLElBQUksS0FBSyxDQUFDLDBCQUEwQixDQUFDO1lBQ3JDLElBQUksS0FBSyxDQUFDLGdDQUFnQyxDQUFDO1lBQzNDLElBQUksS0FBSyxDQUFDLG9DQUFvQyxDQUFDO1lBQy9DLElBQUksS0FBSyxDQUFDLDRDQUE0QyxDQUFDO1NBQ3hELENBQUM7UUFFRixzQ0FBc0M7UUFDdEMsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3BELE1BQU0sVUFBVSxHQUFHLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQ2pELE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUVyQywrQkFBK0I7WUFDL0IsUUFBUSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3QixLQUFLLEVBQUUsWUFBWTthQUNwQixDQUFDLENBQUM7WUFFSCx3QkFBd0I7WUFDeEIsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXRDLE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVwRCxrQ0FBa0M7WUFDbEMsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUMzRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFM0MsNkVBQTZFO1lBQzdFLE1BQU0sTUFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQ3JELE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUM5RCxDQUFDO1lBRUYsNERBQTREO1lBQzVELHdEQUF3RDtZQUN4RCxNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDOUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxtQ0FBbUM7WUFFNUUsZ0NBQWdDO1lBQ2hDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSDs7OztPQUlHO0lBQ0gsSUFBSSxDQUFDLGdEQUFnRCxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQ2hFLE1BQU0sU0FBUyxHQUFHO1lBQ2hCO2dCQUNFLEVBQUUsRUFBRSxPQUFPO2dCQUNYLElBQUksRUFBRSxXQUFXO2dCQUNqQixVQUFVLEVBQUUsY0FBYztnQkFDMUIsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsbUJBQW1CLEVBQUUsY0FBYztnQkFDbkMsU0FBUyxFQUFFLDBCQUEwQjtnQkFDckMsU0FBUyxFQUFFLDBCQUEwQjthQUN0QztTQUNGLENBQUM7UUFFRiwyQ0FBMkM7UUFDM0MsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3BELHFEQUFxRDtZQUNyRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQzNCLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztvQkFDN0IsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCLENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCxNQUFNLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFcEQsNERBQTREO1lBQzVELE1BQU0sZUFBZSxHQUFHO2dCQUN0QixVQUFVLENBQUMsWUFBWSxFQUFFO2dCQUN6QixVQUFVLENBQUMsWUFBWSxFQUFFO2dCQUN6QixVQUFVLENBQUMsWUFBWSxFQUFFO2FBQzFCLENBQUM7WUFFRiw4Q0FBOEM7WUFDOUMsTUFBTSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7WUFFbEUsNkNBQTZDO1lBQzdDLE1BQU0sVUFBVSxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFdEMsMkNBQTJDO1lBQzNDLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5QyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN2QyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUU5QyxnQ0FBZ0M7WUFDaEMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVIOzs7T0FHRztJQUNILElBQUksQ0FBQyw2Q0FBNkMsRUFBRSxLQUFLLElBQUksRUFBRTtRQUM3RCxrREFBa0Q7UUFDbEQsTUFBTSxzQkFBc0IsR0FBRyxDQUFDLEtBQWEsRUFBdUIsRUFBRTtZQUNwRSxNQUFNLEtBQUssR0FBd0IsRUFBRSxDQUFDO1lBQ3RDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDL0IsS0FBSyxDQUFDLElBQUksQ0FBQztvQkFDVCxFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUU7b0JBQ2YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFFO29CQUNqQixVQUFVLEVBQUUsWUFBWSxDQUFDLFVBQVU7b0JBQ25DLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsc0JBQXNCO29CQUNuRSxtQkFBbUIsRUFBRSxXQUFXLENBQUMsRUFBRTtvQkFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7aUJBQ3BDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFDRCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUMsQ0FBQztRQUVGLDZDQUE2QztRQUM3QyxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDcEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWTtZQUNqRSxNQUFNLGNBQWMsR0FBRyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUV6RCwwQ0FBMEM7WUFDMUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3QixLQUFLLEVBQUUsY0FBYzthQUN0QixDQUFDLENBQUM7WUFFSCxNQUFNLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFcEQscUNBQXFDO1lBQ3JDLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRWhDLDJCQUEyQjtZQUMzQixNQUFNLFlBQVksR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVyRCx5REFBeUQ7WUFDekQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ2pELE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsc0JBQXNCLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwRixDQUFDO1lBRUQsaURBQWlEO1lBQ2pELE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXpELGtFQUFrRTtZQUNsRSxNQUFNLFdBQVcsR0FBRyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3pELE1BQU0sVUFBVSxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDdEQsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUV4QyxnQ0FBZ0M7WUFDaEMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUnVsZVJlcG9zaXRvcnkgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZVJlcG9zaXRvcnknO1xyXG5pbXBvcnQgeyBRdWFsaWZpY2F0aW9uUnVsZSB9IGZyb20gJy4uLy4uL3R5cGVzL2RlY2lzaW9uLWVuZ2luZSc7XHJcblxyXG4vKipcclxuICogKipGZWF0dXJlOiBkZWNpc2lvbi1lbmdpbmUsIFByb3BlcnR5IDU6IENhY2hlIHJlZnJlc2ggY29uc2lzdGVuY3kqKlxyXG4gKiAqKlZhbGlkYXRlczogUmVxdWlyZW1lbnRzIDIuNSwgNC4zKipcclxuICogXHJcbiAqIFByb3BlcnR5OiBGb3IgYW55IHJ1bGUgdXBkYXRlIG9wZXJhdGlvbiwgdGhlIGluLW1lbW9yeSBjYWNoZSBzaG91bGQgcmVmbGVjdCBcclxuICogdGhlIHVwZGF0ZWQgcnVsZXMgaW4gc3Vic2VxdWVudCBkZWNpc2lvbiBwcm9jZXNzZXNcclxuICovXHJcblxyXG4vLyBNb2NrIER5bmFtb0RCIGZvciBwcm9wZXJ0eSB0ZXN0aW5nXHJcbmNvbnN0IG1vY2tTZW5kID0gamVzdC5mbigpO1xyXG5qZXN0Lm1vY2soJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYicsICgpID0+ICh7XHJcbiAgRHluYW1vREJDbGllbnQ6IGplc3QuZm4oKS5tb2NrSW1wbGVtZW50YXRpb24oKCkgPT4gKHt9KSlcclxufSkpO1xyXG5qZXN0Lm1vY2soJ0Bhd3Mtc2RrL2xpYi1keW5hbW9kYicsICgpID0+ICh7XHJcbiAgRHluYW1vREJEb2N1bWVudENsaWVudDoge1xyXG4gICAgZnJvbTogamVzdC5mbigpLm1vY2tSZXR1cm5WYWx1ZSh7IHNlbmQ6IG1vY2tTZW5kIH0pXHJcbiAgfSxcclxuICBTY2FuQ29tbWFuZDogamVzdC5mbigpLm1vY2tJbXBsZW1lbnRhdGlvbigocGFyYW1zKSA9PiBwYXJhbXMpXHJcbn0pKTtcclxuXHJcbmRlc2NyaWJlKCdQcm9wZXJ0eSBUZXN0OiBDYWNoZSBSZWZyZXNoIENvbnNpc3RlbmN5JywgKCkgPT4ge1xyXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgLy8gUmVzZXQgbW9ja3MgYmVmb3JlIGVhY2ggdGVzdFxyXG4gICAgamVzdC5jbGVhckFsbE1vY2tzKCk7XHJcbiAgICBtb2NrU2VuZC5tb2NrUmVzZXQoKTtcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IENhY2hlIHJlZnJlc2ggY29uc2lzdGVuY3lcclxuICAgKiBGb3IgYW55IHJ1bGUgdXBkYXRlIG9wZXJhdGlvbiwgY2FsbGluZyByZWZyZXNoQ2FjaGUoKSBzaG91bGQgZW5zdXJlIHRoYXQgXHJcbiAgICogc3Vic2VxdWVudCBsb2FkQWxsUnVsZXMoKSBjYWxscyByZWZsZWN0IHRoZSB1cGRhdGVkIHN0YXRlIGZyb20gdGhlIGRhdGFiYXNlXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIHJlZnJlc2ggY2FjaGUgY29uc2lzdGVudGx5IGFmdGVyIHJ1bGUgdXBkYXRlcycsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIE1hbnVhbCBwcm9wZXJ0eSB0ZXN0aW5nOiBHZW5lcmF0ZSBtdWx0aXBsZSB0ZXN0IHNjZW5hcmlvc1xyXG4gICAgY29uc3QgZ2VuZXJhdGVSdWxlID0gKGlkOiBzdHJpbmcsIHdlaWdodDogbnVtYmVyLCBzZWdtZW50OiBzdHJpbmcpOiBRdWFsaWZpY2F0aW9uUnVsZSA9PiAoe1xyXG4gICAgICBpZCxcclxuICAgICAgbmFtZTogYFRlc3QgUnVsZSAke2lkfWAsXHJcbiAgICAgIGV4cHJlc3Npb246IGBDcml0ZXJpb24ke2lkfSA9PSB0cnVlYCxcclxuICAgICAgd2VpZ2h0LFxyXG4gICAgICBkaXN0cmlidXRpb25TZWdtZW50OiBzZWdtZW50LFxyXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgdXBkYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIFRlc3Qgc2NlbmFyaW9zIHJlcHJlc2VudGluZyBkaWZmZXJlbnQgY2FjaGUgcmVmcmVzaCBzaXR1YXRpb25zXHJcbiAgICBjb25zdCB0ZXN0U2NlbmFyaW9zID0gW1xyXG4gICAgICAvLyBTY2VuYXJpbyAxOiBFbXB0eSBjYWNoZSB0byBwb3B1bGF0ZWQgY2FjaGVcclxuICAgICAge1xyXG4gICAgICAgIGluaXRpYWxSdWxlczogW10sXHJcbiAgICAgICAgdXBkYXRlZFJ1bGVzOiBbZ2VuZXJhdGVSdWxlKCcxJywgMTAsICdzZWdtZW50LTEnKV1cclxuICAgICAgfSxcclxuICAgICAgLy8gU2NlbmFyaW8gMjogU2luZ2xlIHJ1bGUgdG8gbXVsdGlwbGUgcnVsZXNcclxuICAgICAge1xyXG4gICAgICAgIGluaXRpYWxSdWxlczogW2dlbmVyYXRlUnVsZSgnMScsIDEwLCAnc2VnbWVudC0xJyldLFxyXG4gICAgICAgIHVwZGF0ZWRSdWxlczogW1xyXG4gICAgICAgICAgZ2VuZXJhdGVSdWxlKCcxJywgMTAsICdzZWdtZW50LTEnKSxcclxuICAgICAgICAgIGdlbmVyYXRlUnVsZSgnMicsIDIwLCAnc2VnbWVudC0yJyksXHJcbiAgICAgICAgICBnZW5lcmF0ZVJ1bGUoJzMnLCAxNSwgJ3NlZ21lbnQtMycpXHJcbiAgICAgICAgXVxyXG4gICAgICB9LFxyXG4gICAgICAvLyBTY2VuYXJpbyAzOiBSdWxlIHdlaWdodCBjaGFuZ2VzXHJcbiAgICAgIHtcclxuICAgICAgICBpbml0aWFsUnVsZXM6IFtnZW5lcmF0ZVJ1bGUoJzEnLCAxMCwgJ3NlZ21lbnQtMScpLCBnZW5lcmF0ZVJ1bGUoJzInLCAyMCwgJ3NlZ21lbnQtMicpXSxcclxuICAgICAgICB1cGRhdGVkUnVsZXM6IFtnZW5lcmF0ZVJ1bGUoJzEnLCAyNSwgJ3NlZ21lbnQtMScpLCBnZW5lcmF0ZVJ1bGUoJzInLCA1LCAnc2VnbWVudC0yJyldXHJcbiAgICAgIH0sXHJcbiAgICAgIC8vIFNjZW5hcmlvIDQ6IFJ1bGUgcmVtb3ZhbFxyXG4gICAgICB7XHJcbiAgICAgICAgaW5pdGlhbFJ1bGVzOiBbXHJcbiAgICAgICAgICBnZW5lcmF0ZVJ1bGUoJzEnLCAxMCwgJ3NlZ21lbnQtMScpLFxyXG4gICAgICAgICAgZ2VuZXJhdGVSdWxlKCcyJywgMjAsICdzZWdtZW50LTInKSxcclxuICAgICAgICAgIGdlbmVyYXRlUnVsZSgnMycsIDE1LCAnc2VnbWVudC0zJylcclxuICAgICAgICBdLFxyXG4gICAgICAgIHVwZGF0ZWRSdWxlczogW2dlbmVyYXRlUnVsZSgnMicsIDIwLCAnc2VnbWVudC0yJyldXHJcbiAgICAgIH0sXHJcbiAgICAgIC8vIFNjZW5hcmlvIDU6IENvbXBsZXRlIHJ1bGUgcmVwbGFjZW1lbnRcclxuICAgICAge1xyXG4gICAgICAgIGluaXRpYWxSdWxlczogW2dlbmVyYXRlUnVsZSgnb2xkMScsIDEwLCAnb2xkLXNlZ21lbnQnKV0sXHJcbiAgICAgICAgdXBkYXRlZFJ1bGVzOiBbZ2VuZXJhdGVSdWxlKCduZXcxJywgMzAsICduZXctc2VnbWVudCcpXVxyXG4gICAgICB9LFxyXG4gICAgICAvLyBTY2VuYXJpbyA2OiBMYXJnZSBydWxlIHNldCBjaGFuZ2VzXHJcbiAgICAgIHtcclxuICAgICAgICBpbml0aWFsUnVsZXM6IEFycmF5LmZyb20oeyBsZW5ndGg6IDUgfSwgKF8sIGkpID0+IGdlbmVyYXRlUnVsZShgb2xkLSR7aX1gLCBpICogMTAsIGBvbGQtc2VnbWVudC0ke2l9YCkpLFxyXG4gICAgICAgIHVwZGF0ZWRSdWxlczogQXJyYXkuZnJvbSh7IGxlbmd0aDogOCB9LCAoXywgaSkgPT4gZ2VuZXJhdGVSdWxlKGBuZXctJHtpfWAsIGkgKiA1ICsgMTAsIGBuZXctc2VnbWVudC0ke2l9YCkpXHJcbiAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgLy8gUnVuIHByb3BlcnR5IHRlc3QgZm9yIGVhY2ggc2NlbmFyaW8gKDEwMCBpdGVyYXRpb25zIGFzIHNwZWNpZmllZClcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDEwMDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3Qgc2NlbmFyaW9JbmRleCA9IGl0ZXJhdGlvbiAlIHRlc3RTY2VuYXJpb3MubGVuZ3RoO1xyXG4gICAgICBjb25zdCBzY2VuYXJpbyA9IHRlc3RTY2VuYXJpb3Nbc2NlbmFyaW9JbmRleF07XHJcblxyXG4gICAgICAvLyBTZXR1cCBtb2NrIGZvciBpbml0aWFsIGNhY2hlIHBvcHVsYXRpb25cclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogc2NlbmFyaW8uaW5pdGlhbFJ1bGVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gU2V0dXAgbW9jayBmb3IgY2FjaGUgcmVmcmVzaCAodXBkYXRlZCBydWxlcylcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogc2NlbmFyaW8udXBkYXRlZFJ1bGVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG5cclxuICAgICAgLy8gU3RlcCAxOiBMb2FkIGluaXRpYWwgcnVsZXMgKHBvcHVsYXRlIGNhY2hlKVxyXG4gICAgICBjb25zdCBpbml0aWFsTG9hZGVkUnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMTogSW5pdGlhbCBsb2FkIHNob3VsZCBtYXRjaCBpbml0aWFsIHJ1bGVzIChzb3J0ZWQgYnkgd2VpZ2h0KVxyXG4gICAgICBjb25zdCBleHBlY3RlZEluaXRpYWxSdWxlcyA9IFsuLi5zY2VuYXJpby5pbml0aWFsUnVsZXNdLnNvcnQoKGEsIGIpID0+IGIud2VpZ2h0IC0gYS53ZWlnaHQpO1xyXG4gICAgICBleHBlY3QoaW5pdGlhbExvYWRlZFJ1bGVzKS50b0VxdWFsKGV4cGVjdGVkSW5pdGlhbFJ1bGVzKTtcclxuXHJcbiAgICAgIC8vIFN0ZXAgMjogUmVmcmVzaCBjYWNoZSAoc2ltdWxhdGluZyBydWxlIHVwZGF0ZXMgaW4gZGF0YWJhc2UpXHJcbiAgICAgIGF3YWl0IHJlcG9zaXRvcnkucmVmcmVzaENhY2hlKCk7XHJcblxyXG4gICAgICAvLyBTdGVwIDM6IExvYWQgcnVsZXMgYWZ0ZXIgcmVmcmVzaFxyXG4gICAgICBjb25zdCByZWZyZXNoZWRMb2FkZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAyOiBSZWZyZXNoZWQgcnVsZXMgc2hvdWxkIG1hdGNoIHVwZGF0ZWQgcnVsZXMgKHNvcnRlZCBieSB3ZWlnaHQpXHJcbiAgICAgIGNvbnN0IGV4cGVjdGVkVXBkYXRlZFJ1bGVzID0gWy4uLnNjZW5hcmlvLnVwZGF0ZWRSdWxlc10uc29ydCgoYSwgYikgPT4gYi53ZWlnaHQgLSBhLndlaWdodCk7XHJcbiAgICAgIGV4cGVjdChyZWZyZXNoZWRMb2FkZWRSdWxlcykudG9FcXVhbChleHBlY3RlZFVwZGF0ZWRSdWxlcyk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBDYWNoZSBzaG91bGQgcmVmbGVjdCB0aGUgdXBkYXRlZCBzdGF0ZSwgbm90IHRoZSBpbml0aWFsIHN0YXRlXHJcbiAgICAgIGlmIChzY2VuYXJpby5pbml0aWFsUnVsZXMubGVuZ3RoICE9PSBzY2VuYXJpby51cGRhdGVkUnVsZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgZXhwZWN0KHJlZnJlc2hlZExvYWRlZFJ1bGVzLmxlbmd0aCkubm90LnRvQmUoaW5pdGlhbExvYWRlZFJ1bGVzLmxlbmd0aCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDQ6IERhdGFiYXNlIHNob3VsZCBiZSBjYWxsZWQgdHdpY2UgKGluaXRpYWwgbG9hZCArIHJlZnJlc2gpXHJcbiAgICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDIpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNTogQm90aCBjYWxscyBzaG91bGQgdXNlIGNvcnJlY3QgdGFibGUgbmFtZSBhbmQgZmlsdGVyXHJcbiAgICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbk50aENhbGxlZFdpdGgoMSwgZXhwZWN0Lm9iamVjdENvbnRhaW5pbmcoe1xyXG4gICAgICAgIFRhYmxlTmFtZTogJ3Rlc3QtdGFibGUnLFxyXG4gICAgICAgIEZpbHRlckV4cHJlc3Npb246ICdhdHRyaWJ1dGVfbm90X2V4aXN0cyhhY3RpdmUpIE9SIGFjdGl2ZSA9IDphY3RpdmUnLFxyXG4gICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IHsgJzphY3RpdmUnOiAndHJ1ZScgfVxyXG4gICAgICB9KSk7XHJcbiAgICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbk50aENhbGxlZFdpdGgoMiwgZXhwZWN0Lm9iamVjdENvbnRhaW5pbmcoe1xyXG4gICAgICAgIFRhYmxlTmFtZTogJ3Rlc3QtdGFibGUnLFxyXG4gICAgICAgIEZpbHRlckV4cHJlc3Npb246ICdhdHRyaWJ1dGVfbm90X2V4aXN0cyhhY3RpdmUpIE9SIGFjdGl2ZSA9IDphY3RpdmUnLFxyXG4gICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IHsgJzphY3RpdmUnOiAndHJ1ZScgfVxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IENhY2hlIGludmFsaWRhdGlvbiBjb21wbGV0ZW5lc3NcclxuICAgKiBBZnRlciByZWZyZXNoQ2FjaGUoKSwgdGhlIGNhY2hlIHNob3VsZCBiZSBjb21wbGV0ZWx5IGludmFsaWRhdGVkIGFuZCBcclxuICAgKiB0aGUgbmV4dCBsb2FkQWxsUnVsZXMoKSBzaG91bGQgYWx3YXlzIGZldGNoIGZyb20gZGF0YWJhc2VcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgY29tcGxldGVseSBpbnZhbGlkYXRlIGNhY2hlIG9uIHJlZnJlc2gnLCBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBpbml0aWFsUnVsZXMgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogJ3J1bGUxJyxcclxuICAgICAgICBuYW1lOiAnSW5pdGlhbCBSdWxlJyxcclxuICAgICAgICBleHByZXNzaW9uOiAnSW5pdGlhbCA9PSB0cnVlJyxcclxuICAgICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdpbml0aWFsLXNlZ21lbnQnLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWicsXHJcbiAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICB9XHJcbiAgICBdO1xyXG5cclxuICAgIC8vIFRlc3QgY2FjaGUgaW52YWxpZGF0aW9uIGNvbXBsZXRlbmVzcyAoNTAgaXRlcmF0aW9ucylcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDUwOyBpdGVyYXRpb24rKykge1xyXG4gICAgICAvLyBNb2NrIGluaXRpYWwgbG9hZFxyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xyXG4gICAgICAgIEl0ZW1zOiBpbml0aWFsUnVsZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBNb2NrIGxvYWQgYWZ0ZXIgcmVmcmVzaCAoY291bGQgYmUgc2FtZSBvciBkaWZmZXJlbnQgcnVsZXMpXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgICAgSXRlbXM6IGluaXRpYWxSdWxlc1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuXHJcbiAgICAgIC8vIExvYWQgcnVsZXMgdG8gcG9wdWxhdGUgY2FjaGVcclxuICAgICAgYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFZlcmlmeSBjYWNoZSBpcyBwb3B1bGF0ZWQgKHNlY29uZCBjYWxsIHNob3VsZCBub3QgaGl0IGRhdGFiYXNlKVxyXG4gICAgICBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG4gICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTsgLy8gT25seSBvbmUgREIgY2FsbCBzbyBmYXJcclxuXHJcbiAgICAgIC8vIFJlZnJlc2ggY2FjaGUgKHNob3VsZCBpbnZhbGlkYXRlKVxyXG4gICAgICBhd2FpdCByZXBvc2l0b3J5LnJlZnJlc2hDYWNoZSgpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IEFmdGVyIHJlZnJlc2gsIGNhY2hlIHNob3VsZCBiZSBpbnZhbGlkYXRlZFxyXG4gICAgICBjb25zdCBjYWNoZVN0YXRzID0gcmVwb3NpdG9yeS5nZXRDYWNoZVN0YXRzKCk7XHJcbiAgICAgIGV4cGVjdChjYWNoZVN0YXRzLmlzQ2FjaGVkKS50b0JlKHRydWUpOyAvLyByZWZyZXNoQ2FjaGUoKSBsb2FkcyBuZXcgZGF0YVxyXG4gICAgICBleHBlY3QoY2FjaGVTdGF0cy5sYXN0UmVmcmVzaCkubm90LnRvQmVOdWxsKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogRGF0YWJhc2Ugc2hvdWxkIGhhdmUgYmVlbiBjYWxsZWQgdHdpY2UgKGluaXRpYWwgKyByZWZyZXNoKVxyXG4gICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygyKTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2sgZm9yIG5leHQgaXRlcmF0aW9uXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tDbGVhcigpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICAvKipcclxuICAgKiBQcm9wZXJ0eTogQ2FjaGUgcmVmcmVzaCBlcnJvciBoYW5kbGluZ1xyXG4gICAqIFdoZW4gcmVmcmVzaENhY2hlKCkgZW5jb3VudGVycyBkYXRhYmFzZSBlcnJvcnMsIGl0IHNob3VsZCBoYW5kbGUgdGhlbSBncmFjZWZ1bGx5XHJcbiAgICogYW5kIG1haW50YWluIHN5c3RlbSBzdGFiaWxpdHlcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgaGFuZGxlIHJlZnJlc2ggZXJyb3JzIGdyYWNlZnVsbHknLCBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBpbml0aWFsUnVsZXMgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogJ3J1bGUxJyxcclxuICAgICAgICBuYW1lOiAnSW5pdGlhbCBSdWxlJyxcclxuICAgICAgICBleHByZXNzaW9uOiAnSW5pdGlhbCA9PSB0cnVlJyxcclxuICAgICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdpbml0aWFsLXNlZ21lbnQnLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWicsXHJcbiAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICB9XHJcbiAgICBdO1xyXG5cclxuICAgIC8vIERpZmZlcmVudCBlcnJvciB0eXBlcyB0byB0ZXN0XHJcbiAgICBjb25zdCBlcnJvclR5cGVzID0gW1xyXG4gICAgICBuZXcgRXJyb3IoJ05ldHdvcmsgdGltZW91dCBkdXJpbmcgcmVmcmVzaCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ0FjY2VzcyBkZW5pZWQgb24gcmVmcmVzaCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ1RhYmxlIG5vdCBmb3VuZCBkdXJpbmcgcmVmcmVzaCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ1Rocm90dGxpbmdFeGNlcHRpb24gZHVyaW5nIHJlZnJlc2gnKSxcclxuICAgICAgbmV3IEVycm9yKCdTZXJ2aWNlVW5hdmFpbGFibGVFeGNlcHRpb24gZHVyaW5nIHJlZnJlc2gnKVxyXG4gICAgXTtcclxuXHJcbiAgICAvLyBUZXN0IGVycm9yIGhhbmRsaW5nICgyNSBpdGVyYXRpb25zKVxyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgMjU7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIGNvbnN0IGVycm9ySW5kZXggPSBpdGVyYXRpb24gJSBlcnJvclR5cGVzLmxlbmd0aDtcclxuICAgICAgY29uc3QgZXJyb3IgPSBlcnJvclR5cGVzW2Vycm9ySW5kZXhdO1xyXG5cclxuICAgICAgLy8gTW9jayBzdWNjZXNzZnVsIGluaXRpYWwgbG9hZFxyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xyXG4gICAgICAgIEl0ZW1zOiBpbml0aWFsUnVsZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBNb2NrIGVycm9yIG9uIHJlZnJlc2hcclxuICAgICAgbW9ja1NlbmQubW9ja1JlamVjdGVkVmFsdWVPbmNlKGVycm9yKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuXHJcbiAgICAgIC8vIExvYWQgaW5pdGlhbCBydWxlcyBzdWNjZXNzZnVsbHlcclxuICAgICAgY29uc3QgaW5pdGlhbExvYWRlZFJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgZXhwZWN0KGluaXRpYWxMb2FkZWRSdWxlcykudG9IYXZlTGVuZ3RoKDEpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IHJlZnJlc2hDYWNoZSgpIHNob3VsZCB0aHJvdyBtZWFuaW5nZnVsIGVycm9yIHdoZW4gZGF0YWJhc2UgZmFpbHNcclxuICAgICAgYXdhaXQgZXhwZWN0KHJlcG9zaXRvcnkucmVmcmVzaENhY2hlKCkpLnJlamVjdHMudG9UaHJvdyhcclxuICAgICAgICBleHBlY3Quc3RyaW5nQ29udGFpbmluZygnRmFpbGVkIHRvIGxvYWQgcXVhbGlmaWNhdGlvbiBydWxlcycpXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogU3lzdGVtIHNob3VsZCByZW1haW4gc3RhYmxlIGFmdGVyIHJlZnJlc2ggZXJyb3JcclxuICAgICAgLy8gKENhY2hlIHNob3VsZCBiZSBjbGVhcmVkIGJ1dCBzeXN0ZW0gc2hvdWxkIG5vdCBjcmFzaClcclxuICAgICAgY29uc3QgY2FjaGVTdGF0cyA9IHJlcG9zaXRvcnkuZ2V0Q2FjaGVTdGF0cygpO1xyXG4gICAgICBleHBlY3QoY2FjaGVTdGF0cy5pc0NhY2hlZCkudG9CZShmYWxzZSk7IC8vIENhY2hlIHNob3VsZCBiZSBjbGVhcmVkIG9uIGVycm9yXHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IENhY2hlIHJlZnJlc2ggdGltaW5nIGNvbnNpc3RlbmN5XHJcbiAgICogTXVsdGlwbGUgcmFwaWQgY2FsbHMgdG8gcmVmcmVzaENhY2hlKCkgc2hvdWxkIGJlIGhhbmRsZWQgY29uc2lzdGVudGx5XHJcbiAgICogd2l0aG91dCByYWNlIGNvbmRpdGlvbnMgb3IgaW5jb25zaXN0ZW50IHN0YXRlXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIGhhbmRsZSByYXBpZCByZWZyZXNoIGNhbGxzIGNvbnNpc3RlbnRseScsIGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHRlc3RSdWxlcyA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGlkOiAncnVsZTEnLFxyXG4gICAgICAgIG5hbWU6ICdUZXN0IFJ1bGUnLFxyXG4gICAgICAgIGV4cHJlc3Npb246ICdUZXN0ID09IHRydWUnLFxyXG4gICAgICAgIHdlaWdodDogMTUsXHJcbiAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ3Rlc3Qtc2VnbWVudCcsXHJcbiAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonXHJcbiAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgLy8gVGVzdCByYXBpZCByZWZyZXNoIGNhbGxzICgyMCBpdGVyYXRpb25zKVxyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgMjA7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIC8vIE1vY2sgbXVsdGlwbGUgc3VjY2Vzc2Z1bCByZXNwb25zZXMgZm9yIHJhcGlkIGNhbGxzXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNTsgaSsrKSB7XHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICAgIEl0ZW1zOiB0ZXN0UnVsZXNcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IE11bHRpcGxlIHJhcGlkIHJlZnJlc2ggY2FsbHMgc2hvdWxkIGFsbCBzdWNjZWVkXHJcbiAgICAgIGNvbnN0IHJlZnJlc2hQcm9taXNlcyA9IFtcclxuICAgICAgICByZXBvc2l0b3J5LnJlZnJlc2hDYWNoZSgpLFxyXG4gICAgICAgIHJlcG9zaXRvcnkucmVmcmVzaENhY2hlKCksXHJcbiAgICAgICAgcmVwb3NpdG9yeS5yZWZyZXNoQ2FjaGUoKVxyXG4gICAgICBdO1xyXG5cclxuICAgICAgLy8gQWxsIHJlZnJlc2hlcyBzaG91bGQgY29tcGxldGUgd2l0aG91dCBlcnJvclxyXG4gICAgICBhd2FpdCBleHBlY3QoUHJvbWlzZS5hbGwocmVmcmVzaFByb21pc2VzKSkucmVzb2x2ZXMubm90LnRvVGhyb3coKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5OiBGaW5hbCBzdGF0ZSBzaG91bGQgYmUgY29uc2lzdGVudFxyXG4gICAgICBjb25zdCBmaW5hbFJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgZXhwZWN0KGZpbmFsUnVsZXMpLnRvRXF1YWwodGVzdFJ1bGVzKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5OiBDYWNoZSBzaG91bGQgYmUgaW4gdmFsaWQgc3RhdGVcclxuICAgICAgY29uc3QgY2FjaGVTdGF0cyA9IHJlcG9zaXRvcnkuZ2V0Q2FjaGVTdGF0cygpO1xyXG4gICAgICBleHBlY3QoY2FjaGVTdGF0cy5pc0NhY2hlZCkudG9CZSh0cnVlKTtcclxuICAgICAgZXhwZWN0KGNhY2hlU3RhdHMubGFzdFJlZnJlc2gpLm5vdC50b0JlTnVsbCgpO1xyXG5cclxuICAgICAgLy8gUmVzZXQgbW9jayBmb3IgbmV4dCBpdGVyYXRpb25cclxuICAgICAgbW9ja1NlbmQubW9ja0NsZWFyKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBDYWNoZSByZWZyZXNoIHByZXNlcnZlcyBydWxlIG9yZGVyaW5nXHJcbiAgICogQWZ0ZXIgcmVmcmVzaENhY2hlKCksIHJ1bGVzIHNob3VsZCBtYWludGFpbiBwcm9wZXIgd2VpZ2h0LWJhc2VkIG9yZGVyaW5nXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIHByZXNlcnZlIHJ1bGUgb3JkZXJpbmcgYWZ0ZXIgcmVmcmVzaCcsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIEdlbmVyYXRlIHRlc3QgY2FzZXMgd2l0aCB2YXJpb3VzIHJ1bGUgb3JkZXJpbmdzXHJcbiAgICBjb25zdCBnZW5lcmF0ZVVub3JkZXJlZFJ1bGVzID0gKGNvdW50OiBudW1iZXIpOiBRdWFsaWZpY2F0aW9uUnVsZVtdID0+IHtcclxuICAgICAgY29uc3QgcnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXTtcclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XHJcbiAgICAgICAgcnVsZXMucHVzaCh7XHJcbiAgICAgICAgICBpZDogYHJ1bGUtJHtpfWAsXHJcbiAgICAgICAgICBuYW1lOiBgUnVsZSAke2l9YCxcclxuICAgICAgICAgIGV4cHJlc3Npb246IGBDcml0ZXJpb24ke2l9ID09IHRydWVgLFxyXG4gICAgICAgICAgd2VpZ2h0OiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDApICsgMSwgLy8gUmFuZG9tIHdlaWdodCAxLTEwMFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogYHNlZ21lbnQtJHtpfWAsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHJ1bGVzO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBUZXN0IG9yZGVyaW5nIHByZXNlcnZhdGlvbiAoNTAgaXRlcmF0aW9ucylcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDUwOyBpdGVyYXRpb24rKykge1xyXG4gICAgICBjb25zdCBydWxlQ291bnQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA4KSArIDI7IC8vIDItOSBydWxlc1xyXG4gICAgICBjb25zdCB1bm9yZGVyZWRSdWxlcyA9IGdlbmVyYXRlVW5vcmRlcmVkUnVsZXMocnVsZUNvdW50KTtcclxuXHJcbiAgICAgIC8vIE1vY2sgZGF0YWJhc2UgcmV0dXJuaW5nIHVub3JkZXJlZCBydWxlc1xyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xyXG4gICAgICAgIEl0ZW1zOiB1bm9yZGVyZWRSdWxlc1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuXHJcbiAgICAgIC8vIFJlZnJlc2ggY2FjaGUgd2l0aCB1bm9yZGVyZWQgcnVsZXNcclxuICAgICAgYXdhaXQgcmVwb3NpdG9yeS5yZWZyZXNoQ2FjaGUoKTtcclxuXHJcbiAgICAgIC8vIExvYWQgcnVsZXMgYWZ0ZXIgcmVmcmVzaFxyXG4gICAgICBjb25zdCBvcmRlcmVkUnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IFJ1bGVzIHNob3VsZCBiZSBvcmRlcmVkIGJ5IHdlaWdodCBkZXNjZW5kaW5nXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3JkZXJlZFJ1bGVzLmxlbmd0aCAtIDE7IGkrKykge1xyXG4gICAgICAgIGV4cGVjdChvcmRlcmVkUnVsZXNbaV0ud2VpZ2h0KS50b0JlR3JlYXRlclRoYW5PckVxdWFsKG9yZGVyZWRSdWxlc1tpICsgMV0ud2VpZ2h0KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IEFsbCBvcmlnaW5hbCBydWxlcyBzaG91bGQgYmUgcHJlc2VudFxyXG4gICAgICBleHBlY3Qob3JkZXJlZFJ1bGVzKS50b0hhdmVMZW5ndGgodW5vcmRlcmVkUnVsZXMubGVuZ3RoKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5OiBSdWxlIGNvbnRlbnQgc2hvdWxkIGJlIHByZXNlcnZlZCAob25seSBvcmRlciBjaGFuZ2VkKVxyXG4gICAgICBjb25zdCBvcmlnaW5hbElkcyA9IHVub3JkZXJlZFJ1bGVzLm1hcChyID0+IHIuaWQpLnNvcnQoKTtcclxuICAgICAgY29uc3Qgb3JkZXJlZElkcyA9IG9yZGVyZWRSdWxlcy5tYXAociA9PiByLmlkKS5zb3J0KCk7XHJcbiAgICAgIGV4cGVjdChvcmRlcmVkSWRzKS50b0VxdWFsKG9yaWdpbmFsSWRzKTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2sgZm9yIG5leHQgaXRlcmF0aW9uXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tDbGVhcigpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59KTsiXX0=
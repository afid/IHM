"use strict";
/**
 * Manual Property Test Runner for Database Rule Loading
 * **Feature: decision-engine, Property 2: Database rule loading**
 * **Validates: Requirements 1.1**
 *
 * This is a standalone test that can be run without Jest to verify the property
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.testDatabaseRuleLoadingProperty = testDatabaseRuleLoadingProperty;
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
// Simple assertion function
function assert(condition, message) {
    if (!condition) {
        throw new Error(`Assertion failed: ${message}`);
    }
}
// Mock DynamoDB client
class MockDynamoClient {
    constructor() {
        this.mockResponse = null;
        this.mockError = null;
    }
    setMockResponse(response) {
        this.mockResponse = response;
        this.mockError = null;
    }
    setMockError(error) {
        this.mockError = error;
        this.mockResponse = null;
    }
    async send(command) {
        if (this.mockError) {
            throw this.mockError;
        }
        return this.mockResponse;
    }
}
// Property test implementation
async function testDatabaseRuleLoadingProperty() {
    console.log('Running Property Test: Database Rule Loading');
    const mockClient = new MockDynamoClient();
    // Override the DynamoDB client creation in RuleRepository
    const originalDynamoClient = RuleRepository_1.RuleRepository.prototype.dynamoClient;
    const generateRule = (id, weight) => ({
        id,
        name: `Test Rule ${id}`,
        expression: 'NouveauSinistre == true',
        weight,
        distributionSegment: `segment-${id}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    });
    // Test cases representing different scenarios
    const testCases = [
        // Empty rules
        [],
        // Single rule
        [generateRule('1', 10)],
        // Multiple rules with different weights
        [generateRule('1', 10), generateRule('2', 20), generateRule('3', 5)],
        // Rules with same weights
        [generateRule('1', 15), generateRule('2', 15)],
        // Large number of rules
        Array.from({ length: 10 }, (_, i) => generateRule(`rule-${i}`, Math.floor(Math.random() * 100) + 1))
    ];
    let testsPassed = 0;
    let totalTests = 0;
    for (const testCase of testCases) {
        for (let iteration = 0; iteration < 20; iteration++) { // 20 iterations per test case
            totalTests++;
            try {
                // Setup mock response
                mockClient.setMockResponse({ Items: testCase });
                // Create repository with mocked client
                const repository = new RuleRepository_1.RuleRepository('test-table');
                repository.dynamoClient = mockClient;
                // Load rules
                const loadedRules = await repository.loadAllRules();
                // Property 1: All generated rules should be loaded
                assert(loadedRules.length === testCase.length, `Expected ${testCase.length} rules, got ${loadedRules.length}`);
                // Property 2: Rules should be sorted by weight descending
                const expectedRules = [...testCase].sort((a, b) => b.weight - a.weight);
                for (let i = 0; i < loadedRules.length; i++) {
                    assert(loadedRules[i].id === expectedRules[i].id, `Rule at index ${i} has wrong id: expected ${expectedRules[i].id}, got ${loadedRules[i].id}`);
                    assert(loadedRules[i].weight === expectedRules[i].weight, `Rule at index ${i} has wrong weight: expected ${expectedRules[i].weight}, got ${loadedRules[i].weight}`);
                }
                // Property 3: Sorting invariant - each rule weight >= next rule weight
                for (let i = 0; i < loadedRules.length - 1; i++) {
                    assert(loadedRules[i].weight >= loadedRules[i + 1].weight, `Sorting invariant violated at index ${i}: ${loadedRules[i].weight} < ${loadedRules[i + 1].weight}`);
                }
                testsPassed++;
            }
            catch (error) {
                console.error(`Test failed for case ${JSON.stringify(testCase)}, iteration ${iteration}:`, error);
            }
        }
    }
    // Test error handling property
    const errorTypes = [
        new Error('Network timeout'),
        new Error('Access denied'),
        new Error('Table not found')
    ];
    for (const error of errorTypes) {
        for (let iteration = 0; iteration < 5; iteration++) {
            totalTests++;
            try {
                // Setup mock error
                mockClient.setMockError(error);
                const repository = new RuleRepository_1.RuleRepository('test-table');
                repository.dynamoClient = mockClient;
                // Should throw error
                let errorThrown = false;
                try {
                    await repository.loadAllRules();
                }
                catch (thrownError) {
                    errorThrown = true;
                    const error = thrownError;
                    assert(error.message.includes('Failed to load qualification rules'), `Expected error message to contain 'Failed to load qualification rules', got: ${error.message}`);
                }
                assert(errorThrown, 'Expected error to be thrown but none was thrown');
                testsPassed++;
            }
            catch (testError) {
                console.error(`Error handling test failed for ${error.message}, iteration ${iteration}:`, testError);
            }
        }
    }
    console.log(`\nProperty Test Results:`);
    console.log(`Tests passed: ${testsPassed}/${totalTests}`);
    console.log(`Success rate: ${((testsPassed / totalTests) * 100).toFixed(2)}%`);
    if (testsPassed === totalTests) {
        console.log('✅ All property tests passed!');
        console.log('\nProperty 2: Database rule loading - VERIFIED');
        console.log('- Rules are loaded correctly from database');
        console.log('- Rules are sorted by weight in descending order');
        console.log('- Error handling works as expected');
    }
    else {
        console.log('❌ Some property tests failed!');
        throw new Error(`Property test failed: ${totalTests - testsPassed} out of ${totalTests} tests failed`);
    }
}
if (typeof require !== 'undefined' && require.main === module) {
    testDatabaseRuleLoadingProperty()
        .then(() => {
        console.log('\n🎉 Property test completed successfully!');
        if (typeof process !== 'undefined')
            process.exit(0);
    })
        .catch((error) => {
        console.error('\n💥 Property test failed:', error);
        if (typeof process !== 'undefined')
            process.exit(1);
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFudWFsLXByb3BlcnR5LXRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdGVzdHMvZGVjaXNpb24tZW5naW5lL21hbnVhbC1wcm9wZXJ0eS10ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7O0dBTUc7O0FBc0xNLDBFQUErQjtBQXBMeEMsa0ZBQStFO0FBRy9FLDRCQUE0QjtBQUM1QixTQUFTLE1BQU0sQ0FBQyxTQUFrQixFQUFFLE9BQWU7SUFDakQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsT0FBTyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDO0FBQ0gsQ0FBQztBQUVELHVCQUF1QjtBQUN2QixNQUFNLGdCQUFnQjtJQUF0QjtRQUNVLGlCQUFZLEdBQVEsSUFBSSxDQUFDO1FBQ3pCLGNBQVMsR0FBaUIsSUFBSSxDQUFDO0lBa0J6QyxDQUFDO0lBaEJDLGVBQWUsQ0FBQyxRQUFhO1FBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO1FBQzdCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBQ3hCLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBWTtRQUN2QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztJQUMzQixDQUFDO0lBRUQsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFZO1FBQ3JCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ25CLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUN2QixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7Q0FDRjtBQUVELCtCQUErQjtBQUMvQixLQUFLLFVBQVUsK0JBQStCO0lBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsOENBQThDLENBQUMsQ0FBQztJQUU1RCxNQUFNLFVBQVUsR0FBRyxJQUFJLGdCQUFnQixFQUFFLENBQUM7SUFFMUMsMERBQTBEO0lBQzFELE1BQU0sb0JBQW9CLEdBQUksK0JBQXNCLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztJQUU1RSxNQUFNLFlBQVksR0FBRyxDQUFDLEVBQVUsRUFBRSxNQUFjLEVBQXFCLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZFLEVBQUU7UUFDRixJQUFJLEVBQUUsYUFBYSxFQUFFLEVBQUU7UUFDdkIsVUFBVSxFQUFFLHlCQUF5QjtRQUNyQyxNQUFNO1FBQ04sbUJBQW1CLEVBQUUsV0FBVyxFQUFFLEVBQUU7UUFDcEMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1FBQ25DLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtLQUNwQyxDQUFDLENBQUM7SUFFSCw4Q0FBOEM7SUFDOUMsTUFBTSxTQUFTLEdBQUc7UUFDaEIsY0FBYztRQUNkLEVBQUU7UUFDRixjQUFjO1FBQ2QsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZCLHdDQUF3QztRQUN4QyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BFLDBCQUEwQjtRQUMxQixDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5Qyx3QkFBd0I7UUFDeEIsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0tBQ3JHLENBQUM7SUFFRixJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUM7SUFDcEIsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBRW5CLEtBQUssTUFBTSxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7UUFDakMsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsOEJBQThCO1lBQ25GLFVBQVUsRUFBRSxDQUFDO1lBRWIsSUFBSSxDQUFDO2dCQUNILHNCQUFzQjtnQkFDdEIsVUFBVSxDQUFDLGVBQWUsQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUVoRCx1Q0FBdUM7Z0JBQ3ZDLE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDbkQsVUFBa0IsQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO2dCQUU5QyxhQUFhO2dCQUNiLE1BQU0sV0FBVyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUVwRCxtREFBbUQ7Z0JBQ25ELE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLFFBQVEsQ0FBQyxNQUFNLEVBQ3RDLFlBQVksUUFBUSxDQUFDLE1BQU0sZUFBZSxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztnQkFFdkUsMERBQTBEO2dCQUMxRCxNQUFNLGFBQWEsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3hFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzVDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ3pDLGlCQUFpQixDQUFDLDJCQUEyQixhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUNyRyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUNqRCxpQkFBaUIsQ0FBQywrQkFBK0IsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sU0FBUyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztnQkFDbkgsQ0FBQztnQkFFRCx1RUFBdUU7Z0JBQ3ZFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO29CQUNoRCxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFDbEQsdUNBQXVDLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxNQUFNLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztnQkFDOUcsQ0FBQztnQkFFRCxXQUFXLEVBQUUsQ0FBQztZQUNoQixDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHdCQUF3QixJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxlQUFlLFNBQVMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3BHLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELCtCQUErQjtJQUMvQixNQUFNLFVBQVUsR0FBRztRQUNqQixJQUFJLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztRQUM1QixJQUFJLEtBQUssQ0FBQyxlQUFlLENBQUM7UUFDMUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUM7S0FDN0IsQ0FBQztJQUVGLEtBQUssTUFBTSxLQUFLLElBQUksVUFBVSxFQUFFLENBQUM7UUFDL0IsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ25ELFVBQVUsRUFBRSxDQUFDO1lBRWIsSUFBSSxDQUFDO2dCQUNILG1CQUFtQjtnQkFDbkIsVUFBVSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFL0IsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUNuRCxVQUFrQixDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7Z0JBRTlDLHFCQUFxQjtnQkFDckIsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUM7b0JBQ0gsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQUMsT0FBTyxXQUFXLEVBQUUsQ0FBQztvQkFDckIsV0FBVyxHQUFHLElBQUksQ0FBQztvQkFDbkIsTUFBTSxLQUFLLEdBQUcsV0FBb0IsQ0FBQztvQkFDbkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLG9DQUFvQyxDQUFDLEVBQzVELGdGQUFnRixLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztnQkFDMUcsQ0FBQztnQkFFRCxNQUFNLENBQUMsV0FBVyxFQUFFLGlEQUFpRCxDQUFDLENBQUM7Z0JBQ3ZFLFdBQVcsRUFBRSxDQUFDO1lBQ2hCLENBQUM7WUFBQyxPQUFPLFNBQVMsRUFBRSxDQUFDO2dCQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxLQUFLLENBQUMsT0FBTyxlQUFlLFNBQVMsR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZHLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixXQUFXLElBQUksVUFBVSxFQUFFLENBQUMsQ0FBQztJQUMxRCxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFFL0UsSUFBSSxXQUFXLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELENBQUMsQ0FBQztRQUM5RCxPQUFPLENBQUMsR0FBRyxDQUFDLDRDQUE0QyxDQUFDLENBQUM7UUFDMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1FBQ2hFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztJQUNwRCxDQUFDO1NBQU0sQ0FBQztRQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLENBQUMsQ0FBQztRQUM3QyxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixVQUFVLEdBQUcsV0FBVyxXQUFXLFVBQVUsZUFBZSxDQUFDLENBQUM7SUFDekcsQ0FBQztBQUNILENBQUM7QUFPRCxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO0lBQzlELCtCQUErQixFQUFFO1NBQzlCLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLDRDQUE0QyxDQUFDLENBQUM7UUFDMUQsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO1lBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxDQUFDLENBQUM7U0FDRCxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbkQsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO1lBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogTWFudWFsIFByb3BlcnR5IFRlc3QgUnVubmVyIGZvciBEYXRhYmFzZSBSdWxlIExvYWRpbmdcclxuICogKipGZWF0dXJlOiBkZWNpc2lvbi1lbmdpbmUsIFByb3BlcnR5IDI6IERhdGFiYXNlIHJ1bGUgbG9hZGluZyoqXHJcbiAqICoqVmFsaWRhdGVzOiBSZXF1aXJlbWVudHMgMS4xKipcclxuICogXHJcbiAqIFRoaXMgaXMgYSBzdGFuZGFsb25lIHRlc3QgdGhhdCBjYW4gYmUgcnVuIHdpdGhvdXQgSmVzdCB0byB2ZXJpZnkgdGhlIHByb3BlcnR5XHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgUnVsZVJlcG9zaXRvcnkgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZVJlcG9zaXRvcnknO1xyXG5pbXBvcnQgeyBRdWFsaWZpY2F0aW9uUnVsZSB9IGZyb20gJy4uLy4uL3R5cGVzL2RlY2lzaW9uLWVuZ2luZSc7XHJcblxyXG4vLyBTaW1wbGUgYXNzZXJ0aW9uIGZ1bmN0aW9uXHJcbmZ1bmN0aW9uIGFzc2VydChjb25kaXRpb246IGJvb2xlYW4sIG1lc3NhZ2U6IHN0cmluZyk6IHZvaWQge1xyXG4gIGlmICghY29uZGl0aW9uKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoYEFzc2VydGlvbiBmYWlsZWQ6ICR7bWVzc2FnZX1gKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIE1vY2sgRHluYW1vREIgY2xpZW50XHJcbmNsYXNzIE1vY2tEeW5hbW9DbGllbnQge1xyXG4gIHByaXZhdGUgbW9ja1Jlc3BvbnNlOiBhbnkgPSBudWxsO1xyXG4gIHByaXZhdGUgbW9ja0Vycm9yOiBFcnJvciB8IG51bGwgPSBudWxsO1xyXG5cclxuICBzZXRNb2NrUmVzcG9uc2UocmVzcG9uc2U6IGFueSk6IHZvaWQge1xyXG4gICAgdGhpcy5tb2NrUmVzcG9uc2UgPSByZXNwb25zZTtcclxuICAgIHRoaXMubW9ja0Vycm9yID0gbnVsbDtcclxuICB9XHJcblxyXG4gIHNldE1vY2tFcnJvcihlcnJvcjogRXJyb3IpOiB2b2lkIHtcclxuICAgIHRoaXMubW9ja0Vycm9yID0gZXJyb3I7XHJcbiAgICB0aGlzLm1vY2tSZXNwb25zZSA9IG51bGw7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzZW5kKGNvbW1hbmQ6IGFueSk6IFByb21pc2U8YW55PiB7XHJcbiAgICBpZiAodGhpcy5tb2NrRXJyb3IpIHtcclxuICAgICAgdGhyb3cgdGhpcy5tb2NrRXJyb3I7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5tb2NrUmVzcG9uc2U7XHJcbiAgfVxyXG59XHJcblxyXG4vLyBQcm9wZXJ0eSB0ZXN0IGltcGxlbWVudGF0aW9uXHJcbmFzeW5jIGZ1bmN0aW9uIHRlc3REYXRhYmFzZVJ1bGVMb2FkaW5nUHJvcGVydHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc29sZS5sb2coJ1J1bm5pbmcgUHJvcGVydHkgVGVzdDogRGF0YWJhc2UgUnVsZSBMb2FkaW5nJyk7XHJcbiAgXHJcbiAgY29uc3QgbW9ja0NsaWVudCA9IG5ldyBNb2NrRHluYW1vQ2xpZW50KCk7XHJcbiAgXHJcbiAgLy8gT3ZlcnJpZGUgdGhlIER5bmFtb0RCIGNsaWVudCBjcmVhdGlvbiBpbiBSdWxlUmVwb3NpdG9yeVxyXG4gIGNvbnN0IG9yaWdpbmFsRHluYW1vQ2xpZW50ID0gKFJ1bGVSZXBvc2l0b3J5IGFzIGFueSkucHJvdG90eXBlLmR5bmFtb0NsaWVudDtcclxuICBcclxuICBjb25zdCBnZW5lcmF0ZVJ1bGUgPSAoaWQ6IHN0cmluZywgd2VpZ2h0OiBudW1iZXIpOiBRdWFsaWZpY2F0aW9uUnVsZSA9PiAoe1xyXG4gICAgaWQsXHJcbiAgICBuYW1lOiBgVGVzdCBSdWxlICR7aWR9YCxcclxuICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZScsXHJcbiAgICB3ZWlnaHQsXHJcbiAgICBkaXN0cmlidXRpb25TZWdtZW50OiBgc2VnbWVudC0ke2lkfWAsXHJcbiAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgfSk7XHJcblxyXG4gIC8vIFRlc3QgY2FzZXMgcmVwcmVzZW50aW5nIGRpZmZlcmVudCBzY2VuYXJpb3NcclxuICBjb25zdCB0ZXN0Q2FzZXMgPSBbXHJcbiAgICAvLyBFbXB0eSBydWxlc1xyXG4gICAgW10sXHJcbiAgICAvLyBTaW5nbGUgcnVsZVxyXG4gICAgW2dlbmVyYXRlUnVsZSgnMScsIDEwKV0sXHJcbiAgICAvLyBNdWx0aXBsZSBydWxlcyB3aXRoIGRpZmZlcmVudCB3ZWlnaHRzXHJcbiAgICBbZ2VuZXJhdGVSdWxlKCcxJywgMTApLCBnZW5lcmF0ZVJ1bGUoJzInLCAyMCksIGdlbmVyYXRlUnVsZSgnMycsIDUpXSxcclxuICAgIC8vIFJ1bGVzIHdpdGggc2FtZSB3ZWlnaHRzXHJcbiAgICBbZ2VuZXJhdGVSdWxlKCcxJywgMTUpLCBnZW5lcmF0ZVJ1bGUoJzInLCAxNSldLFxyXG4gICAgLy8gTGFyZ2UgbnVtYmVyIG9mIHJ1bGVzXHJcbiAgICBBcnJheS5mcm9tKHsgbGVuZ3RoOiAxMCB9LCAoXywgaSkgPT4gZ2VuZXJhdGVSdWxlKGBydWxlLSR7aX1gLCBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDApICsgMSkpXHJcbiAgXTtcclxuXHJcbiAgbGV0IHRlc3RzUGFzc2VkID0gMDtcclxuICBsZXQgdG90YWxUZXN0cyA9IDA7XHJcblxyXG4gIGZvciAoY29uc3QgdGVzdENhc2Ugb2YgdGVzdENhc2VzKSB7XHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAyMDsgaXRlcmF0aW9uKyspIHsgLy8gMjAgaXRlcmF0aW9ucyBwZXIgdGVzdCBjYXNlXHJcbiAgICAgIHRvdGFsVGVzdHMrKztcclxuICAgICAgXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8gU2V0dXAgbW9jayByZXNwb25zZVxyXG4gICAgICAgIG1vY2tDbGllbnQuc2V0TW9ja1Jlc3BvbnNlKHsgSXRlbXM6IHRlc3RDYXNlIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIENyZWF0ZSByZXBvc2l0b3J5IHdpdGggbW9ja2VkIGNsaWVudFxyXG4gICAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuICAgICAgICAocmVwb3NpdG9yeSBhcyBhbnkpLmR5bmFtb0NsaWVudCA9IG1vY2tDbGllbnQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gTG9hZCBydWxlc1xyXG4gICAgICAgIGNvbnN0IGxvYWRlZFJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBQcm9wZXJ0eSAxOiBBbGwgZ2VuZXJhdGVkIHJ1bGVzIHNob3VsZCBiZSBsb2FkZWRcclxuICAgICAgICBhc3NlcnQobG9hZGVkUnVsZXMubGVuZ3RoID09PSB0ZXN0Q2FzZS5sZW5ndGgsIFxyXG4gICAgICAgICAgICAgICBgRXhwZWN0ZWQgJHt0ZXN0Q2FzZS5sZW5ndGh9IHJ1bGVzLCBnb3QgJHtsb2FkZWRSdWxlcy5sZW5ndGh9YCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gUHJvcGVydHkgMjogUnVsZXMgc2hvdWxkIGJlIHNvcnRlZCBieSB3ZWlnaHQgZGVzY2VuZGluZ1xyXG4gICAgICAgIGNvbnN0IGV4cGVjdGVkUnVsZXMgPSBbLi4udGVzdENhc2VdLnNvcnQoKGEsIGIpID0+IGIud2VpZ2h0IC0gYS53ZWlnaHQpO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbG9hZGVkUnVsZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgIGFzc2VydChsb2FkZWRSdWxlc1tpXS5pZCA9PT0gZXhwZWN0ZWRSdWxlc1tpXS5pZCxcclxuICAgICAgICAgICAgICAgICBgUnVsZSBhdCBpbmRleCAke2l9IGhhcyB3cm9uZyBpZDogZXhwZWN0ZWQgJHtleHBlY3RlZFJ1bGVzW2ldLmlkfSwgZ290ICR7bG9hZGVkUnVsZXNbaV0uaWR9YCk7XHJcbiAgICAgICAgICBhc3NlcnQobG9hZGVkUnVsZXNbaV0ud2VpZ2h0ID09PSBleHBlY3RlZFJ1bGVzW2ldLndlaWdodCxcclxuICAgICAgICAgICAgICAgICBgUnVsZSBhdCBpbmRleCAke2l9IGhhcyB3cm9uZyB3ZWlnaHQ6IGV4cGVjdGVkICR7ZXhwZWN0ZWRSdWxlc1tpXS53ZWlnaHR9LCBnb3QgJHtsb2FkZWRSdWxlc1tpXS53ZWlnaHR9YCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIFByb3BlcnR5IDM6IFNvcnRpbmcgaW52YXJpYW50IC0gZWFjaCBydWxlIHdlaWdodCA+PSBuZXh0IHJ1bGUgd2VpZ2h0XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsb2FkZWRSdWxlcy5sZW5ndGggLSAxOyBpKyspIHtcclxuICAgICAgICAgIGFzc2VydChsb2FkZWRSdWxlc1tpXS53ZWlnaHQgPj0gbG9hZGVkUnVsZXNbaSArIDFdLndlaWdodCxcclxuICAgICAgICAgICAgICAgICBgU29ydGluZyBpbnZhcmlhbnQgdmlvbGF0ZWQgYXQgaW5kZXggJHtpfTogJHtsb2FkZWRSdWxlc1tpXS53ZWlnaHR9IDwgJHtsb2FkZWRSdWxlc1tpICsgMV0ud2VpZ2h0fWApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICB0ZXN0c1Bhc3NlZCsrO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFRlc3QgZmFpbGVkIGZvciBjYXNlICR7SlNPTi5zdHJpbmdpZnkodGVzdENhc2UpfSwgaXRlcmF0aW9uICR7aXRlcmF0aW9ufTpgLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIFRlc3QgZXJyb3IgaGFuZGxpbmcgcHJvcGVydHlcclxuICBjb25zdCBlcnJvclR5cGVzID0gW1xyXG4gICAgbmV3IEVycm9yKCdOZXR3b3JrIHRpbWVvdXQnKSxcclxuICAgIG5ldyBFcnJvcignQWNjZXNzIGRlbmllZCcpLFxyXG4gICAgbmV3IEVycm9yKCdUYWJsZSBub3QgZm91bmQnKVxyXG4gIF07XHJcblxyXG4gIGZvciAoY29uc3QgZXJyb3Igb2YgZXJyb3JUeXBlcykge1xyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgNTsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgdG90YWxUZXN0cysrO1xyXG4gICAgICBcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBTZXR1cCBtb2NrIGVycm9yXHJcbiAgICAgICAgbW9ja0NsaWVudC5zZXRNb2NrRXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuICAgICAgICAocmVwb3NpdG9yeSBhcyBhbnkpLmR5bmFtb0NsaWVudCA9IG1vY2tDbGllbnQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gU2hvdWxkIHRocm93IGVycm9yXHJcbiAgICAgICAgbGV0IGVycm9yVGhyb3duID0gZmFsc2U7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcbiAgICAgICAgfSBjYXRjaCAodGhyb3duRXJyb3IpIHtcclxuICAgICAgICAgIGVycm9yVGhyb3duID0gdHJ1ZTtcclxuICAgICAgICAgIGNvbnN0IGVycm9yID0gdGhyb3duRXJyb3IgYXMgRXJyb3I7XHJcbiAgICAgICAgICBhc3NlcnQoZXJyb3IubWVzc2FnZS5pbmNsdWRlcygnRmFpbGVkIHRvIGxvYWQgcXVhbGlmaWNhdGlvbiBydWxlcycpLFxyXG4gICAgICAgICAgICAgICAgIGBFeHBlY3RlZCBlcnJvciBtZXNzYWdlIHRvIGNvbnRhaW4gJ0ZhaWxlZCB0byBsb2FkIHF1YWxpZmljYXRpb24gcnVsZXMnLCBnb3Q6ICR7ZXJyb3IubWVzc2FnZX1gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgYXNzZXJ0KGVycm9yVGhyb3duLCAnRXhwZWN0ZWQgZXJyb3IgdG8gYmUgdGhyb3duIGJ1dCBub25lIHdhcyB0aHJvd24nKTtcclxuICAgICAgICB0ZXN0c1Bhc3NlZCsrO1xyXG4gICAgICB9IGNhdGNoICh0ZXN0RXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBoYW5kbGluZyB0ZXN0IGZhaWxlZCBmb3IgJHtlcnJvci5tZXNzYWdlfSwgaXRlcmF0aW9uICR7aXRlcmF0aW9ufTpgLCB0ZXN0RXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zb2xlLmxvZyhgXFxuUHJvcGVydHkgVGVzdCBSZXN1bHRzOmApO1xyXG4gIGNvbnNvbGUubG9nKGBUZXN0cyBwYXNzZWQ6ICR7dGVzdHNQYXNzZWR9LyR7dG90YWxUZXN0c31gKTtcclxuICBjb25zb2xlLmxvZyhgU3VjY2VzcyByYXRlOiAkeygodGVzdHNQYXNzZWQgLyB0b3RhbFRlc3RzKSAqIDEwMCkudG9GaXhlZCgyKX0lYCk7XHJcbiAgXHJcbiAgaWYgKHRlc3RzUGFzc2VkID09PSB0b3RhbFRlc3RzKSB7XHJcbiAgICBjb25zb2xlLmxvZygn4pyFIEFsbCBwcm9wZXJ0eSB0ZXN0cyBwYXNzZWQhJyk7XHJcbiAgICBjb25zb2xlLmxvZygnXFxuUHJvcGVydHkgMjogRGF0YWJhc2UgcnVsZSBsb2FkaW5nIC0gVkVSSUZJRUQnKTtcclxuICAgIGNvbnNvbGUubG9nKCctIFJ1bGVzIGFyZSBsb2FkZWQgY29ycmVjdGx5IGZyb20gZGF0YWJhc2UnKTtcclxuICAgIGNvbnNvbGUubG9nKCctIFJ1bGVzIGFyZSBzb3J0ZWQgYnkgd2VpZ2h0IGluIGRlc2NlbmRpbmcgb3JkZXInKTtcclxuICAgIGNvbnNvbGUubG9nKCctIEVycm9yIGhhbmRsaW5nIHdvcmtzIGFzIGV4cGVjdGVkJyk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNvbnNvbGUubG9nKCfinYwgU29tZSBwcm9wZXJ0eSB0ZXN0cyBmYWlsZWQhJyk7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoYFByb3BlcnR5IHRlc3QgZmFpbGVkOiAke3RvdGFsVGVzdHMgLSB0ZXN0c1Bhc3NlZH0gb3V0IG9mICR7dG90YWxUZXN0c30gdGVzdHMgZmFpbGVkYCk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyBSdW4gdGhlIHRlc3QgaWYgdGhpcyBmaWxlIGlzIGV4ZWN1dGVkIGRpcmVjdGx5XHJcbmRlY2xhcmUgY29uc3QgcmVxdWlyZTogYW55O1xyXG5kZWNsYXJlIGNvbnN0IG1vZHVsZTogYW55O1xyXG5kZWNsYXJlIGNvbnN0IHByb2Nlc3M6IGFueTtcclxuXHJcbmlmICh0eXBlb2YgcmVxdWlyZSAhPT0gJ3VuZGVmaW5lZCcgJiYgcmVxdWlyZS5tYWluID09PSBtb2R1bGUpIHtcclxuICB0ZXN0RGF0YWJhc2VSdWxlTG9hZGluZ1Byb3BlcnR5KClcclxuICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ1xcbvCfjokgUHJvcGVydHkgdGVzdCBjb21wbGV0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xyXG4gICAgICBpZiAodHlwZW9mIHByb2Nlc3MgIT09ICd1bmRlZmluZWQnKSBwcm9jZXNzLmV4aXQoMCk7XHJcbiAgICB9KVxyXG4gICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdcXG7wn5KlIFByb3BlcnR5IHRlc3QgZmFpbGVkOicsIGVycm9yKTtcclxuICAgICAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJykgcHJvY2Vzcy5leGl0KDEpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCB7IHRlc3REYXRhYmFzZVJ1bGVMb2FkaW5nUHJvcGVydHkgfTsiXX0=
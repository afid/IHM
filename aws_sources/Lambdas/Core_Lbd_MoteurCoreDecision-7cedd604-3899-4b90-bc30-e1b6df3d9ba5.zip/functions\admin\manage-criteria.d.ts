/**
 * Lambda Function pour gérer les critères via API
 * Endpoint: POST /admin/criteria
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;

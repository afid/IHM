import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import { QualificationRule } from '../../types/decision-engine';
export declare class RuleRepository {
    private cachedRules;
    private lastCacheRefresh;
    private readonly CACHE_TTL_MS;
    protected readonly dynamoClient: DynamoDBDocumentClient;
    protected readonly tableName: string;
    constructor(tableName?: string);
    loadAllRules(): Promise<QualificationRule[]>;
    refreshCache(): Promise<void>;
    private isCacheValid;
    private loadRulesFromDatabase;
    addRule(rule: Omit<QualificationRule, 'createdAt' | 'updatedAt'>): Promise<void>;
    getCacheStats(): {
        isCached: boolean;
        lastRefresh: Date | null;
        cacheAge: number | null;
    };
}

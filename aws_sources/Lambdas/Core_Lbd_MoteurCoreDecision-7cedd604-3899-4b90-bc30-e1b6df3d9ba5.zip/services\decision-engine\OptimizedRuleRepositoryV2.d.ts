import { RuleRepository } from './RuleRepository';
import { QualificationRule } from '../../types/decision-engine';
interface OptimizedRule extends QualificationRule {
    primaryAttribute?: string;
    secondaryAttribute?: string;
}
export declare class OptimizedRuleRepositoryV2 extends RuleRepository {
    protected optimizedCache: Map<string, OptimizedRule[]>;
    protected readonly MAX_RULES_PER_QUERY = 200;
    private get PRIORITY_ATTRIBUTES();
    /**
     * Nouvelle méthode optimisée pour charger les règles selon les attributs
     */
    loadOptimizedRules(contactAttributes: Record<string, any>): Promise<OptimizedRule[]>;
    /**
     * Méthode de compatibilité - utilise l'optimisation si possible
     */
    loadAllRules(): Promise<QualificationRule[]>;
    /**
     * Détermine la stratégie optimale selon les attributs disponibles
     */
    private determineOptimalStrategy;
    /**
     * Détermine si on doit utiliser un GSI pour cet attribut
     */
    private shouldUseGSI;
    /**
     * Exécute une requête avec GSI
     */
    private queryWithGSI;
    /**
     * Exécute un scan avec filtres optimisés
     */
    private scanWithOptimizedFilters;
    /**
     * Charge toutes les règles avec optimisations mineures
     */
    protected loadRulesFromDatabaseOptimized(): Promise<OptimizedRule[]>;
    /**
     * Convertit les items DynamoDB en règles optimisées
     * Adapté pour le format AAN_Decision (Amazon Connect)
     */
    protected convertItemsToOptimizedRules(items: any[]): OptimizedRule[];
    /**
     * Applique un tri déterministe aux règles
     */
    protected applyDeterministicSort(rules: OptimizedRule[]): OptimizedRule[];
    /**
     * Génère une clé de cache optimisée
     */
    private generateOptimizedCacheKey;
    /**
     * Construit une expression de filtre pour le scan
     */
    private buildFilterExpression;
    /**
     * Invalide tous les caches (optimisé et standard)
     */
    refreshCache(): Promise<void>;
    /**
     * Statistiques étendues incluant le cache optimisé
     */
    getCacheStats(): any;
    /**
     * Analyse les performances de l'optimisation
     */
    analyzeOptimizationPerformance(contactAttributes: Record<string, any>): Promise<{
        strategy: string;
        rulesLoaded: number;
        cacheHit: boolean;
        estimatedImprovement: string;
    }>;
}
export {};

/**
 * Service de gestion des critères secondaires via AWS Systems Manager Parameter Store
 *
 * Fonctionnalités :
 * - Cache en mémoire avec TTL configurable
 * - Warm-up au démarrage pour éviter la latence du premier appel
 * - Refresh asynchrone pour maintenir le cache à jour sans bloquer
 * - Métriques de performance pour monitoring
 */
export interface SecondaryCriteriaConfig {
    name: string;
    enabled: boolean;
    description?: string;
    businessJustification?: string;
    addedDate?: string;
}
interface CacheMetrics {
    hits: number;
    misses: number;
    lastRefreshDuration: number;
    lastRefreshTimestamp: number;
}
export declare class CriteriaParameterStore {
    private static readonly PARAMETER_PATH;
    private static readonly DEFAULT_CACHE_TTL;
    private static readonly STALE_CACHE_TTL;
    private static cache;
    private static cacheTimestamp;
    private static cacheTTL;
    private static metrics;
    private static isRefreshing;
    private static ssmClient;
    /**
     * Obtient le client SSM (singleton) avec configuration optimisée
     */
    private static getClient;
    /**
     * Configure le TTL du cache (en millisecondes)
     */
    static setCacheTTL(ttl: number): void;
    /**
     * Charge tous les critères secondaires avec cache intelligent
     *
     * Stratégie :
     * 1. Si cache valide (< TTL) : retour immédiat
     * 2. Si cache périmé mais récent (< 2*TTL) : retour immédiat + refresh async
     * 3. Si cache trop vieux ou absent : refresh synchrone
     */
    static loadAll(): Promise<SecondaryCriteriaConfig[]>;
    /**
     * Rafraîchit le cache de manière synchrone
     */
    private static refreshCache;
    /**
     * Rafraîchit le cache de manière asynchrone (non-bloquant)
     */
    private static refreshCacheAsync;
    /**
     * Parse les paramètres SSM en objets SecondaryCriteriaConfig
     */
    private static parseParameters;
    /**
     * Ajoute ou met à jour un critère secondaire
     */
    static putCriteria(criteria: SecondaryCriteriaConfig): Promise<void>;
    /**
     * Supprime un critère secondaire
     */
    static deleteCriteria(criteriaName: string): Promise<void>;
    /**
     * Récupère un critère spécifique
     */
    static getCriteria(criteriaName: string): Promise<SecondaryCriteriaConfig | null>;
    /**
     * Invalide le cache (force un refresh au prochain appel)
     */
    static invalidateCache(): void;
    /**
     * Pré-charge le cache (warm-up)
     */
    static warmUp(): Promise<void>;
    /**
     * Retourne les métriques du cache
     */
    static getMetrics(): CacheMetrics & {
        cacheAge: number;
        cacheSize: number;
    };
    /**
     * Réinitialise les métriques
     */
    static resetMetrics(): void;
}
export {};

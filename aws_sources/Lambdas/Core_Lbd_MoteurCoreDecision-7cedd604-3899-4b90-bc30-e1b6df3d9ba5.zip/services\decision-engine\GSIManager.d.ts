/**
 * Gestionnaire intelligent des GSI pour évolution en production
 */
interface ConfigurationAnalysis {
    totalGSI: number;
    priorityOrder: string[];
    issues: PriorityIssue[];
    recommendations: string[];
    isOptimal: boolean;
}
interface PriorityIssue {
    type: 'SELECTIVITY_ORDER' | 'PRIORITY_GAPS' | 'DUPLICATE_PRIORITY';
    message: string;
    recommendation: string;
}
interface PriorityChange {
    attribute: string;
    newPriority: number;
}
interface SimulationResult {
    newPriorityOrder: string[];
    estimatedImpact: ImpactEstimation;
    warnings: string[];
}
interface ImpactEstimation {
    performanceChange: 'IMPROVEMENT' | 'DEGRADATION' | 'NEUTRAL';
    estimatedSpeedupPercent: number;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW';
}
export declare class GSIManager {
    private static readonly GSI_CONFIG;
    /**
     * Retourne les attributs prioritaires selon la config actuelle
     */
    static getActivePriorityAttributes(): string[];
    /**
     * Vérifie si un GSI est disponible et actif
     */
    static isGSIAvailable(attribute: string): boolean;
    /**
     * Retourne le nom de l'index pour un attribut
     */
    static getIndexName(attribute: string): string | null;
    /**
     * Active/désactive un GSI (pour déploiements progressifs)
     */
    static toggleGSI(attribute: string, enabled: boolean): void;
    /**
     * Retourne les statistiques des GSI avec analyse de performance
     */
    static getGSIStats(): Record<string, any>;
    /**
     * Analyse la configuration actuelle et suggère des améliorations
     */
    static analyzeCurrentConfiguration(): ConfigurationAnalysis;
    /**
     * Génère des recommandations d'optimisation
     */
    private static generateOptimizationRecommendations;
    /**
     * Simule l'impact d'un changement de priorité
     */
    static simulatePriorityChange(changes: PriorityChange[]): SimulationResult;
    private static calculateEstimatedImpact;
    private static validateConfiguration;
}
export {};

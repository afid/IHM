"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
/**
 * **Feature: decision-engine, Property 4: Rule persistence with weights**
 * **Validates: Requirements 2.1**
 *
 * Property: For any qualification rule with an associated weight, storing the rule
 * should preserve both the rule definition and its weight value
 */
// Mock DynamoDB for property testing
const mockSend = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => ({
    DynamoDBClient: jest.fn().mockImplementation(() => ({}))
}));
jest.mock('@aws-sdk/lib-dynamodb', () => ({
    DynamoDBDocumentClient: {
        from: jest.fn().mockReturnValue({ send: mockSend })
    },
    ScanCommand: jest.fn().mockImplementation((params) => params),
    PutCommand: jest.fn().mockImplementation((params) => params)
}));
describe('Property Test: Rule Persistence with Weights', () => {
    beforeEach(() => {
        // Reset mocks before each test
        jest.clearAllMocks();
        mockSend.mockReset();
    });
    /**
     * Property: Rule persistence round-trip consistency
     * For any qualification rule with weight, storing then loading should preserve
     * all rule properties including the weight value
     */
    test('should preserve rule definition and weight through store-load cycle', async () => {
        // Manual property testing: Generate multiple test cases to simulate property-based testing
        const generateRule = (id, weight, expression) => ({
            id,
            name: `Test Rule ${id}`,
            expression,
            weight,
            distributionSegment: `segment-${id}`
        });
        // Test cases representing different rule scenarios (simulating property-based testing)
        const testExpressions = [
            'NouveauSinistre == true',
            'Client == "VIP"',
            'Score > 80',
            'NouveauSinistre == true && Client == "VIP"',
            'Score > 50 && Client != "BASIC"',
            'Type == "PREMIUM" || Score > 90',
            '(NouveauSinistre == true || Score > 75) && Client == "VIP"',
            'Status == "ACTIVE" && (Type == "GOLD" || Type == "PLATINUM")'
        ];
        const weightRanges = [
            1, // Minimum weight
            10, // Low weight
            50, // Medium weight
            100, // High weight
            999, // Maximum weight
            42, // Random weight
            77, // Another random weight
            123 // Another random weight
        ];
        // Run property test for 100 iterations as specified
        for (let iteration = 0; iteration < 100; iteration++) {
            const expressionIndex = iteration % testExpressions.length;
            const weightIndex = iteration % weightRanges.length;
            const ruleToStore = generateRule(`rule-${iteration}`, weightRanges[weightIndex], testExpressions[expressionIndex]);
            // Mock successful storage
            mockSend.mockResolvedValueOnce({}); // PutCommand response
            // Mock successful loading - return the stored rule with timestamps
            const storedRule = {
                ...ruleToStore,
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            };
            mockSend.mockResolvedValueOnce({
                Items: [storedRule]
            }); // ScanCommand response
            // Create repository instance
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Store the rule
            await repository.addRule(ruleToStore);
            // Load rules from database
            const loadedRules = await repository.loadAllRules();
            // Property 1: Rule should be successfully stored and loaded
            expect(loadedRules).toHaveLength(1);
            const loadedRule = loadedRules[0];
            // Property 2: All original rule properties should be preserved
            expect(loadedRule.id).toBe(ruleToStore.id);
            expect(loadedRule.name).toBe(ruleToStore.name);
            expect(loadedRule.expression).toBe(ruleToStore.expression);
            expect(loadedRule.distributionSegment).toBe(ruleToStore.distributionSegment);
            // Property 3: Weight should be preserved exactly (critical for Requirements 2.1)
            expect(loadedRule.weight).toBe(ruleToStore.weight);
            expect(typeof loadedRule.weight).toBe('number');
            // Property 4: Timestamps should be added during storage
            expect(loadedRule.createdAt).toBeDefined();
            expect(loadedRule.updatedAt).toBeDefined();
            expect(typeof loadedRule.createdAt).toBe('string');
            expect(typeof loadedRule.updatedAt).toBe('string');
            // Property 5: PutCommand should be called with correct rule data including weight
            expect(mockSend).toHaveBeenCalledWith(expect.objectContaining({
                TableName: 'test-table',
                Item: expect.objectContaining({
                    id: ruleToStore.id,
                    name: ruleToStore.name,
                    expression: ruleToStore.expression,
                    weight: ruleToStore.weight,
                    distributionSegment: ruleToStore.distributionSegment,
                    createdAt: expect.any(String),
                    updatedAt: expect.any(String)
                })
            }));
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Weight precision preservation
     * For any numeric weight value, storage should preserve the exact numeric value
     */
    test('should preserve weight precision and type through persistence', async () => {
        // Test various weight values including edge cases
        const weightTestCases = [
            0, // Zero weight (edge case)
            1, // Minimum positive weight
            0.5, // Decimal weight
            10.25, // Decimal with precision
            99.99, // High decimal weight
            100, // Integer weight
            999, // Maximum weight
            42.123, // High precision decimal
            1.0, // Decimal that equals integer
            50.0 // Another decimal that equals integer
        ];
        // Run property test for each weight case (100 iterations total)
        for (let iteration = 0; iteration < 100; iteration++) {
            const weightIndex = iteration % weightTestCases.length;
            const testWeight = weightTestCases[weightIndex];
            const ruleToStore = {
                id: `weight-test-${iteration}`,
                name: `Weight Test Rule ${iteration}`,
                expression: 'NouveauSinistre == true',
                weight: testWeight,
                distributionSegment: `segment-${iteration}`
            };
            // Mock successful storage
            mockSend.mockResolvedValueOnce({});
            // Mock successful loading
            const storedRule = {
                ...ruleToStore,
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            };
            mockSend.mockResolvedValueOnce({
                Items: [storedRule]
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Store and load the rule
            await repository.addRule(ruleToStore);
            const loadedRules = await repository.loadAllRules();
            // Property: Weight value and type should be preserved exactly
            const loadedRule = loadedRules[0];
            expect(loadedRule.weight).toBe(testWeight);
            expect(loadedRule.weight).toStrictEqual(testWeight);
            expect(typeof loadedRule.weight).toBe('number');
            // Property: Weight should maintain mathematical properties
            if (testWeight > 0) {
                expect(loadedRule.weight).toBeGreaterThan(0);
            }
            if (testWeight === Math.floor(testWeight)) {
                expect(Number.isInteger(loadedRule.weight)).toBe(true);
            }
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Multiple rules with different weights persistence
     * For any set of rules with different weights, all weights should be preserved correctly
     */
    test('should preserve all weights when storing multiple rules', async () => {
        // Generate test cases with multiple rules having different weights
        const generateMultipleRules = (count) => {
            const rules = [];
            for (let i = 0; i < count; i++) {
                rules.push({
                    id: `multi-rule-${i}`,
                    name: `Multi Rule ${i}`,
                    expression: `Criterion${i} == true`,
                    weight: Math.floor(Math.random() * 1000) + 1, // Random weight 1-1000
                    distributionSegment: `segment-${i}`
                });
            }
            return rules;
        };
        // Test multiple scenarios with different rule counts (50 iterations)
        for (let iteration = 0; iteration < 50; iteration++) {
            const ruleCount = Math.floor(Math.random() * 8) + 2; // 2-9 rules
            const rulesToStore = generateMultipleRules(ruleCount);
            // Mock successful storage for each rule
            for (let i = 0; i < ruleCount; i++) {
                mockSend.mockResolvedValueOnce({});
            }
            // Mock successful loading - return all stored rules with timestamps
            const storedRules = rulesToStore.map(rule => ({
                ...rule,
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            }));
            mockSend.mockResolvedValueOnce({
                Items: storedRules
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Store all rules
            for (const rule of rulesToStore) {
                await repository.addRule(rule);
            }
            // Load all rules
            const loadedRules = await repository.loadAllRules();
            // Property 1: All rules should be loaded
            expect(loadedRules).toHaveLength(rulesToStore.length);
            // Property 2: All weights should be preserved
            const originalWeights = rulesToStore.map(r => r.weight).sort((a, b) => b - a);
            const loadedWeights = loadedRules.map(r => r.weight);
            // Since loadAllRules sorts by weight descending, compare sorted arrays
            expect(loadedWeights).toEqual(originalWeights);
            // Property 3: Each individual rule's weight should match
            for (const originalRule of rulesToStore) {
                const matchingLoadedRule = loadedRules.find(r => r.id === originalRule.id);
                expect(matchingLoadedRule).toBeDefined();
                expect(matchingLoadedRule.weight).toBe(originalRule.weight);
            }
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Storage error handling preserves data integrity
     * When storage operations fail, no partial data should be persisted
     */
    test('should handle storage errors without corrupting data integrity', async () => {
        const errorTypes = [
            new Error('DynamoDB write timeout'),
            new Error('Access denied'),
            new Error('Table not found'),
            new Error('Validation error'),
            new Error('Throttling exception'),
            new Error('Service unavailable'),
            new Error('Network error'),
            new Error('Resource limit exceeded')
        ];
        // Test error scenarios (50 iterations)
        for (let iteration = 0; iteration < 50; iteration++) {
            const errorIndex = iteration % errorTypes.length;
            const error = errorTypes[errorIndex];
            const ruleToStore = {
                id: `error-test-${iteration}`,
                name: `Error Test Rule ${iteration}`,
                expression: 'NouveauSinistre == true',
                weight: 50,
                distributionSegment: `segment-${iteration}`
            };
            // Mock storage failure
            mockSend.mockRejectedValueOnce(error);
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Property: Storage failure should throw meaningful error
            await expect(repository.addRule(ruleToStore)).rejects.toThrow(expect.stringContaining('Failed to add qualification rule'));
            // Property: Error should preserve original error information
            try {
                await repository.addRule(ruleToStore);
                fail('Expected error to be thrown');
            }
            catch (thrownError) {
                expect(thrownError).toBeInstanceOf(Error);
                expect(thrownError.message).toContain('Failed to add qualification rule');
            }
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Cache invalidation after rule persistence
     * After storing a new rule, the cache should be refreshed to include the new rule
     */
    test('should invalidate cache after rule persistence', async () => {
        const initialRules = [
            {
                id: 'existing-rule',
                name: 'Existing Rule',
                expression: 'Client == "VIP"',
                weight: 10,
                distributionSegment: 'existing-segment',
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            }
        ];
        const newRule = {
            id: 'new-rule',
            name: 'New Rule',
            expression: 'NouveauSinistre == true',
            weight: 20,
            distributionSegment: 'new-segment'
        };
        // Test cache invalidation (25 iterations)
        for (let iteration = 0; iteration < 25; iteration++) {
            // Mock initial load (cache population)
            mockSend.mockResolvedValueOnce({
                Items: initialRules
            });
            // Mock successful storage
            mockSend.mockResolvedValueOnce({});
            // Mock load after storage (should include new rule)
            const updatedRules = [
                ...initialRules,
                {
                    ...newRule,
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ].sort((a, b) => b.weight - a.weight);
            mockSend.mockResolvedValueOnce({
                Items: updatedRules
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Load initial rules (populate cache)
            const initialLoadedRules = await repository.loadAllRules();
            expect(initialLoadedRules).toHaveLength(1);
            // Add new rule (should invalidate cache)
            await repository.addRule(newRule);
            // Load rules again (should include new rule)
            const finalLoadedRules = await repository.loadAllRules();
            // Property: Cache should be invalidated and new rule should be included
            expect(finalLoadedRules).toHaveLength(2);
            // Property: New rule should be present with correct weight
            const addedRule = finalLoadedRules.find(r => r.id === newRule.id);
            expect(addedRule).toBeDefined();
            expect(addedRule.weight).toBe(newRule.weight);
            // Property: Rules should be sorted by weight (new rule has higher weight)
            expect(finalLoadedRules[0].weight).toBeGreaterThanOrEqual(finalLoadedRules[1].weight);
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVsZS1wZXJzaXN0ZW5jZS5wcm9wZXJ0eS50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3Rlc3RzL2RlY2lzaW9uLWVuZ2luZS9ydWxlLXBlcnNpc3RlbmNlLnByb3BlcnR5LnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxrRkFBK0U7QUFHL0U7Ozs7OztHQU1HO0FBRUgscUNBQXFDO0FBQ3JDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLDBCQUEwQixFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDM0MsY0FBYyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3pELENBQUMsQ0FBQyxDQUFDO0FBQ0osSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLHNCQUFzQixFQUFFO1FBQ3RCLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsZUFBZSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsV0FBVyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDO0lBQzdELFVBQVUsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQztDQUM3RCxDQUFDLENBQUMsQ0FBQztBQUVKLFFBQVEsQ0FBQyw4Q0FBOEMsRUFBRSxHQUFHLEVBQUU7SUFDNUQsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLCtCQUErQjtRQUMvQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQyxxRUFBcUUsRUFBRSxLQUFLLElBQUksRUFBRTtRQUNyRiwyRkFBMkY7UUFDM0YsTUFBTSxZQUFZLEdBQUcsQ0FBQyxFQUFVLEVBQUUsTUFBYyxFQUFFLFVBQWtCLEVBQXNELEVBQUUsQ0FBQyxDQUFDO1lBQzVILEVBQUU7WUFDRixJQUFJLEVBQUUsYUFBYSxFQUFFLEVBQUU7WUFDdkIsVUFBVTtZQUNWLE1BQU07WUFDTixtQkFBbUIsRUFBRSxXQUFXLEVBQUUsRUFBRTtTQUNyQyxDQUFDLENBQUM7UUFFSCx1RkFBdUY7UUFDdkYsTUFBTSxlQUFlLEdBQUc7WUFDdEIseUJBQXlCO1lBQ3pCLGlCQUFpQjtZQUNqQixZQUFZO1lBQ1osNENBQTRDO1lBQzVDLGlDQUFpQztZQUNqQyxpQ0FBaUM7WUFDakMsNERBQTREO1lBQzVELDhEQUE4RDtTQUMvRCxDQUFDO1FBRUYsTUFBTSxZQUFZLEdBQUc7WUFDbkIsQ0FBQyxFQUFZLGlCQUFpQjtZQUM5QixFQUFFLEVBQVcsYUFBYTtZQUMxQixFQUFFLEVBQVcsZ0JBQWdCO1lBQzdCLEdBQUcsRUFBVSxjQUFjO1lBQzNCLEdBQUcsRUFBVSxpQkFBaUI7WUFDOUIsRUFBRSxFQUFXLGdCQUFnQjtZQUM3QixFQUFFLEVBQVcsd0JBQXdCO1lBQ3JDLEdBQUcsQ0FBVSx3QkFBd0I7U0FDdEMsQ0FBQztRQUVGLG9EQUFvRDtRQUNwRCxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDckQsTUFBTSxlQUFlLEdBQUcsU0FBUyxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUM7WUFDM0QsTUFBTSxXQUFXLEdBQUcsU0FBUyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUM7WUFFcEQsTUFBTSxXQUFXLEdBQUcsWUFBWSxDQUM5QixRQUFRLFNBQVMsRUFBRSxFQUNuQixZQUFZLENBQUMsV0FBVyxDQUFDLEVBQ3pCLGVBQWUsQ0FBQyxlQUFlLENBQUMsQ0FDakMsQ0FBQztZQUVGLDBCQUEwQjtZQUMxQixRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxzQkFBc0I7WUFFMUQsbUVBQW1FO1lBQ25FLE1BQU0sVUFBVSxHQUFzQjtnQkFDcEMsR0FBRyxXQUFXO2dCQUNkLFNBQVMsRUFBRSwwQkFBMEI7Z0JBQ3JDLFNBQVMsRUFBRSwwQkFBMEI7YUFDdEMsQ0FBQztZQUVGLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0IsS0FBSyxFQUFFLENBQUMsVUFBVSxDQUFDO2FBQ3BCLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUUzQiw2QkFBNkI7WUFDN0IsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRXBELGlCQUFpQjtZQUNqQixNQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFdEMsMkJBQTJCO1lBQzNCLE1BQU0sV0FBVyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRXBELDREQUE0RDtZQUM1RCxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sVUFBVSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVsQywrREFBK0Q7WUFDL0QsTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzNDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMvQyxNQUFNLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0QsTUFBTSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUU3RSxpRkFBaUY7WUFDakYsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFaEQsd0RBQXdEO1lBQ3hELE1BQU0sQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0MsTUFBTSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMzQyxNQUFNLENBQUMsT0FBTyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxPQUFPLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFbkQsa0ZBQWtGO1lBQ2xGLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxvQkFBb0IsQ0FDbkMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO2dCQUN0QixTQUFTLEVBQUUsWUFBWTtnQkFDdkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDNUIsRUFBRSxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUNsQixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUk7b0JBQ3RCLFVBQVUsRUFBRSxXQUFXLENBQUMsVUFBVTtvQkFDbEMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxNQUFNO29CQUMxQixtQkFBbUIsRUFBRSxXQUFXLENBQUMsbUJBQW1CO29CQUNwRCxTQUFTLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7b0JBQzdCLFNBQVMsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztpQkFDOUIsQ0FBQzthQUNILENBQUMsQ0FDSCxDQUFDO1lBRUYsaUNBQWlDO1lBQ2pDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSDs7O09BR0c7SUFDSCxJQUFJLENBQUMsK0RBQStELEVBQUUsS0FBSyxJQUFJLEVBQUU7UUFDL0Usa0RBQWtEO1FBQ2xELE1BQU0sZUFBZSxHQUFHO1lBQ3RCLENBQUMsRUFBWSwwQkFBMEI7WUFDdkMsQ0FBQyxFQUFZLDBCQUEwQjtZQUN2QyxHQUFHLEVBQVUsaUJBQWlCO1lBQzlCLEtBQUssRUFBUSx5QkFBeUI7WUFDdEMsS0FBSyxFQUFRLHNCQUFzQjtZQUNuQyxHQUFHLEVBQVUsaUJBQWlCO1lBQzlCLEdBQUcsRUFBVSxpQkFBaUI7WUFDOUIsTUFBTSxFQUFPLHlCQUF5QjtZQUN0QyxHQUFHLEVBQVUsOEJBQThCO1lBQzNDLElBQUksQ0FBUyxzQ0FBc0M7U0FDcEQsQ0FBQztRQUVGLGdFQUFnRTtRQUNoRSxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDckQsTUFBTSxXQUFXLEdBQUcsU0FBUyxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUM7WUFDdkQsTUFBTSxVQUFVLEdBQUcsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRWhELE1BQU0sV0FBVyxHQUF1RDtnQkFDdEUsRUFBRSxFQUFFLGVBQWUsU0FBUyxFQUFFO2dCQUM5QixJQUFJLEVBQUUsb0JBQW9CLFNBQVMsRUFBRTtnQkFDckMsVUFBVSxFQUFFLHlCQUF5QjtnQkFDckMsTUFBTSxFQUFFLFVBQVU7Z0JBQ2xCLG1CQUFtQixFQUFFLFdBQVcsU0FBUyxFQUFFO2FBQzVDLENBQUM7WUFFRiwwQkFBMEI7WUFDMUIsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRW5DLDBCQUEwQjtZQUMxQixNQUFNLFVBQVUsR0FBc0I7Z0JBQ3BDLEdBQUcsV0FBVztnQkFDZCxTQUFTLEVBQUUsMEJBQTBCO2dCQUNyQyxTQUFTLEVBQUUsMEJBQTBCO2FBQ3RDLENBQUM7WUFFRixRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQzthQUNwQixDQUFDLENBQUM7WUFFSCxNQUFNLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFcEQsMEJBQTBCO1lBQzFCLE1BQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUN0QyxNQUFNLFdBQVcsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVwRCw4REFBOEQ7WUFDOUQsTUFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2xDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzNDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3BELE1BQU0sQ0FBQyxPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFaEQsMkRBQTJEO1lBQzNELElBQUksVUFBVSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNuQixNQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMvQyxDQUFDO1lBQ0QsSUFBSSxVQUFVLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO2dCQUMxQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDekQsQ0FBQztZQUVELGlDQUFpQztZQUNqQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUg7OztPQUdHO0lBQ0gsSUFBSSxDQUFDLHlEQUF5RCxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQ3pFLG1FQUFtRTtRQUNuRSxNQUFNLHFCQUFxQixHQUFHLENBQUMsS0FBYSxFQUE2RCxFQUFFO1lBQ3pHLE1BQU0sS0FBSyxHQUE4RCxFQUFFLENBQUM7WUFDNUUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUMvQixLQUFLLENBQUMsSUFBSSxDQUFDO29CQUNULEVBQUUsRUFBRSxjQUFjLENBQUMsRUFBRTtvQkFDckIsSUFBSSxFQUFFLGNBQWMsQ0FBQyxFQUFFO29CQUN2QixVQUFVLEVBQUUsWUFBWSxDQUFDLFVBQVU7b0JBQ25DLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsdUJBQXVCO29CQUNyRSxtQkFBbUIsRUFBRSxXQUFXLENBQUMsRUFBRTtpQkFDcEMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUNELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQyxDQUFDO1FBRUYscUVBQXFFO1FBQ3JFLEtBQUssSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZO1lBQ2pFLE1BQU0sWUFBWSxHQUFHLHFCQUFxQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRXRELHdDQUF3QztZQUN4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ25DLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyQyxDQUFDO1lBRUQsb0VBQW9FO1lBQ3BFLE1BQU0sV0FBVyxHQUF3QixZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakUsR0FBRyxJQUFJO2dCQUNQLFNBQVMsRUFBRSwwQkFBMEI7Z0JBQ3JDLFNBQVMsRUFBRSwwQkFBMEI7YUFDdEMsQ0FBQyxDQUFDLENBQUM7WUFFSixRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxXQUFXO2FBQ25CLENBQUMsQ0FBQztZQUVILE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVwRCxrQkFBa0I7WUFDbEIsS0FBSyxNQUFNLElBQUksSUFBSSxZQUFZLEVBQUUsQ0FBQztnQkFDaEMsTUFBTSxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2pDLENBQUM7WUFFRCxpQkFBaUI7WUFDakIsTUFBTSxXQUFXLEdBQUcsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFFcEQseUNBQXlDO1lBQ3pDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXRELDhDQUE4QztZQUM5QyxNQUFNLGVBQWUsR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM5RSxNQUFNLGFBQWEsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXJELHVFQUF1RTtZQUN2RSxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBRS9DLHlEQUF5RDtZQUN6RCxLQUFLLE1BQU0sWUFBWSxJQUFJLFlBQVksRUFBRSxDQUFDO2dCQUN4QyxNQUFNLGtCQUFrQixHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDM0UsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sQ0FBQyxrQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELENBQUM7WUFFRCxpQ0FBaUM7WUFDakMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVIOzs7T0FHRztJQUNILElBQUksQ0FBQyxnRUFBZ0UsRUFBRSxLQUFLLElBQUksRUFBRTtRQUNoRixNQUFNLFVBQVUsR0FBRztZQUNqQixJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQztZQUNuQyxJQUFJLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDMUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDNUIsSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUM7WUFDN0IsSUFBSSxLQUFLLENBQUMsc0JBQXNCLENBQUM7WUFDakMsSUFBSSxLQUFLLENBQUMscUJBQXFCLENBQUM7WUFDaEMsSUFBSSxLQUFLLENBQUMsZUFBZSxDQUFDO1lBQzFCLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDO1NBQ3JDLENBQUM7UUFFRix1Q0FBdUM7UUFDdkMsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3BELE1BQU0sVUFBVSxHQUFHLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQ2pELE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUVyQyxNQUFNLFdBQVcsR0FBdUQ7Z0JBQ3RFLEVBQUUsRUFBRSxjQUFjLFNBQVMsRUFBRTtnQkFDN0IsSUFBSSxFQUFFLG1CQUFtQixTQUFTLEVBQUU7Z0JBQ3BDLFVBQVUsRUFBRSx5QkFBeUI7Z0JBQ3JDLE1BQU0sRUFBRSxFQUFFO2dCQUNWLG1CQUFtQixFQUFFLFdBQVcsU0FBUyxFQUFFO2FBQzVDLENBQUM7WUFFRix1QkFBdUI7WUFDdkIsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXRDLE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVwRCwwREFBMEQ7WUFDMUQsTUFBTSxNQUFNLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQzNELE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUM1RCxDQUFDO1lBRUYsNkRBQTZEO1lBQzdELElBQUksQ0FBQztnQkFDSCxNQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1lBQ3RDLENBQUM7WUFBQyxPQUFPLFdBQVcsRUFBRSxDQUFDO2dCQUNyQixNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMxQyxNQUFNLENBQUUsV0FBcUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsa0NBQWtDLENBQUMsQ0FBQztZQUN2RixDQUFDO1lBRUQsaUNBQWlDO1lBQ2pDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSDs7O09BR0c7SUFDSCxJQUFJLENBQUMsZ0RBQWdELEVBQUUsS0FBSyxJQUFJLEVBQUU7UUFDaEUsTUFBTSxZQUFZLEdBQXdCO1lBQ3hDO2dCQUNFLEVBQUUsRUFBRSxlQUFlO2dCQUNuQixJQUFJLEVBQUUsZUFBZTtnQkFDckIsVUFBVSxFQUFFLGlCQUFpQjtnQkFDN0IsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsbUJBQW1CLEVBQUUsa0JBQWtCO2dCQUN2QyxTQUFTLEVBQUUsMEJBQTBCO2dCQUNyQyxTQUFTLEVBQUUsMEJBQTBCO2FBQ3RDO1NBQ0YsQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUF1RDtZQUNsRSxFQUFFLEVBQUUsVUFBVTtZQUNkLElBQUksRUFBRSxVQUFVO1lBQ2hCLFVBQVUsRUFBRSx5QkFBeUI7WUFDckMsTUFBTSxFQUFFLEVBQUU7WUFDVixtQkFBbUIsRUFBRSxhQUFhO1NBQ25DLENBQUM7UUFFRiwwQ0FBMEM7UUFDMUMsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3BELHVDQUF1QztZQUN2QyxRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxZQUFZO2FBQ3BCLENBQUMsQ0FBQztZQUVILDBCQUEwQjtZQUMxQixRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUM7WUFFbkMsb0RBQW9EO1lBQ3BELE1BQU0sWUFBWSxHQUFHO2dCQUNuQixHQUFHLFlBQVk7Z0JBQ2Y7b0JBQ0UsR0FBRyxPQUFPO29CQUNWLFNBQVMsRUFBRSwwQkFBMEI7b0JBQ3JDLFNBQVMsRUFBRSwwQkFBMEI7aUJBQ3RDO2FBQ0YsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0QyxRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxZQUFZO2FBQ3BCLENBQUMsQ0FBQztZQUVILE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVwRCxzQ0FBc0M7WUFDdEMsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUMzRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFM0MseUNBQXlDO1lBQ3pDLE1BQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVsQyw2Q0FBNkM7WUFDN0MsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUV6RCx3RUFBd0U7WUFDeEUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXpDLDJEQUEyRDtZQUMzRCxNQUFNLFNBQVMsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNsRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDaEMsTUFBTSxDQUFDLFNBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRS9DLDBFQUEwRTtZQUMxRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFdEYsaUNBQWlDO1lBQ2pDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJ1bGVSZXBvc2l0b3J5IH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL1J1bGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgUXVhbGlmaWNhdGlvblJ1bGUgfSBmcm9tICcuLi8uLi90eXBlcy9kZWNpc2lvbi1lbmdpbmUnO1xyXG5cclxuLyoqXHJcbiAqICoqRmVhdHVyZTogZGVjaXNpb24tZW5naW5lLCBQcm9wZXJ0eSA0OiBSdWxlIHBlcnNpc3RlbmNlIHdpdGggd2VpZ2h0cyoqXHJcbiAqICoqVmFsaWRhdGVzOiBSZXF1aXJlbWVudHMgMi4xKipcclxuICogXHJcbiAqIFByb3BlcnR5OiBGb3IgYW55IHF1YWxpZmljYXRpb24gcnVsZSB3aXRoIGFuIGFzc29jaWF0ZWQgd2VpZ2h0LCBzdG9yaW5nIHRoZSBydWxlIFxyXG4gKiBzaG91bGQgcHJlc2VydmUgYm90aCB0aGUgcnVsZSBkZWZpbml0aW9uIGFuZCBpdHMgd2VpZ2h0IHZhbHVlXHJcbiAqL1xyXG5cclxuLy8gTW9jayBEeW5hbW9EQiBmb3IgcHJvcGVydHkgdGVzdGluZ1xyXG5jb25zdCBtb2NrU2VuZCA9IGplc3QuZm4oKTtcclxuamVzdC5tb2NrKCdAYXdzLXNkay9jbGllbnQtZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCQ2xpZW50OiBqZXN0LmZuKCkubW9ja0ltcGxlbWVudGF0aW9uKCgpID0+ICh7fSkpXHJcbn0pKTtcclxuamVzdC5tb2NrKCdAYXdzLXNkay9saWItZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCRG9jdW1lbnRDbGllbnQ6IHtcclxuICAgIGZyb206IGplc3QuZm4oKS5tb2NrUmV0dXJuVmFsdWUoeyBzZW5kOiBtb2NrU2VuZCB9KVxyXG4gIH0sXHJcbiAgU2NhbkNvbW1hbmQ6IGplc3QuZm4oKS5tb2NrSW1wbGVtZW50YXRpb24oKHBhcmFtcykgPT4gcGFyYW1zKSxcclxuICBQdXRDb21tYW5kOiBqZXN0LmZuKCkubW9ja0ltcGxlbWVudGF0aW9uKChwYXJhbXMpID0+IHBhcmFtcylcclxufSkpO1xyXG5cclxuZGVzY3JpYmUoJ1Byb3BlcnR5IFRlc3Q6IFJ1bGUgUGVyc2lzdGVuY2Ugd2l0aCBXZWlnaHRzJywgKCkgPT4ge1xyXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgLy8gUmVzZXQgbW9ja3MgYmVmb3JlIGVhY2ggdGVzdFxyXG4gICAgamVzdC5jbGVhckFsbE1vY2tzKCk7XHJcbiAgICBtb2NrU2VuZC5tb2NrUmVzZXQoKTtcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IFJ1bGUgcGVyc2lzdGVuY2Ugcm91bmQtdHJpcCBjb25zaXN0ZW5jeVxyXG4gICAqIEZvciBhbnkgcXVhbGlmaWNhdGlvbiBydWxlIHdpdGggd2VpZ2h0LCBzdG9yaW5nIHRoZW4gbG9hZGluZyBzaG91bGQgcHJlc2VydmUgXHJcbiAgICogYWxsIHJ1bGUgcHJvcGVydGllcyBpbmNsdWRpbmcgdGhlIHdlaWdodCB2YWx1ZVxyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBwcmVzZXJ2ZSBydWxlIGRlZmluaXRpb24gYW5kIHdlaWdodCB0aHJvdWdoIHN0b3JlLWxvYWQgY3ljbGUnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBNYW51YWwgcHJvcGVydHkgdGVzdGluZzogR2VuZXJhdGUgbXVsdGlwbGUgdGVzdCBjYXNlcyB0byBzaW11bGF0ZSBwcm9wZXJ0eS1iYXNlZCB0ZXN0aW5nXHJcbiAgICBjb25zdCBnZW5lcmF0ZVJ1bGUgPSAoaWQ6IHN0cmluZywgd2VpZ2h0OiBudW1iZXIsIGV4cHJlc3Npb246IHN0cmluZyk6IE9taXQ8UXVhbGlmaWNhdGlvblJ1bGUsICdjcmVhdGVkQXQnIHwgJ3VwZGF0ZWRBdCc+ID0+ICh7XHJcbiAgICAgIGlkLFxyXG4gICAgICBuYW1lOiBgVGVzdCBSdWxlICR7aWR9YCxcclxuICAgICAgZXhwcmVzc2lvbixcclxuICAgICAgd2VpZ2h0LFxyXG4gICAgICBkaXN0cmlidXRpb25TZWdtZW50OiBgc2VnbWVudC0ke2lkfWBcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIFRlc3QgY2FzZXMgcmVwcmVzZW50aW5nIGRpZmZlcmVudCBydWxlIHNjZW5hcmlvcyAoc2ltdWxhdGluZyBwcm9wZXJ0eS1iYXNlZCB0ZXN0aW5nKVxyXG4gICAgY29uc3QgdGVzdEV4cHJlc3Npb25zID0gW1xyXG4gICAgICAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgICAnQ2xpZW50ID09IFwiVklQXCInLFxyXG4gICAgICAnU2NvcmUgPiA4MCcsXHJcbiAgICAgICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSAmJiBDbGllbnQgPT0gXCJWSVBcIicsXHJcbiAgICAgICdTY29yZSA+IDUwICYmIENsaWVudCAhPSBcIkJBU0lDXCInLFxyXG4gICAgICAnVHlwZSA9PSBcIlBSRU1JVU1cIiB8fCBTY29yZSA+IDkwJyxcclxuICAgICAgJyhOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSB8fCBTY29yZSA+IDc1KSAmJiBDbGllbnQgPT0gXCJWSVBcIicsXHJcbiAgICAgICdTdGF0dXMgPT0gXCJBQ1RJVkVcIiAmJiAoVHlwZSA9PSBcIkdPTERcIiB8fCBUeXBlID09IFwiUExBVElOVU1cIiknXHJcbiAgICBdO1xyXG5cclxuICAgIGNvbnN0IHdlaWdodFJhbmdlcyA9IFtcclxuICAgICAgMSwgICAgICAgICAgIC8vIE1pbmltdW0gd2VpZ2h0XHJcbiAgICAgIDEwLCAgICAgICAgICAvLyBMb3cgd2VpZ2h0XHJcbiAgICAgIDUwLCAgICAgICAgICAvLyBNZWRpdW0gd2VpZ2h0XHJcbiAgICAgIDEwMCwgICAgICAgICAvLyBIaWdoIHdlaWdodFxyXG4gICAgICA5OTksICAgICAgICAgLy8gTWF4aW11bSB3ZWlnaHRcclxuICAgICAgNDIsICAgICAgICAgIC8vIFJhbmRvbSB3ZWlnaHRcclxuICAgICAgNzcsICAgICAgICAgIC8vIEFub3RoZXIgcmFuZG9tIHdlaWdodFxyXG4gICAgICAxMjMgICAgICAgICAgLy8gQW5vdGhlciByYW5kb20gd2VpZ2h0XHJcbiAgICBdO1xyXG5cclxuICAgIC8vIFJ1biBwcm9wZXJ0eSB0ZXN0IGZvciAxMDAgaXRlcmF0aW9ucyBhcyBzcGVjaWZpZWRcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDEwMDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3QgZXhwcmVzc2lvbkluZGV4ID0gaXRlcmF0aW9uICUgdGVzdEV4cHJlc3Npb25zLmxlbmd0aDtcclxuICAgICAgY29uc3Qgd2VpZ2h0SW5kZXggPSBpdGVyYXRpb24gJSB3ZWlnaHRSYW5nZXMubGVuZ3RoO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgcnVsZVRvU3RvcmUgPSBnZW5lcmF0ZVJ1bGUoXHJcbiAgICAgICAgYHJ1bGUtJHtpdGVyYXRpb259YCxcclxuICAgICAgICB3ZWlnaHRSYW5nZXNbd2VpZ2h0SW5kZXhdLFxyXG4gICAgICAgIHRlc3RFeHByZXNzaW9uc1tleHByZXNzaW9uSW5kZXhdXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBNb2NrIHN1Y2Nlc3NmdWwgc3RvcmFnZVxyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe30pOyAvLyBQdXRDb21tYW5kIHJlc3BvbnNlXHJcbiAgICAgIFxyXG4gICAgICAvLyBNb2NrIHN1Y2Nlc3NmdWwgbG9hZGluZyAtIHJldHVybiB0aGUgc3RvcmVkIHJ1bGUgd2l0aCB0aW1lc3RhbXBzXHJcbiAgICAgIGNvbnN0IHN0b3JlZFJ1bGU6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnJ1bGVUb1N0b3JlLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWicsXHJcbiAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICB9O1xyXG4gICAgICBcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogW3N0b3JlZFJ1bGVdXHJcbiAgICAgIH0pOyAvLyBTY2FuQ29tbWFuZCByZXNwb25zZVxyXG5cclxuICAgICAgLy8gQ3JlYXRlIHJlcG9zaXRvcnkgaW5zdGFuY2VcclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG5cclxuICAgICAgLy8gU3RvcmUgdGhlIHJ1bGVcclxuICAgICAgYXdhaXQgcmVwb3NpdG9yeS5hZGRSdWxlKHJ1bGVUb1N0b3JlKTtcclxuXHJcbiAgICAgIC8vIExvYWQgcnVsZXMgZnJvbSBkYXRhYmFzZVxyXG4gICAgICBjb25zdCBsb2FkZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAxOiBSdWxlIHNob3VsZCBiZSBzdWNjZXNzZnVsbHkgc3RvcmVkIGFuZCBsb2FkZWRcclxuICAgICAgZXhwZWN0KGxvYWRlZFJ1bGVzKS50b0hhdmVMZW5ndGgoMSk7XHJcbiAgICAgIGNvbnN0IGxvYWRlZFJ1bGUgPSBsb2FkZWRSdWxlc1swXTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDI6IEFsbCBvcmlnaW5hbCBydWxlIHByb3BlcnRpZXMgc2hvdWxkIGJlIHByZXNlcnZlZFxyXG4gICAgICBleHBlY3QobG9hZGVkUnVsZS5pZCkudG9CZShydWxlVG9TdG9yZS5pZCk7XHJcbiAgICAgIGV4cGVjdChsb2FkZWRSdWxlLm5hbWUpLnRvQmUocnVsZVRvU3RvcmUubmFtZSk7XHJcbiAgICAgIGV4cGVjdChsb2FkZWRSdWxlLmV4cHJlc3Npb24pLnRvQmUocnVsZVRvU3RvcmUuZXhwcmVzc2lvbik7XHJcbiAgICAgIGV4cGVjdChsb2FkZWRSdWxlLmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmUocnVsZVRvU3RvcmUuZGlzdHJpYnV0aW9uU2VnbWVudCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBXZWlnaHQgc2hvdWxkIGJlIHByZXNlcnZlZCBleGFjdGx5IChjcml0aWNhbCBmb3IgUmVxdWlyZW1lbnRzIDIuMSlcclxuICAgICAgZXhwZWN0KGxvYWRlZFJ1bGUud2VpZ2h0KS50b0JlKHJ1bGVUb1N0b3JlLndlaWdodCk7XHJcbiAgICAgIGV4cGVjdCh0eXBlb2YgbG9hZGVkUnVsZS53ZWlnaHQpLnRvQmUoJ251bWJlcicpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNDogVGltZXN0YW1wcyBzaG91bGQgYmUgYWRkZWQgZHVyaW5nIHN0b3JhZ2VcclxuICAgICAgZXhwZWN0KGxvYWRlZFJ1bGUuY3JlYXRlZEF0KS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QobG9hZGVkUnVsZS51cGRhdGVkQXQpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdCh0eXBlb2YgbG9hZGVkUnVsZS5jcmVhdGVkQXQpLnRvQmUoJ3N0cmluZycpO1xyXG4gICAgICBleHBlY3QodHlwZW9mIGxvYWRlZFJ1bGUudXBkYXRlZEF0KS50b0JlKCdzdHJpbmcnKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDU6IFB1dENvbW1hbmQgc2hvdWxkIGJlIGNhbGxlZCB3aXRoIGNvcnJlY3QgcnVsZSBkYXRhIGluY2x1ZGluZyB3ZWlnaHRcclxuICAgICAgZXhwZWN0KG1vY2tTZW5kKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcclxuICAgICAgICBleHBlY3Qub2JqZWN0Q29udGFpbmluZyh7XHJcbiAgICAgICAgICBUYWJsZU5hbWU6ICd0ZXN0LXRhYmxlJyxcclxuICAgICAgICAgIEl0ZW06IGV4cGVjdC5vYmplY3RDb250YWluaW5nKHtcclxuICAgICAgICAgICAgaWQ6IHJ1bGVUb1N0b3JlLmlkLFxyXG4gICAgICAgICAgICBuYW1lOiBydWxlVG9TdG9yZS5uYW1lLFxyXG4gICAgICAgICAgICBleHByZXNzaW9uOiBydWxlVG9TdG9yZS5leHByZXNzaW9uLFxyXG4gICAgICAgICAgICB3ZWlnaHQ6IHJ1bGVUb1N0b3JlLndlaWdodCxcclxuICAgICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogcnVsZVRvU3RvcmUuZGlzdHJpYnV0aW9uU2VnbWVudCxcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiBleHBlY3QuYW55KFN0cmluZyksXHJcbiAgICAgICAgICAgIHVwZGF0ZWRBdDogZXhwZWN0LmFueShTdHJpbmcpXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrcyBmb3IgbmV4dCBpdGVyYXRpb25cclxuICAgICAgbW9ja1NlbmQubW9ja0NsZWFyKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBXZWlnaHQgcHJlY2lzaW9uIHByZXNlcnZhdGlvblxyXG4gICAqIEZvciBhbnkgbnVtZXJpYyB3ZWlnaHQgdmFsdWUsIHN0b3JhZ2Ugc2hvdWxkIHByZXNlcnZlIHRoZSBleGFjdCBudW1lcmljIHZhbHVlXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIHByZXNlcnZlIHdlaWdodCBwcmVjaXNpb24gYW5kIHR5cGUgdGhyb3VnaCBwZXJzaXN0ZW5jZScsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIFRlc3QgdmFyaW91cyB3ZWlnaHQgdmFsdWVzIGluY2x1ZGluZyBlZGdlIGNhc2VzXHJcbiAgICBjb25zdCB3ZWlnaHRUZXN0Q2FzZXMgPSBbXHJcbiAgICAgIDAsICAgICAgICAgICAvLyBaZXJvIHdlaWdodCAoZWRnZSBjYXNlKVxyXG4gICAgICAxLCAgICAgICAgICAgLy8gTWluaW11bSBwb3NpdGl2ZSB3ZWlnaHRcclxuICAgICAgMC41LCAgICAgICAgIC8vIERlY2ltYWwgd2VpZ2h0XHJcbiAgICAgIDEwLjI1LCAgICAgICAvLyBEZWNpbWFsIHdpdGggcHJlY2lzaW9uXHJcbiAgICAgIDk5Ljk5LCAgICAgICAvLyBIaWdoIGRlY2ltYWwgd2VpZ2h0XHJcbiAgICAgIDEwMCwgICAgICAgICAvLyBJbnRlZ2VyIHdlaWdodFxyXG4gICAgICA5OTksICAgICAgICAgLy8gTWF4aW11bSB3ZWlnaHRcclxuICAgICAgNDIuMTIzLCAgICAgIC8vIEhpZ2ggcHJlY2lzaW9uIGRlY2ltYWxcclxuICAgICAgMS4wLCAgICAgICAgIC8vIERlY2ltYWwgdGhhdCBlcXVhbHMgaW50ZWdlclxyXG4gICAgICA1MC4wICAgICAgICAgLy8gQW5vdGhlciBkZWNpbWFsIHRoYXQgZXF1YWxzIGludGVnZXJcclxuICAgIF07XHJcblxyXG4gICAgLy8gUnVuIHByb3BlcnR5IHRlc3QgZm9yIGVhY2ggd2VpZ2h0IGNhc2UgKDEwMCBpdGVyYXRpb25zIHRvdGFsKVxyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgMTAwOyBpdGVyYXRpb24rKykge1xyXG4gICAgICBjb25zdCB3ZWlnaHRJbmRleCA9IGl0ZXJhdGlvbiAlIHdlaWdodFRlc3RDYXNlcy5sZW5ndGg7XHJcbiAgICAgIGNvbnN0IHRlc3RXZWlnaHQgPSB3ZWlnaHRUZXN0Q2FzZXNbd2VpZ2h0SW5kZXhdO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgcnVsZVRvU3RvcmU6IE9taXQ8UXVhbGlmaWNhdGlvblJ1bGUsICdjcmVhdGVkQXQnIHwgJ3VwZGF0ZWRBdCc+ID0ge1xyXG4gICAgICAgIGlkOiBgd2VpZ2h0LXRlc3QtJHtpdGVyYXRpb259YCxcclxuICAgICAgICBuYW1lOiBgV2VpZ2h0IFRlc3QgUnVsZSAke2l0ZXJhdGlvbn1gLFxyXG4gICAgICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZScsXHJcbiAgICAgICAgd2VpZ2h0OiB0ZXN0V2VpZ2h0LFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6IGBzZWdtZW50LSR7aXRlcmF0aW9ufWBcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIE1vY2sgc3VjY2Vzc2Z1bCBzdG9yYWdlXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7fSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBNb2NrIHN1Y2Nlc3NmdWwgbG9hZGluZ1xyXG4gICAgICBjb25zdCBzdG9yZWRSdWxlOiBRdWFsaWZpY2F0aW9uUnVsZSA9IHtcclxuICAgICAgICAuLi5ydWxlVG9TdG9yZSxcclxuICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonLFxyXG4gICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWidcclxuICAgICAgfTtcclxuICAgICAgXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgICAgSXRlbXM6IFtzdG9yZWRSdWxlXVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuXHJcbiAgICAgIC8vIFN0b3JlIGFuZCBsb2FkIHRoZSBydWxlXHJcbiAgICAgIGF3YWl0IHJlcG9zaXRvcnkuYWRkUnVsZShydWxlVG9TdG9yZSk7XHJcbiAgICAgIGNvbnN0IGxvYWRlZFJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5OiBXZWlnaHQgdmFsdWUgYW5kIHR5cGUgc2hvdWxkIGJlIHByZXNlcnZlZCBleGFjdGx5XHJcbiAgICAgIGNvbnN0IGxvYWRlZFJ1bGUgPSBsb2FkZWRSdWxlc1swXTtcclxuICAgICAgZXhwZWN0KGxvYWRlZFJ1bGUud2VpZ2h0KS50b0JlKHRlc3RXZWlnaHQpO1xyXG4gICAgICBleHBlY3QobG9hZGVkUnVsZS53ZWlnaHQpLnRvU3RyaWN0RXF1YWwodGVzdFdlaWdodCk7XHJcbiAgICAgIGV4cGVjdCh0eXBlb2YgbG9hZGVkUnVsZS53ZWlnaHQpLnRvQmUoJ251bWJlcicpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IFdlaWdodCBzaG91bGQgbWFpbnRhaW4gbWF0aGVtYXRpY2FsIHByb3BlcnRpZXNcclxuICAgICAgaWYgKHRlc3RXZWlnaHQgPiAwKSB7XHJcbiAgICAgICAgZXhwZWN0KGxvYWRlZFJ1bGUud2VpZ2h0KS50b0JlR3JlYXRlclRoYW4oMCk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHRlc3RXZWlnaHQgPT09IE1hdGguZmxvb3IodGVzdFdlaWdodCkpIHtcclxuICAgICAgICBleHBlY3QoTnVtYmVyLmlzSW50ZWdlcihsb2FkZWRSdWxlLndlaWdodCkpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IE11bHRpcGxlIHJ1bGVzIHdpdGggZGlmZmVyZW50IHdlaWdodHMgcGVyc2lzdGVuY2VcclxuICAgKiBGb3IgYW55IHNldCBvZiBydWxlcyB3aXRoIGRpZmZlcmVudCB3ZWlnaHRzLCBhbGwgd2VpZ2h0cyBzaG91bGQgYmUgcHJlc2VydmVkIGNvcnJlY3RseVxyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBwcmVzZXJ2ZSBhbGwgd2VpZ2h0cyB3aGVuIHN0b3JpbmcgbXVsdGlwbGUgcnVsZXMnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBHZW5lcmF0ZSB0ZXN0IGNhc2VzIHdpdGggbXVsdGlwbGUgcnVsZXMgaGF2aW5nIGRpZmZlcmVudCB3ZWlnaHRzXHJcbiAgICBjb25zdCBnZW5lcmF0ZU11bHRpcGxlUnVsZXMgPSAoY291bnQ6IG51bWJlcik6IEFycmF5PE9taXQ8UXVhbGlmaWNhdGlvblJ1bGUsICdjcmVhdGVkQXQnIHwgJ3VwZGF0ZWRBdCc+PiA9PiB7XHJcbiAgICAgIGNvbnN0IHJ1bGVzOiBBcnJheTxPbWl0PFF1YWxpZmljYXRpb25SdWxlLCAnY3JlYXRlZEF0JyB8ICd1cGRhdGVkQXQnPj4gPSBbXTtcclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XHJcbiAgICAgICAgcnVsZXMucHVzaCh7XHJcbiAgICAgICAgICBpZDogYG11bHRpLXJ1bGUtJHtpfWAsXHJcbiAgICAgICAgICBuYW1lOiBgTXVsdGkgUnVsZSAke2l9YCxcclxuICAgICAgICAgIGV4cHJlc3Npb246IGBDcml0ZXJpb24ke2l9ID09IHRydWVgLFxyXG4gICAgICAgICAgd2VpZ2h0OiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDAwKSArIDEsIC8vIFJhbmRvbSB3ZWlnaHQgMS0xMDAwXHJcbiAgICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiBgc2VnbWVudC0ke2l9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBydWxlcztcclxuICAgIH07XHJcblxyXG4gICAgLy8gVGVzdCBtdWx0aXBsZSBzY2VuYXJpb3Mgd2l0aCBkaWZmZXJlbnQgcnVsZSBjb3VudHMgKDUwIGl0ZXJhdGlvbnMpXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCA1MDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3QgcnVsZUNvdW50ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogOCkgKyAyOyAvLyAyLTkgcnVsZXNcclxuICAgICAgY29uc3QgcnVsZXNUb1N0b3JlID0gZ2VuZXJhdGVNdWx0aXBsZVJ1bGVzKHJ1bGVDb3VudCk7XHJcblxyXG4gICAgICAvLyBNb2NrIHN1Y2Nlc3NmdWwgc3RvcmFnZSBmb3IgZWFjaCBydWxlXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcnVsZUNvdW50OyBpKyspIHtcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe30pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBNb2NrIHN1Y2Nlc3NmdWwgbG9hZGluZyAtIHJldHVybiBhbGwgc3RvcmVkIHJ1bGVzIHdpdGggdGltZXN0YW1wc1xyXG4gICAgICBjb25zdCBzdG9yZWRSdWxlczogUXVhbGlmaWNhdGlvblJ1bGVbXSA9IHJ1bGVzVG9TdG9yZS5tYXAocnVsZSA9PiAoe1xyXG4gICAgICAgIC4uLnJ1bGUsXHJcbiAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonXHJcbiAgICAgIH0pKTtcclxuICAgICAgXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgICAgSXRlbXM6IHN0b3JlZFJ1bGVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG5cclxuICAgICAgLy8gU3RvcmUgYWxsIHJ1bGVzXHJcbiAgICAgIGZvciAoY29uc3QgcnVsZSBvZiBydWxlc1RvU3RvcmUpIHtcclxuICAgICAgICBhd2FpdCByZXBvc2l0b3J5LmFkZFJ1bGUocnVsZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIExvYWQgYWxsIHJ1bGVzXHJcbiAgICAgIGNvbnN0IGxvYWRlZFJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDE6IEFsbCBydWxlcyBzaG91bGQgYmUgbG9hZGVkXHJcbiAgICAgIGV4cGVjdChsb2FkZWRSdWxlcykudG9IYXZlTGVuZ3RoKHJ1bGVzVG9TdG9yZS5sZW5ndGgpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMjogQWxsIHdlaWdodHMgc2hvdWxkIGJlIHByZXNlcnZlZFxyXG4gICAgICBjb25zdCBvcmlnaW5hbFdlaWdodHMgPSBydWxlc1RvU3RvcmUubWFwKHIgPT4gci53ZWlnaHQpLnNvcnQoKGEsIGIpID0+IGIgLSBhKTtcclxuICAgICAgY29uc3QgbG9hZGVkV2VpZ2h0cyA9IGxvYWRlZFJ1bGVzLm1hcChyID0+IHIud2VpZ2h0KTtcclxuICAgICAgXHJcbiAgICAgIC8vIFNpbmNlIGxvYWRBbGxSdWxlcyBzb3J0cyBieSB3ZWlnaHQgZGVzY2VuZGluZywgY29tcGFyZSBzb3J0ZWQgYXJyYXlzXHJcbiAgICAgIGV4cGVjdChsb2FkZWRXZWlnaHRzKS50b0VxdWFsKG9yaWdpbmFsV2VpZ2h0cyk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBFYWNoIGluZGl2aWR1YWwgcnVsZSdzIHdlaWdodCBzaG91bGQgbWF0Y2hcclxuICAgICAgZm9yIChjb25zdCBvcmlnaW5hbFJ1bGUgb2YgcnVsZXNUb1N0b3JlKSB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hpbmdMb2FkZWRSdWxlID0gbG9hZGVkUnVsZXMuZmluZChyID0+IHIuaWQgPT09IG9yaWdpbmFsUnVsZS5pZCk7XHJcbiAgICAgICAgZXhwZWN0KG1hdGNoaW5nTG9hZGVkUnVsZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgICBleHBlY3QobWF0Y2hpbmdMb2FkZWRSdWxlIS53ZWlnaHQpLnRvQmUob3JpZ2luYWxSdWxlLndlaWdodCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IFN0b3JhZ2UgZXJyb3IgaGFuZGxpbmcgcHJlc2VydmVzIGRhdGEgaW50ZWdyaXR5XHJcbiAgICogV2hlbiBzdG9yYWdlIG9wZXJhdGlvbnMgZmFpbCwgbm8gcGFydGlhbCBkYXRhIHNob3VsZCBiZSBwZXJzaXN0ZWRcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgaGFuZGxlIHN0b3JhZ2UgZXJyb3JzIHdpdGhvdXQgY29ycnVwdGluZyBkYXRhIGludGVncml0eScsIGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGVycm9yVHlwZXMgPSBbXHJcbiAgICAgIG5ldyBFcnJvcignRHluYW1vREIgd3JpdGUgdGltZW91dCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ0FjY2VzcyBkZW5pZWQnKSxcclxuICAgICAgbmV3IEVycm9yKCdUYWJsZSBub3QgZm91bmQnKSxcclxuICAgICAgbmV3IEVycm9yKCdWYWxpZGF0aW9uIGVycm9yJyksXHJcbiAgICAgIG5ldyBFcnJvcignVGhyb3R0bGluZyBleGNlcHRpb24nKSxcclxuICAgICAgbmV3IEVycm9yKCdTZXJ2aWNlIHVuYXZhaWxhYmxlJyksXHJcbiAgICAgIG5ldyBFcnJvcignTmV0d29yayBlcnJvcicpLFxyXG4gICAgICBuZXcgRXJyb3IoJ1Jlc291cmNlIGxpbWl0IGV4Y2VlZGVkJylcclxuICAgIF07XHJcblxyXG4gICAgLy8gVGVzdCBlcnJvciBzY2VuYXJpb3MgKDUwIGl0ZXJhdGlvbnMpXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCA1MDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3QgZXJyb3JJbmRleCA9IGl0ZXJhdGlvbiAlIGVycm9yVHlwZXMubGVuZ3RoO1xyXG4gICAgICBjb25zdCBlcnJvciA9IGVycm9yVHlwZXNbZXJyb3JJbmRleF07XHJcblxyXG4gICAgICBjb25zdCBydWxlVG9TdG9yZTogT21pdDxRdWFsaWZpY2F0aW9uUnVsZSwgJ2NyZWF0ZWRBdCcgfCAndXBkYXRlZEF0Jz4gPSB7XHJcbiAgICAgICAgaWQ6IGBlcnJvci10ZXN0LSR7aXRlcmF0aW9ufWAsXHJcbiAgICAgICAgbmFtZTogYEVycm9yIFRlc3QgUnVsZSAke2l0ZXJhdGlvbn1gLFxyXG4gICAgICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZScsXHJcbiAgICAgICAgd2VpZ2h0OiA1MCxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiBgc2VnbWVudC0ke2l0ZXJhdGlvbn1gXHJcbiAgICAgIH07XHJcblxyXG4gICAgICAvLyBNb2NrIHN0b3JhZ2UgZmFpbHVyZVxyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVqZWN0ZWRWYWx1ZU9uY2UoZXJyb3IpO1xyXG5cclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IFN0b3JhZ2UgZmFpbHVyZSBzaG91bGQgdGhyb3cgbWVhbmluZ2Z1bCBlcnJvclxyXG4gICAgICBhd2FpdCBleHBlY3QocmVwb3NpdG9yeS5hZGRSdWxlKHJ1bGVUb1N0b3JlKSkucmVqZWN0cy50b1Rocm93KFxyXG4gICAgICAgIGV4cGVjdC5zdHJpbmdDb250YWluaW5nKCdGYWlsZWQgdG8gYWRkIHF1YWxpZmljYXRpb24gcnVsZScpXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogRXJyb3Igc2hvdWxkIHByZXNlcnZlIG9yaWdpbmFsIGVycm9yIGluZm9ybWF0aW9uXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5hZGRSdWxlKHJ1bGVUb1N0b3JlKTtcclxuICAgICAgICBmYWlsKCdFeHBlY3RlZCBlcnJvciB0byBiZSB0aHJvd24nKTtcclxuICAgICAgfSBjYXRjaCAodGhyb3duRXJyb3IpIHtcclxuICAgICAgICBleHBlY3QodGhyb3duRXJyb3IpLnRvQmVJbnN0YW5jZU9mKEVycm9yKTtcclxuICAgICAgICBleHBlY3QoKHRocm93bkVycm9yIGFzIEVycm9yKS5tZXNzYWdlKS50b0NvbnRhaW4oJ0ZhaWxlZCB0byBhZGQgcXVhbGlmaWNhdGlvbiBydWxlJyk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IENhY2hlIGludmFsaWRhdGlvbiBhZnRlciBydWxlIHBlcnNpc3RlbmNlXHJcbiAgICogQWZ0ZXIgc3RvcmluZyBhIG5ldyBydWxlLCB0aGUgY2FjaGUgc2hvdWxkIGJlIHJlZnJlc2hlZCB0byBpbmNsdWRlIHRoZSBuZXcgcnVsZVxyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBpbnZhbGlkYXRlIGNhY2hlIGFmdGVyIHJ1bGUgcGVyc2lzdGVuY2UnLCBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBpbml0aWFsUnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogJ2V4aXN0aW5nLXJ1bGUnLFxyXG4gICAgICAgIG5hbWU6ICdFeGlzdGluZyBSdWxlJyxcclxuICAgICAgICBleHByZXNzaW9uOiAnQ2xpZW50ID09IFwiVklQXCInLFxyXG4gICAgICAgIHdlaWdodDogMTAsXHJcbiAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ2V4aXN0aW5nLXNlZ21lbnQnLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWicsXHJcbiAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICB9XHJcbiAgICBdO1xyXG5cclxuICAgIGNvbnN0IG5ld1J1bGU6IE9taXQ8UXVhbGlmaWNhdGlvblJ1bGUsICdjcmVhdGVkQXQnIHwgJ3VwZGF0ZWRBdCc+ID0ge1xyXG4gICAgICBpZDogJ25ldy1ydWxlJyxcclxuICAgICAgbmFtZTogJ05ldyBSdWxlJyxcclxuICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJyxcclxuICAgICAgd2VpZ2h0OiAyMCxcclxuICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ25ldy1zZWdtZW50J1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBUZXN0IGNhY2hlIGludmFsaWRhdGlvbiAoMjUgaXRlcmF0aW9ucylcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDI1OyBpdGVyYXRpb24rKykge1xyXG4gICAgICAvLyBNb2NrIGluaXRpYWwgbG9hZCAoY2FjaGUgcG9wdWxhdGlvbilcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogaW5pdGlhbFJ1bGVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gTW9jayBzdWNjZXNzZnVsIHN0b3JhZ2VcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHt9KTtcclxuXHJcbiAgICAgIC8vIE1vY2sgbG9hZCBhZnRlciBzdG9yYWdlIChzaG91bGQgaW5jbHVkZSBuZXcgcnVsZSlcclxuICAgICAgY29uc3QgdXBkYXRlZFJ1bGVzID0gW1xyXG4gICAgICAgIC4uLmluaXRpYWxSdWxlcyxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAuLi5uZXdSdWxlLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWidcclxuICAgICAgICB9XHJcbiAgICAgIF0uc29ydCgoYSwgYikgPT4gYi53ZWlnaHQgLSBhLndlaWdodCk7XHJcblxyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xyXG4gICAgICAgIEl0ZW1zOiB1cGRhdGVkUnVsZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByZXBvc2l0b3J5ID0gbmV3IFJ1bGVSZXBvc2l0b3J5KCd0ZXN0LXRhYmxlJyk7XHJcblxyXG4gICAgICAvLyBMb2FkIGluaXRpYWwgcnVsZXMgKHBvcHVsYXRlIGNhY2hlKVxyXG4gICAgICBjb25zdCBpbml0aWFsTG9hZGVkUnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG4gICAgICBleHBlY3QoaW5pdGlhbExvYWRlZFJ1bGVzKS50b0hhdmVMZW5ndGgoMSk7XHJcblxyXG4gICAgICAvLyBBZGQgbmV3IHJ1bGUgKHNob3VsZCBpbnZhbGlkYXRlIGNhY2hlKVxyXG4gICAgICBhd2FpdCByZXBvc2l0b3J5LmFkZFJ1bGUobmV3UnVsZSk7XHJcblxyXG4gICAgICAvLyBMb2FkIHJ1bGVzIGFnYWluIChzaG91bGQgaW5jbHVkZSBuZXcgcnVsZSlcclxuICAgICAgY29uc3QgZmluYWxMb2FkZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogQ2FjaGUgc2hvdWxkIGJlIGludmFsaWRhdGVkIGFuZCBuZXcgcnVsZSBzaG91bGQgYmUgaW5jbHVkZWRcclxuICAgICAgZXhwZWN0KGZpbmFsTG9hZGVkUnVsZXMpLnRvSGF2ZUxlbmd0aCgyKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFByb3BlcnR5OiBOZXcgcnVsZSBzaG91bGQgYmUgcHJlc2VudCB3aXRoIGNvcnJlY3Qgd2VpZ2h0XHJcbiAgICAgIGNvbnN0IGFkZGVkUnVsZSA9IGZpbmFsTG9hZGVkUnVsZXMuZmluZChyID0+IHIuaWQgPT09IG5ld1J1bGUuaWQpO1xyXG4gICAgICBleHBlY3QoYWRkZWRSdWxlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QoYWRkZWRSdWxlIS53ZWlnaHQpLnRvQmUobmV3UnVsZS53ZWlnaHQpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IFJ1bGVzIHNob3VsZCBiZSBzb3J0ZWQgYnkgd2VpZ2h0IChuZXcgcnVsZSBoYXMgaGlnaGVyIHdlaWdodClcclxuICAgICAgZXhwZWN0KGZpbmFsTG9hZGVkUnVsZXNbMF0ud2VpZ2h0KS50b0JlR3JlYXRlclRoYW5PckVxdWFsKGZpbmFsTG9hZGVkUnVsZXNbMV0ud2VpZ2h0KTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxufSk7Il19
"use strict";
/**
 * Service de gestion des critères secondaires via AWS Systems Manager Parameter Store
 *
 * Fonctionnalités :
 * - Cache en mémoire avec TTL configurable
 * - Warm-up au démarrage pour éviter la latence du premier appel
 * - Refresh asynchrone pour maintenir le cache à jour sans bloquer
 * - Métriques de performance pour monitoring
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CriteriaParameterStore = void 0;
const client_ssm_1 = require("@aws-sdk/client-ssm");
class CriteriaParameterStore {
    /**
     * Obtient le client SSM (singleton) avec configuration optimisée
     */
    static getClient() {
        if (!this.ssmClient) {
            this.ssmClient = new client_ssm_1.SSMClient({
                maxAttempts: 2, // Réduire les retries (par défaut: 3)
                requestHandler: {
                    connectionTimeout: 1000, // 1s pour établir la connexion
                    requestTimeout: 3000 // 3s max pour la requête complète
                }
            });
        }
        return this.ssmClient;
    }
    /**
     * Configure le TTL du cache (en millisecondes)
     */
    static setCacheTTL(ttl) {
        this.cacheTTL = ttl;
        console.log(`✅ Cache TTL set to ${ttl}ms (${ttl / 1000}s)`);
    }
    /**
     * Charge tous les critères secondaires avec cache intelligent
     *
     * Stratégie :
     * 1. Si cache valide (< TTL) : retour immédiat
     * 2. Si cache périmé mais récent (< 2*TTL) : retour immédiat + refresh async
     * 3. Si cache trop vieux ou absent : refresh synchrone
     */
    static async loadAll() {
        const now = Date.now();
        const cacheAge = now - this.cacheTimestamp;
        // ✅ Cache valide : retour immédiat
        if (this.cache && cacheAge < this.cacheTTL) {
            this.metrics.hits++;
            console.log(`📦 Cache HIT (age: ${Math.round(cacheAge / 1000)}s, hits: ${this.metrics.hits})`);
            return this.cache;
        }
        // ✅ Cache périmé mais récent : retour immédiat + refresh async
        if (this.cache && cacheAge < this.STALE_CACHE_TTL) {
            this.metrics.hits++;
            console.log(`📦 Cache HIT (stale, age: ${Math.round(cacheAge / 1000)}s) - refreshing async`);
            // Refresh en arrière-plan sans bloquer
            this.refreshCacheAsync();
            return this.cache;
        }
        // ⚠️ Cache absent ou trop vieux : refresh synchrone
        this.metrics.misses++;
        console.log(`🌐 Cache MISS (age: ${Math.round(cacheAge / 1000)}s, misses: ${this.metrics.misses})`);
        return await this.refreshCache();
    }
    /**
     * Rafraîchit le cache de manière synchrone
     */
    static async refreshCache() {
        var _a, _b, _c;
        // Éviter les refresh concurrents
        if (this.isRefreshing) {
            console.log('[CACHE] Refresh already in progress, waiting...');
            // Attendre un peu et retourner le cache actuel si disponible
            await new Promise(resolve => setTimeout(resolve, 100));
            return this.cache || [];
        }
        this.isRefreshing = true;
        const startTime = Date.now();
        try {
            console.log('[CACHE] Refreshing criteria cache from Parameter Store...');
            console.log('[CACHE] Path:', this.PARAMETER_PATH);
            const client = this.getClient();
            console.log('[CACHE] SSM Client created:', !!client);
            const command = new client_ssm_1.GetParametersByPathCommand({
                Path: this.PARAMETER_PATH,
                Recursive: true,
                WithDecryption: false
            });
            console.log('[CACHE] Command created with input:', JSON.stringify(command.input));
            console.log('[CACHE] Sending command to SSM...');
            const result = await client.send(command);
            console.log('[CACHE] Command completed successfully');
            console.log('[CACHE] Raw parameters received:', ((_a = result.Parameters) === null || _a === void 0 ? void 0 : _a.length) || 0);
            console.log('[CACHE] Result structure:', JSON.stringify({
                hasParameters: !!result.Parameters,
                parametersIsArray: Array.isArray(result.Parameters),
                parametersLength: (_b = result.Parameters) === null || _b === void 0 ? void 0 : _b.length
            }));
            // Parser les paramètres
            const criteria = this.parseParameters(result.Parameters || []);
            console.log('[CACHE] Parsed criteria:', criteria.length);
            criteria.forEach(c => {
                console.log('[CACHE] Criterion:', c.name, 'enabled:', c.enabled);
            });
            // Mettre à jour le cache
            this.cache = criteria;
            this.cacheTimestamp = Date.now();
            // Métriques
            const duration = Date.now() - startTime;
            this.metrics.lastRefreshDuration = duration;
            this.metrics.lastRefreshTimestamp = this.cacheTimestamp;
            console.log('[CACHE] Cache refreshed:', criteria.length, 'criteria loaded in', duration, 'ms');
            return this.cache;
        }
        catch (error) {
            console.error('[ERROR] Failed to refresh cache from Parameter Store');
            console.error('[ERROR] Error type:', typeof error);
            console.error('[ERROR] Error name:', error === null || error === void 0 ? void 0 : error.name);
            console.error('[ERROR] Error message:', error === null || error === void 0 ? void 0 : error.message);
            console.error('[ERROR] Error code:', error === null || error === void 0 ? void 0 : error.code);
            console.error('[ERROR] Error statusCode:', (_c = error === null || error === void 0 ? void 0 : error.$metadata) === null || _c === void 0 ? void 0 : _c.httpStatusCode);
            console.error('[ERROR] Error stack:', error === null || error === void 0 ? void 0 : error.stack);
            // Serialiser l'erreur complète
            try {
                const errorDetails = JSON.stringify(error, Object.getOwnPropertyNames(error), 2);
                console.error('[ERROR] Full error details:', errorDetails);
            }
            catch (serializeError) {
                console.error('[ERROR] Could not serialize error:', serializeError);
            }
            // En cas d'erreur, retourner le cache existant si disponible
            if (this.cache) {
                console.warn('[WARN] Using stale cache due to refresh error');
                return this.cache;
            }
            // Sinon, retourner un tableau vide
            console.warn('[WARN] No cache available, returning empty array');
            return [];
        }
        finally {
            this.isRefreshing = false;
        }
    }
    /**
     * Rafraîchit le cache de manière asynchrone (non-bloquant)
     */
    static refreshCacheAsync() {
        // Fire and forget
        this.refreshCache().catch(error => {
            console.error('❌ Async cache refresh failed:', error);
        });
    }
    /**
     * Parse les paramètres SSM en objets SecondaryCriteriaConfig
     */
    static parseParameters(parameters) {
        console.log('[PARSE] Starting to parse', parameters.length, 'parameters');
        const parsed = parameters.map((param, index) => {
            var _a, _b;
            try {
                console.log('[PARSE] Parameter', index, '- Name:', param.Name);
                console.log('[PARSE] Parameter', index, '- Value:', param.Value);
                const value = JSON.parse(param.Value || '{}');
                // Extraire le nom du critère depuis le chemin du paramètre
                // Ex: /decision-engine/criteria/secondary/TypeClient -> TypeClient
                const name = ((_a = param.Name) === null || _a === void 0 ? void 0 : _a.split('/').pop()) || 'unknown';
                const config = {
                    name,
                    enabled: (_b = value.enabled) !== null && _b !== void 0 ? _b : false,
                    description: value.description,
                    businessJustification: value.businessJustification,
                    addedDate: value.addedDate
                };
                console.log('[PARSE] Parameter', index, '- Parsed successfully:', name);
                return config;
            }
            catch (error) {
                console.error('[PARSE] Failed to parse parameter', param.Name);
                console.error('[PARSE] Parse error:', error === null || error === void 0 ? void 0 : error.message);
                return null;
            }
        });
        const filtered = parsed.filter((c) => c !== null);
        console.log('[PARSE] Successfully parsed', filtered.length, 'out of', parameters.length, 'parameters');
        return filtered;
    }
    /**
     * Ajoute ou met à jour un critère secondaire
     */
    static async putCriteria(criteria) {
        const client = this.getClient();
        const parameterName = `${this.PARAMETER_PATH}/${criteria.name}`;
        const parameterValue = JSON.stringify({
            enabled: criteria.enabled,
            description: criteria.description,
            businessJustification: criteria.businessJustification,
            addedDate: criteria.addedDate || new Date().toISOString().split('T')[0]
        });
        const command = new client_ssm_1.PutParameterCommand({
            Name: parameterName,
            Value: parameterValue,
            Type: 'String',
            Overwrite: true,
            Description: `Secondary criteria: ${criteria.description || criteria.name}`
        });
        await client.send(command);
        console.log(`✅ Criteria ${criteria.name} saved to Parameter Store`);
        // Invalider le cache pour forcer un refresh
        this.invalidateCache();
    }
    /**
     * Supprime un critère secondaire
     */
    static async deleteCriteria(criteriaName) {
        const client = this.getClient();
        const parameterName = `${this.PARAMETER_PATH}/${criteriaName}`;
        const command = new client_ssm_1.DeleteParameterCommand({
            Name: parameterName
        });
        await client.send(command);
        console.log(`✅ Criteria ${criteriaName} deleted from Parameter Store`);
        // Invalider le cache pour forcer un refresh
        this.invalidateCache();
    }
    /**
     * Récupère un critère spécifique
     */
    static async getCriteria(criteriaName) {
        var _a, _b;
        const client = this.getClient();
        const parameterName = `${this.PARAMETER_PATH}/${criteriaName}`;
        try {
            const command = new client_ssm_1.GetParameterCommand({
                Name: parameterName
            });
            const result = await client.send(command);
            if (!((_a = result.Parameter) === null || _a === void 0 ? void 0 : _a.Value)) {
                return null;
            }
            const value = JSON.parse(result.Parameter.Value);
            return {
                name: criteriaName,
                enabled: (_b = value.enabled) !== null && _b !== void 0 ? _b : false,
                description: value.description,
                businessJustification: value.businessJustification,
                addedDate: value.addedDate
            };
        }
        catch (error) {
            if (error.name === 'ParameterNotFound') {
                return null;
            }
            throw error;
        }
    }
    /**
     * Invalide le cache (force un refresh au prochain appel)
     */
    static invalidateCache() {
        this.cache = null;
        this.cacheTimestamp = 0;
        console.log('🗑️ Cache invalidated');
    }
    /**
     * Pré-charge le cache (warm-up)
     */
    static async warmUp() {
        console.log('🔥 Warming up criteria cache...');
        await this.refreshCache();
        console.log('✅ Cache warmed up successfully');
    }
    /**
     * Retourne les métriques du cache
     */
    static getMetrics() {
        var _a;
        return {
            ...this.metrics,
            cacheAge: Date.now() - this.cacheTimestamp,
            cacheSize: ((_a = this.cache) === null || _a === void 0 ? void 0 : _a.length) || 0
        };
    }
    /**
     * Réinitialise les métriques
     */
    static resetMetrics() {
        this.metrics = {
            hits: 0,
            misses: 0,
            lastRefreshDuration: 0,
            lastRefreshTimestamp: 0
        };
        console.log('📊 Metrics reset');
    }
}
exports.CriteriaParameterStore = CriteriaParameterStore;
CriteriaParameterStore.PARAMETER_PATH = '/decision-engine/criteria/secondary';
CriteriaParameterStore.DEFAULT_CACHE_TTL = 5 * 60 * 1000; // 5 minutes
CriteriaParameterStore.STALE_CACHE_TTL = 10 * 60 * 1000; // 10 minutes (pour refresh async)
// Cache en mémoire
CriteriaParameterStore.cache = null;
CriteriaParameterStore.cacheTimestamp = 0;
CriteriaParameterStore.cacheTTL = CriteriaParameterStore.DEFAULT_CACHE_TTL;
// Métriques
CriteriaParameterStore.metrics = {
    hits: 0,
    misses: 0,
    lastRefreshDuration: 0,
    lastRefreshTimestamp: 0
};
// Flag pour éviter les refresh concurrents
CriteriaParameterStore.isRefreshing = false;
// Client SSM réutilisable
CriteriaParameterStore.ssmClient = null;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ3JpdGVyaWFQYXJhbWV0ZXJTdG9yZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvQ3JpdGVyaWFQYXJhbWV0ZXJTdG9yZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7Ozs7O0dBUUc7OztBQUVILG9EQUE4STtBQWlCOUksTUFBYSxzQkFBc0I7SUF3QmpDOztPQUVHO0lBQ0ssTUFBTSxDQUFDLFNBQVM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksc0JBQVMsQ0FBQztnQkFDN0IsV0FBVyxFQUFFLENBQUMsRUFBRSxzQ0FBc0M7Z0JBQ3RELGNBQWMsRUFBRTtvQkFDZCxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsK0JBQStCO29CQUN4RCxjQUFjLEVBQUUsSUFBSSxDQUFLLGtDQUFrQztpQkFDNUQ7YUFDRixDQUFDLENBQUM7UUFDTCxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3hCLENBQUM7SUFFRDs7T0FFRztJQUNILE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBVztRQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQztRQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixHQUFHLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU87UUFDbEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLE1BQU0sUUFBUSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRTNDLG1DQUFtQztRQUNuQyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztZQUMvRixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDcEIsQ0FBQztRQUVELCtEQUErRDtRQUMvRCxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNsRCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBRTdGLHVDQUF1QztZQUN2QyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUV6QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDcEIsQ0FBQztRQUVELG9EQUFvRDtRQUNwRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUVwRyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFRDs7T0FFRztJQUNLLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWTs7UUFDL0IsaUNBQWlDO1FBQ2pDLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaURBQWlELENBQUMsQ0FBQztZQUMvRCw2REFBNkQ7WUFDN0QsTUFBTSxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN2RCxPQUFPLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDO1FBQzFCLENBQUM7UUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztRQUN6QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFFN0IsSUFBSSxDQUFDO1lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQywyREFBMkQsQ0FBQyxDQUFDO1lBQ3pFLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUVsRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDaEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFckQsTUFBTSxPQUFPLEdBQUcsSUFBSSx1Q0FBMEIsQ0FBQztnQkFDN0MsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjO2dCQUN6QixTQUFTLEVBQUUsSUFBSTtnQkFDZixjQUFjLEVBQUUsS0FBSzthQUN0QixDQUFDLENBQUM7WUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFFbEYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1lBQ2pELE1BQU0sTUFBTSxHQUFHLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7WUFFdEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxDQUFBLE1BQUEsTUFBTSxDQUFDLFVBQVUsMENBQUUsTUFBTSxLQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2hGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDdEQsYUFBYSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtnQkFDbEMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO2dCQUNuRCxnQkFBZ0IsRUFBRSxNQUFBLE1BQU0sQ0FBQyxVQUFVLDBDQUFFLE1BQU07YUFDNUMsQ0FBQyxDQUFDLENBQUM7WUFFSix3QkFBd0I7WUFDeEIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBRS9ELE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3pELFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25FLENBQUMsQ0FBQyxDQUFDO1lBRUgseUJBQXlCO1lBQ3pCLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRWpDLFlBQVk7WUFDWixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEdBQUcsUUFBUSxDQUFDO1lBQzVDLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUV4RCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsb0JBQW9CLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRS9GLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztRQUVwQixDQUFDO1FBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztZQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLHNEQUFzRCxDQUFDLENBQUM7WUFDdEUsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxPQUFPLEtBQUssQ0FBQyxDQUFDO1lBQ25ELE9BQU8sQ0FBQyxLQUFLLENBQUMscUJBQXFCLEVBQUUsS0FBSyxhQUFMLEtBQUssdUJBQUwsS0FBSyxDQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2xELE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxhQUFMLEtBQUssdUJBQUwsS0FBSyxDQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ3hELE9BQU8sQ0FBQyxLQUFLLENBQUMscUJBQXFCLEVBQUUsS0FBSyxhQUFMLEtBQUssdUJBQUwsS0FBSyxDQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2xELE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsTUFBQSxLQUFLLGFBQUwsS0FBSyx1QkFBTCxLQUFLLENBQUUsU0FBUywwQ0FBRSxjQUFjLENBQUMsQ0FBQztZQUM3RSxPQUFPLENBQUMsS0FBSyxDQUFDLHNCQUFzQixFQUFFLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxLQUFLLENBQUMsQ0FBQztZQUVwRCwrQkFBK0I7WUFDL0IsSUFBSSxDQUFDO2dCQUNILE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDakYsT0FBTyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUM3RCxDQUFDO1lBQUMsT0FBTyxjQUFjLEVBQUUsQ0FBQztnQkFDeEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUN0RSxDQUFDO1lBRUQsNkRBQTZEO1lBQzdELElBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNmLE9BQU8sQ0FBQyxJQUFJLENBQUMsK0NBQStDLENBQUMsQ0FBQztnQkFDOUQsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQ3BCLENBQUM7WUFFRCxtQ0FBbUM7WUFDbkMsT0FBTyxDQUFDLElBQUksQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1lBQ2pFLE9BQU8sRUFBRSxDQUFDO1FBRVosQ0FBQztnQkFBUyxDQUFDO1lBQ1QsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLE1BQU0sQ0FBQyxpQkFBaUI7UUFDOUIsa0JBQWtCO1FBQ2xCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNLLE1BQU0sQ0FBQyxlQUFlLENBQUMsVUFBaUI7UUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxVQUFVLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRTFFLE1BQU0sTUFBTSxHQUF1QyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFOztZQUNqRixJQUFJLENBQUM7Z0JBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDL0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFakUsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDO2dCQUU5QywyREFBMkQ7Z0JBQzNELG1FQUFtRTtnQkFDbkUsTUFBTSxJQUFJLEdBQUcsQ0FBQSxNQUFBLEtBQUssQ0FBQyxJQUFJLDBDQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUksU0FBUyxDQUFDO2dCQUV2RCxNQUFNLE1BQU0sR0FBNEI7b0JBQ3RDLElBQUk7b0JBQ0osT0FBTyxFQUFFLE1BQUEsS0FBSyxDQUFDLE9BQU8sbUNBQUksS0FBSztvQkFDL0IsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO29CQUM5QixxQkFBcUIsRUFBRSxLQUFLLENBQUMscUJBQXFCO29CQUNsRCxTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7aUJBQzNCLENBQUM7Z0JBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLEVBQUUsd0JBQXdCLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hFLE9BQU8sTUFBTSxDQUFDO1lBQ2hCLENBQUM7WUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO2dCQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLG1DQUFtQyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDL0QsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLGFBQUwsS0FBSyx1QkFBTCxLQUFLLENBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ3RELE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBZ0MsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQztRQUNoRixPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLFVBQVUsQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFdkcsT0FBTyxRQUFRLENBQUM7SUFDbEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsTUFBTSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBaUM7UUFDeEQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRWhDLE1BQU0sYUFBYSxHQUFHLEdBQUcsSUFBSSxDQUFDLGNBQWMsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDaEUsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUNwQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU87WUFDekIsV0FBVyxFQUFFLFFBQVEsQ0FBQyxXQUFXO1lBQ2pDLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxxQkFBcUI7WUFDckQsU0FBUyxFQUFFLFFBQVEsQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hFLENBQUMsQ0FBQztRQUVILE1BQU0sT0FBTyxHQUFHLElBQUksZ0NBQW1CLENBQUM7WUFDdEMsSUFBSSxFQUFFLGFBQWE7WUFDbkIsS0FBSyxFQUFFLGNBQWM7WUFDckIsSUFBSSxFQUFFLFFBQVE7WUFDZCxTQUFTLEVBQUUsSUFBSTtZQUNmLFdBQVcsRUFBRSx1QkFBdUIsUUFBUSxDQUFDLFdBQVcsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFO1NBQzVFLENBQUMsQ0FBQztRQUVILE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQixPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsUUFBUSxDQUFDLElBQUksMkJBQTJCLENBQUMsQ0FBQztRQUVwRSw0Q0FBNEM7UUFDNUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7T0FFRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFlBQW9CO1FBQzlDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUVoQyxNQUFNLGFBQWEsR0FBRyxHQUFHLElBQUksQ0FBQyxjQUFjLElBQUksWUFBWSxFQUFFLENBQUM7UUFFL0QsTUFBTSxPQUFPLEdBQUcsSUFBSSxtQ0FBc0IsQ0FBQztZQUN6QyxJQUFJLEVBQUUsYUFBYTtTQUNwQixDQUFDLENBQUM7UUFFSCxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLFlBQVksK0JBQStCLENBQUMsQ0FBQztRQUV2RSw0Q0FBNEM7UUFDNUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7T0FFRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFlBQW9COztRQUMzQyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFFaEMsTUFBTSxhQUFhLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBRS9ELElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxHQUFHLElBQUksZ0NBQW1CLENBQUM7Z0JBQ3RDLElBQUksRUFBRSxhQUFhO2FBQ3BCLENBQUMsQ0FBQztZQUVILE1BQU0sTUFBTSxHQUFHLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUUxQyxJQUFJLENBQUMsQ0FBQSxNQUFBLE1BQU0sQ0FBQyxTQUFTLDBDQUFFLEtBQUssQ0FBQSxFQUFFLENBQUM7Z0JBQzdCLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUVELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVqRCxPQUFPO2dCQUNMLElBQUksRUFBRSxZQUFZO2dCQUNsQixPQUFPLEVBQUUsTUFBQSxLQUFLLENBQUMsT0FBTyxtQ0FBSSxLQUFLO2dCQUMvQixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7Z0JBQzlCLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxxQkFBcUI7Z0JBQ2xELFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUzthQUMzQixDQUFDO1FBRUosQ0FBQztRQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7WUFDcEIsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLG1CQUFtQixFQUFFLENBQUM7Z0JBQ3ZDLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUNELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILE1BQU0sQ0FBQyxlQUFlO1FBQ3BCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU07UUFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLE1BQU0sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxNQUFNLENBQUMsVUFBVTs7UUFDZixPQUFPO1lBQ0wsR0FBRyxJQUFJLENBQUMsT0FBTztZQUNmLFFBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWM7WUFDMUMsU0FBUyxFQUFFLENBQUEsTUFBQSxJQUFJLENBQUMsS0FBSywwQ0FBRSxNQUFNLEtBQUksQ0FBQztTQUNuQyxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsTUFBTSxDQUFDLFlBQVk7UUFDakIsSUFBSSxDQUFDLE9BQU8sR0FBRztZQUNiLElBQUksRUFBRSxDQUFDO1lBQ1AsTUFBTSxFQUFFLENBQUM7WUFDVCxtQkFBbUIsRUFBRSxDQUFDO1lBQ3RCLG9CQUFvQixFQUFFLENBQUM7U0FDeEIsQ0FBQztRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNsQyxDQUFDOztBQWpXSCx3REFrV0M7QUFqV3lCLHFDQUFjLEdBQUcscUNBQXFDLENBQUM7QUFDdkQsd0NBQWlCLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxZQUFZO0FBQy9DLHNDQUFlLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxrQ0FBa0M7QUFFNUYsbUJBQW1CO0FBQ0osNEJBQUssR0FBcUMsSUFBSSxDQUFDO0FBQy9DLHFDQUFjLEdBQVcsQ0FBQyxDQUFDO0FBQzNCLCtCQUFRLEdBQVcsc0JBQXNCLENBQUMsaUJBQWlCLENBQUM7QUFFM0UsWUFBWTtBQUNHLDhCQUFPLEdBQWlCO0lBQ3JDLElBQUksRUFBRSxDQUFDO0lBQ1AsTUFBTSxFQUFFLENBQUM7SUFDVCxtQkFBbUIsRUFBRSxDQUFDO0lBQ3RCLG9CQUFvQixFQUFFLENBQUM7Q0FDeEIsQ0FBQztBQUVGLDJDQUEyQztBQUM1QixtQ0FBWSxHQUFZLEtBQUssQ0FBQztBQUU3QywwQkFBMEI7QUFDWCxnQ0FBUyxHQUFxQixJQUFJLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogU2VydmljZSBkZSBnZXN0aW9uIGRlcyBjcml0w6hyZXMgc2Vjb25kYWlyZXMgdmlhIEFXUyBTeXN0ZW1zIE1hbmFnZXIgUGFyYW1ldGVyIFN0b3JlXHJcbiAqIFxyXG4gKiBGb25jdGlvbm5hbGl0w6lzIDpcclxuICogLSBDYWNoZSBlbiBtw6ltb2lyZSBhdmVjIFRUTCBjb25maWd1cmFibGVcclxuICogLSBXYXJtLXVwIGF1IGTDqW1hcnJhZ2UgcG91ciDDqXZpdGVyIGxhIGxhdGVuY2UgZHUgcHJlbWllciBhcHBlbFxyXG4gKiAtIFJlZnJlc2ggYXN5bmNocm9uZSBwb3VyIG1haW50ZW5pciBsZSBjYWNoZSDDoCBqb3VyIHNhbnMgYmxvcXVlclxyXG4gKiAtIE3DqXRyaXF1ZXMgZGUgcGVyZm9ybWFuY2UgcG91ciBtb25pdG9yaW5nXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgU1NNQ2xpZW50LCBHZXRQYXJhbWV0ZXJzQnlQYXRoQ29tbWFuZCwgUHV0UGFyYW1ldGVyQ29tbWFuZCwgRGVsZXRlUGFyYW1ldGVyQ29tbWFuZCwgR2V0UGFyYW1ldGVyQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1zc20nO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBTZWNvbmRhcnlDcml0ZXJpYUNvbmZpZyB7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIGVuYWJsZWQ6IGJvb2xlYW47XHJcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XHJcbiAgYnVzaW5lc3NKdXN0aWZpY2F0aW9uPzogc3RyaW5nO1xyXG4gIGFkZGVkRGF0ZT86IHN0cmluZztcclxufVxyXG5cclxuaW50ZXJmYWNlIENhY2hlTWV0cmljcyB7XHJcbiAgaGl0czogbnVtYmVyO1xyXG4gIG1pc3NlczogbnVtYmVyO1xyXG4gIGxhc3RSZWZyZXNoRHVyYXRpb246IG51bWJlcjtcclxuICBsYXN0UmVmcmVzaFRpbWVzdGFtcDogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgQ3JpdGVyaWFQYXJhbWV0ZXJTdG9yZSB7XHJcbiAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgUEFSQU1FVEVSX1BBVEggPSAnL2RlY2lzaW9uLWVuZ2luZS9jcml0ZXJpYS9zZWNvbmRhcnknO1xyXG4gIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IERFRkFVTFRfQ0FDSEVfVFRMID0gNSAqIDYwICogMTAwMDsgLy8gNSBtaW51dGVzXHJcbiAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgU1RBTEVfQ0FDSEVfVFRMID0gMTAgKiA2MCAqIDEwMDA7IC8vIDEwIG1pbnV0ZXMgKHBvdXIgcmVmcmVzaCBhc3luYylcclxuICBcclxuICAvLyBDYWNoZSBlbiBtw6ltb2lyZVxyXG4gIHByaXZhdGUgc3RhdGljIGNhY2hlOiBTZWNvbmRhcnlDcml0ZXJpYUNvbmZpZ1tdIHwgbnVsbCA9IG51bGw7XHJcbiAgcHJpdmF0ZSBzdGF0aWMgY2FjaGVUaW1lc3RhbXA6IG51bWJlciA9IDA7XHJcbiAgcHJpdmF0ZSBzdGF0aWMgY2FjaGVUVEw6IG51bWJlciA9IENyaXRlcmlhUGFyYW1ldGVyU3RvcmUuREVGQVVMVF9DQUNIRV9UVEw7XHJcbiAgXHJcbiAgLy8gTcOpdHJpcXVlc1xyXG4gIHByaXZhdGUgc3RhdGljIG1ldHJpY3M6IENhY2hlTWV0cmljcyA9IHtcclxuICAgIGhpdHM6IDAsXHJcbiAgICBtaXNzZXM6IDAsXHJcbiAgICBsYXN0UmVmcmVzaER1cmF0aW9uOiAwLFxyXG4gICAgbGFzdFJlZnJlc2hUaW1lc3RhbXA6IDBcclxuICB9O1xyXG4gIFxyXG4gIC8vIEZsYWcgcG91ciDDqXZpdGVyIGxlcyByZWZyZXNoIGNvbmN1cnJlbnRzXHJcbiAgcHJpdmF0ZSBzdGF0aWMgaXNSZWZyZXNoaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgXHJcbiAgLy8gQ2xpZW50IFNTTSByw6l1dGlsaXNhYmxlXHJcbiAgcHJpdmF0ZSBzdGF0aWMgc3NtQ2xpZW50OiBTU01DbGllbnQgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgLyoqXHJcbiAgICogT2J0aWVudCBsZSBjbGllbnQgU1NNIChzaW5nbGV0b24pIGF2ZWMgY29uZmlndXJhdGlvbiBvcHRpbWlzw6llXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBzdGF0aWMgZ2V0Q2xpZW50KCk6IFNTTUNsaWVudCB7XHJcbiAgICBpZiAoIXRoaXMuc3NtQ2xpZW50KSB7XHJcbiAgICAgIHRoaXMuc3NtQ2xpZW50ID0gbmV3IFNTTUNsaWVudCh7XHJcbiAgICAgICAgbWF4QXR0ZW1wdHM6IDIsIC8vIFLDqWR1aXJlIGxlcyByZXRyaWVzIChwYXIgZMOpZmF1dDogMylcclxuICAgICAgICByZXF1ZXN0SGFuZGxlcjoge1xyXG4gICAgICAgICAgY29ubmVjdGlvblRpbWVvdXQ6IDEwMDAsIC8vIDFzIHBvdXIgw6l0YWJsaXIgbGEgY29ubmV4aW9uXHJcbiAgICAgICAgICByZXF1ZXN0VGltZW91dDogMzAwMCAgICAgLy8gM3MgbWF4IHBvdXIgbGEgcmVxdcOqdGUgY29tcGzDqHRlXHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnNzbUNsaWVudDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbmZpZ3VyZSBsZSBUVEwgZHUgY2FjaGUgKGVuIG1pbGxpc2Vjb25kZXMpXHJcbiAgICovXHJcbiAgc3RhdGljIHNldENhY2hlVFRMKHR0bDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICB0aGlzLmNhY2hlVFRMID0gdHRsO1xyXG4gICAgY29uc29sZS5sb2coYOKchSBDYWNoZSBUVEwgc2V0IHRvICR7dHRsfW1zICgke3R0bCAvIDEwMDB9cylgKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoYXJnZSB0b3VzIGxlcyBjcml0w6hyZXMgc2Vjb25kYWlyZXMgYXZlYyBjYWNoZSBpbnRlbGxpZ2VudFxyXG4gICAqIFxyXG4gICAqIFN0cmF0w6lnaWUgOlxyXG4gICAqIDEuIFNpIGNhY2hlIHZhbGlkZSAoPCBUVEwpIDogcmV0b3VyIGltbcOpZGlhdFxyXG4gICAqIDIuIFNpIGNhY2hlIHDDqXJpbcOpIG1haXMgcsOpY2VudCAoPCAyKlRUTCkgOiByZXRvdXIgaW1tw6lkaWF0ICsgcmVmcmVzaCBhc3luY1xyXG4gICAqIDMuIFNpIGNhY2hlIHRyb3AgdmlldXggb3UgYWJzZW50IDogcmVmcmVzaCBzeW5jaHJvbmVcclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgbG9hZEFsbCgpOiBQcm9taXNlPFNlY29uZGFyeUNyaXRlcmlhQ29uZmlnW10+IHtcclxuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XHJcbiAgICBjb25zdCBjYWNoZUFnZSA9IG5vdyAtIHRoaXMuY2FjaGVUaW1lc3RhbXA7XHJcblxyXG4gICAgLy8g4pyFIENhY2hlIHZhbGlkZSA6IHJldG91ciBpbW3DqWRpYXRcclxuICAgIGlmICh0aGlzLmNhY2hlICYmIGNhY2hlQWdlIDwgdGhpcy5jYWNoZVRUTCkge1xyXG4gICAgICB0aGlzLm1ldHJpY3MuaGl0cysrO1xyXG4gICAgICBjb25zb2xlLmxvZyhg8J+TpiBDYWNoZSBISVQgKGFnZTogJHtNYXRoLnJvdW5kKGNhY2hlQWdlIC8gMTAwMCl9cywgaGl0czogJHt0aGlzLm1ldHJpY3MuaGl0c30pYCk7XHJcbiAgICAgIHJldHVybiB0aGlzLmNhY2hlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOKchSBDYWNoZSBww6lyaW3DqSBtYWlzIHLDqWNlbnQgOiByZXRvdXIgaW1tw6lkaWF0ICsgcmVmcmVzaCBhc3luY1xyXG4gICAgaWYgKHRoaXMuY2FjaGUgJiYgY2FjaGVBZ2UgPCB0aGlzLlNUQUxFX0NBQ0hFX1RUTCkge1xyXG4gICAgICB0aGlzLm1ldHJpY3MuaGl0cysrO1xyXG4gICAgICBjb25zb2xlLmxvZyhg8J+TpiBDYWNoZSBISVQgKHN0YWxlLCBhZ2U6ICR7TWF0aC5yb3VuZChjYWNoZUFnZSAvIDEwMDApfXMpIC0gcmVmcmVzaGluZyBhc3luY2ApO1xyXG4gICAgICBcclxuICAgICAgLy8gUmVmcmVzaCBlbiBhcnJpw6hyZS1wbGFuIHNhbnMgYmxvcXVlclxyXG4gICAgICB0aGlzLnJlZnJlc2hDYWNoZUFzeW5jKCk7XHJcbiAgICAgIFxyXG4gICAgICByZXR1cm4gdGhpcy5jYWNoZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyDimqDvuI8gQ2FjaGUgYWJzZW50IG91IHRyb3AgdmlldXggOiByZWZyZXNoIHN5bmNocm9uZVxyXG4gICAgdGhpcy5tZXRyaWNzLm1pc3NlcysrO1xyXG4gICAgY29uc29sZS5sb2coYPCfjJAgQ2FjaGUgTUlTUyAoYWdlOiAke01hdGgucm91bmQoY2FjaGVBZ2UgLyAxMDAwKX1zLCBtaXNzZXM6ICR7dGhpcy5tZXRyaWNzLm1pc3Nlc30pYCk7XHJcbiAgICBcclxuICAgIHJldHVybiBhd2FpdCB0aGlzLnJlZnJlc2hDYWNoZSgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmFmcmHDrmNoaXQgbGUgY2FjaGUgZGUgbWFuacOocmUgc3luY2hyb25lXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgcmVmcmVzaENhY2hlKCk6IFByb21pc2U8U2Vjb25kYXJ5Q3JpdGVyaWFDb25maWdbXT4ge1xyXG4gICAgLy8gw4l2aXRlciBsZXMgcmVmcmVzaCBjb25jdXJyZW50c1xyXG4gICAgaWYgKHRoaXMuaXNSZWZyZXNoaW5nKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdbQ0FDSEVdIFJlZnJlc2ggYWxyZWFkeSBpbiBwcm9ncmVzcywgd2FpdGluZy4uLicpO1xyXG4gICAgICAvLyBBdHRlbmRyZSB1biBwZXUgZXQgcmV0b3VybmVyIGxlIGNhY2hlIGFjdHVlbCBzaSBkaXNwb25pYmxlXHJcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxMDApKTtcclxuICAgICAgcmV0dXJuIHRoaXMuY2FjaGUgfHwgW107XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5pc1JlZnJlc2hpbmcgPSB0cnVlO1xyXG4gICAgY29uc3Qgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zb2xlLmxvZygnW0NBQ0hFXSBSZWZyZXNoaW5nIGNyaXRlcmlhIGNhY2hlIGZyb20gUGFyYW1ldGVyIFN0b3JlLi4uJyk7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdbQ0FDSEVdIFBhdGg6JywgdGhpcy5QQVJBTUVURVJfUEFUSCk7XHJcbiAgICAgIFxyXG4gICAgICBjb25zdCBjbGllbnQgPSB0aGlzLmdldENsaWVudCgpO1xyXG4gICAgICBjb25zb2xlLmxvZygnW0NBQ0hFXSBTU00gQ2xpZW50IGNyZWF0ZWQ6JywgISFjbGllbnQpO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBHZXRQYXJhbWV0ZXJzQnlQYXRoQ29tbWFuZCh7XHJcbiAgICAgICAgUGF0aDogdGhpcy5QQVJBTUVURVJfUEFUSCxcclxuICAgICAgICBSZWN1cnNpdmU6IHRydWUsXHJcbiAgICAgICAgV2l0aERlY3J5cHRpb246IGZhbHNlXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zb2xlLmxvZygnW0NBQ0hFXSBDb21tYW5kIGNyZWF0ZWQgd2l0aCBpbnB1dDonLCBKU09OLnN0cmluZ2lmeShjb21tYW5kLmlucHV0KSk7XHJcblxyXG4gICAgICBjb25zb2xlLmxvZygnW0NBQ0hFXSBTZW5kaW5nIGNvbW1hbmQgdG8gU1NNLi4uJyk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5zZW5kKGNvbW1hbmQpO1xyXG4gICAgICBjb25zb2xlLmxvZygnW0NBQ0hFXSBDb21tYW5kIGNvbXBsZXRlZCBzdWNjZXNzZnVsbHknKTtcclxuICAgICAgXHJcbiAgICAgIGNvbnNvbGUubG9nKCdbQ0FDSEVdIFJhdyBwYXJhbWV0ZXJzIHJlY2VpdmVkOicsIHJlc3VsdC5QYXJhbWV0ZXJzPy5sZW5ndGggfHwgMCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdbQ0FDSEVdIFJlc3VsdCBzdHJ1Y3R1cmU6JywgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIGhhc1BhcmFtZXRlcnM6ICEhcmVzdWx0LlBhcmFtZXRlcnMsXHJcbiAgICAgICAgcGFyYW1ldGVyc0lzQXJyYXk6IEFycmF5LmlzQXJyYXkocmVzdWx0LlBhcmFtZXRlcnMpLFxyXG4gICAgICAgIHBhcmFtZXRlcnNMZW5ndGg6IHJlc3VsdC5QYXJhbWV0ZXJzPy5sZW5ndGhcclxuICAgICAgfSkpO1xyXG4gICAgICBcclxuICAgICAgLy8gUGFyc2VyIGxlcyBwYXJhbcOodHJlc1xyXG4gICAgICBjb25zdCBjcml0ZXJpYSA9IHRoaXMucGFyc2VQYXJhbWV0ZXJzKHJlc3VsdC5QYXJhbWV0ZXJzIHx8IFtdKTtcclxuICAgICAgXHJcbiAgICAgIGNvbnNvbGUubG9nKCdbQ0FDSEVdIFBhcnNlZCBjcml0ZXJpYTonLCBjcml0ZXJpYS5sZW5ndGgpO1xyXG4gICAgICBjcml0ZXJpYS5mb3JFYWNoKGMgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdbQ0FDSEVdIENyaXRlcmlvbjonLCBjLm5hbWUsICdlbmFibGVkOicsIGMuZW5hYmxlZCk7XHJcbiAgICAgIH0pO1xyXG4gICAgICBcclxuICAgICAgLy8gTWV0dHJlIMOgIGpvdXIgbGUgY2FjaGVcclxuICAgICAgdGhpcy5jYWNoZSA9IGNyaXRlcmlhO1xyXG4gICAgICB0aGlzLmNhY2hlVGltZXN0YW1wID0gRGF0ZS5ub3coKTtcclxuICAgICAgXHJcbiAgICAgIC8vIE3DqXRyaXF1ZXNcclxuICAgICAgY29uc3QgZHVyYXRpb24gPSBEYXRlLm5vdygpIC0gc3RhcnRUaW1lO1xyXG4gICAgICB0aGlzLm1ldHJpY3MubGFzdFJlZnJlc2hEdXJhdGlvbiA9IGR1cmF0aW9uO1xyXG4gICAgICB0aGlzLm1ldHJpY3MubGFzdFJlZnJlc2hUaW1lc3RhbXAgPSB0aGlzLmNhY2hlVGltZXN0YW1wO1xyXG4gICAgICBcclxuICAgICAgY29uc29sZS5sb2coJ1tDQUNIRV0gQ2FjaGUgcmVmcmVzaGVkOicsIGNyaXRlcmlhLmxlbmd0aCwgJ2NyaXRlcmlhIGxvYWRlZCBpbicsIGR1cmF0aW9uLCAnbXMnKTtcclxuICAgICAgXHJcbiAgICAgIHJldHVybiB0aGlzLmNhY2hlO1xyXG4gICAgICBcclxuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignW0VSUk9SXSBGYWlsZWQgdG8gcmVmcmVzaCBjYWNoZSBmcm9tIFBhcmFtZXRlciBTdG9yZScpO1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdbRVJST1JdIEVycm9yIHR5cGU6JywgdHlwZW9mIGVycm9yKTtcclxuICAgICAgY29uc29sZS5lcnJvcignW0VSUk9SXSBFcnJvciBuYW1lOicsIGVycm9yPy5uYW1lKTtcclxuICAgICAgY29uc29sZS5lcnJvcignW0VSUk9SXSBFcnJvciBtZXNzYWdlOicsIGVycm9yPy5tZXNzYWdlKTtcclxuICAgICAgY29uc29sZS5lcnJvcignW0VSUk9SXSBFcnJvciBjb2RlOicsIGVycm9yPy5jb2RlKTtcclxuICAgICAgY29uc29sZS5lcnJvcignW0VSUk9SXSBFcnJvciBzdGF0dXNDb2RlOicsIGVycm9yPy4kbWV0YWRhdGE/Lmh0dHBTdGF0dXNDb2RlKTtcclxuICAgICAgY29uc29sZS5lcnJvcignW0VSUk9SXSBFcnJvciBzdGFjazonLCBlcnJvcj8uc3RhY2spO1xyXG4gICAgICBcclxuICAgICAgLy8gU2VyaWFsaXNlciBsJ2VycmV1ciBjb21wbMOodGVcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBlcnJvckRldGFpbHMgPSBKU09OLnN0cmluZ2lmeShlcnJvciwgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoZXJyb3IpLCAyKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdbRVJST1JdIEZ1bGwgZXJyb3IgZGV0YWlsczonLCBlcnJvckRldGFpbHMpO1xyXG4gICAgICB9IGNhdGNoIChzZXJpYWxpemVFcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tFUlJPUl0gQ291bGQgbm90IHNlcmlhbGl6ZSBlcnJvcjonLCBzZXJpYWxpemVFcnJvcik7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIC8vIEVuIGNhcyBkJ2VycmV1ciwgcmV0b3VybmVyIGxlIGNhY2hlIGV4aXN0YW50IHNpIGRpc3BvbmlibGVcclxuICAgICAgaWYgKHRoaXMuY2FjaGUpIHtcclxuICAgICAgICBjb25zb2xlLndhcm4oJ1tXQVJOXSBVc2luZyBzdGFsZSBjYWNoZSBkdWUgdG8gcmVmcmVzaCBlcnJvcicpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNhY2hlO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICAvLyBTaW5vbiwgcmV0b3VybmVyIHVuIHRhYmxlYXUgdmlkZVxyXG4gICAgICBjb25zb2xlLndhcm4oJ1tXQVJOXSBObyBjYWNoZSBhdmFpbGFibGUsIHJldHVybmluZyBlbXB0eSBhcnJheScpO1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICAgIFxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgdGhpcy5pc1JlZnJlc2hpbmcgPSBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJhZnJhw65jaGl0IGxlIGNhY2hlIGRlIG1hbmnDqHJlIGFzeW5jaHJvbmUgKG5vbi1ibG9xdWFudClcclxuICAgKi9cclxuICBwcml2YXRlIHN0YXRpYyByZWZyZXNoQ2FjaGVBc3luYygpOiB2b2lkIHtcclxuICAgIC8vIEZpcmUgYW5kIGZvcmdldFxyXG4gICAgdGhpcy5yZWZyZXNoQ2FjaGUoKS5jYXRjaChlcnJvciA9PiB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ+KdjCBBc3luYyBjYWNoZSByZWZyZXNoIGZhaWxlZDonLCBlcnJvcik7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFBhcnNlIGxlcyBwYXJhbcOodHJlcyBTU00gZW4gb2JqZXRzIFNlY29uZGFyeUNyaXRlcmlhQ29uZmlnXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBzdGF0aWMgcGFyc2VQYXJhbWV0ZXJzKHBhcmFtZXRlcnM6IGFueVtdKTogU2Vjb25kYXJ5Q3JpdGVyaWFDb25maWdbXSB7XHJcbiAgICBjb25zb2xlLmxvZygnW1BBUlNFXSBTdGFydGluZyB0byBwYXJzZScsIHBhcmFtZXRlcnMubGVuZ3RoLCAncGFyYW1ldGVycycpO1xyXG4gICAgXHJcbiAgICBjb25zdCBwYXJzZWQ6IChTZWNvbmRhcnlDcml0ZXJpYUNvbmZpZyB8IG51bGwpW10gPSBwYXJhbWV0ZXJzLm1hcCgocGFyYW0sIGluZGV4KSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1tQQVJTRV0gUGFyYW1ldGVyJywgaW5kZXgsICctIE5hbWU6JywgcGFyYW0uTmFtZSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1tQQVJTRV0gUGFyYW1ldGVyJywgaW5kZXgsICctIFZhbHVlOicsIHBhcmFtLlZhbHVlKTtcclxuICAgICAgICBcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IEpTT04ucGFyc2UocGFyYW0uVmFsdWUgfHwgJ3t9Jyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gRXh0cmFpcmUgbGUgbm9tIGR1IGNyaXTDqHJlIGRlcHVpcyBsZSBjaGVtaW4gZHUgcGFyYW3DqHRyZVxyXG4gICAgICAgIC8vIEV4OiAvZGVjaXNpb24tZW5naW5lL2NyaXRlcmlhL3NlY29uZGFyeS9UeXBlQ2xpZW50IC0+IFR5cGVDbGllbnRcclxuICAgICAgICBjb25zdCBuYW1lID0gcGFyYW0uTmFtZT8uc3BsaXQoJy8nKS5wb3AoKSB8fCAndW5rbm93bic7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgY29uZmlnOiBTZWNvbmRhcnlDcml0ZXJpYUNvbmZpZyA9IHtcclxuICAgICAgICAgIG5hbWUsXHJcbiAgICAgICAgICBlbmFibGVkOiB2YWx1ZS5lbmFibGVkID8/IGZhbHNlLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IHZhbHVlLmRlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgYnVzaW5lc3NKdXN0aWZpY2F0aW9uOiB2YWx1ZS5idXNpbmVzc0p1c3RpZmljYXRpb24sXHJcbiAgICAgICAgICBhZGRlZERhdGU6IHZhbHVlLmFkZGVkRGF0ZVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc29sZS5sb2coJ1tQQVJTRV0gUGFyYW1ldGVyJywgaW5kZXgsICctIFBhcnNlZCBzdWNjZXNzZnVsbHk6JywgbmFtZSk7XHJcbiAgICAgICAgcmV0dXJuIGNvbmZpZztcclxuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQQVJTRV0gRmFpbGVkIHRvIHBhcnNlIHBhcmFtZXRlcicsIHBhcmFtLk5hbWUpO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQQVJTRV0gUGFyc2UgZXJyb3I6JywgZXJyb3I/Lm1lc3NhZ2UpO1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBwYXJzZWQuZmlsdGVyKChjKTogYyBpcyBTZWNvbmRhcnlDcml0ZXJpYUNvbmZpZyA9PiBjICE9PSBudWxsKTtcclxuICAgIGNvbnNvbGUubG9nKCdbUEFSU0VdIFN1Y2Nlc3NmdWxseSBwYXJzZWQnLCBmaWx0ZXJlZC5sZW5ndGgsICdvdXQgb2YnLCBwYXJhbWV0ZXJzLmxlbmd0aCwgJ3BhcmFtZXRlcnMnKTtcclxuICAgIFxyXG4gICAgcmV0dXJuIGZpbHRlcmVkO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQWpvdXRlIG91IG1ldCDDoCBqb3VyIHVuIGNyaXTDqHJlIHNlY29uZGFpcmVcclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgcHV0Q3JpdGVyaWEoY3JpdGVyaWE6IFNlY29uZGFyeUNyaXRlcmlhQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCBjbGllbnQgPSB0aGlzLmdldENsaWVudCgpO1xyXG4gICAgXHJcbiAgICBjb25zdCBwYXJhbWV0ZXJOYW1lID0gYCR7dGhpcy5QQVJBTUVURVJfUEFUSH0vJHtjcml0ZXJpYS5uYW1lfWA7XHJcbiAgICBjb25zdCBwYXJhbWV0ZXJWYWx1ZSA9IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgZW5hYmxlZDogY3JpdGVyaWEuZW5hYmxlZCxcclxuICAgICAgZGVzY3JpcHRpb246IGNyaXRlcmlhLmRlc2NyaXB0aW9uLFxyXG4gICAgICBidXNpbmVzc0p1c3RpZmljYXRpb246IGNyaXRlcmlhLmJ1c2luZXNzSnVzdGlmaWNhdGlvbixcclxuICAgICAgYWRkZWREYXRlOiBjcml0ZXJpYS5hZGRlZERhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF1cclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgUHV0UGFyYW1ldGVyQ29tbWFuZCh7XHJcbiAgICAgIE5hbWU6IHBhcmFtZXRlck5hbWUsXHJcbiAgICAgIFZhbHVlOiBwYXJhbWV0ZXJWYWx1ZSxcclxuICAgICAgVHlwZTogJ1N0cmluZycsXHJcbiAgICAgIE92ZXJ3cml0ZTogdHJ1ZSxcclxuICAgICAgRGVzY3JpcHRpb246IGBTZWNvbmRhcnkgY3JpdGVyaWE6ICR7Y3JpdGVyaWEuZGVzY3JpcHRpb24gfHwgY3JpdGVyaWEubmFtZX1gXHJcbiAgICB9KTtcclxuXHJcbiAgICBhd2FpdCBjbGllbnQuc2VuZChjb21tYW5kKTtcclxuICAgIGNvbnNvbGUubG9nKGDinIUgQ3JpdGVyaWEgJHtjcml0ZXJpYS5uYW1lfSBzYXZlZCB0byBQYXJhbWV0ZXIgU3RvcmVgKTtcclxuICAgIFxyXG4gICAgLy8gSW52YWxpZGVyIGxlIGNhY2hlIHBvdXIgZm9yY2VyIHVuIHJlZnJlc2hcclxuICAgIHRoaXMuaW52YWxpZGF0ZUNhY2hlKCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBTdXBwcmltZSB1biBjcml0w6hyZSBzZWNvbmRhaXJlXHJcbiAgICovXHJcbiAgc3RhdGljIGFzeW5jIGRlbGV0ZUNyaXRlcmlhKGNyaXRlcmlhTmFtZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCBjbGllbnQgPSB0aGlzLmdldENsaWVudCgpO1xyXG4gICAgXHJcbiAgICBjb25zdCBwYXJhbWV0ZXJOYW1lID0gYCR7dGhpcy5QQVJBTUVURVJfUEFUSH0vJHtjcml0ZXJpYU5hbWV9YDtcclxuICAgIFxyXG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBEZWxldGVQYXJhbWV0ZXJDb21tYW5kKHtcclxuICAgICAgTmFtZTogcGFyYW1ldGVyTmFtZVxyXG4gICAgfSk7XHJcblxyXG4gICAgYXdhaXQgY2xpZW50LnNlbmQoY29tbWFuZCk7XHJcbiAgICBjb25zb2xlLmxvZyhg4pyFIENyaXRlcmlhICR7Y3JpdGVyaWFOYW1lfSBkZWxldGVkIGZyb20gUGFyYW1ldGVyIFN0b3JlYCk7XHJcbiAgICBcclxuICAgIC8vIEludmFsaWRlciBsZSBjYWNoZSBwb3VyIGZvcmNlciB1biByZWZyZXNoXHJcbiAgICB0aGlzLmludmFsaWRhdGVDYWNoZSgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUsOpY3Vww6hyZSB1biBjcml0w6hyZSBzcMOpY2lmaXF1ZVxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBnZXRDcml0ZXJpYShjcml0ZXJpYU5hbWU6IHN0cmluZyk6IFByb21pc2U8U2Vjb25kYXJ5Q3JpdGVyaWFDb25maWcgfCBudWxsPiB7XHJcbiAgICBjb25zdCBjbGllbnQgPSB0aGlzLmdldENsaWVudCgpO1xyXG4gICAgXHJcbiAgICBjb25zdCBwYXJhbWV0ZXJOYW1lID0gYCR7dGhpcy5QQVJBTUVURVJfUEFUSH0vJHtjcml0ZXJpYU5hbWV9YDtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBHZXRQYXJhbWV0ZXJDb21tYW5kKHtcclxuICAgICAgICBOYW1lOiBwYXJhbWV0ZXJOYW1lXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2xpZW50LnNlbmQoY29tbWFuZCk7XHJcbiAgICAgIFxyXG4gICAgICBpZiAoIXJlc3VsdC5QYXJhbWV0ZXI/LlZhbHVlKSB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHZhbHVlID0gSlNPTi5wYXJzZShyZXN1bHQuUGFyYW1ldGVyLlZhbHVlKTtcclxuICAgICAgXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgbmFtZTogY3JpdGVyaWFOYW1lLFxyXG4gICAgICAgIGVuYWJsZWQ6IHZhbHVlLmVuYWJsZWQgPz8gZmFsc2UsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IHZhbHVlLmRlc2NyaXB0aW9uLFxyXG4gICAgICAgIGJ1c2luZXNzSnVzdGlmaWNhdGlvbjogdmFsdWUuYnVzaW5lc3NKdXN0aWZpY2F0aW9uLFxyXG4gICAgICAgIGFkZGVkRGF0ZTogdmFsdWUuYWRkZWREYXRlXHJcbiAgICAgIH07XHJcbiAgICAgIFxyXG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xyXG4gICAgICBpZiAoZXJyb3IubmFtZSA9PT0gJ1BhcmFtZXRlck5vdEZvdW5kJykge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9XHJcbiAgICAgIHRocm93IGVycm9yO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogSW52YWxpZGUgbGUgY2FjaGUgKGZvcmNlIHVuIHJlZnJlc2ggYXUgcHJvY2hhaW4gYXBwZWwpXHJcbiAgICovXHJcbiAgc3RhdGljIGludmFsaWRhdGVDYWNoZSgpOiB2b2lkIHtcclxuICAgIHRoaXMuY2FjaGUgPSBudWxsO1xyXG4gICAgdGhpcy5jYWNoZVRpbWVzdGFtcCA9IDA7XHJcbiAgICBjb25zb2xlLmxvZygn8J+Xke+4jyBDYWNoZSBpbnZhbGlkYXRlZCcpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUHLDqS1jaGFyZ2UgbGUgY2FjaGUgKHdhcm0tdXApXHJcbiAgICovXHJcbiAgc3RhdGljIGFzeW5jIHdhcm1VcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnNvbGUubG9nKCfwn5SlIFdhcm1pbmcgdXAgY3JpdGVyaWEgY2FjaGUuLi4nKTtcclxuICAgIGF3YWl0IHRoaXMucmVmcmVzaENhY2hlKCk7XHJcbiAgICBjb25zb2xlLmxvZygn4pyFIENhY2hlIHdhcm1lZCB1cCBzdWNjZXNzZnVsbHknKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldG91cm5lIGxlcyBtw6l0cmlxdWVzIGR1IGNhY2hlXHJcbiAgICovXHJcbiAgc3RhdGljIGdldE1ldHJpY3MoKTogQ2FjaGVNZXRyaWNzICYgeyBjYWNoZUFnZTogbnVtYmVyOyBjYWNoZVNpemU6IG51bWJlciB9IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIC4uLnRoaXMubWV0cmljcyxcclxuICAgICAgY2FjaGVBZ2U6IERhdGUubm93KCkgLSB0aGlzLmNhY2hlVGltZXN0YW1wLFxyXG4gICAgICBjYWNoZVNpemU6IHRoaXMuY2FjaGU/Lmxlbmd0aCB8fCAwXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUsOpaW5pdGlhbGlzZSBsZXMgbcOpdHJpcXVlc1xyXG4gICAqL1xyXG4gIHN0YXRpYyByZXNldE1ldHJpY3MoKTogdm9pZCB7XHJcbiAgICB0aGlzLm1ldHJpY3MgPSB7XHJcbiAgICAgIGhpdHM6IDAsXHJcbiAgICAgIG1pc3NlczogMCxcclxuICAgICAgbGFzdFJlZnJlc2hEdXJhdGlvbjogMCxcclxuICAgICAgbGFzdFJlZnJlc2hUaW1lc3RhbXA6IDBcclxuICAgIH07XHJcbiAgICBjb25zb2xlLmxvZygn8J+TiiBNZXRyaWNzIHJlc2V0Jyk7XHJcbiAgfVxyXG59XHJcbiJdfQ==
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Mock AWS SDK
jest.mock('@aws-sdk/client-dynamodb');
jest.mock('@aws-sdk/lib-dynamodb');
describe('RuleRepository Unit Tests', () => {
    let repository;
    let mockSend;
    let mockDynamoClient;
    const sampleRule = {
        id: 'rule-1',
        name: 'Test Rule',
        expression: 'NouveauSinistre == true',
        weight: 10,
        distributionSegment: 'segment-1',
        createdAt: '2023-01-01T00:00:00Z',
        updatedAt: '2023-01-01T00:00:00Z'
    };
    beforeEach(() => {
        // Reset all mocks
        jest.clearAllMocks();
        // Mock DynamoDB client
        mockSend = jest.fn();
        mockDynamoClient = {
            send: mockSend
        };
        // Mock DynamoDBDocumentClient.from to return our mock
        lib_dynamodb_1.DynamoDBDocumentClient.from.mockReturnValue(mockDynamoClient);
        // Create repository instance
        repository = new RuleRepository_1.RuleRepository('test-table');
    });
    describe('DynamoDB CRUD Operations', () => {
        describe('loadAllRules', () => {
            test('should load rules from DynamoDB successfully', async () => {
                // Arrange
                const mockResponse = {
                    Items: [
                        {
                            id: 'rule-1',
                            name: 'Rule 1',
                            expression: 'NouveauSinistre == true',
                            weight: 10,
                            distributionSegment: 'segment-1',
                            createdAt: '2023-01-01T00:00:00Z',
                            updatedAt: '2023-01-01T00:00:00Z'
                        },
                        {
                            id: 'rule-2',
                            name: 'Rule 2',
                            expression: 'Client == "VIP"',
                            weight: 20,
                            distributionSegment: 'segment-2',
                            createdAt: '2023-01-01T00:00:00Z',
                            updatedAt: '2023-01-01T00:00:00Z'
                        }
                    ]
                };
                mockSend.mockResolvedValueOnce(mockResponse);
                // Act
                const rules = await repository.loadAllRules();
                // Assert
                expect(rules).toHaveLength(2);
                expect(rules[0].weight).toBe(20); // Should be sorted by weight descending
                expect(rules[1].weight).toBe(10);
                expect(mockSend).toHaveBeenCalledWith(expect.any(lib_dynamodb_1.ScanCommand));
            });
            test('should return empty array when no rules exist', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [] });
                // Act
                const rules = await repository.loadAllRules();
                // Assert
                expect(rules).toEqual([]);
                expect(mockSend).toHaveBeenCalledTimes(1);
            });
            test('should handle undefined Items in DynamoDB response', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({});
                // Act
                const rules = await repository.loadAllRules();
                // Assert
                expect(rules).toEqual([]);
            });
            test('should throw error when DynamoDB operation fails', async () => {
                // Arrange
                const error = new Error('DynamoDB connection failed');
                mockSend.mockRejectedValueOnce(error);
                // Act & Assert
                await expect(repository.loadAllRules()).rejects.toThrow('Failed to load qualification rules: DynamoDB connection failed');
                expect(mockSend).toHaveBeenCalledTimes(1);
            });
            test('should use correct scan parameters', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [] });
                // Act
                await repository.loadAllRules();
                // Assert
                expect(mockSend).toHaveBeenCalledWith(expect.objectContaining({
                    input: expect.objectContaining({
                        TableName: 'test-table',
                        FilterExpression: 'attribute_not_exists(active) OR active = :active',
                        ExpressionAttributeValues: {
                            ':active': 'true'
                        }
                    })
                }));
            });
        });
        describe('addRule', () => {
            test('should add rule to DynamoDB successfully', async () => {
                // Arrange
                const ruleToAdd = {
                    id: 'new-rule',
                    name: 'New Rule',
                    expression: 'Score > 80',
                    weight: 15,
                    distributionSegment: 'premium-segment'
                };
                // Mock successful put operation
                mockSend.mockResolvedValueOnce({});
                // Mock cache refresh (loadAllRules call)
                mockSend.mockResolvedValueOnce({ Items: [] });
                // Act
                await repository.addRule(ruleToAdd);
                // Assert
                expect(mockSend).toHaveBeenCalledTimes(2); // Put + cache refresh
                // Verify PutCommand was called with correct parameters
                const putCall = mockSend.mock.calls[0][0];
                expect(putCall).toBeInstanceOf(lib_dynamodb_1.PutCommand);
                expect(putCall.input.TableName).toBe('test-table');
                expect(putCall.input.Item.id).toBe('new-rule');
                expect(putCall.input.Item.createdAt).toBeDefined();
                expect(putCall.input.Item.updatedAt).toBeDefined();
            });
            test('should add timestamps when adding rule', async () => {
                // Arrange
                const ruleToAdd = {
                    id: 'timestamped-rule',
                    name: 'Timestamped Rule',
                    expression: 'Region == "Paris"',
                    weight: 25,
                    distributionSegment: 'paris-segment'
                };
                mockSend.mockResolvedValueOnce({});
                mockSend.mockResolvedValueOnce({ Items: [] });
                // Act
                await repository.addRule(ruleToAdd);
                // Assert
                const putCall = mockSend.mock.calls[0][0];
                const addedRule = putCall.input.Item;
                expect(addedRule.createdAt).toBeDefined();
                expect(addedRule.updatedAt).toBeDefined();
                expect(new Date(addedRule.createdAt)).toBeInstanceOf(Date);
                expect(new Date(addedRule.updatedAt)).toBeInstanceOf(Date);
            });
            test('should throw error when DynamoDB put operation fails', async () => {
                // Arrange
                const ruleToAdd = {
                    id: 'failing-rule',
                    name: 'Failing Rule',
                    expression: 'Test == true',
                    weight: 5,
                    distributionSegment: 'test-segment'
                };
                const error = new Error('Put operation failed');
                mockSend.mockRejectedValueOnce(error);
                // Act & Assert
                await expect(repository.addRule(ruleToAdd)).rejects.toThrow('Failed to add qualification rule: Put operation failed');
            });
            test('should refresh cache after adding rule', async () => {
                // Arrange
                const ruleToAdd = {
                    id: 'cache-test-rule',
                    name: 'Cache Test Rule',
                    expression: 'CacheTest == true',
                    weight: 30,
                    distributionSegment: 'cache-segment'
                };
                mockSend.mockResolvedValueOnce({}); // Put operation
                mockSend.mockResolvedValueOnce({ Items: [] }); // Cache refresh
                // Act
                await repository.addRule(ruleToAdd);
                // Assert
                expect(mockSend).toHaveBeenCalledTimes(2);
                // First call should be PutCommand
                expect(mockSend.mock.calls[0][0]).toBeInstanceOf(lib_dynamodb_1.PutCommand);
                // Second call should be ScanCommand (cache refresh)
                expect(mockSend.mock.calls[1][0]).toBeInstanceOf(lib_dynamodb_1.ScanCommand);
            });
        });
    });
    describe('Cache Management', () => {
        describe('cache behavior', () => {
            test('should return cached rules on subsequent calls within TTL', async () => {
                // Arrange
                const mockResponse = { Items: [sampleRule] };
                mockSend.mockResolvedValueOnce(mockResponse);
                // Act
                const firstCall = await repository.loadAllRules();
                const secondCall = await repository.loadAllRules();
                // Assert
                expect(firstCall).toEqual(secondCall);
                expect(mockSend).toHaveBeenCalledTimes(1); // Only one DB call
            });
            test('should load from database when cache is empty', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] });
                // Act
                const rules = await repository.loadAllRules();
                // Assert
                expect(rules).toHaveLength(1);
                expect(mockSend).toHaveBeenCalledTimes(1);
            });
            test('should refresh cache when explicitly requested', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Initial load
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Refresh
                // Act
                await repository.loadAllRules(); // Initial load
                await repository.refreshCache(); // Explicit refresh
                // Assert
                expect(mockSend).toHaveBeenCalledTimes(2);
            });
            test('should invalidate cache on refresh', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Initial load
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // After refresh
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Second call after refresh
                // Act
                await repository.loadAllRules(); // Initial load (cached)
                await repository.refreshCache(); // Invalidate cache
                await repository.loadAllRules(); // Should load from DB again
                // Assert
                expect(mockSend).toHaveBeenCalledTimes(3);
            });
        });
        describe('getCacheStats', () => {
            test('should return correct cache stats when cache is empty', () => {
                // Act
                const stats = repository.getCacheStats();
                // Assert
                expect(stats.isCached).toBe(false);
                expect(stats.lastRefresh).toBeNull();
                expect(stats.cacheAge).toBeNull();
            });
            test('should return correct cache stats when cache is populated', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] });
                const beforeLoad = Date.now();
                // Act
                await repository.loadAllRules();
                const stats = repository.getCacheStats();
                const afterLoad = Date.now();
                // Assert
                expect(stats.isCached).toBe(true);
                expect(stats.lastRefresh).toBeInstanceOf(Date);
                expect(stats.cacheAge).toBeGreaterThanOrEqual(0);
                expect(stats.cacheAge).toBeLessThan(afterLoad - beforeLoad + 100); // Allow some margin
            });
            test('should return correct cache stats after refresh', async () => {
                // Arrange
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Initial load
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Refresh
                // Act
                await repository.loadAllRules();
                const statsBeforeRefresh = repository.getCacheStats();
                // Wait a bit to ensure different timestamps
                await new Promise(resolve => setTimeout(resolve, 10));
                await repository.refreshCache();
                const statsAfterRefresh = repository.getCacheStats();
                // Assert
                expect(statsBeforeRefresh.isCached).toBe(true);
                expect(statsAfterRefresh.isCached).toBe(true);
                expect(statsAfterRefresh.lastRefresh.getTime()).toBeGreaterThan(statsBeforeRefresh.lastRefresh.getTime());
            });
        });
        describe('cache TTL behavior', () => {
            test('should respect cache TTL', async () => {
                // Arrange
                const originalCacheTTL = repository.CACHE_TTL_MS;
                repository.CACHE_TTL_MS = 50; // 50ms TTL for testing
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // Initial load
                mockSend.mockResolvedValueOnce({ Items: [sampleRule] }); // After TTL expires
                // Act
                await repository.loadAllRules(); // Initial load
                // Wait for TTL to expire
                await new Promise(resolve => setTimeout(resolve, 60));
                await repository.loadAllRules(); // Should load from DB again
                // Assert
                expect(mockSend).toHaveBeenCalledTimes(2);
                // Restore original TTL
                repository.CACHE_TTL_MS = originalCacheTTL;
            });
        });
    });
    describe('Rule Sorting', () => {
        test('should sort rules by weight in descending order', async () => {
            // Arrange
            const unsortedRules = [
                {
                    id: 'rule-1',
                    name: 'Rule 1',
                    expression: 'Test == 1',
                    weight: 5,
                    distributionSegment: 'segment-1',
                    createdAt: '2023-01-01T00:00:00Z',
                    updatedAt: '2023-01-01T00:00:00Z'
                },
                {
                    id: 'rule-2',
                    name: 'Rule 2',
                    expression: 'Test == 2',
                    weight: 15,
                    distributionSegment: 'segment-2',
                    createdAt: '2023-01-01T00:00:00Z',
                    updatedAt: '2023-01-01T00:00:00Z'
                },
                {
                    id: 'rule-3',
                    name: 'Rule 3',
                    expression: 'Test == 3',
                    weight: 10,
                    distributionSegment: 'segment-3',
                    createdAt: '2023-01-01T00:00:00Z',
                    updatedAt: '2023-01-01T00:00:00Z'
                }
            ];
            mockSend.mockResolvedValueOnce({ Items: unsortedRules });
            // Act
            const rules = await repository.loadAllRules();
            // Assert
            expect(rules).toHaveLength(3);
            expect(rules[0].weight).toBe(15); // Highest weight first
            expect(rules[1].weight).toBe(10);
            expect(rules[2].weight).toBe(5); // Lowest weight last
        });
    });
    describe('Environment Configuration', () => {
        test('should use default table name when not provided', () => {
            // Arrange
            delete process.env.QUALIFICATION_RULES_TABLE;
            // Act
            const defaultRepository = new RuleRepository_1.RuleRepository();
            // Assert - We can't directly test the private tableName, but we can verify it doesn't throw
            expect(defaultRepository).toBeInstanceOf(RuleRepository_1.RuleRepository);
        });
        test('should use environment variable for table name', () => {
            // Arrange
            process.env.QUALIFICATION_RULES_TABLE = 'env-table-name';
            // Act
            const envRepository = new RuleRepository_1.RuleRepository();
            // Assert - We can't directly test the private tableName, but we can verify it doesn't throw
            expect(envRepository).toBeInstanceOf(RuleRepository_1.RuleRepository);
            // Cleanup
            delete process.env.QUALIFICATION_RULES_TABLE;
        });
        test('should use provided table name over environment variable', () => {
            // Arrange
            process.env.QUALIFICATION_RULES_TABLE = 'env-table-name';
            // Act
            const customRepository = new RuleRepository_1.RuleRepository('custom-table-name');
            // Assert - We can't directly test the private tableName, but we can verify it doesn't throw
            expect(customRepository).toBeInstanceOf(RuleRepository_1.RuleRepository);
            // Cleanup
            delete process.env.QUALIFICATION_RULES_TABLE;
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUnVsZVJlcG9zaXRvcnkudW5pdC50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3Rlc3RzL2RlY2lzaW9uLWVuZ2luZS9SdWxlUmVwb3NpdG9yeS51bml0LnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxrRkFBK0U7QUFFL0Usd0RBQXdGO0FBRXhGLGVBQWU7QUFDZixJQUFJLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDdEMsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRW5DLFFBQVEsQ0FBQywyQkFBMkIsRUFBRSxHQUFHLEVBQUU7SUFDekMsSUFBSSxVQUEwQixDQUFDO0lBQy9CLElBQUksUUFBa0MsQ0FBQztJQUN2QyxJQUFJLGdCQUFxRCxDQUFDO0lBRTFELE1BQU0sVUFBVSxHQUFzQjtRQUNwQyxFQUFFLEVBQUUsUUFBUTtRQUNaLElBQUksRUFBRSxXQUFXO1FBQ2pCLFVBQVUsRUFBRSx5QkFBeUI7UUFDckMsTUFBTSxFQUFFLEVBQUU7UUFDVixtQkFBbUIsRUFBRSxXQUFXO1FBQ2hDLFNBQVMsRUFBRSxzQkFBc0I7UUFDakMsU0FBUyxFQUFFLHNCQUFzQjtLQUNsQyxDQUFDO0lBRUYsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLGtCQUFrQjtRQUNsQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsdUJBQXVCO1FBQ3ZCLFFBQVEsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDckIsZ0JBQWdCLEdBQUc7WUFDakIsSUFBSSxFQUFFLFFBQVE7U0FDUixDQUFDO1FBRVQsc0RBQXNEO1FBQ3JELHFDQUFzQixDQUFDLElBQWtCLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFN0UsNkJBQTZCO1FBQzdCLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxFQUFFO1FBQ3hDLFFBQVEsQ0FBQyxjQUFjLEVBQUUsR0FBRyxFQUFFO1lBQzVCLElBQUksQ0FBQyw4Q0FBOEMsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDOUQsVUFBVTtnQkFDVixNQUFNLFlBQVksR0FBRztvQkFDbkIsS0FBSyxFQUFFO3dCQUNMOzRCQUNFLEVBQUUsRUFBRSxRQUFROzRCQUNaLElBQUksRUFBRSxRQUFROzRCQUNkLFVBQVUsRUFBRSx5QkFBeUI7NEJBQ3JDLE1BQU0sRUFBRSxFQUFFOzRCQUNWLG1CQUFtQixFQUFFLFdBQVc7NEJBQ2hDLFNBQVMsRUFBRSxzQkFBc0I7NEJBQ2pDLFNBQVMsRUFBRSxzQkFBc0I7eUJBQ2xDO3dCQUNEOzRCQUNFLEVBQUUsRUFBRSxRQUFROzRCQUNaLElBQUksRUFBRSxRQUFROzRCQUNkLFVBQVUsRUFBRSxpQkFBaUI7NEJBQzdCLE1BQU0sRUFBRSxFQUFFOzRCQUNWLG1CQUFtQixFQUFFLFdBQVc7NEJBQ2hDLFNBQVMsRUFBRSxzQkFBc0I7NEJBQ2pDLFNBQVMsRUFBRSxzQkFBc0I7eUJBQ2xDO3FCQUNGO2lCQUNGLENBQUM7Z0JBQ0YsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUU3QyxNQUFNO2dCQUNOLE1BQU0sS0FBSyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUU5QyxTQUFTO2dCQUNULE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsd0NBQXdDO2dCQUMxRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMEJBQVcsQ0FBQyxDQUFDLENBQUM7WUFDakUsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsK0NBQStDLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQy9ELFVBQVU7Z0JBQ1YsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBRTlDLE1BQU07Z0JBQ04sTUFBTSxLQUFLLEdBQUcsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBRTlDLFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDMUIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVDLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLG9EQUFvRCxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNwRSxVQUFVO2dCQUNWLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFFbkMsTUFBTTtnQkFDTixNQUFNLEtBQUssR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFFOUMsU0FBUztnQkFDVCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGtEQUFrRCxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNsRSxVQUFVO2dCQUNWLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLDRCQUE0QixDQUFDLENBQUM7Z0JBQ3RELFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFdEMsZUFBZTtnQkFDZixNQUFNLE1BQU0sQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGdFQUFnRSxDQUFDLENBQUM7Z0JBQzFILE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxvQ0FBb0MsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDcEQsVUFBVTtnQkFDVixRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFFOUMsTUFBTTtnQkFDTixNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFFaEMsU0FBUztnQkFDVCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO29CQUM1RCxLQUFLLEVBQUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDO3dCQUM3QixTQUFTLEVBQUUsWUFBWTt3QkFDdkIsZ0JBQWdCLEVBQUUsa0RBQWtEO3dCQUNwRSx5QkFBeUIsRUFBRTs0QkFDekIsU0FBUyxFQUFFLE1BQU07eUJBQ2xCO3FCQUNGLENBQUM7aUJBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsUUFBUSxDQUFDLFNBQVMsRUFBRSxHQUFHLEVBQUU7WUFDdkIsSUFBSSxDQUFDLDBDQUEwQyxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUMxRCxVQUFVO2dCQUNWLE1BQU0sU0FBUyxHQUFHO29CQUNoQixFQUFFLEVBQUUsVUFBVTtvQkFDZCxJQUFJLEVBQUUsVUFBVTtvQkFDaEIsVUFBVSxFQUFFLFlBQVk7b0JBQ3hCLE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLGlCQUFpQjtpQkFDdkMsQ0FBQztnQkFFRixnQ0FBZ0M7Z0JBQ2hDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDbkMseUNBQXlDO2dCQUN6QyxRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFFOUMsTUFBTTtnQkFDTixNQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBRXBDLFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCO2dCQUVqRSx1REFBdUQ7Z0JBQ3ZELE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMxQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLHlCQUFVLENBQUMsQ0FBQztnQkFDM0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUNuRCxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUMvQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25ELE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyRCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDeEQsVUFBVTtnQkFDVixNQUFNLFNBQVMsR0FBRztvQkFDaEIsRUFBRSxFQUFFLGtCQUFrQjtvQkFDdEIsSUFBSSxFQUFFLGtCQUFrQjtvQkFDeEIsVUFBVSxFQUFFLG1CQUFtQjtvQkFDL0IsTUFBTSxFQUFFLEVBQUU7b0JBQ1YsbUJBQW1CLEVBQUUsZUFBZTtpQkFDckMsQ0FBQztnQkFFRixRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ25DLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUU5QyxNQUFNO2dCQUNOLE1BQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFFcEMsU0FBUztnQkFDVCxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUMsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7Z0JBRXJDLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzNELE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDN0QsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsc0RBQXNELEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ3RFLFVBQVU7Z0JBQ1YsTUFBTSxTQUFTLEdBQUc7b0JBQ2hCLEVBQUUsRUFBRSxjQUFjO29CQUNsQixJQUFJLEVBQUUsY0FBYztvQkFDcEIsVUFBVSxFQUFFLGNBQWM7b0JBQzFCLE1BQU0sRUFBRSxDQUFDO29CQUNULG1CQUFtQixFQUFFLGNBQWM7aUJBQ3BDLENBQUM7Z0JBRUYsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQztnQkFDaEQsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUV0QyxlQUFlO2dCQUNmLE1BQU0sTUFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLHdEQUF3RCxDQUFDLENBQUM7WUFDeEgsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQ3hELFVBQVU7Z0JBQ1YsTUFBTSxTQUFTLEdBQUc7b0JBQ2hCLEVBQUUsRUFBRSxpQkFBaUI7b0JBQ3JCLElBQUksRUFBRSxpQkFBaUI7b0JBQ3ZCLFVBQVUsRUFBRSxtQkFBbUI7b0JBQy9CLE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLGVBQWU7aUJBQ3JDLENBQUM7Z0JBRUYsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO2dCQUNwRCxRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLGdCQUFnQjtnQkFFL0QsTUFBTTtnQkFDTixNQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBRXBDLFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUxQyxrQ0FBa0M7Z0JBQ2xDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyx5QkFBVSxDQUFDLENBQUM7Z0JBRTdELG9EQUFvRDtnQkFDcEQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLDBCQUFXLENBQUMsQ0FBQztZQUNoRSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxFQUFFO1FBQ2hDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLEVBQUU7WUFDOUIsSUFBSSxDQUFDLDJEQUEyRCxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUMzRSxVQUFVO2dCQUNWLE1BQU0sWUFBWSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztnQkFDN0MsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUU3QyxNQUFNO2dCQUNOLE1BQU0sU0FBUyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNsRCxNQUFNLFVBQVUsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFFbkQsU0FBUztnQkFDVCxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN0QyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7WUFDaEUsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsK0NBQStDLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQy9ELFVBQVU7Z0JBQ1YsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUV4RCxNQUFNO2dCQUNOLE1BQU0sS0FBSyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUU5QyxTQUFTO2dCQUNULE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxnREFBZ0QsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDaEUsVUFBVTtnQkFDVixRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxlQUFlO2dCQUN4RSxRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVO2dCQUVuRSxNQUFNO2dCQUNOLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsZUFBZTtnQkFDaEQsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxtQkFBbUI7Z0JBRXBELFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVDLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLG9DQUFvQyxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNwRCxVQUFVO2dCQUNWLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGVBQWU7Z0JBQ3hFLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGdCQUFnQjtnQkFDekUsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsNEJBQTRCO2dCQUVyRixNQUFNO2dCQUNOLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsd0JBQXdCO2dCQUN6RCxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQjtnQkFDcEQsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyw0QkFBNEI7Z0JBRTdELFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsZUFBZSxFQUFFLEdBQUcsRUFBRTtZQUM3QixJQUFJLENBQUMsdURBQXVELEVBQUUsR0FBRyxFQUFFO2dCQUNqRSxNQUFNO2dCQUNOLE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFFekMsU0FBUztnQkFDVCxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDckMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQywyREFBMkQsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDM0UsVUFBVTtnQkFDVixRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3hELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFFOUIsTUFBTTtnQkFDTixNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDaEMsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN6QyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBRTdCLFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMvQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqRCxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLEdBQUcsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsb0JBQW9CO1lBQ3pGLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGlEQUFpRCxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUNqRSxVQUFVO2dCQUNWLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGVBQWU7Z0JBQ3hFLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVU7Z0JBRW5FLE1BQU07Z0JBQ04sTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ2hDLE1BQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUV0RCw0Q0FBNEM7Z0JBQzVDLE1BQU0sSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBRXRELE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNoQyxNQUFNLGlCQUFpQixHQUFHLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFFckQsU0FBUztnQkFDVCxNQUFNLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMvQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM5QyxNQUFNLENBQUMsaUJBQWlCLENBQUMsV0FBWSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLFdBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzlHLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDMUMsVUFBVTtnQkFDVixNQUFNLGdCQUFnQixHQUFJLFVBQWtCLENBQUMsWUFBWSxDQUFDO2dCQUN6RCxVQUFrQixDQUFDLFlBQVksR0FBRyxFQUFFLENBQUMsQ0FBQyx1QkFBdUI7Z0JBRTlELFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGVBQWU7Z0JBQ3hFLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG9CQUFvQjtnQkFFN0UsTUFBTTtnQkFDTixNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLGVBQWU7Z0JBRWhELHlCQUF5QjtnQkFDekIsTUFBTSxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFdEQsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyw0QkFBNEI7Z0JBRTdELFNBQVM7Z0JBQ1QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUxQyx1QkFBdUI7Z0JBQ3RCLFVBQWtCLENBQUMsWUFBWSxHQUFHLGdCQUFnQixDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyxjQUFjLEVBQUUsR0FBRyxFQUFFO1FBQzVCLElBQUksQ0FBQyxpREFBaUQsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNqRSxVQUFVO1lBQ1YsTUFBTSxhQUFhLEdBQUc7Z0JBQ3BCO29CQUNFLEVBQUUsRUFBRSxRQUFRO29CQUNaLElBQUksRUFBRSxRQUFRO29CQUNkLFVBQVUsRUFBRSxXQUFXO29CQUN2QixNQUFNLEVBQUUsQ0FBQztvQkFDVCxtQkFBbUIsRUFBRSxXQUFXO29CQUNoQyxTQUFTLEVBQUUsc0JBQXNCO29CQUNqQyxTQUFTLEVBQUUsc0JBQXNCO2lCQUNsQztnQkFDRDtvQkFDRSxFQUFFLEVBQUUsUUFBUTtvQkFDWixJQUFJLEVBQUUsUUFBUTtvQkFDZCxVQUFVLEVBQUUsV0FBVztvQkFDdkIsTUFBTSxFQUFFLEVBQUU7b0JBQ1YsbUJBQW1CLEVBQUUsV0FBVztvQkFDaEMsU0FBUyxFQUFFLHNCQUFzQjtvQkFDakMsU0FBUyxFQUFFLHNCQUFzQjtpQkFDbEM7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLFFBQVE7b0JBQ1osSUFBSSxFQUFFLFFBQVE7b0JBQ2QsVUFBVSxFQUFFLFdBQVc7b0JBQ3ZCLE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLFdBQVc7b0JBQ2hDLFNBQVMsRUFBRSxzQkFBc0I7b0JBQ2pDLFNBQVMsRUFBRSxzQkFBc0I7aUJBQ2xDO2FBQ0YsQ0FBQztZQUVGLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO1lBRXpELE1BQU07WUFDTixNQUFNLEtBQUssR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUU5QyxTQUFTO1lBQ1QsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM5QixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtZQUN6RCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNqQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFLHFCQUFxQjtRQUN6RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUSxDQUFDLDJCQUEyQixFQUFFLEdBQUcsRUFBRTtRQUN6QyxJQUFJLENBQUMsaURBQWlELEVBQUUsR0FBRyxFQUFFO1lBQzNELFVBQVU7WUFDVixPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUM7WUFFN0MsTUFBTTtZQUNOLE1BQU0saUJBQWlCLEdBQUcsSUFBSSwrQkFBYyxFQUFFLENBQUM7WUFFL0MsNEZBQTRGO1lBQzVGLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQywrQkFBYyxDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0RBQWdELEVBQUUsR0FBRyxFQUFFO1lBQzFELFVBQVU7WUFDVixPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixHQUFHLGdCQUFnQixDQUFDO1lBRXpELE1BQU07WUFDTixNQUFNLGFBQWEsR0FBRyxJQUFJLCtCQUFjLEVBQUUsQ0FBQztZQUUzQyw0RkFBNEY7WUFDNUYsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLGNBQWMsQ0FBQywrQkFBYyxDQUFDLENBQUM7WUFFckQsVUFBVTtZQUNWLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQywwREFBMEQsRUFBRSxHQUFHLEVBQUU7WUFDcEUsVUFBVTtZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEdBQUcsZ0JBQWdCLENBQUM7WUFFekQsTUFBTTtZQUNOLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSwrQkFBYyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFFakUsNEZBQTRGO1lBQzVGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLGNBQWMsQ0FBQywrQkFBYyxDQUFDLENBQUM7WUFFeEQsVUFBVTtZQUNWLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSdWxlUmVwb3NpdG9yeSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2RlY2lzaW9uLWVuZ2luZS9SdWxlUmVwb3NpdG9yeSc7XHJcbmltcG9ydCB7IFF1YWxpZmljYXRpb25SdWxlIH0gZnJvbSAnLi4vLi4vdHlwZXMvZGVjaXNpb24tZW5naW5lJztcclxuaW1wb3J0IHsgRHluYW1vREJEb2N1bWVudENsaWVudCwgU2NhbkNvbW1hbmQsIFB1dENvbW1hbmQgfSBmcm9tICdAYXdzLXNkay9saWItZHluYW1vZGInO1xyXG5cclxuLy8gTW9jayBBV1MgU0RLXHJcbmplc3QubW9jaygnQGF3cy1zZGsvY2xpZW50LWR5bmFtb2RiJyk7XHJcbmplc3QubW9jaygnQGF3cy1zZGsvbGliLWR5bmFtb2RiJyk7XHJcblxyXG5kZXNjcmliZSgnUnVsZVJlcG9zaXRvcnkgVW5pdCBUZXN0cycsICgpID0+IHtcclxuICBsZXQgcmVwb3NpdG9yeTogUnVsZVJlcG9zaXRvcnk7XHJcbiAgbGV0IG1vY2tTZW5kOiBqZXN0Lk1vY2tlZEZ1bmN0aW9uPGFueT47XHJcbiAgbGV0IG1vY2tEeW5hbW9DbGllbnQ6IGplc3QuTW9ja2VkPER5bmFtb0RCRG9jdW1lbnRDbGllbnQ+O1xyXG5cclxuICBjb25zdCBzYW1wbGVSdWxlOiBRdWFsaWZpY2F0aW9uUnVsZSA9IHtcclxuICAgIGlkOiAncnVsZS0xJyxcclxuICAgIG5hbWU6ICdUZXN0IFJ1bGUnLFxyXG4gICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJyxcclxuICAgIHdlaWdodDogMTAsXHJcbiAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnc2VnbWVudC0xJyxcclxuICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJyxcclxuICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJ1xyXG4gIH07XHJcblxyXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgLy8gUmVzZXQgYWxsIG1vY2tzXHJcbiAgICBqZXN0LmNsZWFyQWxsTW9ja3MoKTtcclxuICAgIFxyXG4gICAgLy8gTW9jayBEeW5hbW9EQiBjbGllbnRcclxuICAgIG1vY2tTZW5kID0gamVzdC5mbigpO1xyXG4gICAgbW9ja0R5bmFtb0NsaWVudCA9IHtcclxuICAgICAgc2VuZDogbW9ja1NlbmRcclxuICAgIH0gYXMgYW55O1xyXG5cclxuICAgIC8vIE1vY2sgRHluYW1vREJEb2N1bWVudENsaWVudC5mcm9tIHRvIHJldHVybiBvdXIgbW9ja1xyXG4gICAgKER5bmFtb0RCRG9jdW1lbnRDbGllbnQuZnJvbSBhcyBqZXN0Lk1vY2spLm1vY2tSZXR1cm5WYWx1ZShtb2NrRHluYW1vQ2xpZW50KTtcclxuXHJcbiAgICAvLyBDcmVhdGUgcmVwb3NpdG9yeSBpbnN0YW5jZVxyXG4gICAgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnRHluYW1vREIgQ1JVRCBPcGVyYXRpb25zJywgKCkgPT4ge1xyXG4gICAgZGVzY3JpYmUoJ2xvYWRBbGxSdWxlcycsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIGxvYWQgcnVsZXMgZnJvbSBEeW5hbW9EQiBzdWNjZXNzZnVsbHknLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICAgIGNvbnN0IG1vY2tSZXNwb25zZSA9IHtcclxuICAgICAgICAgIEl0ZW1zOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ3J1bGUtMScsXHJcbiAgICAgICAgICAgICAgbmFtZTogJ1J1bGUgMScsXHJcbiAgICAgICAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJyxcclxuICAgICAgICAgICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50LTEnLFxyXG4gICAgICAgICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJyxcclxuICAgICAgICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwWidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGlkOiAncnVsZS0yJyxcclxuICAgICAgICAgICAgICBuYW1lOiAnUnVsZSAyJyxcclxuICAgICAgICAgICAgICBleHByZXNzaW9uOiAnQ2xpZW50ID09IFwiVklQXCInLFxyXG4gICAgICAgICAgICAgIHdlaWdodDogMjAsXHJcbiAgICAgICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ3NlZ21lbnQtMicsXHJcbiAgICAgICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonLFxyXG4gICAgICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UobW9ja1Jlc3BvbnNlKTtcclxuXHJcbiAgICAgICAgLy8gQWN0XHJcbiAgICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBleHBlY3QocnVsZXMpLnRvSGF2ZUxlbmd0aCgyKTtcclxuICAgICAgICBleHBlY3QocnVsZXNbMF0ud2VpZ2h0KS50b0JlKDIwKTsgLy8gU2hvdWxkIGJlIHNvcnRlZCBieSB3ZWlnaHQgZGVzY2VuZGluZ1xyXG4gICAgICAgIGV4cGVjdChydWxlc1sxXS53ZWlnaHQpLnRvQmUoMTApO1xyXG4gICAgICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbkNhbGxlZFdpdGgoZXhwZWN0LmFueShTY2FuQ29tbWFuZCkpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCByZXR1cm4gZW1wdHkgYXJyYXkgd2hlbiBubyBydWxlcyBleGlzdCcsIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyBBcnJhbmdlXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtdIH0pO1xyXG5cclxuICAgICAgICAvLyBBY3RcclxuICAgICAgICBjb25zdCBydWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAgIC8vIEFzc2VydFxyXG4gICAgICAgIGV4cGVjdChydWxlcykudG9FcXVhbChbXSk7XHJcbiAgICAgICAgZXhwZWN0KG1vY2tTZW5kKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIGhhbmRsZSB1bmRlZmluZWQgSXRlbXMgaW4gRHluYW1vREIgcmVzcG9uc2UnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7fSk7XHJcblxyXG4gICAgICAgIC8vIEFjdFxyXG4gICAgICAgIGNvbnN0IHJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuXHJcbiAgICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgICAgZXhwZWN0KHJ1bGVzKS50b0VxdWFsKFtdKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgdGhyb3cgZXJyb3Igd2hlbiBEeW5hbW9EQiBvcGVyYXRpb24gZmFpbHMnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdEeW5hbW9EQiBjb25uZWN0aW9uIGZhaWxlZCcpO1xyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZWplY3RlZFZhbHVlT25jZShlcnJvcik7XHJcblxyXG4gICAgICAgIC8vIEFjdCAmIEFzc2VydFxyXG4gICAgICAgIGF3YWl0IGV4cGVjdChyZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpKS5yZWplY3RzLnRvVGhyb3coJ0ZhaWxlZCB0byBsb2FkIHF1YWxpZmljYXRpb24gcnVsZXM6IER5bmFtb0RCIGNvbm5lY3Rpb24gZmFpbGVkJyk7XHJcbiAgICAgICAgZXhwZWN0KG1vY2tTZW5kKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHVzZSBjb3JyZWN0IHNjYW4gcGFyYW1ldGVycycsIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyBBcnJhbmdlXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtdIH0pO1xyXG5cclxuICAgICAgICAvLyBBY3RcclxuICAgICAgICBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKGV4cGVjdC5vYmplY3RDb250YWluaW5nKHtcclxuICAgICAgICAgIGlucHV0OiBleHBlY3Qub2JqZWN0Q29udGFpbmluZyh7XHJcbiAgICAgICAgICAgIFRhYmxlTmFtZTogJ3Rlc3QtdGFibGUnLFxyXG4gICAgICAgICAgICBGaWx0ZXJFeHByZXNzaW9uOiAnYXR0cmlidXRlX25vdF9leGlzdHMoYWN0aXZlKSBPUiBhY3RpdmUgPSA6YWN0aXZlJyxcclxuICAgICAgICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczoge1xyXG4gICAgICAgICAgICAgICc6YWN0aXZlJzogJ3RydWUnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIGRlc2NyaWJlKCdhZGRSdWxlJywgKCkgPT4ge1xyXG4gICAgICB0ZXN0KCdzaG91bGQgYWRkIHJ1bGUgdG8gRHluYW1vREIgc3VjY2Vzc2Z1bGx5JywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgICBjb25zdCBydWxlVG9BZGQgPSB7XHJcbiAgICAgICAgICBpZDogJ25ldy1ydWxlJyxcclxuICAgICAgICAgIG5hbWU6ICdOZXcgUnVsZScsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnU2NvcmUgPiA4MCcsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDE1LFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ3ByZW1pdW0tc2VnbWVudCdcclxuICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIE1vY2sgc3VjY2Vzc2Z1bCBwdXQgb3BlcmF0aW9uXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHt9KTtcclxuICAgICAgICAvLyBNb2NrIGNhY2hlIHJlZnJlc2ggKGxvYWRBbGxSdWxlcyBjYWxsKVxyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7IEl0ZW1zOiBbXSB9KTtcclxuXHJcbiAgICAgICAgLy8gQWN0XHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5hZGRSdWxlKHJ1bGVUb0FkZCk7XHJcblxyXG4gICAgICAgIC8vIEFzc2VydFxyXG4gICAgICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDIpOyAvLyBQdXQgKyBjYWNoZSByZWZyZXNoXHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gVmVyaWZ5IFB1dENvbW1hbmQgd2FzIGNhbGxlZCB3aXRoIGNvcnJlY3QgcGFyYW1ldGVyc1xyXG4gICAgICAgIGNvbnN0IHB1dENhbGwgPSBtb2NrU2VuZC5tb2NrLmNhbGxzWzBdWzBdO1xyXG4gICAgICAgIGV4cGVjdChwdXRDYWxsKS50b0JlSW5zdGFuY2VPZihQdXRDb21tYW5kKTtcclxuICAgICAgICBleHBlY3QocHV0Q2FsbC5pbnB1dC5UYWJsZU5hbWUpLnRvQmUoJ3Rlc3QtdGFibGUnKTtcclxuICAgICAgICBleHBlY3QocHV0Q2FsbC5pbnB1dC5JdGVtLmlkKS50b0JlKCduZXctcnVsZScpO1xyXG4gICAgICAgIGV4cGVjdChwdXRDYWxsLmlucHV0Lkl0ZW0uY3JlYXRlZEF0KS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICAgIGV4cGVjdChwdXRDYWxsLmlucHV0Lkl0ZW0udXBkYXRlZEF0KS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBhZGQgdGltZXN0YW1wcyB3aGVuIGFkZGluZyBydWxlJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgICBjb25zdCBydWxlVG9BZGQgPSB7XHJcbiAgICAgICAgICBpZDogJ3RpbWVzdGFtcGVkLXJ1bGUnLFxyXG4gICAgICAgICAgbmFtZTogJ1RpbWVzdGFtcGVkIFJ1bGUnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ1JlZ2lvbiA9PSBcIlBhcmlzXCInLFxyXG4gICAgICAgICAgd2VpZ2h0OiAyNSxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdwYXJpcy1zZWdtZW50J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHt9KTtcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoeyBJdGVtczogW10gfSk7XHJcblxyXG4gICAgICAgIC8vIEFjdFxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkuYWRkUnVsZShydWxlVG9BZGQpO1xyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBjb25zdCBwdXRDYWxsID0gbW9ja1NlbmQubW9jay5jYWxsc1swXVswXTtcclxuICAgICAgICBjb25zdCBhZGRlZFJ1bGUgPSBwdXRDYWxsLmlucHV0Lkl0ZW07XHJcbiAgICAgICAgXHJcbiAgICAgICAgZXhwZWN0KGFkZGVkUnVsZS5jcmVhdGVkQXQpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KGFkZGVkUnVsZS51cGRhdGVkQXQpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KG5ldyBEYXRlKGFkZGVkUnVsZS5jcmVhdGVkQXQpKS50b0JlSW5zdGFuY2VPZihEYXRlKTtcclxuICAgICAgICBleHBlY3QobmV3IERhdGUoYWRkZWRSdWxlLnVwZGF0ZWRBdCkpLnRvQmVJbnN0YW5jZU9mKERhdGUpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCB0aHJvdyBlcnJvciB3aGVuIER5bmFtb0RCIHB1dCBvcGVyYXRpb24gZmFpbHMnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICAgIGNvbnN0IHJ1bGVUb0FkZCA9IHtcclxuICAgICAgICAgIGlkOiAnZmFpbGluZy1ydWxlJyxcclxuICAgICAgICAgIG5hbWU6ICdGYWlsaW5nIFJ1bGUnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ1Rlc3QgPT0gdHJ1ZScsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDUsXHJcbiAgICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAndGVzdC1zZWdtZW50J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgZXJyb3IgPSBuZXcgRXJyb3IoJ1B1dCBvcGVyYXRpb24gZmFpbGVkJyk7XHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1JlamVjdGVkVmFsdWVPbmNlKGVycm9yKTtcclxuXHJcbiAgICAgICAgLy8gQWN0ICYgQXNzZXJ0XHJcbiAgICAgICAgYXdhaXQgZXhwZWN0KHJlcG9zaXRvcnkuYWRkUnVsZShydWxlVG9BZGQpKS5yZWplY3RzLnRvVGhyb3coJ0ZhaWxlZCB0byBhZGQgcXVhbGlmaWNhdGlvbiBydWxlOiBQdXQgb3BlcmF0aW9uIGZhaWxlZCcpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCByZWZyZXNoIGNhY2hlIGFmdGVyIGFkZGluZyBydWxlJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgICBjb25zdCBydWxlVG9BZGQgPSB7XHJcbiAgICAgICAgICBpZDogJ2NhY2hlLXRlc3QtcnVsZScsXHJcbiAgICAgICAgICBuYW1lOiAnQ2FjaGUgVGVzdCBSdWxlJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdDYWNoZVRlc3QgPT0gdHJ1ZScsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDMwLFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ2NhY2hlLXNlZ21lbnQnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe30pOyAvLyBQdXQgb3BlcmF0aW9uXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtdIH0pOyAvLyBDYWNoZSByZWZyZXNoXHJcblxyXG4gICAgICAgIC8vIEFjdFxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkuYWRkUnVsZShydWxlVG9BZGQpO1xyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygyKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBGaXJzdCBjYWxsIHNob3VsZCBiZSBQdXRDb21tYW5kXHJcbiAgICAgICAgZXhwZWN0KG1vY2tTZW5kLm1vY2suY2FsbHNbMF1bMF0pLnRvQmVJbnN0YW5jZU9mKFB1dENvbW1hbmQpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIFNlY29uZCBjYWxsIHNob3VsZCBiZSBTY2FuQ29tbWFuZCAoY2FjaGUgcmVmcmVzaClcclxuICAgICAgICBleHBlY3QobW9ja1NlbmQubW9jay5jYWxsc1sxXVswXSkudG9CZUluc3RhbmNlT2YoU2NhbkNvbW1hbmQpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnQ2FjaGUgTWFuYWdlbWVudCcsICgpID0+IHtcclxuICAgIGRlc2NyaWJlKCdjYWNoZSBiZWhhdmlvcicsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIHJldHVybiBjYWNoZWQgcnVsZXMgb24gc3Vic2VxdWVudCBjYWxscyB3aXRoaW4gVFRMJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgICBjb25zdCBtb2NrUmVzcG9uc2UgPSB7IEl0ZW1zOiBbc2FtcGxlUnVsZV0gfTtcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UobW9ja1Jlc3BvbnNlKTtcclxuXHJcbiAgICAgICAgLy8gQWN0XHJcbiAgICAgICAgY29uc3QgZmlyc3RDYWxsID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgICBjb25zdCBzZWNvbmRDYWxsID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuXHJcbiAgICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgICAgZXhwZWN0KGZpcnN0Q2FsbCkudG9FcXVhbChzZWNvbmRDYWxsKTtcclxuICAgICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTsgLy8gT25seSBvbmUgREIgY2FsbFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBsb2FkIGZyb20gZGF0YWJhc2Ugd2hlbiBjYWNoZSBpcyBlbXB0eScsIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyBBcnJhbmdlXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtzYW1wbGVSdWxlXSB9KTtcclxuXHJcbiAgICAgICAgLy8gQWN0XHJcbiAgICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBleHBlY3QocnVsZXMpLnRvSGF2ZUxlbmd0aCgxKTtcclxuICAgICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmVmcmVzaCBjYWNoZSB3aGVuIGV4cGxpY2l0bHkgcmVxdWVzdGVkJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoeyBJdGVtczogW3NhbXBsZVJ1bGVdIH0pOyAvLyBJbml0aWFsIGxvYWRcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoeyBJdGVtczogW3NhbXBsZVJ1bGVdIH0pOyAvLyBSZWZyZXNoXHJcblxyXG4gICAgICAgIC8vIEFjdFxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7IC8vIEluaXRpYWwgbG9hZFxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkucmVmcmVzaENhY2hlKCk7IC8vIEV4cGxpY2l0IHJlZnJlc2hcclxuXHJcbiAgICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgICAgZXhwZWN0KG1vY2tTZW5kKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMik7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIGludmFsaWRhdGUgY2FjaGUgb24gcmVmcmVzaCcsIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyBBcnJhbmdlXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtzYW1wbGVSdWxlXSB9KTsgLy8gSW5pdGlhbCBsb2FkXHJcbiAgICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtzYW1wbGVSdWxlXSB9KTsgLy8gQWZ0ZXIgcmVmcmVzaFxyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7IEl0ZW1zOiBbc2FtcGxlUnVsZV0gfSk7IC8vIFNlY29uZCBjYWxsIGFmdGVyIHJlZnJlc2hcclxuXHJcbiAgICAgICAgLy8gQWN0XHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTsgLy8gSW5pdGlhbCBsb2FkIChjYWNoZWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5yZWZyZXNoQ2FjaGUoKTsgLy8gSW52YWxpZGF0ZSBjYWNoZVxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7IC8vIFNob3VsZCBsb2FkIGZyb20gREIgYWdhaW5cclxuXHJcbiAgICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgICAgZXhwZWN0KG1vY2tTZW5kKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMyk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcblxyXG4gICAgZGVzY3JpYmUoJ2dldENhY2hlU3RhdHMnLCAoKSA9PiB7XHJcbiAgICAgIHRlc3QoJ3Nob3VsZCByZXR1cm4gY29ycmVjdCBjYWNoZSBzdGF0cyB3aGVuIGNhY2hlIGlzIGVtcHR5JywgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFjdFxyXG4gICAgICAgIGNvbnN0IHN0YXRzID0gcmVwb3NpdG9yeS5nZXRDYWNoZVN0YXRzKCk7XHJcblxyXG4gICAgICAgIC8vIEFzc2VydFxyXG4gICAgICAgIGV4cGVjdChzdGF0cy5pc0NhY2hlZCkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KHN0YXRzLmxhc3RSZWZyZXNoKS50b0JlTnVsbCgpO1xyXG4gICAgICAgIGV4cGVjdChzdGF0cy5jYWNoZUFnZSkudG9CZU51bGwoKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmV0dXJuIGNvcnJlY3QgY2FjaGUgc3RhdHMgd2hlbiBjYWNoZSBpcyBwb3B1bGF0ZWQnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7IEl0ZW1zOiBbc2FtcGxlUnVsZV0gfSk7XHJcbiAgICAgICAgY29uc3QgYmVmb3JlTG9hZCA9IERhdGUubm93KCk7XHJcblxyXG4gICAgICAgIC8vIEFjdFxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcbiAgICAgICAgY29uc3Qgc3RhdHMgPSByZXBvc2l0b3J5LmdldENhY2hlU3RhdHMoKTtcclxuICAgICAgICBjb25zdCBhZnRlckxvYWQgPSBEYXRlLm5vdygpO1xyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBleHBlY3Qoc3RhdHMuaXNDYWNoZWQpLnRvQmUodHJ1ZSk7XHJcbiAgICAgICAgZXhwZWN0KHN0YXRzLmxhc3RSZWZyZXNoKS50b0JlSW5zdGFuY2VPZihEYXRlKTtcclxuICAgICAgICBleHBlY3Qoc3RhdHMuY2FjaGVBZ2UpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoMCk7XHJcbiAgICAgICAgZXhwZWN0KHN0YXRzLmNhY2hlQWdlKS50b0JlTGVzc1RoYW4oYWZ0ZXJMb2FkIC0gYmVmb3JlTG9hZCArIDEwMCk7IC8vIEFsbG93IHNvbWUgbWFyZ2luXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJldHVybiBjb3JyZWN0IGNhY2hlIHN0YXRzIGFmdGVyIHJlZnJlc2gnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7IEl0ZW1zOiBbc2FtcGxlUnVsZV0gfSk7IC8vIEluaXRpYWwgbG9hZFxyXG4gICAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7IEl0ZW1zOiBbc2FtcGxlUnVsZV0gfSk7IC8vIFJlZnJlc2hcclxuXHJcbiAgICAgICAgLy8gQWN0XHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgICBjb25zdCBzdGF0c0JlZm9yZVJlZnJlc2ggPSByZXBvc2l0b3J5LmdldENhY2hlU3RhdHMoKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBXYWl0IGEgYml0IHRvIGVuc3VyZSBkaWZmZXJlbnQgdGltZXN0YW1wc1xyXG4gICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxMCkpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGF3YWl0IHJlcG9zaXRvcnkucmVmcmVzaENhY2hlKCk7XHJcbiAgICAgICAgY29uc3Qgc3RhdHNBZnRlclJlZnJlc2ggPSByZXBvc2l0b3J5LmdldENhY2hlU3RhdHMoKTtcclxuXHJcbiAgICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgICAgZXhwZWN0KHN0YXRzQmVmb3JlUmVmcmVzaC5pc0NhY2hlZCkudG9CZSh0cnVlKTtcclxuICAgICAgICBleHBlY3Qoc3RhdHNBZnRlclJlZnJlc2guaXNDYWNoZWQpLnRvQmUodHJ1ZSk7XHJcbiAgICAgICAgZXhwZWN0KHN0YXRzQWZ0ZXJSZWZyZXNoLmxhc3RSZWZyZXNoIS5nZXRUaW1lKCkpLnRvQmVHcmVhdGVyVGhhbihzdGF0c0JlZm9yZVJlZnJlc2gubGFzdFJlZnJlc2ghLmdldFRpbWUoKSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcblxyXG4gICAgZGVzY3JpYmUoJ2NhY2hlIFRUTCBiZWhhdmlvcicsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIHJlc3BlY3QgY2FjaGUgVFRMJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgICBjb25zdCBvcmlnaW5hbENhY2hlVFRMID0gKHJlcG9zaXRvcnkgYXMgYW55KS5DQUNIRV9UVExfTVM7XHJcbiAgICAgICAgKHJlcG9zaXRvcnkgYXMgYW55KS5DQUNIRV9UVExfTVMgPSA1MDsgLy8gNTBtcyBUVEwgZm9yIHRlc3RpbmdcclxuICAgICAgICBcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoeyBJdGVtczogW3NhbXBsZVJ1bGVdIH0pOyAvLyBJbml0aWFsIGxvYWRcclxuICAgICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoeyBJdGVtczogW3NhbXBsZVJ1bGVdIH0pOyAvLyBBZnRlciBUVEwgZXhwaXJlc1xyXG5cclxuICAgICAgICAvLyBBY3RcclxuICAgICAgICBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpOyAvLyBJbml0aWFsIGxvYWRcclxuICAgICAgICBcclxuICAgICAgICAvLyBXYWl0IGZvciBUVEwgdG8gZXhwaXJlXHJcbiAgICAgICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDYwKSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTsgLy8gU2hvdWxkIGxvYWQgZnJvbSBEQiBhZ2FpblxyXG5cclxuICAgICAgICAvLyBBc3NlcnRcclxuICAgICAgICBleHBlY3QobW9ja1NlbmQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygyKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBSZXN0b3JlIG9yaWdpbmFsIFRUTFxyXG4gICAgICAgIChyZXBvc2l0b3J5IGFzIGFueSkuQ0FDSEVfVFRMX01TID0gb3JpZ2luYWxDYWNoZVRUTDtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9KTtcclxuXHJcbiAgZGVzY3JpYmUoJ1J1bGUgU29ydGluZycsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCBzb3J0IHJ1bGVzIGJ5IHdlaWdodCBpbiBkZXNjZW5kaW5nIG9yZGVyJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAvLyBBcnJhbmdlXHJcbiAgICAgIGNvbnN0IHVuc29ydGVkUnVsZXMgPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdydWxlLTEnLFxyXG4gICAgICAgICAgbmFtZTogJ1J1bGUgMScsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnVGVzdCA9PSAxJyxcclxuICAgICAgICAgIHdlaWdodDogNSxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50LTEnLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ3J1bGUtMicsXHJcbiAgICAgICAgICBuYW1lOiAnUnVsZSAyJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdUZXN0ID09IDInLFxyXG4gICAgICAgICAgd2VpZ2h0OiAxNSxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50LTInLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ3J1bGUtMycsXHJcbiAgICAgICAgICBuYW1lOiAnUnVsZSAzJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdUZXN0ID09IDMnLFxyXG4gICAgICAgICAgd2VpZ2h0OiAxMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50LTMnLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonXHJcbiAgICAgICAgfVxyXG4gICAgICBdO1xyXG4gICAgICBcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IHVuc29ydGVkUnVsZXMgfSk7XHJcblxyXG4gICAgICAvLyBBY3RcclxuICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgIGV4cGVjdChydWxlcykudG9IYXZlTGVuZ3RoKDMpO1xyXG4gICAgICBleHBlY3QocnVsZXNbMF0ud2VpZ2h0KS50b0JlKDE1KTsgLy8gSGlnaGVzdCB3ZWlnaHQgZmlyc3RcclxuICAgICAgZXhwZWN0KHJ1bGVzWzFdLndlaWdodCkudG9CZSgxMCk7XHJcbiAgICAgIGV4cGVjdChydWxlc1syXS53ZWlnaHQpLnRvQmUoNSk7ICAvLyBMb3dlc3Qgd2VpZ2h0IGxhc3RcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnRW52aXJvbm1lbnQgQ29uZmlndXJhdGlvbicsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCB1c2UgZGVmYXVsdCB0YWJsZSBuYW1lIHdoZW4gbm90IHByb3ZpZGVkJywgKCkgPT4ge1xyXG4gICAgICAvLyBBcnJhbmdlXHJcbiAgICAgIGRlbGV0ZSBwcm9jZXNzLmVudi5RVUFMSUZJQ0FUSU9OX1JVTEVTX1RBQkxFO1xyXG4gICAgICBcclxuICAgICAgLy8gQWN0XHJcbiAgICAgIGNvbnN0IGRlZmF1bHRSZXBvc2l0b3J5ID0gbmV3IFJ1bGVSZXBvc2l0b3J5KCk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBBc3NlcnQgLSBXZSBjYW4ndCBkaXJlY3RseSB0ZXN0IHRoZSBwcml2YXRlIHRhYmxlTmFtZSwgYnV0IHdlIGNhbiB2ZXJpZnkgaXQgZG9lc24ndCB0aHJvd1xyXG4gICAgICBleHBlY3QoZGVmYXVsdFJlcG9zaXRvcnkpLnRvQmVJbnN0YW5jZU9mKFJ1bGVSZXBvc2l0b3J5KTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCB1c2UgZW52aXJvbm1lbnQgdmFyaWFibGUgZm9yIHRhYmxlIG5hbWUnLCAoKSA9PiB7XHJcbiAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgcHJvY2Vzcy5lbnYuUVVBTElGSUNBVElPTl9SVUxFU19UQUJMRSA9ICdlbnYtdGFibGUtbmFtZSc7XHJcbiAgICAgIFxyXG4gICAgICAvLyBBY3RcclxuICAgICAgY29uc3QgZW52UmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgpO1xyXG4gICAgICBcclxuICAgICAgLy8gQXNzZXJ0IC0gV2UgY2FuJ3QgZGlyZWN0bHkgdGVzdCB0aGUgcHJpdmF0ZSB0YWJsZU5hbWUsIGJ1dCB3ZSBjYW4gdmVyaWZ5IGl0IGRvZXNuJ3QgdGhyb3dcclxuICAgICAgZXhwZWN0KGVudlJlcG9zaXRvcnkpLnRvQmVJbnN0YW5jZU9mKFJ1bGVSZXBvc2l0b3J5KTtcclxuICAgICAgXHJcbiAgICAgIC8vIENsZWFudXBcclxuICAgICAgZGVsZXRlIHByb2Nlc3MuZW52LlFVQUxJRklDQVRJT05fUlVMRVNfVEFCTEU7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgdXNlIHByb3ZpZGVkIHRhYmxlIG5hbWUgb3ZlciBlbnZpcm9ubWVudCB2YXJpYWJsZScsICgpID0+IHtcclxuICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICBwcm9jZXNzLmVudi5RVUFMSUZJQ0FUSU9OX1JVTEVTX1RBQkxFID0gJ2Vudi10YWJsZS1uYW1lJztcclxuICAgICAgXHJcbiAgICAgIC8vIEFjdFxyXG4gICAgICBjb25zdCBjdXN0b21SZXBvc2l0b3J5ID0gbmV3IFJ1bGVSZXBvc2l0b3J5KCdjdXN0b20tdGFibGUtbmFtZScpO1xyXG4gICAgICBcclxuICAgICAgLy8gQXNzZXJ0IC0gV2UgY2FuJ3QgZGlyZWN0bHkgdGVzdCB0aGUgcHJpdmF0ZSB0YWJsZU5hbWUsIGJ1dCB3ZSBjYW4gdmVyaWZ5IGl0IGRvZXNuJ3QgdGhyb3dcclxuICAgICAgZXhwZWN0KGN1c3RvbVJlcG9zaXRvcnkpLnRvQmVJbnN0YW5jZU9mKFJ1bGVSZXBvc2l0b3J5KTtcclxuICAgICAgXHJcbiAgICAgIC8vIENsZWFudXBcclxuICAgICAgZGVsZXRlIHByb2Nlc3MuZW52LlFVQUxJRklDQVRJT05fUlVMRVNfVEFCTEU7XHJcbiAgICB9KTtcclxuICB9KTtcclxufSk7Il19
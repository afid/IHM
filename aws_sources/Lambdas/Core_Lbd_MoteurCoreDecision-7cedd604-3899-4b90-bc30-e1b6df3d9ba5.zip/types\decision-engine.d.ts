export type ContactAttributes = Record<string, boolean | string | number>;
export interface QualificationRequest {
    interactionId: string;
    contactAttributes: ContactAttributes;
}
export interface DecisionResponse {
    success: boolean;
    distributionSegment?: string;
    selectedRuleId?: string;
    libellé?: string;
    priority?: number;
    error?: string;
    errorCode?: string;
    timestamp?: string;
    requestId?: string;
    eliminationTrace?: EliminationStep[];
}
export interface QualificationRule {
    id: string;
    name: string;
    expression: string;
    weight: number;
    distributionSegment: string;
    libellé?: string;
    priority?: number;
    createdAt: string;
    updatedAt: string;
}
export interface EvaluationResult {
    eligibleRules: QualificationRule[];
    eliminatedRules: EliminatedRule[];
    selectedRule?: QualificationRule;
    distributionSegment?: string;
    error?: string;
    eliminationTrace?: EliminationStep[];
}
export interface EliminatedRule {
    rule: QualificationRule;
    reason: string;
    contactAttributeKey: string;
    contactAttributeValue: any;
}
export interface EliminationStep {
    contactAttributeKey: string;
    contactAttributeValue: any;
    remainingRules: number;
    eliminatedCount: number;
}
export interface DistributionSegment {
    segmentId: string;
    segmentName: string;
    description?: string;
}
export interface ErrorResponse {
    success: false;
    error: string;
    errorCode: string;
    timestamp: string;
    requestId: string;
    details?: any;
}

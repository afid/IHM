"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RuleEvaluator_1 = require("../../services/decision-engine/RuleEvaluator");
describe('RuleEvaluator Unit Tests', () => {
    let evaluator;
    const validRule = {
        id: 'rule-1',
        name: 'Valid Rule',
        expression: 'NouveauSinistre == true',
        weight: 10,
        distributionSegment: 'valid-segment',
        createdAt: '2023-01-01T00:00:00Z',
        updatedAt: '2023-01-01T00:00:00Z'
    };
    const contactAttributes = {
        NouveauSinistre: true,
        Client: 'VIP'
    };
    beforeEach(() => {
        evaluator = new RuleEvaluator_1.RuleEvaluator();
    });
    describe('Distribution Segment Validation - Requirements 2.1, 2.2', () => {
        test('should return distribution segment for valid rule', () => {
            // Arrange
            const rules = [validRule];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeDefined();
            expect(result.distributionSegment).toBe('valid-segment');
            expect(result.error).toBeUndefined();
        });
        test('should handle missing distribution segment', () => {
            // Arrange
            const ruleWithMissingSegment = {
                ...validRule,
                id: 'rule-missing-segment',
                distributionSegment: ''
            };
            const rules = [ruleWithMissingSegment];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Segment de distribution manquant pour la règle rule-missing-segment, vérifier le paramétrage');
        });
        test('should handle null distribution segment', () => {
            // Arrange
            const ruleWithNullSegment = {
                ...validRule,
                id: 'rule-null-segment',
                distributionSegment: null
            };
            const rules = [ruleWithNullSegment];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Segment de distribution manquant pour la règle rule-null-segment, vérifier le paramétrage');
        });
        test('should handle undefined distribution segment', () => {
            // Arrange
            const ruleWithUndefinedSegment = {
                ...validRule,
                id: 'rule-undefined-segment',
                distributionSegment: undefined
            };
            const rules = [ruleWithUndefinedSegment];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Segment de distribution manquant pour la règle rule-undefined-segment, vérifier le paramétrage');
        });
        test('should handle whitespace-only distribution segment', () => {
            // Arrange
            const ruleWithWhitespaceSegment = {
                ...validRule,
                id: 'rule-whitespace-segment',
                distributionSegment: '   \t\n   '
            };
            const rules = [ruleWithWhitespaceSegment];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Segment de distribution vide pour la règle rule-whitespace-segment, vérifier le paramétrage');
        });
        test('should handle non-string distribution segment', () => {
            // Arrange
            const ruleWithInvalidSegment = {
                ...validRule,
                id: 'rule-invalid-segment',
                distributionSegment: 123
            };
            const rules = [ruleWithInvalidSegment];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Segment de distribution invalide pour la règle rule-invalid-segment, vérifier le paramétrage');
        });
        test('should validate distribution segment for multiple eligible rules', () => {
            // Arrange
            const validRule1 = {
                ...validRule,
                id: 'rule-1',
                weight: 20,
                distributionSegment: 'segment-1'
            };
            const invalidRule = {
                ...validRule,
                id: 'rule-2',
                weight: 30, // Higher weight but invalid segment
                distributionSegment: ''
            };
            const rules = [validRule1, invalidRule];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Segment de distribution manquant pour la règle rule-2, vérifier le paramétrage');
        });
        test('should return valid segment when rule has valid segment after validation', () => {
            // Arrange
            const ruleWithValidSegment = {
                ...validRule,
                id: 'rule-valid-segment',
                distributionSegment: 'premium-support'
            };
            const rules = [ruleWithValidSegment];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeDefined();
            expect(result.selectedRule.id).toBe('rule-valid-segment');
            expect(result.distributionSegment).toBe('premium-support');
            expect(result.error).toBeUndefined();
        });
    });
    describe('Weight-based Selection with Distribution Segment Validation', () => {
        test('should select highest weight rule with valid distribution segment', () => {
            // Arrange
            const lowWeightRule = {
                ...validRule,
                id: 'rule-low',
                weight: 10,
                distributionSegment: 'low-priority-segment'
            };
            const highWeightRule = {
                ...validRule,
                id: 'rule-high',
                weight: 20,
                distributionSegment: 'high-priority-segment'
            };
            const rules = [lowWeightRule, highWeightRule];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeDefined();
            expect(result.selectedRule.id).toBe('rule-high');
            expect(result.selectedRule.weight).toBe(20);
            expect(result.distributionSegment).toBe('high-priority-segment');
            expect(result.error).toBeUndefined();
        });
        test('should handle equal weights error with valid segments', () => {
            // Arrange
            const rule1 = {
                ...validRule,
                id: 'rule-1',
                weight: 15,
                distributionSegment: 'segment-1'
            };
            const rule2 = {
                ...validRule,
                id: 'rule-2',
                weight: 15, // Same weight
                distributionSegment: 'segment-2'
            };
            const rules = [rule1, rule2];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Les règles rule-1 et rule-2 ont des poids identiques, vérifier le paramétrage');
        });
    });
    describe('Error Handling', () => {
        test('should handle no matching rules', () => {
            // Arrange
            const nonMatchingRule = {
                ...validRule,
                expression: 'NouveauSinistre == false' // Won't match our contact attributes
            };
            const rules = [nonMatchingRule];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Aucune règle ne correspond, vérifier le paramétrage');
        });
        test('should handle rule evaluation errors gracefully', () => {
            // Arrange
            const malformedRule = {
                ...validRule,
                id: 'malformed-rule',
                expression: 'invalid syntax =='
            };
            const rules = [malformedRule];
            // Act
            const result = evaluator.evaluateRules(contactAttributes, rules);
            // Assert
            expect(result.selectedRule).toBeUndefined();
            expect(result.distributionSegment).toBeUndefined();
            expect(result.error).toBe('Aucune règle ne correspond, vérifier le paramétrage');
            expect(result.eliminatedRules).toHaveLength(1);
            expect(result.eliminatedRules[0].reason).toContain('Rule evaluation failed');
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUnVsZUV2YWx1YXRvci51bml0LnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdGVzdHMvZGVjaXNpb24tZW5naW5lL1J1bGVFdmFsdWF0b3IudW5pdC50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsZ0ZBQTZFO0FBRzdFLFFBQVEsQ0FBQywwQkFBMEIsRUFBRSxHQUFHLEVBQUU7SUFDeEMsSUFBSSxTQUF3QixDQUFDO0lBRTdCLE1BQU0sU0FBUyxHQUFzQjtRQUNuQyxFQUFFLEVBQUUsUUFBUTtRQUNaLElBQUksRUFBRSxZQUFZO1FBQ2xCLFVBQVUsRUFBRSx5QkFBeUI7UUFDckMsTUFBTSxFQUFFLEVBQUU7UUFDVixtQkFBbUIsRUFBRSxlQUFlO1FBQ3BDLFNBQVMsRUFBRSxzQkFBc0I7UUFDakMsU0FBUyxFQUFFLHNCQUFzQjtLQUNsQyxDQUFDO0lBRUYsTUFBTSxpQkFBaUIsR0FBc0I7UUFDM0MsZUFBZSxFQUFFLElBQUk7UUFDckIsTUFBTSxFQUFFLEtBQUs7S0FDZCxDQUFDO0lBRUYsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLFNBQVMsR0FBRyxJQUFJLDZCQUFhLEVBQUUsQ0FBQztJQUNsQyxDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyx5REFBeUQsRUFBRSxHQUFHLEVBQUU7UUFDdkUsSUFBSSxDQUFDLG1EQUFtRCxFQUFFLEdBQUcsRUFBRTtZQUM3RCxVQUFVO1lBQ1YsTUFBTSxLQUFLLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUUxQixNQUFNO1lBQ04sTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVqRSxTQUFTO1lBQ1QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMxQyxNQUFNLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ3pELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsNENBQTRDLEVBQUUsR0FBRyxFQUFFO1lBQ3RELFVBQVU7WUFDVixNQUFNLHNCQUFzQixHQUFzQjtnQkFDaEQsR0FBRyxTQUFTO2dCQUNaLEVBQUUsRUFBRSxzQkFBc0I7Z0JBQzFCLG1CQUFtQixFQUFFLEVBQUU7YUFDeEIsQ0FBQztZQUNGLE1BQU0sS0FBSyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUV2QyxNQUFNO1lBQ04sTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVqRSxTQUFTO1lBQ1QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsOEZBQThGLENBQUMsQ0FBQztRQUM1SCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyx5Q0FBeUMsRUFBRSxHQUFHLEVBQUU7WUFDbkQsVUFBVTtZQUNWLE1BQU0sbUJBQW1CLEdBQXNCO2dCQUM3QyxHQUFHLFNBQVM7Z0JBQ1osRUFBRSxFQUFFLG1CQUFtQjtnQkFDdkIsbUJBQW1CLEVBQUUsSUFBVzthQUNqQyxDQUFDO1lBQ0YsTUFBTSxLQUFLLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBRXBDLE1BQU07WUFDTixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWpFLFNBQVM7WUFDVCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQywyRkFBMkYsQ0FBQyxDQUFDO1FBQ3pILENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDhDQUE4QyxFQUFFLEdBQUcsRUFBRTtZQUN4RCxVQUFVO1lBQ1YsTUFBTSx3QkFBd0IsR0FBc0I7Z0JBQ2xELEdBQUcsU0FBUztnQkFDWixFQUFFLEVBQUUsd0JBQXdCO2dCQUM1QixtQkFBbUIsRUFBRSxTQUFnQjthQUN0QyxDQUFDO1lBQ0YsTUFBTSxLQUFLLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBRXpDLE1BQU07WUFDTixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWpFLFNBQVM7WUFDVCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxnR0FBZ0csQ0FBQyxDQUFDO1FBQzlILENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLG9EQUFvRCxFQUFFLEdBQUcsRUFBRTtZQUM5RCxVQUFVO1lBQ1YsTUFBTSx5QkFBeUIsR0FBc0I7Z0JBQ25ELEdBQUcsU0FBUztnQkFDWixFQUFFLEVBQUUseUJBQXlCO2dCQUM3QixtQkFBbUIsRUFBRSxZQUFZO2FBQ2xDLENBQUM7WUFDRixNQUFNLEtBQUssR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUM7WUFFMUMsTUFBTTtZQUNOLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFakUsU0FBUztZQUNULE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDNUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLDZGQUE2RixDQUFDLENBQUM7UUFDM0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsK0NBQStDLEVBQUUsR0FBRyxFQUFFO1lBQ3pELFVBQVU7WUFDVixNQUFNLHNCQUFzQixHQUFzQjtnQkFDaEQsR0FBRyxTQUFTO2dCQUNaLEVBQUUsRUFBRSxzQkFBc0I7Z0JBQzFCLG1CQUFtQixFQUFFLEdBQVU7YUFDaEMsQ0FBQztZQUNGLE1BQU0sS0FBSyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUV2QyxNQUFNO1lBQ04sTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVqRSxTQUFTO1lBQ1QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsOEZBQThGLENBQUMsQ0FBQztRQUM1SCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxrRUFBa0UsRUFBRSxHQUFHLEVBQUU7WUFDNUUsVUFBVTtZQUNWLE1BQU0sVUFBVSxHQUFzQjtnQkFDcEMsR0FBRyxTQUFTO2dCQUNaLEVBQUUsRUFBRSxRQUFRO2dCQUNaLE1BQU0sRUFBRSxFQUFFO2dCQUNWLG1CQUFtQixFQUFFLFdBQVc7YUFDakMsQ0FBQztZQUVGLE1BQU0sV0FBVyxHQUFzQjtnQkFDckMsR0FBRyxTQUFTO2dCQUNaLEVBQUUsRUFBRSxRQUFRO2dCQUNaLE1BQU0sRUFBRSxFQUFFLEVBQUUsb0NBQW9DO2dCQUNoRCxtQkFBbUIsRUFBRSxFQUFFO2FBQ3hCLENBQUM7WUFFRixNQUFNLEtBQUssR0FBRyxDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUV4QyxNQUFNO1lBQ04sTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVqRSxTQUFTO1lBQ1QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0ZBQWdGLENBQUMsQ0FBQztRQUM5RyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQywwRUFBMEUsRUFBRSxHQUFHLEVBQUU7WUFDcEYsVUFBVTtZQUNWLE1BQU0sb0JBQW9CLEdBQXNCO2dCQUM5QyxHQUFHLFNBQVM7Z0JBQ1osRUFBRSxFQUFFLG9CQUFvQjtnQkFDeEIsbUJBQW1CLEVBQUUsaUJBQWlCO2FBQ3ZDLENBQUM7WUFDRixNQUFNLEtBQUssR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFFckMsTUFBTTtZQUNOLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFakUsU0FBUztZQUNULE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDMUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDM0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQzNELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyw2REFBNkQsRUFBRSxHQUFHLEVBQUU7UUFDM0UsSUFBSSxDQUFDLG1FQUFtRSxFQUFFLEdBQUcsRUFBRTtZQUM3RSxVQUFVO1lBQ1YsTUFBTSxhQUFhLEdBQXNCO2dCQUN2QyxHQUFHLFNBQVM7Z0JBQ1osRUFBRSxFQUFFLFVBQVU7Z0JBQ2QsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsbUJBQW1CLEVBQUUsc0JBQXNCO2FBQzVDLENBQUM7WUFFRixNQUFNLGNBQWMsR0FBc0I7Z0JBQ3hDLEdBQUcsU0FBUztnQkFDWixFQUFFLEVBQUUsV0FBVztnQkFDZixNQUFNLEVBQUUsRUFBRTtnQkFDVixtQkFBbUIsRUFBRSx1QkFBdUI7YUFDN0MsQ0FBQztZQUVGLE1BQU0sS0FBSyxHQUFHLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1lBRTlDLE1BQU07WUFDTixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWpFLFNBQVM7WUFDVCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNsRCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDN0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ2pFLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsdURBQXVELEVBQUUsR0FBRyxFQUFFO1lBQ2pFLFVBQVU7WUFDVixNQUFNLEtBQUssR0FBc0I7Z0JBQy9CLEdBQUcsU0FBUztnQkFDWixFQUFFLEVBQUUsUUFBUTtnQkFDWixNQUFNLEVBQUUsRUFBRTtnQkFDVixtQkFBbUIsRUFBRSxXQUFXO2FBQ2pDLENBQUM7WUFFRixNQUFNLEtBQUssR0FBc0I7Z0JBQy9CLEdBQUcsU0FBUztnQkFDWixFQUFFLEVBQUUsUUFBUTtnQkFDWixNQUFNLEVBQUUsRUFBRSxFQUFFLGNBQWM7Z0JBQzFCLG1CQUFtQixFQUFFLFdBQVc7YUFDakMsQ0FBQztZQUVGLE1BQU0sS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRTdCLE1BQU07WUFDTixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWpFLFNBQVM7WUFDVCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQywrRUFBK0UsQ0FBQyxDQUFDO1FBQzdHLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFO1FBQzlCLElBQUksQ0FBQyxpQ0FBaUMsRUFBRSxHQUFHLEVBQUU7WUFDM0MsVUFBVTtZQUNWLE1BQU0sZUFBZSxHQUFzQjtnQkFDekMsR0FBRyxTQUFTO2dCQUNaLFVBQVUsRUFBRSwwQkFBMEIsQ0FBQyxxQ0FBcUM7YUFDN0UsQ0FBQztZQUNGLE1BQU0sS0FBSyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7WUFFaEMsTUFBTTtZQUNOLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFakUsU0FBUztZQUNULE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDNUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLHFEQUFxRCxDQUFDLENBQUM7UUFDbkYsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsaURBQWlELEVBQUUsR0FBRyxFQUFFO1lBQzNELFVBQVU7WUFDVixNQUFNLGFBQWEsR0FBc0I7Z0JBQ3ZDLEdBQUcsU0FBUztnQkFDWixFQUFFLEVBQUUsZ0JBQWdCO2dCQUNwQixVQUFVLEVBQUUsbUJBQW1CO2FBQ2hDLENBQUM7WUFDRixNQUFNLEtBQUssR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRTlCLE1BQU07WUFDTixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWpFLFNBQVM7WUFDVCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO1lBQ2pGLE1BQU0sQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9DLE1BQU0sQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQy9FLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJ1bGVFdmFsdWF0b3IgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZUV2YWx1YXRvcic7XHJcbmltcG9ydCB7IFF1YWxpZmljYXRpb25SdWxlLCBDb250YWN0QXR0cmlidXRlcyB9IGZyb20gJy4uLy4uL3R5cGVzL2RlY2lzaW9uLWVuZ2luZSc7XHJcblxyXG5kZXNjcmliZSgnUnVsZUV2YWx1YXRvciBVbml0IFRlc3RzJywgKCkgPT4ge1xyXG4gIGxldCBldmFsdWF0b3I6IFJ1bGVFdmFsdWF0b3I7XHJcblxyXG4gIGNvbnN0IHZhbGlkUnVsZTogUXVhbGlmaWNhdGlvblJ1bGUgPSB7XHJcbiAgICBpZDogJ3J1bGUtMScsXHJcbiAgICBuYW1lOiAnVmFsaWQgUnVsZScsXHJcbiAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgd2VpZ2h0OiAxMCxcclxuICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICd2YWxpZC1zZWdtZW50JyxcclxuICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJyxcclxuICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJ1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbnRhY3RBdHRyaWJ1dGVzOiBDb250YWN0QXR0cmlidXRlcyA9IHtcclxuICAgIE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSxcclxuICAgIENsaWVudDogJ1ZJUCdcclxuICB9O1xyXG5cclxuICBiZWZvcmVFYWNoKCgpID0+IHtcclxuICAgIGV2YWx1YXRvciA9IG5ldyBSdWxlRXZhbHVhdG9yKCk7XHJcbiAgfSk7XHJcblxyXG4gIGRlc2NyaWJlKCdEaXN0cmlidXRpb24gU2VnbWVudCBWYWxpZGF0aW9uIC0gUmVxdWlyZW1lbnRzIDIuMSwgMi4yJywgKCkgPT4ge1xyXG4gICAgdGVzdCgnc2hvdWxkIHJldHVybiBkaXN0cmlidXRpb24gc2VnbWVudCBmb3IgdmFsaWQgcnVsZScsICgpID0+IHtcclxuICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICBjb25zdCBydWxlcyA9IFt2YWxpZFJ1bGVdO1xyXG5cclxuICAgICAgLy8gQWN0XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcblxyXG4gICAgICAvLyBBc3NlcnRcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZGlzdHJpYnV0aW9uU2VnbWVudCkudG9CZSgndmFsaWQtc2VnbWVudCcpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgaGFuZGxlIG1pc3NpbmcgZGlzdHJpYnV0aW9uIHNlZ21lbnQnLCAoKSA9PiB7XHJcbiAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgY29uc3QgcnVsZVdpdGhNaXNzaW5nU2VnbWVudDogUXVhbGlmaWNhdGlvblJ1bGUgPSB7XHJcbiAgICAgICAgLi4udmFsaWRSdWxlLFxyXG4gICAgICAgIGlkOiAncnVsZS1taXNzaW5nLXNlZ21lbnQnLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICcnXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJ1bGVzID0gW3J1bGVXaXRoTWlzc2luZ1NlZ21lbnRdO1xyXG5cclxuICAgICAgLy8gQWN0XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcblxyXG4gICAgICAvLyBBc3NlcnRcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmUoJ1NlZ21lbnQgZGUgZGlzdHJpYnV0aW9uIG1hbnF1YW50IHBvdXIgbGEgcsOoZ2xlIHJ1bGUtbWlzc2luZy1zZWdtZW50LCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgaGFuZGxlIG51bGwgZGlzdHJpYnV0aW9uIHNlZ21lbnQnLCAoKSA9PiB7XHJcbiAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgY29uc3QgcnVsZVdpdGhOdWxsU2VnbWVudDogUXVhbGlmaWNhdGlvblJ1bGUgPSB7XHJcbiAgICAgICAgLi4udmFsaWRSdWxlLFxyXG4gICAgICAgIGlkOiAncnVsZS1udWxsLXNlZ21lbnQnLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6IG51bGwgYXMgYW55XHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJ1bGVzID0gW3J1bGVXaXRoTnVsbFNlZ21lbnRdO1xyXG5cclxuICAgICAgLy8gQWN0XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcblxyXG4gICAgICAvLyBBc3NlcnRcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmUoJ1NlZ21lbnQgZGUgZGlzdHJpYnV0aW9uIG1hbnF1YW50IHBvdXIgbGEgcsOoZ2xlIHJ1bGUtbnVsbC1zZWdtZW50LCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgaGFuZGxlIHVuZGVmaW5lZCBkaXN0cmlidXRpb24gc2VnbWVudCcsICgpID0+IHtcclxuICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICBjb25zdCBydWxlV2l0aFVuZGVmaW5lZFNlZ21lbnQ6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtdW5kZWZpbmVkLXNlZ21lbnQnLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6IHVuZGVmaW5lZCBhcyBhbnlcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgcnVsZXMgPSBbcnVsZVdpdGhVbmRlZmluZWRTZWdtZW50XTtcclxuXHJcbiAgICAgIC8vIEFjdFxyXG4gICAgICBjb25zdCByZXN1bHQgPSBldmFsdWF0b3IuZXZhbHVhdGVSdWxlcyhjb250YWN0QXR0cmlidXRlcywgcnVsZXMpO1xyXG5cclxuICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZGlzdHJpYnV0aW9uU2VnbWVudCkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlKCdTZWdtZW50IGRlIGRpc3RyaWJ1dGlvbiBtYW5xdWFudCBwb3VyIGxhIHLDqGdsZSBydWxlLXVuZGVmaW5lZC1zZWdtZW50LCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgaGFuZGxlIHdoaXRlc3BhY2Utb25seSBkaXN0cmlidXRpb24gc2VnbWVudCcsICgpID0+IHtcclxuICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICBjb25zdCBydWxlV2l0aFdoaXRlc3BhY2VTZWdtZW50OiBRdWFsaWZpY2F0aW9uUnVsZSA9IHtcclxuICAgICAgICAuLi52YWxpZFJ1bGUsXHJcbiAgICAgICAgaWQ6ICdydWxlLXdoaXRlc3BhY2Utc2VnbWVudCcsXHJcbiAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJyAgIFxcdFxcbiAgICdcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgcnVsZXMgPSBbcnVsZVdpdGhXaGl0ZXNwYWNlU2VnbWVudF07XHJcblxyXG4gICAgICAvLyBBY3RcclxuICAgICAgY29uc3QgcmVzdWx0ID0gZXZhbHVhdG9yLmV2YWx1YXRlUnVsZXMoY29udGFjdEF0dHJpYnV0ZXMsIHJ1bGVzKTtcclxuXHJcbiAgICAgIC8vIEFzc2VydFxyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZSkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9CZSgnU2VnbWVudCBkZSBkaXN0cmlidXRpb24gdmlkZSBwb3VyIGxhIHLDqGdsZSBydWxlLXdoaXRlc3BhY2Utc2VnbWVudCwgdsOpcmlmaWVyIGxlIHBhcmFtw6l0cmFnZScpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIGhhbmRsZSBub24tc3RyaW5nIGRpc3RyaWJ1dGlvbiBzZWdtZW50JywgKCkgPT4ge1xyXG4gICAgICAvLyBBcnJhbmdlXHJcbiAgICAgIGNvbnN0IHJ1bGVXaXRoSW52YWxpZFNlZ21lbnQ6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtaW52YWxpZC1zZWdtZW50JyxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAxMjMgYXMgYW55XHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJ1bGVzID0gW3J1bGVXaXRoSW52YWxpZFNlZ21lbnRdO1xyXG5cclxuICAgICAgLy8gQWN0XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcblxyXG4gICAgICAvLyBBc3NlcnRcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmUoJ1NlZ21lbnQgZGUgZGlzdHJpYnV0aW9uIGludmFsaWRlIHBvdXIgbGEgcsOoZ2xlIHJ1bGUtaW52YWxpZC1zZWdtZW50LCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgdmFsaWRhdGUgZGlzdHJpYnV0aW9uIHNlZ21lbnQgZm9yIG11bHRpcGxlIGVsaWdpYmxlIHJ1bGVzJywgKCkgPT4ge1xyXG4gICAgICAvLyBBcnJhbmdlXHJcbiAgICAgIGNvbnN0IHZhbGlkUnVsZTE6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtMScsXHJcbiAgICAgICAgd2VpZ2h0OiAyMCxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnc2VnbWVudC0xJ1xyXG4gICAgICB9O1xyXG4gICAgICBcclxuICAgICAgY29uc3QgaW52YWxpZFJ1bGU6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtMicsXHJcbiAgICAgICAgd2VpZ2h0OiAzMCwgLy8gSGlnaGVyIHdlaWdodCBidXQgaW52YWxpZCBzZWdtZW50XHJcbiAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJydcclxuICAgICAgfTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IHJ1bGVzID0gW3ZhbGlkUnVsZTEsIGludmFsaWRSdWxlXTtcclxuXHJcbiAgICAgIC8vIEFjdFxyXG4gICAgICBjb25zdCByZXN1bHQgPSBldmFsdWF0b3IuZXZhbHVhdGVSdWxlcyhjb250YWN0QXR0cmlidXRlcywgcnVsZXMpO1xyXG5cclxuICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZGlzdHJpYnV0aW9uU2VnbWVudCkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlKCdTZWdtZW50IGRlIGRpc3RyaWJ1dGlvbiBtYW5xdWFudCBwb3VyIGxhIHLDqGdsZSBydWxlLTIsIHbDqXJpZmllciBsZSBwYXJhbcOpdHJhZ2UnKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCByZXR1cm4gdmFsaWQgc2VnbWVudCB3aGVuIHJ1bGUgaGFzIHZhbGlkIHNlZ21lbnQgYWZ0ZXIgdmFsaWRhdGlvbicsICgpID0+IHtcclxuICAgICAgLy8gQXJyYW5nZVxyXG4gICAgICBjb25zdCBydWxlV2l0aFZhbGlkU2VnbWVudDogUXVhbGlmaWNhdGlvblJ1bGUgPSB7XHJcbiAgICAgICAgLi4udmFsaWRSdWxlLFxyXG4gICAgICAgIGlkOiAncnVsZS12YWxpZC1zZWdtZW50JyxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAncHJlbWl1bS1zdXBwb3J0J1xyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCBydWxlcyA9IFtydWxlV2l0aFZhbGlkU2VnbWVudF07XHJcblxyXG4gICAgICAvLyBBY3RcclxuICAgICAgY29uc3QgcmVzdWx0ID0gZXZhbHVhdG9yLmV2YWx1YXRlUnVsZXMoY29udGFjdEF0dHJpYnV0ZXMsIHJ1bGVzKTtcclxuXHJcbiAgICAgIC8vIEFzc2VydFxyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUhLmlkKS50b0JlKCdydWxlLXZhbGlkLXNlZ21lbnQnKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlKCdwcmVtaXVtLXN1cHBvcnQnKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcblxyXG4gIGRlc2NyaWJlKCdXZWlnaHQtYmFzZWQgU2VsZWN0aW9uIHdpdGggRGlzdHJpYnV0aW9uIFNlZ21lbnQgVmFsaWRhdGlvbicsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCBzZWxlY3QgaGlnaGVzdCB3ZWlnaHQgcnVsZSB3aXRoIHZhbGlkIGRpc3RyaWJ1dGlvbiBzZWdtZW50JywgKCkgPT4ge1xyXG4gICAgICAvLyBBcnJhbmdlXHJcbiAgICAgIGNvbnN0IGxvd1dlaWdodFJ1bGU6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtbG93JyxcclxuICAgICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdsb3ctcHJpb3JpdHktc2VnbWVudCdcclxuICAgICAgfTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IGhpZ2hXZWlnaHRSdWxlOiBRdWFsaWZpY2F0aW9uUnVsZSA9IHtcclxuICAgICAgICAuLi52YWxpZFJ1bGUsXHJcbiAgICAgICAgaWQ6ICdydWxlLWhpZ2gnLFxyXG4gICAgICAgIHdlaWdodDogMjAsXHJcbiAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ2hpZ2gtcHJpb3JpdHktc2VnbWVudCdcclxuICAgICAgfTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IHJ1bGVzID0gW2xvd1dlaWdodFJ1bGUsIGhpZ2hXZWlnaHRSdWxlXTtcclxuXHJcbiAgICAgIC8vIEFjdFxyXG4gICAgICBjb25zdCByZXN1bHQgPSBldmFsdWF0b3IuZXZhbHVhdGVSdWxlcyhjb250YWN0QXR0cmlidXRlcywgcnVsZXMpO1xyXG5cclxuICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZSEuaWQpLnRvQmUoJ3J1bGUtaGlnaCcpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZSEud2VpZ2h0KS50b0JlKDIwKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlKCdoaWdoLXByaW9yaXR5LXNlZ21lbnQnKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIGhhbmRsZSBlcXVhbCB3ZWlnaHRzIGVycm9yIHdpdGggdmFsaWQgc2VnbWVudHMnLCAoKSA9PiB7XHJcbiAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgY29uc3QgcnVsZTE6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtMScsXHJcbiAgICAgICAgd2VpZ2h0OiAxNSxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnc2VnbWVudC0xJ1xyXG4gICAgICB9O1xyXG4gICAgICBcclxuICAgICAgY29uc3QgcnVsZTI6IFF1YWxpZmljYXRpb25SdWxlID0ge1xyXG4gICAgICAgIC4uLnZhbGlkUnVsZSxcclxuICAgICAgICBpZDogJ3J1bGUtMicsXHJcbiAgICAgICAgd2VpZ2h0OiAxNSwgLy8gU2FtZSB3ZWlnaHRcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnc2VnbWVudC0yJ1xyXG4gICAgICB9O1xyXG4gICAgICBcclxuICAgICAgY29uc3QgcnVsZXMgPSBbcnVsZTEsIHJ1bGUyXTtcclxuXHJcbiAgICAgIC8vIEFjdFxyXG4gICAgICBjb25zdCByZXN1bHQgPSBldmFsdWF0b3IuZXZhbHVhdGVSdWxlcyhjb250YWN0QXR0cmlidXRlcywgcnVsZXMpO1xyXG5cclxuICAgICAgLy8gQXNzZXJ0XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZGlzdHJpYnV0aW9uU2VnbWVudCkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlKCdMZXMgcsOoZ2xlcyBydWxlLTEgZXQgcnVsZS0yIG9udCBkZXMgcG9pZHMgaWRlbnRpcXVlcywgdsOpcmlmaWVyIGxlIHBhcmFtw6l0cmFnZScpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcblxyXG4gIGRlc2NyaWJlKCdFcnJvciBIYW5kbGluZycsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgbm8gbWF0Y2hpbmcgcnVsZXMnLCAoKSA9PiB7XHJcbiAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgY29uc3Qgbm9uTWF0Y2hpbmdSdWxlOiBRdWFsaWZpY2F0aW9uUnVsZSA9IHtcclxuICAgICAgICAuLi52YWxpZFJ1bGUsXHJcbiAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSBmYWxzZScgLy8gV29uJ3QgbWF0Y2ggb3VyIGNvbnRhY3QgYXR0cmlidXRlc1xyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCBydWxlcyA9IFtub25NYXRjaGluZ1J1bGVdO1xyXG5cclxuICAgICAgLy8gQWN0XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcblxyXG4gICAgICAvLyBBc3NlcnRcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmUoJ0F1Y3VuZSByw6hnbGUgbmUgY29ycmVzcG9uZCwgdsOpcmlmaWVyIGxlIHBhcmFtw6l0cmFnZScpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIGhhbmRsZSBydWxlIGV2YWx1YXRpb24gZXJyb3JzIGdyYWNlZnVsbHknLCAoKSA9PiB7XHJcbiAgICAgIC8vIEFycmFuZ2VcclxuICAgICAgY29uc3QgbWFsZm9ybWVkUnVsZTogUXVhbGlmaWNhdGlvblJ1bGUgPSB7XHJcbiAgICAgICAgLi4udmFsaWRSdWxlLFxyXG4gICAgICAgIGlkOiAnbWFsZm9ybWVkLXJ1bGUnLFxyXG4gICAgICAgIGV4cHJlc3Npb246ICdpbnZhbGlkIHN5bnRheCA9PSdcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgcnVsZXMgPSBbbWFsZm9ybWVkUnVsZV07XHJcblxyXG4gICAgICAvLyBBY3RcclxuICAgICAgY29uc3QgcmVzdWx0ID0gZXZhbHVhdG9yLmV2YWx1YXRlUnVsZXMoY29udGFjdEF0dHJpYnV0ZXMsIHJ1bGVzKTtcclxuXHJcbiAgICAgIC8vIEFzc2VydFxyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZSkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9CZSgnQXVjdW5lIHLDqGdsZSBuZSBjb3JyZXNwb25kLCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlJyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZWxpbWluYXRlZFJ1bGVzKS50b0hhdmVMZW5ndGgoMSk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZWxpbWluYXRlZFJ1bGVzWzBdLnJlYXNvbikudG9Db250YWluKCdSdWxlIGV2YWx1YXRpb24gZmFpbGVkJyk7XHJcbiAgICB9KTtcclxuICB9KTtcclxufSk7Il19
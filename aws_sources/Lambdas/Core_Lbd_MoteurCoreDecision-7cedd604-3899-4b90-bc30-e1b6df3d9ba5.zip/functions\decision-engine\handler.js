"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const DecisionEngine_1 = require("../../services/decision-engine/DecisionEngine");
// Fonction pour détecter le type d'événement
function isApiGatewayEvent(event) {
    return event.httpMethod !== undefined;
}
// Fonction pour détecter un événement Connect
function isConnectEvent(event) {
    return event.Details !== undefined || (event.interactionId !== undefined && event.contactAttributes !== undefined);
}
// Traiter les événements API Gateway
async function handleApiGatewayRequest(event) {
    var _a, _b, _c, _d;
    // Handle preflight OPTIONS requests for CORS
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Access-Control-Max-Age': '86400'
            },
            body: ''
        };
    }
    try {
        // Validate HTTP method
        if (event.httpMethod !== 'POST') {
            return {
                statusCode: 405,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    error: 'Method not allowed',
                    errorCode: 'METHOD_NOT_ALLOWED',
                    timestamp: new Date().toISOString(),
                    requestId: ((_a = event.requestContext) === null || _a === void 0 ? void 0 : _a.requestId) || 'unknown'
                })
            };
        }
        // Validate request body exists
        if (!event.body) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    error: 'Request body is required',
                    errorCode: 'MISSING_BODY',
                    timestamp: new Date().toISOString(),
                    requestId: ((_b = event.requestContext) === null || _b === void 0 ? void 0 : _b.requestId) || 'unknown'
                })
            };
        }
        // Parse request body with error handling
        let request;
        try {
            request = JSON.parse(event.body);
        }
        catch (parseError) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    error: 'Invalid JSON in request body',
                    errorCode: 'INVALID_JSON',
                    timestamp: new Date().toISOString(),
                    requestId: ((_c = event.requestContext) === null || _c === void 0 ? void 0 : _c.requestId) || 'unknown'
                })
            };
        }
        // Initialize decision engine
        const decisionEngine = new DecisionEngine_1.DecisionEngine();
        // Process decision
        const response = await decisionEngine.processDecision(request);
        // Determine status code based on response
        const statusCode = response.success ? 200 : 400;
        return {
            statusCode,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            body: JSON.stringify(response)
        };
    }
    catch (error) {
        console.error('Decision engine error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                error: 'Internal server error',
                errorCode: 'INTERNAL_ERROR',
                timestamp: new Date().toISOString(),
                requestId: ((_d = event.requestContext) === null || _d === void 0 ? void 0 : _d.requestId) || 'unknown'
            })
        };
    }
}
// Traiter les événements Amazon Connect
async function handleConnectRequest(event) {
    var _a;
    try {
        console.log('Processing Connect event:', JSON.stringify(event, null, 2));
        let interactionId;
        let contactAttributes;
        // Extraire les données selon le format Connect ou format de test direct
        if ((_a = event.Details) === null || _a === void 0 ? void 0 : _a.ContactData) {
            // Format Amazon Connect standard
            interactionId = event.Details.ContactData.ContactId || 'unknown';
            contactAttributes = event.Details.ContactData.Attributes || {};
            // Convertir les valeurs string en types appropriés
            const convertedAttributes = {};
            for (const [key, value] of Object.entries(contactAttributes)) {
                // Essayer de convertir les booléens et nombres
                if (value === 'true')
                    convertedAttributes[key] = true;
                else if (value === 'false')
                    convertedAttributes[key] = false;
                else if (!isNaN(Number(value)) && value !== '')
                    convertedAttributes[key] = Number(value);
                else
                    convertedAttributes[key] = value;
            }
            contactAttributes = convertedAttributes;
        }
        else if (event.interactionId && event.contactAttributes) {
            // Format de test direct
            interactionId = event.interactionId;
            contactAttributes = event.contactAttributes;
        }
        else {
            throw new Error('Invalid Connect event format: missing ContactData or direct attributes');
        }
        // Créer la requête pour le moteur de décision
        const request = {
            interactionId,
            contactAttributes
        };
        console.log('Processed qualification request:', JSON.stringify(request, null, 2));
        // Initialize decision engine
        const decisionEngine = new DecisionEngine_1.DecisionEngine();
        // Process decision
        const response = await decisionEngine.processDecision(request);
        // Retourner la réponse au format Connect
        const connectResponse = {
            success: response.success,
            timestamp: new Date().toISOString(),
            requestId: interactionId
        };
        if (response.success && response.distributionSegment) {
            connectResponse.distributionSegment = response.distributionSegment;
            // Ajouter l'ID de la règle qui a matché
            if (response.selectedRuleId) {
                connectResponse.ruleId = response.selectedRuleId;
            }
            // Ajouter le libellé et la priorité
            if (response.libellé) {
                connectResponse.libellé = response.libellé;
            }
            if (response.priority !== undefined) {
                connectResponse.priority = response.priority;
            }
        }
        else {
            connectResponse.error = response.error || 'Decision processing failed';
            connectResponse.errorCode = response.errorCode || 'PROCESSING_ERROR';
        }
        console.log('Connect response:', JSON.stringify(connectResponse, null, 2));
        return connectResponse;
    }
    catch (error) {
        console.error('Connect decision engine error:', error);
        return {
            success: false,
            error: 'Internal server error',
            errorCode: 'INTERNAL_ERROR',
            timestamp: new Date().toISOString(),
            requestId: 'unknown'
        };
    }
}
const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    // ✅ LAZY LOADING : Pas de warm-up au démarrage
    // Le cache Parameter Store sera chargé automatiquement au premier appel
    // Avantages :
    // - 0ms si aucun critère secondaire actif (votre cas actuel)
    // - Cache réutilisé entre invocations Lambda warm
    // - Chargement uniquement quand nécessaire
    // Détecter le type d'événement et router vers le bon handler
    if (isApiGatewayEvent(event)) {
        console.log('Processing as API Gateway event');
        return handleApiGatewayRequest(event);
    }
    else if (isConnectEvent(event)) {
        console.log('Processing as Connect event');
        return handleConnectRequest(event);
    }
    else {
        console.error('Unknown event type:', event);
        // Retourner une erreur générique
        const errorResponse = {
            success: false,
            error: 'Unsupported event type',
            errorCode: 'UNSUPPORTED_EVENT_TYPE',
            timestamp: new Date().toISOString(),
            requestId: 'unknown'
        };
        // Si ça ressemble à une requête API Gateway, retourner le format approprié
        if (event.httpMethod !== undefined) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify(errorResponse)
            };
        }
        // Sinon retourner directement l'erreur
        return errorResponse;
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9mdW5jdGlvbnMvZGVjaXNpb24tZW5naW5lL2hhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0Esa0ZBQStFO0FBOEIvRSw2Q0FBNkM7QUFDN0MsU0FBUyxpQkFBaUIsQ0FBQyxLQUFVO0lBQ25DLE9BQU8sS0FBSyxDQUFDLFVBQVUsS0FBSyxTQUFTLENBQUM7QUFDeEMsQ0FBQztBQUVELDhDQUE4QztBQUM5QyxTQUFTLGNBQWMsQ0FBQyxLQUFVO0lBQ2hDLE9BQU8sS0FBSyxDQUFDLE9BQU8sS0FBSyxTQUFTLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsaUJBQWlCLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDckgsQ0FBQztBQUVELHFDQUFxQztBQUNyQyxLQUFLLFVBQVUsdUJBQXVCLENBQUMsS0FBMkI7O0lBQ2hFLDZDQUE2QztJQUM3QyxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDbkMsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTyxFQUFFO2dCQUNQLDZCQUE2QixFQUFFLEdBQUc7Z0JBQ2xDLDhCQUE4QixFQUFFLDZCQUE2QjtnQkFDN0QsOEJBQThCLEVBQUUsY0FBYztnQkFDOUMsd0JBQXdCLEVBQUUsT0FBTzthQUNsQztZQUNELElBQUksRUFBRSxFQUFFO1NBQ1QsQ0FBQztJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCx1QkFBdUI7UUFDdkIsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQ2hDLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFO29CQUNQLGNBQWMsRUFBRSxrQkFBa0I7b0JBQ2xDLDZCQUE2QixFQUFFLEdBQUc7aUJBQ25DO2dCQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixPQUFPLEVBQUUsS0FBSztvQkFDZCxLQUFLLEVBQUUsb0JBQW9CO29CQUMzQixTQUFTLEVBQUUsb0JBQW9CO29CQUMvQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7b0JBQ25DLFNBQVMsRUFBRSxDQUFBLE1BQUEsS0FBSyxDQUFDLGNBQWMsMENBQUUsU0FBUyxLQUFJLFNBQVM7aUJBQ3hELENBQUM7YUFDSCxDQUFDO1FBQ0osQ0FBQztRQUVELCtCQUErQjtRQUMvQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2hCLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFO29CQUNQLGNBQWMsRUFBRSxrQkFBa0I7b0JBQ2xDLDZCQUE2QixFQUFFLEdBQUc7aUJBQ25DO2dCQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixPQUFPLEVBQUUsS0FBSztvQkFDZCxLQUFLLEVBQUUsMEJBQTBCO29CQUNqQyxTQUFTLEVBQUUsY0FBYztvQkFDekIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxTQUFTLEVBQUUsQ0FBQSxNQUFBLEtBQUssQ0FBQyxjQUFjLDBDQUFFLFNBQVMsS0FBSSxTQUFTO2lCQUN4RCxDQUFDO2FBQ0gsQ0FBQztRQUNKLENBQUM7UUFFRCx5Q0FBeUM7UUFDekMsSUFBSSxPQUE2QixDQUFDO1FBQ2xDLElBQUksQ0FBQztZQUNILE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBQUMsT0FBTyxVQUFVLEVBQUUsQ0FBQztZQUNwQixPQUFPO2dCQUNMLFVBQVUsRUFBRSxHQUFHO2dCQUNmLE9BQU8sRUFBRTtvQkFDUCxjQUFjLEVBQUUsa0JBQWtCO29CQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2lCQUNuQztnQkFDRCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQkFDbkIsT0FBTyxFQUFFLEtBQUs7b0JBQ2QsS0FBSyxFQUFFLDhCQUE4QjtvQkFDckMsU0FBUyxFQUFFLGNBQWM7b0JBQ3pCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtvQkFDbkMsU0FBUyxFQUFFLENBQUEsTUFBQSxLQUFLLENBQUMsY0FBYywwQ0FBRSxTQUFTLEtBQUksU0FBUztpQkFDeEQsQ0FBQzthQUNILENBQUM7UUFDSixDQUFDO1FBRUQsNkJBQTZCO1FBQzdCLE1BQU0sY0FBYyxHQUFHLElBQUksK0JBQWMsRUFBRSxDQUFDO1FBRTVDLG1CQUFtQjtRQUNuQixNQUFNLFFBQVEsR0FBcUIsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWpGLDBDQUEwQztRQUMxQyxNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUVoRCxPQUFPO1lBQ0wsVUFBVTtZQUNWLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2dCQUNsQyw4QkFBOEIsRUFBRSw2QkFBNkI7Z0JBQzdELDhCQUE4QixFQUFFLGNBQWM7YUFDL0M7WUFDRCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7U0FDL0IsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUUvQyxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUU7Z0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtnQkFDbEMsNkJBQTZCLEVBQUUsR0FBRzthQUNuQztZQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNuQixPQUFPLEVBQUUsS0FBSztnQkFDZCxLQUFLLEVBQUUsdUJBQXVCO2dCQUM5QixTQUFTLEVBQUUsZ0JBQWdCO2dCQUMzQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7Z0JBQ25DLFNBQVMsRUFBRSxDQUFBLE1BQUEsS0FBSyxDQUFDLGNBQWMsMENBQUUsU0FBUyxLQUFJLFNBQVM7YUFDeEQsQ0FBQztTQUNILENBQUM7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVELHdDQUF3QztBQUN4QyxLQUFLLFVBQVUsb0JBQW9CLENBQUMsS0FBbUI7O0lBQ3JELElBQUksQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFekUsSUFBSSxhQUFxQixDQUFDO1FBQzFCLElBQUksaUJBQXNDLENBQUM7UUFFM0Msd0VBQXdFO1FBQ3hFLElBQUksTUFBQSxLQUFLLENBQUMsT0FBTywwQ0FBRSxXQUFXLEVBQUUsQ0FBQztZQUMvQixpQ0FBaUM7WUFDakMsYUFBYSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUM7WUFDakUsaUJBQWlCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztZQUUvRCxtREFBbUQ7WUFDbkQsTUFBTSxtQkFBbUIsR0FBd0IsRUFBRSxDQUFDO1lBQ3BELEtBQUssTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztnQkFDN0QsK0NBQStDO2dCQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNO29CQUFFLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztxQkFDakQsSUFBSSxLQUFLLEtBQUssT0FBTztvQkFBRSxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7cUJBQ3hELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksS0FBSyxLQUFLLEVBQUU7b0JBQUUsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDOztvQkFDcEYsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO1lBQ3hDLENBQUM7WUFDRCxpQkFBaUIsR0FBRyxtQkFBbUIsQ0FBQztRQUMxQyxDQUFDO2FBQU0sSUFBSSxLQUFLLENBQUMsYUFBYSxJQUFJLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQzFELHdCQUF3QjtZQUN4QixhQUFhLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQztZQUNwQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7UUFDOUMsQ0FBQzthQUFNLENBQUM7WUFDTixNQUFNLElBQUksS0FBSyxDQUFDLHdFQUF3RSxDQUFDLENBQUM7UUFDNUYsQ0FBQztRQUVELDhDQUE4QztRQUM5QyxNQUFNLE9BQU8sR0FBeUI7WUFDcEMsYUFBYTtZQUNiLGlCQUFpQjtTQUNsQixDQUFDO1FBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVsRiw2QkFBNkI7UUFDN0IsTUFBTSxjQUFjLEdBQUcsSUFBSSwrQkFBYyxFQUFFLENBQUM7UUFFNUMsbUJBQW1CO1FBQ25CLE1BQU0sUUFBUSxHQUFxQixNQUFNLGNBQWMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFakYseUNBQXlDO1FBQ3pDLE1BQU0sZUFBZSxHQUFvQjtZQUN2QyxPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU87WUFDekIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1lBQ25DLFNBQVMsRUFBRSxhQUFhO1NBQ3pCLENBQUM7UUFFRixJQUFJLFFBQVEsQ0FBQyxPQUFPLElBQUksUUFBUSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDckQsZUFBZSxDQUFDLG1CQUFtQixHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQztZQUNuRSx3Q0FBd0M7WUFDeEMsSUFBSSxRQUFRLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQzVCLGVBQWUsQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQztZQUNuRCxDQUFDO1lBQ0Qsb0NBQW9DO1lBQ3BDLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNyQixlQUFlLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDN0MsQ0FBQztZQUNELElBQUksUUFBUSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDcEMsZUFBZSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO1lBQy9DLENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLGVBQWUsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssSUFBSSw0QkFBNEIsQ0FBQztZQUN2RSxlQUFlLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksa0JBQWtCLENBQUM7UUFDdkUsQ0FBQztRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0UsT0FBTyxlQUFlLENBQUM7SUFFekIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXZELE9BQU87WUFDTCxPQUFPLEVBQUUsS0FBSztZQUNkLEtBQUssRUFBRSx1QkFBdUI7WUFDOUIsU0FBUyxFQUFFLGdCQUFnQjtZQUMzQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDbkMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQztJQUNKLENBQUM7QUFDSCxDQUFDO0FBRU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQVUsRUFBZ0IsRUFBRTtJQUN4RCxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRS9ELCtDQUErQztJQUMvQyx3RUFBd0U7SUFDeEUsY0FBYztJQUNkLDZEQUE2RDtJQUM3RCxrREFBa0Q7SUFDbEQsMkNBQTJDO0lBRTNDLDZEQUE2RDtJQUM3RCxJQUFJLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLE9BQU8sdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztTQUFNLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDakMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQzNDLE9BQU8sb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztTQUFNLENBQUM7UUFDTixPQUFPLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRTVDLGlDQUFpQztRQUNqQyxNQUFNLGFBQWEsR0FBRztZQUNwQixPQUFPLEVBQUUsS0FBSztZQUNkLEtBQUssRUFBRSx3QkFBd0I7WUFDL0IsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDbkMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQztRQUVGLDJFQUEyRTtRQUMzRSxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDbkMsT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPLEVBQUU7b0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtvQkFDbEMsNkJBQTZCLEVBQUUsR0FBRztpQkFDbkM7Z0JBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDO2FBQ3BDLENBQUM7UUFDSixDQUFDO1FBRUQsdUNBQXVDO1FBQ3ZDLE9BQU8sYUFBYSxDQUFDO0lBQ3ZCLENBQUM7QUFDSCxDQUFDLENBQUM7QUE1Q1csUUFBQSxPQUFPLFdBNENsQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFQSUdhdGV3YXlQcm94eUV2ZW50LCBBUElHYXRld2F5UHJveHlSZXN1bHQgfSBmcm9tICdhd3MtbGFtYmRhJztcclxuaW1wb3J0IHsgRGVjaXNpb25FbmdpbmUgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvRGVjaXNpb25FbmdpbmUnO1xyXG5pbXBvcnQgeyBRdWFsaWZpY2F0aW9uUmVxdWVzdCwgRGVjaXNpb25SZXNwb25zZSB9IGZyb20gJy4uLy4uL3R5cGVzL2RlY2lzaW9uLWVuZ2luZSc7XHJcbmltcG9ydCB7IEh5YnJpZENyaXRlcmlhTWFuYWdlciB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2RlY2lzaW9uLWVuZ2luZS9IeWJyaWRDcml0ZXJpYU1hbmFnZXInO1xyXG5cclxuLy8gVHlwZXMgcG91ciBBbWF6b24gQ29ubmVjdFxyXG5pbnRlcmZhY2UgQ29ubmVjdEV2ZW50IHtcclxuICBEZXRhaWxzPzoge1xyXG4gICAgQ29udGFjdERhdGE/OiB7XHJcbiAgICAgIEF0dHJpYnV0ZXM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xyXG4gICAgICBDb250YWN0SWQ/OiBzdHJpbmc7XHJcbiAgICB9O1xyXG4gICAgUGFyYW1ldGVycz86IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XHJcbiAgfTtcclxuICAvLyBTdXBwb3J0IGRpcmVjdCBwb3VyIGxlcyB0ZXN0c1xyXG4gIGludGVyYWN0aW9uSWQ/OiBzdHJpbmc7XHJcbiAgY29udGFjdEF0dHJpYnV0ZXM/OiBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xyXG59XHJcblxyXG5pbnRlcmZhY2UgQ29ubmVjdFJlc3BvbnNlIHtcclxuICBkaXN0cmlidXRpb25TZWdtZW50Pzogc3RyaW5nO1xyXG4gIHN1Y2Nlc3M6IGJvb2xlYW47XHJcbiAgZXJyb3I/OiBzdHJpbmc7XHJcbiAgZXJyb3JDb2RlPzogc3RyaW5nO1xyXG4gIHRpbWVzdGFtcDogc3RyaW5nO1xyXG4gIHJlcXVlc3RJZD86IHN0cmluZztcclxuICBydWxlSWQ/OiBzdHJpbmc7ICAvLyBJRCBkZSBsYSByw6hnbGVcclxuICBsaWJlbGzDqT86IHN0cmluZzsgIC8vIERlc2NyaXB0aW9uIGRlIGxhIHLDqGdsZVxyXG4gIHByaW9yaXR5PzogbnVtYmVyOyAgLy8gUHJpb3JpdMOpIGRlIGxhIHLDqGdsZVxyXG59XHJcblxyXG4vLyBGb25jdGlvbiBwb3VyIGTDqXRlY3RlciBsZSB0eXBlIGQnw6l2w6luZW1lbnRcclxuZnVuY3Rpb24gaXNBcGlHYXRld2F5RXZlbnQoZXZlbnQ6IGFueSk6IGV2ZW50IGlzIEFQSUdhdGV3YXlQcm94eUV2ZW50IHtcclxuICByZXR1cm4gZXZlbnQuaHR0cE1ldGhvZCAhPT0gdW5kZWZpbmVkO1xyXG59XHJcblxyXG4vLyBGb25jdGlvbiBwb3VyIGTDqXRlY3RlciB1biDDqXbDqW5lbWVudCBDb25uZWN0XHJcbmZ1bmN0aW9uIGlzQ29ubmVjdEV2ZW50KGV2ZW50OiBhbnkpOiBldmVudCBpcyBDb25uZWN0RXZlbnQge1xyXG4gIHJldHVybiBldmVudC5EZXRhaWxzICE9PSB1bmRlZmluZWQgfHwgKGV2ZW50LmludGVyYWN0aW9uSWQgIT09IHVuZGVmaW5lZCAmJiBldmVudC5jb250YWN0QXR0cmlidXRlcyAhPT0gdW5kZWZpbmVkKTtcclxufVxyXG5cclxuLy8gVHJhaXRlciBsZXMgw6l2w6luZW1lbnRzIEFQSSBHYXRld2F5XHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFwaUdhdGV3YXlSZXF1ZXN0KGV2ZW50OiBBUElHYXRld2F5UHJveHlFdmVudCk6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiB7XHJcbiAgLy8gSGFuZGxlIHByZWZsaWdodCBPUFRJT05TIHJlcXVlc3RzIGZvciBDT1JTXHJcbiAgaWYgKGV2ZW50Lmh0dHBNZXRob2QgPT09ICdPUFRJT05TJykge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcclxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdDb250ZW50LVR5cGUsIEF1dGhvcml6YXRpb24nLFxyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJ09QVElPTlMsUE9TVCcsXHJcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLU1heC1BZ2UnOiAnODY0MDAnXHJcbiAgICAgIH0sXHJcbiAgICAgIGJvZHk6ICcnXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIC8vIFZhbGlkYXRlIEhUVFAgbWV0aG9kXHJcbiAgICBpZiAoZXZlbnQuaHR0cE1ldGhvZCAhPT0gJ1BPU1QnKSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzQ29kZTogNDA1LFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgICAgIGVycm9yOiAnTWV0aG9kIG5vdCBhbGxvd2VkJyxcclxuICAgICAgICAgIGVycm9yQ29kZTogJ01FVEhPRF9OT1RfQUxMT1dFRCcsXHJcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgIHJlcXVlc3RJZDogZXZlbnQucmVxdWVzdENvbnRleHQ/LnJlcXVlc3RJZCB8fCAndW5rbm93bidcclxuICAgICAgICB9KVxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFZhbGlkYXRlIHJlcXVlc3QgYm9keSBleGlzdHNcclxuICAgIGlmICghZXZlbnQuYm9keSkge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBlcnJvcjogJ1JlcXVlc3QgYm9keSBpcyByZXF1aXJlZCcsXHJcbiAgICAgICAgICBlcnJvckNvZGU6ICdNSVNTSU5HX0JPRFknLFxyXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICByZXF1ZXN0SWQ6IGV2ZW50LnJlcXVlc3RDb250ZXh0Py5yZXF1ZXN0SWQgfHwgJ3Vua25vd24nXHJcbiAgICAgICAgfSlcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBQYXJzZSByZXF1ZXN0IGJvZHkgd2l0aCBlcnJvciBoYW5kbGluZ1xyXG4gICAgbGV0IHJlcXVlc3Q6IFF1YWxpZmljYXRpb25SZXF1ZXN0O1xyXG4gICAgdHJ5IHtcclxuICAgICAgcmVxdWVzdCA9IEpTT04ucGFyc2UoZXZlbnQuYm9keSk7XHJcbiAgICB9IGNhdGNoIChwYXJzZUVycm9yKSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgICAgIGVycm9yOiAnSW52YWxpZCBKU09OIGluIHJlcXVlc3QgYm9keScsXHJcbiAgICAgICAgICBlcnJvckNvZGU6ICdJTlZBTElEX0pTT04nLFxyXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICByZXF1ZXN0SWQ6IGV2ZW50LnJlcXVlc3RDb250ZXh0Py5yZXF1ZXN0SWQgfHwgJ3Vua25vd24nXHJcbiAgICAgICAgfSlcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8gSW5pdGlhbGl6ZSBkZWNpc2lvbiBlbmdpbmVcclxuICAgIGNvbnN0IGRlY2lzaW9uRW5naW5lID0gbmV3IERlY2lzaW9uRW5naW5lKCk7XHJcbiAgICBcclxuICAgIC8vIFByb2Nlc3MgZGVjaXNpb25cclxuICAgIGNvbnN0IHJlc3BvbnNlOiBEZWNpc2lvblJlc3BvbnNlID0gYXdhaXQgZGVjaXNpb25FbmdpbmUucHJvY2Vzc0RlY2lzaW9uKHJlcXVlc3QpO1xyXG4gICAgXHJcbiAgICAvLyBEZXRlcm1pbmUgc3RhdHVzIGNvZGUgYmFzZWQgb24gcmVzcG9uc2VcclxuICAgIGNvbnN0IHN0YXR1c0NvZGUgPSByZXNwb25zZS5zdWNjZXNzID8gMjAwIDogNDAwO1xyXG4gICAgXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdGF0dXNDb2RlLFxyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZSwgQXV0aG9yaXphdGlvbicsXHJcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnT1BUSU9OUyxQT1NUJ1xyXG4gICAgICB9LFxyXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZXNwb25zZSlcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ0RlY2lzaW9uIGVuZ2luZSBlcnJvcjonLCBlcnJvcik7XHJcbiAgICBcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IDUwMCxcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJ1xyXG4gICAgICB9LFxyXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6ICdJbnRlcm5hbCBzZXJ2ZXIgZXJyb3InLFxyXG4gICAgICAgIGVycm9yQ29kZTogJ0lOVEVSTkFMX0VSUk9SJyxcclxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICByZXF1ZXN0SWQ6IGV2ZW50LnJlcXVlc3RDb250ZXh0Py5yZXF1ZXN0SWQgfHwgJ3Vua25vd24nXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gVHJhaXRlciBsZXMgw6l2w6luZW1lbnRzIEFtYXpvbiBDb25uZWN0XHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZUNvbm5lY3RSZXF1ZXN0KGV2ZW50OiBDb25uZWN0RXZlbnQpOiBQcm9taXNlPENvbm5lY3RSZXNwb25zZT4ge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zb2xlLmxvZygnUHJvY2Vzc2luZyBDb25uZWN0IGV2ZW50OicsIEpTT04uc3RyaW5naWZ5KGV2ZW50LCBudWxsLCAyKSk7XHJcblxyXG4gICAgbGV0IGludGVyYWN0aW9uSWQ6IHN0cmluZztcclxuICAgIGxldCBjb250YWN0QXR0cmlidXRlczogUmVjb3JkPHN0cmluZywgYW55PjtcclxuXHJcbiAgICAvLyBFeHRyYWlyZSBsZXMgZG9ubsOpZXMgc2Vsb24gbGUgZm9ybWF0IENvbm5lY3Qgb3UgZm9ybWF0IGRlIHRlc3QgZGlyZWN0XHJcbiAgICBpZiAoZXZlbnQuRGV0YWlscz8uQ29udGFjdERhdGEpIHtcclxuICAgICAgLy8gRm9ybWF0IEFtYXpvbiBDb25uZWN0IHN0YW5kYXJkXHJcbiAgICAgIGludGVyYWN0aW9uSWQgPSBldmVudC5EZXRhaWxzLkNvbnRhY3REYXRhLkNvbnRhY3RJZCB8fCAndW5rbm93bic7XHJcbiAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzID0gZXZlbnQuRGV0YWlscy5Db250YWN0RGF0YS5BdHRyaWJ1dGVzIHx8IHt9O1xyXG4gICAgICBcclxuICAgICAgLy8gQ29udmVydGlyIGxlcyB2YWxldXJzIHN0cmluZyBlbiB0eXBlcyBhcHByb3ByacOpc1xyXG4gICAgICBjb25zdCBjb252ZXJ0ZWRBdHRyaWJ1dGVzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge307XHJcbiAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGNvbnRhY3RBdHRyaWJ1dGVzKSkge1xyXG4gICAgICAgIC8vIEVzc2F5ZXIgZGUgY29udmVydGlyIGxlcyBib29sw6llbnMgZXQgbm9tYnJlc1xyXG4gICAgICAgIGlmICh2YWx1ZSA9PT0gJ3RydWUnKSBjb252ZXJ0ZWRBdHRyaWJ1dGVzW2tleV0gPSB0cnVlO1xyXG4gICAgICAgIGVsc2UgaWYgKHZhbHVlID09PSAnZmFsc2UnKSBjb252ZXJ0ZWRBdHRyaWJ1dGVzW2tleV0gPSBmYWxzZTtcclxuICAgICAgICBlbHNlIGlmICghaXNOYU4oTnVtYmVyKHZhbHVlKSkgJiYgdmFsdWUgIT09ICcnKSBjb252ZXJ0ZWRBdHRyaWJ1dGVzW2tleV0gPSBOdW1iZXIodmFsdWUpO1xyXG4gICAgICAgIGVsc2UgY29udmVydGVkQXR0cmlidXRlc1trZXldID0gdmFsdWU7XHJcbiAgICAgIH1cclxuICAgICAgY29udGFjdEF0dHJpYnV0ZXMgPSBjb252ZXJ0ZWRBdHRyaWJ1dGVzO1xyXG4gICAgfSBlbHNlIGlmIChldmVudC5pbnRlcmFjdGlvbklkICYmIGV2ZW50LmNvbnRhY3RBdHRyaWJ1dGVzKSB7XHJcbiAgICAgIC8vIEZvcm1hdCBkZSB0ZXN0IGRpcmVjdFxyXG4gICAgICBpbnRlcmFjdGlvbklkID0gZXZlbnQuaW50ZXJhY3Rpb25JZDtcclxuICAgICAgY29udGFjdEF0dHJpYnV0ZXMgPSBldmVudC5jb250YWN0QXR0cmlidXRlcztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBDb25uZWN0IGV2ZW50IGZvcm1hdDogbWlzc2luZyBDb250YWN0RGF0YSBvciBkaXJlY3QgYXR0cmlidXRlcycpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENyw6llciBsYSByZXF1w6p0ZSBwb3VyIGxlIG1vdGV1ciBkZSBkw6ljaXNpb25cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFF1YWxpZmljYXRpb25SZXF1ZXN0ID0ge1xyXG4gICAgICBpbnRlcmFjdGlvbklkLFxyXG4gICAgICBjb250YWN0QXR0cmlidXRlc1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zb2xlLmxvZygnUHJvY2Vzc2VkIHF1YWxpZmljYXRpb24gcmVxdWVzdDonLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0LCBudWxsLCAyKSk7XHJcblxyXG4gICAgLy8gSW5pdGlhbGl6ZSBkZWNpc2lvbiBlbmdpbmVcclxuICAgIGNvbnN0IGRlY2lzaW9uRW5naW5lID0gbmV3IERlY2lzaW9uRW5naW5lKCk7XHJcbiAgICBcclxuICAgIC8vIFByb2Nlc3MgZGVjaXNpb25cclxuICAgIGNvbnN0IHJlc3BvbnNlOiBEZWNpc2lvblJlc3BvbnNlID0gYXdhaXQgZGVjaXNpb25FbmdpbmUucHJvY2Vzc0RlY2lzaW9uKHJlcXVlc3QpO1xyXG4gICAgXHJcbiAgICAvLyBSZXRvdXJuZXIgbGEgcsOpcG9uc2UgYXUgZm9ybWF0IENvbm5lY3RcclxuICAgIGNvbnN0IGNvbm5lY3RSZXNwb25zZTogQ29ubmVjdFJlc3BvbnNlID0ge1xyXG4gICAgICBzdWNjZXNzOiByZXNwb25zZS5zdWNjZXNzLFxyXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgcmVxdWVzdElkOiBpbnRlcmFjdGlvbklkXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChyZXNwb25zZS5zdWNjZXNzICYmIHJlc3BvbnNlLmRpc3RyaWJ1dGlvblNlZ21lbnQpIHtcclxuICAgICAgY29ubmVjdFJlc3BvbnNlLmRpc3RyaWJ1dGlvblNlZ21lbnQgPSByZXNwb25zZS5kaXN0cmlidXRpb25TZWdtZW50O1xyXG4gICAgICAvLyBBam91dGVyIGwnSUQgZGUgbGEgcsOoZ2xlIHF1aSBhIG1hdGNow6lcclxuICAgICAgaWYgKHJlc3BvbnNlLnNlbGVjdGVkUnVsZUlkKSB7XHJcbiAgICAgICAgY29ubmVjdFJlc3BvbnNlLnJ1bGVJZCA9IHJlc3BvbnNlLnNlbGVjdGVkUnVsZUlkO1xyXG4gICAgICB9XHJcbiAgICAgIC8vIEFqb3V0ZXIgbGUgbGliZWxsw6kgZXQgbGEgcHJpb3JpdMOpXHJcbiAgICAgIGlmIChyZXNwb25zZS5saWJlbGzDqSkge1xyXG4gICAgICAgIGNvbm5lY3RSZXNwb25zZS5saWJlbGzDqSA9IHJlc3BvbnNlLmxpYmVsbMOpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChyZXNwb25zZS5wcmlvcml0eSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgY29ubmVjdFJlc3BvbnNlLnByaW9yaXR5ID0gcmVzcG9uc2UucHJpb3JpdHk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbm5lY3RSZXNwb25zZS5lcnJvciA9IHJlc3BvbnNlLmVycm9yIHx8ICdEZWNpc2lvbiBwcm9jZXNzaW5nIGZhaWxlZCc7XHJcbiAgICAgIGNvbm5lY3RSZXNwb25zZS5lcnJvckNvZGUgPSByZXNwb25zZS5lcnJvckNvZGUgfHwgJ1BST0NFU1NJTkdfRVJST1InO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnNvbGUubG9nKCdDb25uZWN0IHJlc3BvbnNlOicsIEpTT04uc3RyaW5naWZ5KGNvbm5lY3RSZXNwb25zZSwgbnVsbCwgMikpO1xyXG4gICAgcmV0dXJuIGNvbm5lY3RSZXNwb25zZTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ0Nvbm5lY3QgZGVjaXNpb24gZW5naW5lIGVycm9yOicsIGVycm9yKTtcclxuICAgIFxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOiAnSW50ZXJuYWwgc2VydmVyIGVycm9yJyxcclxuICAgICAgZXJyb3JDb2RlOiAnSU5URVJOQUxfRVJST1InLFxyXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgcmVxdWVzdElkOiAndW5rbm93bidcclxuICAgIH07XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgaGFuZGxlciA9IGFzeW5jIChldmVudDogYW55KTogUHJvbWlzZTxhbnk+ID0+IHtcclxuICBjb25zb2xlLmxvZygnUmVjZWl2ZWQgZXZlbnQ6JywgSlNPTi5zdHJpbmdpZnkoZXZlbnQsIG51bGwsIDIpKTtcclxuXHJcbiAgLy8g4pyFIExBWlkgTE9BRElORyA6IFBhcyBkZSB3YXJtLXVwIGF1IGTDqW1hcnJhZ2VcclxuICAvLyBMZSBjYWNoZSBQYXJhbWV0ZXIgU3RvcmUgc2VyYSBjaGFyZ8OpIGF1dG9tYXRpcXVlbWVudCBhdSBwcmVtaWVyIGFwcGVsXHJcbiAgLy8gQXZhbnRhZ2VzIDpcclxuICAvLyAtIDBtcyBzaSBhdWN1biBjcml0w6hyZSBzZWNvbmRhaXJlIGFjdGlmICh2b3RyZSBjYXMgYWN0dWVsKVxyXG4gIC8vIC0gQ2FjaGUgcsOpdXRpbGlzw6kgZW50cmUgaW52b2NhdGlvbnMgTGFtYmRhIHdhcm1cclxuICAvLyAtIENoYXJnZW1lbnQgdW5pcXVlbWVudCBxdWFuZCBuw6ljZXNzYWlyZVxyXG5cclxuICAvLyBEw6l0ZWN0ZXIgbGUgdHlwZSBkJ8OpdsOpbmVtZW50IGV0IHJvdXRlciB2ZXJzIGxlIGJvbiBoYW5kbGVyXHJcbiAgaWYgKGlzQXBpR2F0ZXdheUV2ZW50KGV2ZW50KSkge1xyXG4gICAgY29uc29sZS5sb2coJ1Byb2Nlc3NpbmcgYXMgQVBJIEdhdGV3YXkgZXZlbnQnKTtcclxuICAgIHJldHVybiBoYW5kbGVBcGlHYXRld2F5UmVxdWVzdChldmVudCk7XHJcbiAgfSBlbHNlIGlmIChpc0Nvbm5lY3RFdmVudChldmVudCkpIHtcclxuICAgIGNvbnNvbGUubG9nKCdQcm9jZXNzaW5nIGFzIENvbm5lY3QgZXZlbnQnKTtcclxuICAgIHJldHVybiBoYW5kbGVDb25uZWN0UmVxdWVzdChldmVudCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ1Vua25vd24gZXZlbnQgdHlwZTonLCBldmVudCk7XHJcbiAgICBcclxuICAgIC8vIFJldG91cm5lciB1bmUgZXJyZXVyIGfDqW7DqXJpcXVlXHJcbiAgICBjb25zdCBlcnJvclJlc3BvbnNlID0ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6ICdVbnN1cHBvcnRlZCBldmVudCB0eXBlJyxcclxuICAgICAgZXJyb3JDb2RlOiAnVU5TVVBQT1JURURfRVZFTlRfVFlQRScsXHJcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICByZXF1ZXN0SWQ6ICd1bmtub3duJ1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBTaSDDp2EgcmVzc2VtYmxlIMOgIHVuZSByZXF1w6p0ZSBBUEkgR2F0ZXdheSwgcmV0b3VybmVyIGxlIGZvcm1hdCBhcHByb3ByacOpXHJcbiAgICBpZiAoZXZlbnQuaHR0cE1ldGhvZCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShlcnJvclJlc3BvbnNlKVxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFNpbm9uIHJldG91cm5lciBkaXJlY3RlbWVudCBsJ2VycmV1clxyXG4gICAgcmV0dXJuIGVycm9yUmVzcG9uc2U7XHJcbiAgfVxyXG59OyJdfQ==
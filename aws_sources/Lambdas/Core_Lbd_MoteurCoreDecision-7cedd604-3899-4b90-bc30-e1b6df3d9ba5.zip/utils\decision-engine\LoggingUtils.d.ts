import { ContactAttributes, QualificationRule, EliminationStep, EliminatedRule } from '../../types/decision-engine';
export interface LogContext {
    requestId: string;
    interactionId: string;
    timestamp: string;
}
export interface AuditTrail {
    requestId: string;
    interactionId: string;
    startTime: string;
    endTime?: string;
    duration?: number;
    inputAttributes: ContactAttributes;
    rulesLoaded: number;
    eliminationSteps: EliminationStep[];
    eliminatedRules: EliminatedRule[];
    selectedRule?: QualificationRule;
    distributionSegment?: string;
    success: boolean;
    error?: string;
    errorCode?: string;
}
export declare class LoggingUtils {
    private static auditTrails;
    /**
     * Creates a new audit trail for a decision process
     * Requirements: 5.5 - Include timestamps and unique request identifiers
     */
    static createAuditTrail(context: LogContext, contactAttributes: ContactAttributes): void;
    /**
     * Logs the start of decision process with comprehensive input tracking
     * Requirements: 5.1 - Log input criteria and selected rule
     */
    static logDecisionStart(context: LogContext, contactAttributes: ContactAttributes): void;
    /**
     * Logs rules loaded from database with detailed information
     * Requirements: 5.1 - Log the input criteria and selected rule
     */
    static logRulesLoaded(context: LogContext, ruleCount: number, rules?: QualificationRule[]): void;
    /**
     * Logs each elimination step with detailed tracking
     * Requirements: 5.2 - Record which rules were eliminated and why
     */
    static logEliminationStep(context: LogContext, step: EliminationStep, eliminatedRules?: EliminatedRule[]): void;
    /**
     * Logs rule selection with comprehensive decision rationale
     * Requirements: 5.3 - Log decision rationale including weight comparison
     */
    static logRuleSelected(context: LogContext, rule: QualificationRule, reason: string, eligibleRules?: QualificationRule[]): void;
    /**
     * Logs errors with detailed information for troubleshooting
     * Requirements: 5.4 - Log detailed error information for troubleshooting
     */
    static logError(context: LogContext, error: string, details?: any, errorCode?: string): void;
    /**
     * Logs decision completion with comprehensive summary
     * Requirements: 5.1, 5.3 - Complete audit trail with decision rationale
     */
    static logDecisionComplete(context: LogContext, success: boolean, distributionSegment?: string, errorCode?: string): void;
    /**
     * Logs database operations for monitoring and troubleshooting
     */
    static logDatabaseOperation(context: LogContext, operation: string, success: boolean, details?: any): void;
    /**
     * Logs cache operations for performance monitoring
     */
    static logCacheOperation(context: LogContext, operation: string, hit: boolean, details?: any): void;
    /**
     * Gets the current audit trail for a request (for testing/debugging)
     */
    static getAuditTrail(requestId: string): AuditTrail | undefined;
    /**
     * Clears all audit trails (for testing)
     */
    static clearAuditTrails(): void;
}

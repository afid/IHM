import { QualificationRequest, DecisionResponse } from '../../types/decision-engine';
export declare class DecisionEngine {
    private ruleRepository;
    private ruleEvaluator;
    constructor();
    /**
     * Filtre les attributs du contact pour ne garder que les critères actifs
     * (primaires + secondaires actifs dans Parameter Store)
     */
    private filterActiveAttributes;
    processDecision(request: QualificationRequest): Promise<DecisionResponse>;
    /**
     * Extracts rule IDs from equal weights error message
     */
    private extractRuleIdsFromError;
    /**
     * Extracts rule ID from distribution segment error message
     */
    private extractRuleIdFromSegmentError;
}

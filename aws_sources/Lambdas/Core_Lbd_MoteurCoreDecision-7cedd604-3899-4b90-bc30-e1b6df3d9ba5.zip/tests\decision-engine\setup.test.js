"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ValidationUtils_1 = require("../../utils/decision-engine/ValidationUtils");
const RuleParser_1 = require("../../utils/decision-engine/RuleParser");
const RuleEvaluator_1 = require("../../services/decision-engine/RuleEvaluator");
describe('Decision Engine Setup Tests', () => {
    describe('ValidationUtils', () => {
        test('should validate valid qualification request', () => {
            const request = {
                interactionId: 'test-123',
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP',
                    Score: 85
                }
            };
            const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(request);
            expect(result.isValid).toBe(true);
            expect(result.error).toBeUndefined();
        });
        test('should reject invalid qualification request', () => {
            const request = {
                contactAttributes: {
                    NouveauSinistre: true
                }
                // Missing interactionId
            };
            const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(request);
            expect(result.isValid).toBe(false);
            expect(result.error).toContain('interactionId');
        });
        test('should validate contact attributes', () => {
            const attributes = {
                booleanAttr: true,
                stringAttr: 'test',
                numberAttr: 42
            };
            const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
            expect(result.isValid).toBe(true);
        });
        test('should reject invalid contact attribute types', () => {
            const attributes = {
                validAttr: true,
                invalidAttr: { nested: 'object' } // Invalid type
            };
            const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
            expect(result.isValid).toBe(false);
            expect(result.error).toContain('invalid type');
        });
    });
    describe('RuleParser', () => {
        test('should validate simple rule syntax', () => {
            const expression = 'NouveauSinistre == true && Client == "VIP"';
            const result = RuleParser_1.RuleParser.validateRuleSyntax(expression);
            expect(result.isValid).toBe(true);
        });
        test('should reject empty rule expression', () => {
            const result = RuleParser_1.RuleParser.validateRuleSyntax('');
            expect(result.isValid).toBe(false);
            expect(result.error).toContain('empty');
        });
        test('should detect syntax errors', () => {
            const expression = '(NouveauSinistre == true && Client == VIP';
            const result = RuleParser_1.RuleParser.validateRuleSyntax(expression);
            expect(result.isValid).toBe(false);
        });
        test('should parse simple comparison expression', () => {
            const expression = 'NouveauSinistre == true';
            const result = RuleParser_1.RuleParser.parseRuleExpression(expression);
            expect(result.isValid).toBe(true);
            expect(result.tokens).toBeDefined();
            expect(result.tokens.length).toBeGreaterThan(0);
            expect(result.ast).toBeDefined();
            expect(result.ast.type).toBe('ComparisonExpression');
        });
        test('should parse complex boolean expression', () => {
            const expression = 'NouveauSinistre == true && Client == "VIP"';
            const result = RuleParser_1.RuleParser.parseRuleExpression(expression);
            expect(result.isValid).toBe(true);
            expect(result.ast).toBeDefined();
            expect(result.ast.type).toBe('BinaryExpression');
        });
        test('should evaluate expression against contact attributes', () => {
            const expression = 'NouveauSinistre == true && Client == "VIP"';
            const parseResult = RuleParser_1.RuleParser.parseRuleExpression(expression);
            expect(parseResult.isValid).toBe(true);
            const contactAttributes = {
                NouveauSinistre: true,
                Client: 'VIP'
            };
            const result = RuleParser_1.RuleParser.evaluateExpression(parseResult.ast, contactAttributes);
            expect(result).toBe(true);
        });
        test('should evaluate expression with missing attributes', () => {
            const expression = 'NouveauSinistre == true';
            const parseResult = RuleParser_1.RuleParser.parseRuleExpression(expression);
            expect(parseResult.isValid).toBe(true);
            const contactAttributes = {
                Client: 'VIP'
                // NouveauSinistre is missing
            };
            const result = RuleParser_1.RuleParser.evaluateExpression(parseResult.ast, contactAttributes);
            expect(result).toBe(false); // undefined == true should be false
        });
    });
    describe('RuleEvaluator', () => {
        const evaluator = new RuleEvaluator_1.RuleEvaluator();
        test('should select rule with highest weight', () => {
            const rules = [
                {
                    id: 'rule1',
                    name: 'Rule 1',
                    expression: 'NouveauSinistre == true',
                    weight: 10,
                    distributionSegment: 'segment1',
                    createdAt: '2023-01-01',
                    updatedAt: '2023-01-01'
                },
                {
                    id: 'rule2',
                    name: 'Rule 2',
                    expression: 'Client == "VIP"',
                    weight: 20,
                    distributionSegment: 'segment2',
                    createdAt: '2023-01-01',
                    updatedAt: '2023-01-01'
                }
            ];
            const contactAttributes = {
                NouveauSinistre: true,
                Client: 'VIP'
            };
            const result = evaluator.evaluateRules(contactAttributes, rules);
            expect(result.selectedRule).toBeDefined();
            expect(result.selectedRule.id).toBe('rule2'); // Higher weight
            expect(result.distributionSegment).toBe('segment2');
            expect(result.error).toBeUndefined();
        });
        test('should return error when no rules match', () => {
            const rules = [
                {
                    id: 'rule1',
                    name: 'Rule 1',
                    expression: 'NouveauSinistre == false',
                    weight: 10,
                    distributionSegment: 'segment1',
                    createdAt: '2023-01-01',
                    updatedAt: '2023-01-01'
                }
            ];
            const contactAttributes = {
                NouveauSinistre: true
            };
            const result = evaluator.evaluateRules(contactAttributes, rules);
            expect(result.selectedRule).toBeUndefined();
            expect(result.error).toBe('Aucune règle ne correspond, vérifier le paramétrage');
        });
        test('should return error when multiple rules have equal weights', () => {
            const rules = [
                {
                    id: 'rule1',
                    name: 'Rule 1',
                    expression: 'NouveauSinistre == true',
                    weight: 10,
                    distributionSegment: 'segment1',
                    createdAt: '2023-01-01',
                    updatedAt: '2023-01-01'
                },
                {
                    id: 'rule2',
                    name: 'Rule 2',
                    expression: 'Client == "VIP"',
                    weight: 10, // Same weight
                    distributionSegment: 'segment2',
                    createdAt: '2023-01-01',
                    updatedAt: '2023-01-01'
                }
            ];
            const contactAttributes = {
                NouveauSinistre: true,
                Client: 'VIP'
            };
            const result = evaluator.evaluateRules(contactAttributes, rules);
            expect(result.selectedRule).toBeUndefined();
            expect(result.error).toContain('ont des poids identiques');
            expect(result.error).toContain('rule1 et rule2');
        });
    });
    describe('Type Definitions', () => {
        test('should create valid QualificationRequest', () => {
            const request = {
                interactionId: 'test-interaction-123',
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP',
                    Score: 95,
                    Region: 'Paris'
                }
            };
            expect(request.interactionId).toBe('test-interaction-123');
            expect(request.contactAttributes.NouveauSinistre).toBe(true);
            expect(request.contactAttributes.Client).toBe('VIP');
            expect(request.contactAttributes.Score).toBe(95);
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0dXAudGVzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy90ZXN0cy9kZWNpc2lvbi1lbmdpbmUvc2V0dXAudGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGlGQUE4RTtBQUM5RSx1RUFBb0U7QUFDcEUsZ0ZBQTZFO0FBRzdFLFFBQVEsQ0FBQyw2QkFBNkIsRUFBRSxHQUFHLEVBQUU7SUFFM0MsUUFBUSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRTtRQUMvQixJQUFJLENBQUMsNkNBQTZDLEVBQUUsR0FBRyxFQUFFO1lBQ3ZELE1BQU0sT0FBTyxHQUF5QjtnQkFDcEMsYUFBYSxFQUFFLFVBQVU7Z0JBQ3pCLGlCQUFpQixFQUFFO29CQUNqQixlQUFlLEVBQUUsSUFBSTtvQkFDckIsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsS0FBSyxFQUFFLEVBQUU7aUJBQ1Y7YUFDRixDQUFDO1lBRUYsTUFBTSxNQUFNLEdBQUcsaUNBQWUsQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDZDQUE2QyxFQUFFLEdBQUcsRUFBRTtZQUN2RCxNQUFNLE9BQU8sR0FBRztnQkFDZCxpQkFBaUIsRUFBRTtvQkFDakIsZUFBZSxFQUFFLElBQUk7aUJBQ3RCO2dCQUNELHdCQUF3QjthQUN6QixDQUFDO1lBRUYsTUFBTSxNQUFNLEdBQUcsaUNBQWUsQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxvQ0FBb0MsRUFBRSxHQUFHLEVBQUU7WUFDOUMsTUFBTSxVQUFVLEdBQXNCO2dCQUNwQyxXQUFXLEVBQUUsSUFBSTtnQkFDakIsVUFBVSxFQUFFLE1BQU07Z0JBQ2xCLFVBQVUsRUFBRSxFQUFFO2FBQ2YsQ0FBQztZQUVGLE1BQU0sTUFBTSxHQUFHLGlDQUFlLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDckUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsK0NBQStDLEVBQUUsR0FBRyxFQUFFO1lBQ3pELE1BQU0sVUFBVSxHQUFHO2dCQUNqQixTQUFTLEVBQUUsSUFBSTtnQkFDZixXQUFXLEVBQUUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLENBQUMsZUFBZTthQUNsRCxDQUFDO1lBRUYsTUFBTSxNQUFNLEdBQUcsaUNBQWUsQ0FBQyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUSxDQUFDLFlBQVksRUFBRSxHQUFHLEVBQUU7UUFDMUIsSUFBSSxDQUFDLG9DQUFvQyxFQUFFLEdBQUcsRUFBRTtZQUM5QyxNQUFNLFVBQVUsR0FBRyw0Q0FBNEMsQ0FBQztZQUNoRSxNQUFNLE1BQU0sR0FBRyx1QkFBVSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3pELE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLHFDQUFxQyxFQUFFLEdBQUcsRUFBRTtZQUMvQyxNQUFNLE1BQU0sR0FBRyx1QkFBVSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2pELE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25DLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDZCQUE2QixFQUFFLEdBQUcsRUFBRTtZQUN2QyxNQUFNLFVBQVUsR0FBRywyQ0FBMkMsQ0FBQztZQUMvRCxNQUFNLE1BQU0sR0FBRyx1QkFBVSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3pELE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDJDQUEyQyxFQUFFLEdBQUcsRUFBRTtZQUNyRCxNQUFNLFVBQVUsR0FBRyx5QkFBeUIsQ0FBQztZQUM3QyxNQUFNLE1BQU0sR0FBRyx1QkFBVSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzFELE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2xDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDcEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pELE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDakMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDeEQsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMseUNBQXlDLEVBQUUsR0FBRyxFQUFFO1lBQ25ELE1BQU0sVUFBVSxHQUFHLDRDQUE0QyxDQUFDO1lBQ2hFLE1BQU0sTUFBTSxHQUFHLHVCQUFVLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDMUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyx1REFBdUQsRUFBRSxHQUFHLEVBQUU7WUFDakUsTUFBTSxVQUFVLEdBQUcsNENBQTRDLENBQUM7WUFDaEUsTUFBTSxXQUFXLEdBQUcsdUJBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMvRCxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV2QyxNQUFNLGlCQUFpQixHQUFHO2dCQUN4QixlQUFlLEVBQUUsSUFBSTtnQkFDckIsTUFBTSxFQUFFLEtBQUs7YUFDZCxDQUFDO1lBRUYsTUFBTSxNQUFNLEdBQUcsdUJBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsR0FBSSxFQUFFLGlCQUFpQixDQUFDLENBQUM7WUFDbEYsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxvREFBb0QsRUFBRSxHQUFHLEVBQUU7WUFDOUQsTUFBTSxVQUFVLEdBQUcseUJBQXlCLENBQUM7WUFDN0MsTUFBTSxXQUFXLEdBQUcsdUJBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMvRCxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV2QyxNQUFNLGlCQUFpQixHQUFHO2dCQUN4QixNQUFNLEVBQUUsS0FBSztnQkFDYiw2QkFBNkI7YUFDOUIsQ0FBQztZQUVGLE1BQU0sTUFBTSxHQUFHLHVCQUFVLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLEdBQUksRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1lBQ2xGLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxvQ0FBb0M7UUFDbEUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyxlQUFlLEVBQUUsR0FBRyxFQUFFO1FBQzdCLE1BQU0sU0FBUyxHQUFHLElBQUksNkJBQWEsRUFBRSxDQUFDO1FBRXRDLElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxHQUFHLEVBQUU7WUFDbEQsTUFBTSxLQUFLLEdBQXdCO2dCQUNqQztvQkFDRSxFQUFFLEVBQUUsT0FBTztvQkFDWCxJQUFJLEVBQUUsUUFBUTtvQkFDZCxVQUFVLEVBQUUseUJBQXlCO29CQUNyQyxNQUFNLEVBQUUsRUFBRTtvQkFDVixtQkFBbUIsRUFBRSxVQUFVO29CQUMvQixTQUFTLEVBQUUsWUFBWTtvQkFDdkIsU0FBUyxFQUFFLFlBQVk7aUJBQ3hCO2dCQUNEO29CQUNFLEVBQUUsRUFBRSxPQUFPO29CQUNYLElBQUksRUFBRSxRQUFRO29CQUNkLFVBQVUsRUFBRSxpQkFBaUI7b0JBQzdCLE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLFVBQVU7b0JBQy9CLFNBQVMsRUFBRSxZQUFZO29CQUN2QixTQUFTLEVBQUUsWUFBWTtpQkFDeEI7YUFDRixDQUFDO1lBRUYsTUFBTSxpQkFBaUIsR0FBRztnQkFDeEIsZUFBZSxFQUFFLElBQUk7Z0JBQ3JCLE1BQU0sRUFBRSxLQUFLO2FBQ2QsQ0FBQztZQUVGLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDakUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMxQyxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0I7WUFDL0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNwRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLHlDQUF5QyxFQUFFLEdBQUcsRUFBRTtZQUNuRCxNQUFNLEtBQUssR0FBd0I7Z0JBQ2pDO29CQUNFLEVBQUUsRUFBRSxPQUFPO29CQUNYLElBQUksRUFBRSxRQUFRO29CQUNkLFVBQVUsRUFBRSwwQkFBMEI7b0JBQ3RDLE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLFVBQVU7b0JBQy9CLFNBQVMsRUFBRSxZQUFZO29CQUN2QixTQUFTLEVBQUUsWUFBWTtpQkFDeEI7YUFDRixDQUFDO1lBRUYsTUFBTSxpQkFBaUIsR0FBRztnQkFDeEIsZUFBZSxFQUFFLElBQUk7YUFDdEIsQ0FBQztZQUVGLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDakUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO1FBQ25GLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDREQUE0RCxFQUFFLEdBQUcsRUFBRTtZQUN0RSxNQUFNLEtBQUssR0FBd0I7Z0JBQ2pDO29CQUNFLEVBQUUsRUFBRSxPQUFPO29CQUNYLElBQUksRUFBRSxRQUFRO29CQUNkLFVBQVUsRUFBRSx5QkFBeUI7b0JBQ3JDLE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLFVBQVU7b0JBQy9CLFNBQVMsRUFBRSxZQUFZO29CQUN2QixTQUFTLEVBQUUsWUFBWTtpQkFDeEI7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLE9BQU87b0JBQ1gsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsVUFBVSxFQUFFLGlCQUFpQjtvQkFDN0IsTUFBTSxFQUFFLEVBQUUsRUFBRSxjQUFjO29CQUMxQixtQkFBbUIsRUFBRSxVQUFVO29CQUMvQixTQUFTLEVBQUUsWUFBWTtvQkFDdkIsU0FBUyxFQUFFLFlBQVk7aUJBQ3hCO2FBQ0YsQ0FBQztZQUVGLE1BQU0saUJBQWlCLEdBQUc7Z0JBQ3hCLGVBQWUsRUFBRSxJQUFJO2dCQUNyQixNQUFNLEVBQUUsS0FBSzthQUNkLENBQUM7WUFFRixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2pFLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDNUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsMEJBQTBCLENBQUMsQ0FBQztZQUMzRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxFQUFFO1FBQ2hDLElBQUksQ0FBQywwQ0FBMEMsRUFBRSxHQUFHLEVBQUU7WUFDcEQsTUFBTSxPQUFPLEdBQXlCO2dCQUNwQyxhQUFhLEVBQUUsc0JBQXNCO2dCQUNyQyxpQkFBaUIsRUFBRTtvQkFDakIsZUFBZSxFQUFFLElBQUk7b0JBQ3JCLE1BQU0sRUFBRSxLQUFLO29CQUNiLEtBQUssRUFBRSxFQUFFO29CQUNULE1BQU0sRUFBRSxPQUFPO2lCQUNoQjthQUNGLENBQUM7WUFFRixNQUFNLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQzNELE1BQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdELE1BQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFZhbGlkYXRpb25VdGlscyB9IGZyb20gJy4uLy4uL3V0aWxzL2RlY2lzaW9uLWVuZ2luZS9WYWxpZGF0aW9uVXRpbHMnO1xyXG5pbXBvcnQgeyBSdWxlUGFyc2VyIH0gZnJvbSAnLi4vLi4vdXRpbHMvZGVjaXNpb24tZW5naW5lL1J1bGVQYXJzZXInO1xyXG5pbXBvcnQgeyBSdWxlRXZhbHVhdG9yIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL1J1bGVFdmFsdWF0b3InO1xyXG5pbXBvcnQgeyBRdWFsaWZpY2F0aW9uUmVxdWVzdCwgQ29udGFjdEF0dHJpYnV0ZXMsIFF1YWxpZmljYXRpb25SdWxlIH0gZnJvbSAnLi4vLi4vdHlwZXMvZGVjaXNpb24tZW5naW5lJztcclxuXHJcbmRlc2NyaWJlKCdEZWNpc2lvbiBFbmdpbmUgU2V0dXAgVGVzdHMnLCAoKSA9PiB7XHJcbiAgXHJcbiAgZGVzY3JpYmUoJ1ZhbGlkYXRpb25VdGlscycsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCB2YWxpZGF0ZSB2YWxpZCBxdWFsaWZpY2F0aW9uIHJlcXVlc3QnLCAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlcXVlc3Q6IFF1YWxpZmljYXRpb25SZXF1ZXN0ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LTEyMycsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IHtcclxuICAgICAgICAgIE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSxcclxuICAgICAgICAgIENsaWVudDogJ1ZJUCcsXHJcbiAgICAgICAgICBTY29yZTogODVcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVRdWFsaWZpY2F0aW9uUmVxdWVzdChyZXF1ZXN0KTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5pc1ZhbGlkKS50b0JlKHRydWUpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IGludmFsaWQgcXVhbGlmaWNhdGlvbiByZXF1ZXN0JywgKCkgPT4ge1xyXG4gICAgICBjb25zdCByZXF1ZXN0ID0ge1xyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7XHJcbiAgICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gTWlzc2luZyBpbnRlcmFjdGlvbklkXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVRdWFsaWZpY2F0aW9uUmVxdWVzdChyZXF1ZXN0KTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5pc1ZhbGlkKS50b0JlKGZhbHNlKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCdpbnRlcmFjdGlvbklkJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgdmFsaWRhdGUgY29udGFjdCBhdHRyaWJ1dGVzJywgKCkgPT4ge1xyXG4gICAgICBjb25zdCBhdHRyaWJ1dGVzOiBDb250YWN0QXR0cmlidXRlcyA9IHtcclxuICAgICAgICBib29sZWFuQXR0cjogdHJ1ZSxcclxuICAgICAgICBzdHJpbmdBdHRyOiAndGVzdCcsXHJcbiAgICAgICAgbnVtYmVyQXR0cjogNDJcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFZhbGlkYXRpb25VdGlscy52YWxpZGF0ZUNvbnRhY3RBdHRyaWJ1dGVzKGF0dHJpYnV0ZXMpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUodHJ1ZSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IGludmFsaWQgY29udGFjdCBhdHRyaWJ1dGUgdHlwZXMnLCAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgdmFsaWRBdHRyOiB0cnVlLFxyXG4gICAgICAgIGludmFsaWRBdHRyOiB7IG5lc3RlZDogJ29iamVjdCcgfSAvLyBJbnZhbGlkIHR5cGVcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFZhbGlkYXRpb25VdGlscy52YWxpZGF0ZUNvbnRhY3RBdHRyaWJ1dGVzKGF0dHJpYnV0ZXMpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0NvbnRhaW4oJ2ludmFsaWQgdHlwZScpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcblxyXG4gIGRlc2NyaWJlKCdSdWxlUGFyc2VyJywgKCkgPT4ge1xyXG4gICAgdGVzdCgnc2hvdWxkIHZhbGlkYXRlIHNpbXBsZSBydWxlIHN5bnRheCcsICgpID0+IHtcclxuICAgICAgY29uc3QgZXhwcmVzc2lvbiA9ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSAmJiBDbGllbnQgPT0gXCJWSVBcIic7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFJ1bGVQYXJzZXIudmFsaWRhdGVSdWxlU3ludGF4KGV4cHJlc3Npb24pO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUodHJ1ZSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IGVtcHR5IHJ1bGUgZXhwcmVzc2lvbicsICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gUnVsZVBhcnNlci52YWxpZGF0ZVJ1bGVTeW50YXgoJycpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0NvbnRhaW4oJ2VtcHR5Jyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgZGV0ZWN0IHN5bnRheCBlcnJvcnMnLCAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGV4cHJlc3Npb24gPSAnKE5vdXZlYXVTaW5pc3RyZSA9PSB0cnVlICYmIENsaWVudCA9PSBWSVAnO1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBSdWxlUGFyc2VyLnZhbGlkYXRlUnVsZVN5bnRheChleHByZXNzaW9uKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5pc1ZhbGlkKS50b0JlKGZhbHNlKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCBwYXJzZSBzaW1wbGUgY29tcGFyaXNvbiBleHByZXNzaW9uJywgKCkgPT4ge1xyXG4gICAgICBjb25zdCBleHByZXNzaW9uID0gJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJztcclxuICAgICAgY29uc3QgcmVzdWx0ID0gUnVsZVBhcnNlci5wYXJzZVJ1bGVFeHByZXNzaW9uKGV4cHJlc3Npb24pO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQudG9rZW5zKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LnRva2VucyEubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuYXN0KS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmFzdCEudHlwZSkudG9CZSgnQ29tcGFyaXNvbkV4cHJlc3Npb24nKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCBwYXJzZSBjb21wbGV4IGJvb2xlYW4gZXhwcmVzc2lvbicsICgpID0+IHtcclxuICAgICAgY29uc3QgZXhwcmVzc2lvbiA9ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSAmJiBDbGllbnQgPT0gXCJWSVBcIic7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFJ1bGVQYXJzZXIucGFyc2VSdWxlRXhwcmVzc2lvbihleHByZXNzaW9uKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5pc1ZhbGlkKS50b0JlKHRydWUpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmFzdCkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5hc3QhLnR5cGUpLnRvQmUoJ0JpbmFyeUV4cHJlc3Npb24nKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCBldmFsdWF0ZSBleHByZXNzaW9uIGFnYWluc3QgY29udGFjdCBhdHRyaWJ1dGVzJywgKCkgPT4ge1xyXG4gICAgICBjb25zdCBleHByZXNzaW9uID0gJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlICYmIENsaWVudCA9PSBcIlZJUFwiJztcclxuICAgICAgY29uc3QgcGFyc2VSZXN1bHQgPSBSdWxlUGFyc2VyLnBhcnNlUnVsZUV4cHJlc3Npb24oZXhwcmVzc2lvbik7XHJcbiAgICAgIGV4cGVjdChwYXJzZVJlc3VsdC5pc1ZhbGlkKS50b0JlKHRydWUpO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgY29udGFjdEF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgTm91dmVhdVNpbmlzdHJlOiB0cnVlLFxyXG4gICAgICAgIENsaWVudDogJ1ZJUCdcclxuICAgICAgfTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFJ1bGVQYXJzZXIuZXZhbHVhdGVFeHByZXNzaW9uKHBhcnNlUmVzdWx0LmFzdCEsIGNvbnRhY3RBdHRyaWJ1dGVzKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdCkudG9CZSh0cnVlKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCBldmFsdWF0ZSBleHByZXNzaW9uIHdpdGggbWlzc2luZyBhdHRyaWJ1dGVzJywgKCkgPT4ge1xyXG4gICAgICBjb25zdCBleHByZXNzaW9uID0gJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJztcclxuICAgICAgY29uc3QgcGFyc2VSZXN1bHQgPSBSdWxlUGFyc2VyLnBhcnNlUnVsZUV4cHJlc3Npb24oZXhwcmVzc2lvbik7XHJcbiAgICAgIGV4cGVjdChwYXJzZVJlc3VsdC5pc1ZhbGlkKS50b0JlKHRydWUpO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgY29udGFjdEF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgQ2xpZW50OiAnVklQJ1xyXG4gICAgICAgIC8vIE5vdXZlYXVTaW5pc3RyZSBpcyBtaXNzaW5nXHJcbiAgICAgIH07XHJcbiAgICAgIFxyXG4gICAgICBjb25zdCByZXN1bHQgPSBSdWxlUGFyc2VyLmV2YWx1YXRlRXhwcmVzc2lvbihwYXJzZVJlc3VsdC5hc3QhLCBjb250YWN0QXR0cmlidXRlcyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQpLnRvQmUoZmFsc2UpOyAvLyB1bmRlZmluZWQgPT0gdHJ1ZSBzaG91bGQgYmUgZmFsc2VcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnUnVsZUV2YWx1YXRvcicsICgpID0+IHtcclxuICAgIGNvbnN0IGV2YWx1YXRvciA9IG5ldyBSdWxlRXZhbHVhdG9yKCk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIHNlbGVjdCBydWxlIHdpdGggaGlnaGVzdCB3ZWlnaHQnLCAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHJ1bGVzOiBRdWFsaWZpY2F0aW9uUnVsZVtdID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiAncnVsZTEnLFxyXG4gICAgICAgICAgbmFtZTogJ1J1bGUgMScsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgICAgICAgd2VpZ2h0OiAxMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50MScsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDEnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ3J1bGUyJyxcclxuICAgICAgICAgIG5hbWU6ICdSdWxlIDInLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ0NsaWVudCA9PSBcIlZJUFwiJyxcclxuICAgICAgICAgIHdlaWdodDogMjAsXHJcbiAgICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnc2VnbWVudDInLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMScsXHJcbiAgICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxJ1xyXG4gICAgICAgIH1cclxuICAgICAgXTtcclxuXHJcbiAgICAgIGNvbnN0IGNvbnRhY3RBdHRyaWJ1dGVzID0ge1xyXG4gICAgICAgIE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSxcclxuICAgICAgICBDbGllbnQ6ICdWSVAnXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBldmFsdWF0b3IuZXZhbHVhdGVSdWxlcyhjb250YWN0QXR0cmlidXRlcywgcnVsZXMpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGUhLmlkKS50b0JlKCdydWxlMicpOyAvLyBIaWdoZXIgd2VpZ2h0XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZGlzdHJpYnV0aW9uU2VnbWVudCkudG9CZSgnc2VnbWVudDInKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIHJldHVybiBlcnJvciB3aGVuIG5vIHJ1bGVzIG1hdGNoJywgKCkgPT4ge1xyXG4gICAgICBjb25zdCBydWxlczogUXVhbGlmaWNhdGlvblJ1bGVbXSA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ3J1bGUxJyxcclxuICAgICAgICAgIG5hbWU6ICdSdWxlIDEnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSBmYWxzZScsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ3NlZ21lbnQxJyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDEnLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMSdcclxuICAgICAgICB9XHJcbiAgICAgIF07XHJcblxyXG4gICAgICBjb25zdCBjb250YWN0QXR0cmlidXRlcyA9IHtcclxuICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IHRydWVcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmUoJ0F1Y3VuZSByw6hnbGUgbmUgY29ycmVzcG9uZCwgdsOpcmlmaWVyIGxlIHBhcmFtw6l0cmFnZScpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIHJldHVybiBlcnJvciB3aGVuIG11bHRpcGxlIHJ1bGVzIGhhdmUgZXF1YWwgd2VpZ2h0cycsICgpID0+IHtcclxuICAgICAgY29uc3QgcnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdydWxlMScsXHJcbiAgICAgICAgICBuYW1lOiAnUnVsZSAxJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZScsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ3NlZ21lbnQxJyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDEnLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiAncnVsZTInLFxyXG4gICAgICAgICAgbmFtZTogJ1J1bGUgMicsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnQ2xpZW50ID09IFwiVklQXCInLFxyXG4gICAgICAgICAgd2VpZ2h0OiAxMCwgLy8gU2FtZSB3ZWlnaHRcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50MicsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDEnXHJcbiAgICAgICAgfVxyXG4gICAgICBdO1xyXG5cclxuICAgICAgY29uc3QgY29udGFjdEF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgTm91dmVhdVNpbmlzdHJlOiB0cnVlLFxyXG4gICAgICAgIENsaWVudDogJ1ZJUCdcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzKGNvbnRhY3RBdHRyaWJ1dGVzLCBydWxlcyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignb250IGRlcyBwb2lkcyBpZGVudGlxdWVzJyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbigncnVsZTEgZXQgcnVsZTInKTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnVHlwZSBEZWZpbml0aW9ucycsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCBjcmVhdGUgdmFsaWQgUXVhbGlmaWNhdGlvblJlcXVlc3QnLCAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlcXVlc3Q6IFF1YWxpZmljYXRpb25SZXF1ZXN0ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LWludGVyYWN0aW9uLTEyMycsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IHtcclxuICAgICAgICAgIE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSxcclxuICAgICAgICAgIENsaWVudDogJ1ZJUCcsXHJcbiAgICAgICAgICBTY29yZTogOTUsXHJcbiAgICAgICAgICBSZWdpb246ICdQYXJpcydcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBleHBlY3QocmVxdWVzdC5pbnRlcmFjdGlvbklkKS50b0JlKCd0ZXN0LWludGVyYWN0aW9uLTEyMycpO1xyXG4gICAgICBleHBlY3QocmVxdWVzdC5jb250YWN0QXR0cmlidXRlcy5Ob3V2ZWF1U2luaXN0cmUpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIGV4cGVjdChyZXF1ZXN0LmNvbnRhY3RBdHRyaWJ1dGVzLkNsaWVudCkudG9CZSgnVklQJyk7XHJcbiAgICAgIGV4cGVjdChyZXF1ZXN0LmNvbnRhY3RBdHRyaWJ1dGVzLlNjb3JlKS50b0JlKDk1KTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59KTsiXX0=
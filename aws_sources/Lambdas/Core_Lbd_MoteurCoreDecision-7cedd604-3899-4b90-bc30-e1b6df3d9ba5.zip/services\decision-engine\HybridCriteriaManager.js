"use strict";
/**
 * Gestionnaire des critères hybrides pour l'architecture GSI + FilterExpression
 *
 * Ce gestionnaire permet de :
 * 1. Configurer facilement les critères primaires (GSI) - EN DUR dans le code
 * 2. Gérer les critères secondaires (FilterExpression) - DYNAMIQUES via Parameter Store
 * 3. Gérer la priorité et l'activation des critères
 *
 * ARCHITECTURE :
 * - Critères PRIMAIRES : restent en dur (nécessitent un redéploiement pour modification)
 * - Critères SECONDAIRES : stockés dans Parameter Store (modification sans redéploiement)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HybridCriteriaManager = void 0;
const CriteriaParameterStore_1 = require("./CriteriaParameterStore");
class HybridCriteriaManager {
    /**
     * Initialise le gestionnaire (DEPRECATED - lazy loading préféré)
     *
     * ⚠️ Cette méthode n'est plus nécessaire avec le lazy loading.
     * Le cache Parameter Store sera chargé automatiquement au premier appel.
     *
     * Avantages du lazy loading :
     * - Pas de délai au cold start si aucun critère secondaire actif
     * - Cache réutilisé entre invocations Lambda warm
     * - Chargement uniquement quand nécessaire
     */
    static async initialize() {
        console.log('ℹ️ HybridCriteriaManager.initialize() called - using lazy loading strategy');
        console.log('ℹ️ Cache will be loaded on first use (0ms if no secondary criteria active)');
        // Ne rien faire - le lazy loading s'occupe de tout
    }
    /**
     * Retourne tous les critères primaires actifs (pour GSI)
     * SYNCHRONE - Les critères primaires sont en dur
     */
    static getActivePrimaryCriteria() {
        return this.PRIMARY_CRITERIA
            .filter(c => c.enabled)
            .sort((a, b) => (a.priority || 0) - (b.priority || 0))
            .map(c => c.name);
    }
    /**
     * Retourne tous les critères secondaires actifs (pour FilterExpression)
     * ASYNCHRONE - Les critères secondaires sont chargés depuis Parameter Store
     *
     * FALLBACK : Si Parameter Store retourne vide, utilise les critères en dur
     */
    static async getActiveSecondaryCriteria() {
        console.log('[HYBRID] Loading secondary criteria from Parameter Store...');
        const secondaryCriteria = await CriteriaParameterStore_1.CriteriaParameterStore.loadAll();
        console.log('[HYBRID] Total criteria loaded:', secondaryCriteria.length);
        // ⚠️ FALLBACK : Si Parameter Store retourne vide, utiliser les critères en dur
        if (secondaryCriteria.length === 0) {
            console.warn('[HYBRID] Parameter Store returned empty - using FALLBACK criteria');
            const fallbackActive = this.SECONDARY_CRITERIA_FALLBACK.filter(c => c.enabled);
            console.log('[HYBRID] Fallback criteria:', fallbackActive.length, 'active out of', this.SECONDARY_CRITERIA_FALLBACK.length);
            fallbackActive.forEach(c => {
                console.log('[HYBRID] Fallback criterion:', c.name, 'enabled:', c.enabled);
            });
            return fallbackActive.map(c => c.name);
        }
        const activeCriteria = secondaryCriteria.filter(c => c.enabled);
        console.log('[HYBRID] Active criteria:', activeCriteria.length);
        activeCriteria.forEach(c => {
            console.log('[HYBRID] Active criterion:', c.name, 'enabled:', c.enabled);
        });
        return activeCriteria.map(c => c.name);
    }
    /**
     * Retourne TOUS les critères actifs (primaires + secondaires)
     * ASYNCHRONE - Combine les critères primaires (en dur) et secondaires (Parameter Store)
     */
    static async getAllActiveCriteria() {
        const primaryNames = this.getActivePrimaryCriteria();
        const secondaryNames = await this.getActiveSecondaryCriteria();
        return [...primaryNames, ...secondaryNames];
    }
    /**
     * Vérifie si un critère est primaire (GSI)
     * SYNCHRONE - Les critères primaires sont en dur
     */
    static isPrimaryCriteria(criteriaName) {
        const criteria = this.PRIMARY_CRITERIA.find(c => c.name === criteriaName);
        return criteria ? criteria.enabled : false;
    }
    /**
     * Vérifie si un critère est secondaire (FilterExpression)
     * ASYNCHRONE - Les critères secondaires sont dans Parameter Store
     */
    static async isSecondaryCriteria(criteriaName) {
        const secondaryCriteria = await CriteriaParameterStore_1.CriteriaParameterStore.loadAll();
        const criteria = secondaryCriteria.find(c => c.name === criteriaName);
        return criteria ? criteria.enabled : false;
    }
    /**
     * Active/désactive un critère SECONDAIRE
     * ASYNCHRONE - Modifie le critère dans Parameter Store
     *
     * Note : Les critères primaires ne peuvent pas être modifiés dynamiquement
     */
    static async toggleSecondaryCriteria(criteriaName, enabled) {
        try {
            // Récupérer le critère existant
            const criteria = await CriteriaParameterStore_1.CriteriaParameterStore.getCriteria(criteriaName);
            if (!criteria) {
                console.warn(`⚠️ Secondary criteria ${criteriaName} not found`);
                return false;
            }
            // Mettre à jour le critère
            criteria.enabled = enabled;
            await CriteriaParameterStore_1.CriteriaParameterStore.putCriteria(criteria);
            console.log(`✅ Secondary criteria ${criteriaName} ${enabled ? 'enabled' : 'disabled'}`);
            return true;
        }
        catch (error) {
            console.error(`❌ Failed to toggle criteria ${criteriaName}:`, error);
            return false;
        }
    }
    /**
     * Ajoute un nouveau critère secondaire
     * ASYNCHRONE - Ajoute le critère dans Parameter Store
     */
    static async addSecondaryCriteria(name, description, businessJustification) {
        try {
            // Vérifier que le critère n'existe pas déjà
            const existing = await CriteriaParameterStore_1.CriteriaParameterStore.getCriteria(name);
            if (existing) {
                console.warn(`⚠️ Secondary criteria ${name} already exists`);
                return false;
            }
            // Créer le nouveau critère
            const newCriteria = {
                name,
                enabled: true,
                description,
                businessJustification,
                addedDate: new Date().toISOString().split('T')[0]
            };
            await CriteriaParameterStore_1.CriteriaParameterStore.putCriteria(newCriteria);
            console.log(`✅ New secondary criteria ${name} added successfully`);
            return true;
        }
        catch (error) {
            console.error(`❌ Failed to add criteria ${name}:`, error);
            return false;
        }
    }
    /**
     * Supprime un critère secondaire
     * ASYNCHRONE - Supprime le critère de Parameter Store
     */
    static async deleteSecondaryCriteria(criteriaName) {
        try {
            await CriteriaParameterStore_1.CriteriaParameterStore.deleteCriteria(criteriaName);
            console.log(`✅ Secondary criteria ${criteriaName} deleted successfully`);
            return true;
        }
        catch (error) {
            console.error(`❌ Failed to delete criteria ${criteriaName}:`, error);
            return false;
        }
    }
    /**
     * Retourne les statistiques des critères
     * ASYNCHRONE - Inclut les critères secondaires depuis Parameter Store
     *
     * FALLBACK : Si Parameter Store retourne vide, utilise les critères en dur
     */
    static async getCriteriaStats() {
        const primaryCriteria = this.PRIMARY_CRITERIA;
        const secondaryCriteria = await CriteriaParameterStore_1.CriteriaParameterStore.loadAll();
        // ⚠️ FALLBACK : Si Parameter Store retourne vide, utiliser les critères en dur
        const criteriaToUse = secondaryCriteria.length > 0
            ? secondaryCriteria
            : this.SECONDARY_CRITERIA_FALLBACK;
        if (secondaryCriteria.length === 0) {
            console.warn('⚠️ Using FALLBACK criteria in getCriteriaStats()');
        }
        const enabledPrimary = primaryCriteria.filter(c => c.enabled);
        const enabledSecondary = criteriaToUse.filter(c => c.enabled);
        // Estimation du coût GSI (5€ par GSI actif)
        const gsiCost = `${enabledPrimary.length * 5}€/mois`;
        // Estimation de performance
        const estimatedPerformance = enabledPrimary.length > 0 ?
            `${85 + Math.min(enabledSecondary.length * 2, 13)}% réduction` :
            `${Math.min(enabledSecondary.length * 5, 60)}% réduction`;
        // Métriques du cache
        const cacheMetrics = CriteriaParameterStore_1.CriteriaParameterStore.getMetrics();
        return {
            totalCriteria: primaryCriteria.length + criteriaToUse.length,
            primaryCount: primaryCriteria.length,
            secondaryCount: criteriaToUse.length,
            enabledPrimary: enabledPrimary.length,
            enabledSecondary: enabledSecondary.length,
            gsiCost,
            estimatedPerformance,
            cacheMetrics
        };
    }
    /**
     * Retourne la configuration complète (primaires + secondaires)
     * ASYNCHRONE - Inclut les critères secondaires depuis Parameter Store
     *
     * FALLBACK : Si Parameter Store retourne vide, utilise les critères en dur
     */
    static async getFullConfiguration() {
        const secondaryCriteria = await CriteriaParameterStore_1.CriteriaParameterStore.loadAll();
        // ⚠️ FALLBACK : Si Parameter Store retourne vide, utiliser les critères en dur
        const criteriaToUse = secondaryCriteria.length > 0
            ? secondaryCriteria
            : this.SECONDARY_CRITERIA_FALLBACK;
        if (secondaryCriteria.length === 0) {
            console.warn('⚠️ Using FALLBACK criteria in getFullConfiguration()');
        }
        // Convertir les critères secondaires au format CriteriaConfig
        const secondaryAsConfig = criteriaToUse.map(c => ({
            name: c.name,
            type: 'secondary',
            enabled: c.enabled,
            description: c.description,
            businessJustification: c.businessJustification,
            addedDate: c.addedDate
        }));
        return [...this.PRIMARY_CRITERIA, ...secondaryAsConfig];
    }
    /**
     * Valide qu'un ensemble d'attributs contient des critères connus
     * ASYNCHRONE - Vérifie contre les critères primaires et secondaires
     */
    static async validateContactAttributes(contactAttributes) {
        const allKnownCriteria = await this.getAllActiveCriteria();
        const attributeKeys = Object.keys(contactAttributes);
        const knownCriteria = attributeKeys.filter(key => allKnownCriteria.includes(key));
        const unknownCriteria = attributeKeys.filter(key => !allKnownCriteria.includes(key));
        // Vérifier les critères primaires (synchrone)
        const primaryCriteriaFound = knownCriteria.filter(key => this.isPrimaryCriteria(key));
        // Vérifier les critères secondaires (asynchrone)
        const secondaryCriteriaChecks = await Promise.all(knownCriteria.map(async (key) => ({
            key,
            isSecondary: await this.isSecondaryCriteria(key)
        })));
        const secondaryCriteriaFound = secondaryCriteriaChecks
            .filter(c => c.isSecondary)
            .map(c => c.key);
        return {
            knownCriteria,
            unknownCriteria,
            primaryCriteriaFound,
            secondaryCriteriaFound
        };
    }
    /**
     * Configure le TTL du cache Parameter Store
     */
    static setCacheTTL(ttl) {
        CriteriaParameterStore_1.CriteriaParameterStore.setCacheTTL(ttl);
    }
    /**
     * Invalide le cache Parameter Store (force un refresh)
     */
    static invalidateCache() {
        CriteriaParameterStore_1.CriteriaParameterStore.invalidateCache();
    }
}
exports.HybridCriteriaManager = HybridCriteriaManager;
// ========== CRITÈRES PRIMAIRES (GSI) - EN DUR ==========
// Ces critères restent dans le code car ils nécessitent des GSI DynamoDB
// Toute modification nécessite un redéploiement de l'infrastructure
HybridCriteriaManager.PRIMARY_CRITERIA = [
    {
        name: 'UC_IntentionDeduite',
        type: 'primary',
        enabled: true,
        priority: 1,
        selectivity: 'high',
        description: 'Intention déduite du numéro appelé (ex: "Gestion Sinistre", "Souscription", "SAV")',
        businessJustification: 'Critère principal de routage basé sur le numéro appelé - très sélectif',
        addedDate: '2024-12-31'
    },
    {
        name: 'UC_IntentionCaptee',
        type: 'primary',
        enabled: true,
        priority: 2,
        selectivity: 'medium',
        description: 'Intention captée par bot/SVI (ex: "AUTO_SOUSC", "HABITAT_SINISTRE", "INFO_CONTRAT")',
        businessJustification: 'Intention précise identifiée par le bot - complément de UC_IntentionDeduite',
        addedDate: '2024-12-31'
    }
];
// ========== CRITÈRES SECONDAIRES FALLBACK ==========
// Ces critères sont utilisés si Parameter Store est indisponible ou retourne vide
// Ils permettent de continuer à fonctionner même en cas de problème avec Parameter Store
HybridCriteriaManager.SECONDARY_CRITERIA_FALLBACK = [
    {
        name: 'TypeClient',
        enabled: false,
        description: 'Type de client (Particulier, Professionnel, Entreprise)',
        businessJustification: 'Routage différencié selon le type de client',
        addedDate: '2025-01-15'
    },
    {
        name: 'RegionClient',
        enabled: false,
        description: 'Région géographique du client',
        businessJustification: 'Routage vers équipes régionales',
        addedDate: '2025-01-15'
    },
    {
        name: 'NiveauUrgence',
        enabled: false,
        description: 'Niveau d\'urgence détecté (Critique, Normale, Faible)',
        businessJustification: 'Priorisation des appels urgents',
        addedDate: '2025-01-15'
    },
    {
        name: 'CanalOrigine',
        enabled: false,
        description: 'Canal d\'origine de l\'appel (Téléphone, Web, Mobile App)',
        businessJustification: 'Routage selon le canal d\'origine',
        addedDate: '2025-01-15'
    },
    {
        name: 'HistoriqueClient',
        enabled: false,
        description: 'Historique client (Nouveau, Récurrent, VIP)',
        businessJustification: 'Traitement différencié selon l\'historique',
        addedDate: '2025-01-15'
    }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSHlicmlkQ3JpdGVyaWFNYW5hZ2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3NlcnZpY2VzL2RlY2lzaW9uLWVuZ2luZS9IeWJyaWRDcml0ZXJpYU1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7Ozs7Ozs7OztHQVdHOzs7QUFFSCxxRUFBMkY7QUF3QjNGLE1BQWEscUJBQXFCO0lBdUVoQzs7Ozs7Ozs7OztPQVVHO0lBQ0gsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVO1FBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEVBQTRFLENBQUMsQ0FBQztRQUMxRixPQUFPLENBQUMsR0FBRyxDQUFDLDRFQUE0RSxDQUFDLENBQUM7UUFDMUYsbURBQW1EO0lBQ3JELENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsd0JBQXdCO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQjthQUN6QixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2FBQ3RCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDckQsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsMEJBQTBCO1FBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkRBQTZELENBQUMsQ0FBQztRQUMzRSxNQUFNLGlCQUFpQixHQUFHLE1BQU0sK0NBQXNCLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDakUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV6RSwrRUFBK0U7UUFDL0UsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbkMsT0FBTyxDQUFDLElBQUksQ0FBQyxtRUFBbUUsQ0FBQyxDQUFDO1lBQ2xGLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDL0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsRUFBRSxjQUFjLENBQUMsTUFBTSxFQUFFLGVBQWUsRUFBRSxJQUFJLENBQUMsMkJBQTJCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDNUgsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDekIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0UsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekMsQ0FBQztRQUVELE1BQU0sY0FBYyxHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNoRSxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixFQUFFLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNoRSxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNFLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQjtRQUMvQixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUNyRCxNQUFNLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1FBRS9ELE9BQU8sQ0FBQyxHQUFHLFlBQVksRUFBRSxHQUFHLGNBQWMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsaUJBQWlCLENBQUMsWUFBb0I7UUFDM0MsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssWUFBWSxDQUFDLENBQUM7UUFDMUUsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztJQUM3QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsTUFBTSxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxZQUFvQjtRQUNuRCxNQUFNLGlCQUFpQixHQUFHLE1BQU0sK0NBQXNCLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDakUsTUFBTSxRQUFRLEdBQUcsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxZQUFZLENBQUMsQ0FBQztRQUN0RSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsdUJBQXVCLENBQUMsWUFBb0IsRUFBRSxPQUFnQjtRQUN6RSxJQUFJLENBQUM7WUFDSCxnQ0FBZ0M7WUFDaEMsTUFBTSxRQUFRLEdBQUcsTUFBTSwrQ0FBc0IsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFeEUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUNkLE9BQU8sQ0FBQyxJQUFJLENBQUMseUJBQXlCLFlBQVksWUFBWSxDQUFDLENBQUM7Z0JBQ2hFLE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQztZQUVELDJCQUEyQjtZQUMzQixRQUFRLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUMzQixNQUFNLCtDQUFzQixDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUVuRCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixZQUFZLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7WUFDeEYsT0FBTyxJQUFJLENBQUM7UUFFZCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLFlBQVksR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUMvQixJQUFZLEVBQ1osV0FBbUIsRUFDbkIscUJBQTZCO1FBRTdCLElBQUksQ0FBQztZQUNILDRDQUE0QztZQUM1QyxNQUFNLFFBQVEsR0FBRyxNQUFNLCtDQUFzQixDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoRSxJQUFJLFFBQVEsRUFBRSxDQUFDO2dCQUNiLE9BQU8sQ0FBQyxJQUFJLENBQUMseUJBQXlCLElBQUksaUJBQWlCLENBQUMsQ0FBQztnQkFDN0QsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDO1lBRUQsMkJBQTJCO1lBQzNCLE1BQU0sV0FBVyxHQUE0QjtnQkFDM0MsSUFBSTtnQkFDSixPQUFPLEVBQUUsSUFBSTtnQkFDYixXQUFXO2dCQUNYLHFCQUFxQjtnQkFDckIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsRCxDQUFDO1lBRUYsTUFBTSwrQ0FBc0IsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFdEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsSUFBSSxxQkFBcUIsQ0FBQyxDQUFDO1lBQ25FLE9BQU8sSUFBSSxDQUFDO1FBRWQsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDRCQUE0QixJQUFJLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMxRCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsTUFBTSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxZQUFvQjtRQUN2RCxJQUFJLENBQUM7WUFDSCxNQUFNLCtDQUFzQixDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUMxRCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixZQUFZLHVCQUF1QixDQUFDLENBQUM7WUFDekUsT0FBTyxJQUFJLENBQUM7UUFFZCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLFlBQVksR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsZ0JBQWdCO1FBQzNCLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sK0NBQXNCLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFakUsK0VBQStFO1FBQy9FLE1BQU0sYUFBYSxHQUFHLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQ2hELENBQUMsQ0FBQyxpQkFBaUI7WUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQztRQUVyQyxJQUFJLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNuQyxPQUFPLENBQUMsSUFBSSxDQUFDLGtEQUFrRCxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUVELE1BQU0sY0FBYyxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUQsTUFBTSxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTlELDRDQUE0QztRQUM1QyxNQUFNLE9BQU8sR0FBRyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFFckQsNEJBQTRCO1FBQzVCLE1BQU0sb0JBQW9CLEdBQUcsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN0RCxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2hFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUM7UUFFNUQscUJBQXFCO1FBQ3JCLE1BQU0sWUFBWSxHQUFHLCtDQUFzQixDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRXpELE9BQU87WUFDTCxhQUFhLEVBQUUsZUFBZSxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsTUFBTTtZQUM1RCxZQUFZLEVBQUUsZUFBZSxDQUFDLE1BQU07WUFDcEMsY0FBYyxFQUFFLGFBQWEsQ0FBQyxNQUFNO1lBQ3BDLGNBQWMsRUFBRSxjQUFjLENBQUMsTUFBTTtZQUNyQyxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxNQUFNO1lBQ3pDLE9BQU87WUFDUCxvQkFBb0I7WUFDcEIsWUFBWTtTQUNiLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQjtRQUMvQixNQUFNLGlCQUFpQixHQUFHLE1BQU0sK0NBQXNCLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFakUsK0VBQStFO1FBQy9FLE1BQU0sYUFBYSxHQUFHLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQ2hELENBQUMsQ0FBQyxpQkFBaUI7WUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQztRQUVyQyxJQUFJLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNuQyxPQUFPLENBQUMsSUFBSSxDQUFDLHNEQUFzRCxDQUFDLENBQUM7UUFDdkUsQ0FBQztRQUVELDhEQUE4RDtRQUM5RCxNQUFNLGlCQUFpQixHQUFxQixhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNsRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7WUFDWixJQUFJLEVBQUUsV0FBb0I7WUFDMUIsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPO1lBQ2xCLFdBQVcsRUFBRSxDQUFDLENBQUMsV0FBVztZQUMxQixxQkFBcUIsRUFBRSxDQUFDLENBQUMscUJBQXFCO1lBQzlDLFNBQVMsRUFBRSxDQUFDLENBQUMsU0FBUztTQUN2QixDQUFDLENBQUMsQ0FBQztRQUVKLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLGlCQUFpQixDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVEOzs7T0FHRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMseUJBQXlCLENBQUMsaUJBQXNDO1FBTTNFLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUMzRCxNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFFckQsTUFBTSxhQUFhLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2xGLE1BQU0sZUFBZSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRXJGLDhDQUE4QztRQUM5QyxNQUFNLG9CQUFvQixHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUV0RixpREFBaUQ7UUFDakQsTUFBTSx1QkFBdUIsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQy9DLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFDLEdBQUcsRUFBQyxFQUFFLENBQUMsQ0FBQztZQUM5QixHQUFHO1lBQ0gsV0FBVyxFQUFFLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQztTQUNqRCxDQUFDLENBQUMsQ0FDSixDQUFDO1FBQ0YsTUFBTSxzQkFBc0IsR0FBRyx1QkFBdUI7YUFDbkQsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQzthQUMxQixHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFbkIsT0FBTztZQUNMLGFBQWE7WUFDYixlQUFlO1lBQ2Ysb0JBQW9CO1lBQ3BCLHNCQUFzQjtTQUN2QixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFXO1FBQzVCLCtDQUFzQixDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxNQUFNLENBQUMsZUFBZTtRQUNwQiwrQ0FBc0IsQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQyxDQUFDOztBQWhYSCxzREFpWEM7QUEvV0MsMERBQTBEO0FBQzFELHlFQUF5RTtBQUN6RSxvRUFBb0U7QUFFNUMsc0NBQWdCLEdBQXFCO0lBQzNEO1FBQ0UsSUFBSSxFQUFFLHFCQUFxQjtRQUMzQixJQUFJLEVBQUUsU0FBUztRQUNmLE9BQU8sRUFBRSxJQUFJO1FBQ2IsUUFBUSxFQUFFLENBQUM7UUFDWCxXQUFXLEVBQUUsTUFBTTtRQUNuQixXQUFXLEVBQUUsb0ZBQW9GO1FBQ2pHLHFCQUFxQixFQUFFLHdFQUF3RTtRQUMvRixTQUFTLEVBQUUsWUFBWTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLG9CQUFvQjtRQUMxQixJQUFJLEVBQUUsU0FBUztRQUNmLE9BQU8sRUFBRSxJQUFJO1FBQ2IsUUFBUSxFQUFFLENBQUM7UUFDWCxXQUFXLEVBQUUsUUFBUTtRQUNyQixXQUFXLEVBQUUscUZBQXFGO1FBQ2xHLHFCQUFxQixFQUFFLDZFQUE2RTtRQUNwRyxTQUFTLEVBQUUsWUFBWTtLQUN4QjtDQUNGLENBQUM7QUFFRixzREFBc0Q7QUFDdEQsa0ZBQWtGO0FBQ2xGLHlGQUF5RjtBQUVqRSxpREFBMkIsR0FBOEI7SUFDL0U7UUFDRSxJQUFJLEVBQUUsWUFBWTtRQUNsQixPQUFPLEVBQUUsS0FBSztRQUNkLFdBQVcsRUFBRSx5REFBeUQ7UUFDdEUscUJBQXFCLEVBQUUsNkNBQTZDO1FBQ3BFLFNBQVMsRUFBRSxZQUFZO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsY0FBYztRQUNwQixPQUFPLEVBQUUsS0FBSztRQUNkLFdBQVcsRUFBRSwrQkFBK0I7UUFDNUMscUJBQXFCLEVBQUUsaUNBQWlDO1FBQ3hELFNBQVMsRUFBRSxZQUFZO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsZUFBZTtRQUNyQixPQUFPLEVBQUUsS0FBSztRQUNkLFdBQVcsRUFBRSx1REFBdUQ7UUFDcEUscUJBQXFCLEVBQUUsaUNBQWlDO1FBQ3hELFNBQVMsRUFBRSxZQUFZO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsY0FBYztRQUNwQixPQUFPLEVBQUUsS0FBSztRQUNkLFdBQVcsRUFBRSwyREFBMkQ7UUFDeEUscUJBQXFCLEVBQUUsbUNBQW1DO1FBQzFELFNBQVMsRUFBRSxZQUFZO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsa0JBQWtCO1FBQ3hCLE9BQU8sRUFBRSxLQUFLO1FBQ2QsV0FBVyxFQUFFLDZDQUE2QztRQUMxRCxxQkFBcUIsRUFBRSw0Q0FBNEM7UUFDbkUsU0FBUyxFQUFFLFlBQVk7S0FDeEI7Q0FDRixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEdlc3Rpb25uYWlyZSBkZXMgY3JpdMOocmVzIGh5YnJpZGVzIHBvdXIgbCdhcmNoaXRlY3R1cmUgR1NJICsgRmlsdGVyRXhwcmVzc2lvblxyXG4gKiBcclxuICogQ2UgZ2VzdGlvbm5haXJlIHBlcm1ldCBkZSA6XHJcbiAqIDEuIENvbmZpZ3VyZXIgZmFjaWxlbWVudCBsZXMgY3JpdMOocmVzIHByaW1haXJlcyAoR1NJKSAtIEVOIERVUiBkYW5zIGxlIGNvZGVcclxuICogMi4gR8OpcmVyIGxlcyBjcml0w6hyZXMgc2Vjb25kYWlyZXMgKEZpbHRlckV4cHJlc3Npb24pIC0gRFlOQU1JUVVFUyB2aWEgUGFyYW1ldGVyIFN0b3JlXHJcbiAqIDMuIEfDqXJlciBsYSBwcmlvcml0w6kgZXQgbCdhY3RpdmF0aW9uIGRlcyBjcml0w6hyZXNcclxuICogXHJcbiAqIEFSQ0hJVEVDVFVSRSA6XHJcbiAqIC0gQ3JpdMOocmVzIFBSSU1BSVJFUyA6IHJlc3RlbnQgZW4gZHVyIChuw6ljZXNzaXRlbnQgdW4gcmVkw6lwbG9pZW1lbnQgcG91ciBtb2RpZmljYXRpb24pXHJcbiAqIC0gQ3JpdMOocmVzIFNFQ09OREFJUkVTIDogc3RvY2vDqXMgZGFucyBQYXJhbWV0ZXIgU3RvcmUgKG1vZGlmaWNhdGlvbiBzYW5zIHJlZMOpcGxvaWVtZW50KVxyXG4gKi9cclxuXHJcbmltcG9ydCB7IENyaXRlcmlhUGFyYW1ldGVyU3RvcmUsIFNlY29uZGFyeUNyaXRlcmlhQ29uZmlnIH0gZnJvbSAnLi9Dcml0ZXJpYVBhcmFtZXRlclN0b3JlJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ3JpdGVyaWFDb25maWcge1xyXG4gIG5hbWU6IHN0cmluZztcclxuICB0eXBlOiAncHJpbWFyeScgfCAnc2Vjb25kYXJ5JztcclxuICBlbmFibGVkOiBib29sZWFuO1xyXG4gIHByaW9yaXR5PzogbnVtYmVyOyAgICAgICAgICAgLy8gUG91ciBsZXMgY3JpdMOocmVzIHByaW1haXJlcyB1bmlxdWVtZW50XHJcbiAgc2VsZWN0aXZpdHk/OiAnaGlnaCcgfCAnbWVkaXVtJyB8ICdsb3cnOyAgLy8gUG91ciBsZXMgY3JpdMOocmVzIHByaW1haXJlc1xyXG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xyXG4gIGJ1c2luZXNzSnVzdGlmaWNhdGlvbj86IHN0cmluZztcclxuICBhZGRlZERhdGU/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ3JpdGVyaWFTdGF0cyB7XHJcbiAgdG90YWxDcml0ZXJpYTogbnVtYmVyO1xyXG4gIHByaW1hcnlDb3VudDogbnVtYmVyO1xyXG4gIHNlY29uZGFyeUNvdW50OiBudW1iZXI7XHJcbiAgZW5hYmxlZFByaW1hcnk6IG51bWJlcjtcclxuICBlbmFibGVkU2Vjb25kYXJ5OiBudW1iZXI7XHJcbiAgZ3NpQ29zdDogc3RyaW5nO1xyXG4gIGVzdGltYXRlZFBlcmZvcm1hbmNlOiBzdHJpbmc7XHJcbiAgY2FjaGVNZXRyaWNzPzogYW55O1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgSHlicmlkQ3JpdGVyaWFNYW5hZ2VyIHtcclxuICBcclxuICAvLyA9PT09PT09PT09IENSSVTDiFJFUyBQUklNQUlSRVMgKEdTSSkgLSBFTiBEVVIgPT09PT09PT09PVxyXG4gIC8vIENlcyBjcml0w6hyZXMgcmVzdGVudCBkYW5zIGxlIGNvZGUgY2FyIGlscyBuw6ljZXNzaXRlbnQgZGVzIEdTSSBEeW5hbW9EQlxyXG4gIC8vIFRvdXRlIG1vZGlmaWNhdGlvbiBuw6ljZXNzaXRlIHVuIHJlZMOpcGxvaWVtZW50IGRlIGwnaW5mcmFzdHJ1Y3R1cmVcclxuICBcclxuICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBQUklNQVJZX0NSSVRFUklBOiBDcml0ZXJpYUNvbmZpZ1tdID0gW1xyXG4gICAge1xyXG4gICAgICBuYW1lOiAnVUNfSW50ZW50aW9uRGVkdWl0ZScsXHJcbiAgICAgIHR5cGU6ICdwcmltYXJ5JyxcclxuICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgcHJpb3JpdHk6IDEsXHJcbiAgICAgIHNlbGVjdGl2aXR5OiAnaGlnaCcsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnSW50ZW50aW9uIGTDqWR1aXRlIGR1IG51bcOpcm8gYXBwZWzDqSAoZXg6IFwiR2VzdGlvbiBTaW5pc3RyZVwiLCBcIlNvdXNjcmlwdGlvblwiLCBcIlNBVlwiKScsXHJcbiAgICAgIGJ1c2luZXNzSnVzdGlmaWNhdGlvbjogJ0NyaXTDqHJlIHByaW5jaXBhbCBkZSByb3V0YWdlIGJhc8OpIHN1ciBsZSBudW3DqXJvIGFwcGVsw6kgLSB0csOocyBzw6lsZWN0aWYnLFxyXG4gICAgICBhZGRlZERhdGU6ICcyMDI0LTEyLTMxJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbmFtZTogJ1VDX0ludGVudGlvbkNhcHRlZScsXHJcbiAgICAgIHR5cGU6ICdwcmltYXJ5JyxcclxuICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgcHJpb3JpdHk6IDIsXHJcbiAgICAgIHNlbGVjdGl2aXR5OiAnbWVkaXVtJyxcclxuICAgICAgZGVzY3JpcHRpb246ICdJbnRlbnRpb24gY2FwdMOpZSBwYXIgYm90L1NWSSAoZXg6IFwiQVVUT19TT1VTQ1wiLCBcIkhBQklUQVRfU0lOSVNUUkVcIiwgXCJJTkZPX0NPTlRSQVRcIiknLFxyXG4gICAgICBidXNpbmVzc0p1c3RpZmljYXRpb246ICdJbnRlbnRpb24gcHLDqWNpc2UgaWRlbnRpZmnDqWUgcGFyIGxlIGJvdCAtIGNvbXBsw6ltZW50IGRlIFVDX0ludGVudGlvbkRlZHVpdGUnLFxyXG4gICAgICBhZGRlZERhdGU6ICcyMDI0LTEyLTMxJ1xyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIC8vID09PT09PT09PT0gQ1JJVMOIUkVTIFNFQ09OREFJUkVTIEZBTExCQUNLID09PT09PT09PT1cclxuICAvLyBDZXMgY3JpdMOocmVzIHNvbnQgdXRpbGlzw6lzIHNpIFBhcmFtZXRlciBTdG9yZSBlc3QgaW5kaXNwb25pYmxlIG91IHJldG91cm5lIHZpZGVcclxuICAvLyBJbHMgcGVybWV0dGVudCBkZSBjb250aW51ZXIgw6AgZm9uY3Rpb25uZXIgbcOqbWUgZW4gY2FzIGRlIHByb2Jsw6htZSBhdmVjIFBhcmFtZXRlciBTdG9yZVxyXG4gIFxyXG4gIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IFNFQ09OREFSWV9DUklURVJJQV9GQUxMQkFDSzogU2Vjb25kYXJ5Q3JpdGVyaWFDb25maWdbXSA9IFtcclxuICAgIHtcclxuICAgICAgbmFtZTogJ1R5cGVDbGllbnQnLFxyXG4gICAgICBlbmFibGVkOiBmYWxzZSxcclxuICAgICAgZGVzY3JpcHRpb246ICdUeXBlIGRlIGNsaWVudCAoUGFydGljdWxpZXIsIFByb2Zlc3Npb25uZWwsIEVudHJlcHJpc2UpJyxcclxuICAgICAgYnVzaW5lc3NKdXN0aWZpY2F0aW9uOiAnUm91dGFnZSBkaWZmw6lyZW5jacOpIHNlbG9uIGxlIHR5cGUgZGUgY2xpZW50JyxcclxuICAgICAgYWRkZWREYXRlOiAnMjAyNS0wMS0xNSdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6ICdSZWdpb25DbGllbnQnLFxyXG4gICAgICBlbmFibGVkOiBmYWxzZSxcclxuICAgICAgZGVzY3JpcHRpb246ICdSw6lnaW9uIGfDqW9ncmFwaGlxdWUgZHUgY2xpZW50JyxcclxuICAgICAgYnVzaW5lc3NKdXN0aWZpY2F0aW9uOiAnUm91dGFnZSB2ZXJzIMOpcXVpcGVzIHLDqWdpb25hbGVzJyxcclxuICAgICAgYWRkZWREYXRlOiAnMjAyNS0wMS0xNSdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6ICdOaXZlYXVVcmdlbmNlJyxcclxuICAgICAgZW5hYmxlZDogZmFsc2UsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnTml2ZWF1IGRcXCd1cmdlbmNlIGTDqXRlY3TDqSAoQ3JpdGlxdWUsIE5vcm1hbGUsIEZhaWJsZSknLFxyXG4gICAgICBidXNpbmVzc0p1c3RpZmljYXRpb246ICdQcmlvcmlzYXRpb24gZGVzIGFwcGVscyB1cmdlbnRzJyxcclxuICAgICAgYWRkZWREYXRlOiAnMjAyNS0wMS0xNSdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6ICdDYW5hbE9yaWdpbmUnLFxyXG4gICAgICBlbmFibGVkOiBmYWxzZSxcclxuICAgICAgZGVzY3JpcHRpb246ICdDYW5hbCBkXFwnb3JpZ2luZSBkZSBsXFwnYXBwZWwgKFTDqWzDqXBob25lLCBXZWIsIE1vYmlsZSBBcHApJyxcclxuICAgICAgYnVzaW5lc3NKdXN0aWZpY2F0aW9uOiAnUm91dGFnZSBzZWxvbiBsZSBjYW5hbCBkXFwnb3JpZ2luZScsXHJcbiAgICAgIGFkZGVkRGF0ZTogJzIwMjUtMDEtMTUnXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBuYW1lOiAnSGlzdG9yaXF1ZUNsaWVudCcsXHJcbiAgICAgIGVuYWJsZWQ6IGZhbHNlLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJ0hpc3RvcmlxdWUgY2xpZW50IChOb3V2ZWF1LCBSw6ljdXJyZW50LCBWSVApJyxcclxuICAgICAgYnVzaW5lc3NKdXN0aWZpY2F0aW9uOiAnVHJhaXRlbWVudCBkaWZmw6lyZW5jacOpIHNlbG9uIGxcXCdoaXN0b3JpcXVlJyxcclxuICAgICAgYWRkZWREYXRlOiAnMjAyNS0wMS0xNSdcclxuICAgIH1cclxuICBdO1xyXG5cclxuICAvKipcclxuICAgKiBJbml0aWFsaXNlIGxlIGdlc3Rpb25uYWlyZSAoREVQUkVDQVRFRCAtIGxhenkgbG9hZGluZyBwcsOpZsOpcsOpKVxyXG4gICAqIFxyXG4gICAqIOKaoO+4jyBDZXR0ZSBtw6l0aG9kZSBuJ2VzdCBwbHVzIG7DqWNlc3NhaXJlIGF2ZWMgbGUgbGF6eSBsb2FkaW5nLlxyXG4gICAqIExlIGNhY2hlIFBhcmFtZXRlciBTdG9yZSBzZXJhIGNoYXJnw6kgYXV0b21hdGlxdWVtZW50IGF1IHByZW1pZXIgYXBwZWwuXHJcbiAgICogXHJcbiAgICogQXZhbnRhZ2VzIGR1IGxhenkgbG9hZGluZyA6XHJcbiAgICogLSBQYXMgZGUgZMOpbGFpIGF1IGNvbGQgc3RhcnQgc2kgYXVjdW4gY3JpdMOocmUgc2Vjb25kYWlyZSBhY3RpZlxyXG4gICAqIC0gQ2FjaGUgcsOpdXRpbGlzw6kgZW50cmUgaW52b2NhdGlvbnMgTGFtYmRhIHdhcm1cclxuICAgKiAtIENoYXJnZW1lbnQgdW5pcXVlbWVudCBxdWFuZCBuw6ljZXNzYWlyZVxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBpbml0aWFsaXplKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgY29uc29sZS5sb2coJ+KEue+4jyBIeWJyaWRDcml0ZXJpYU1hbmFnZXIuaW5pdGlhbGl6ZSgpIGNhbGxlZCAtIHVzaW5nIGxhenkgbG9hZGluZyBzdHJhdGVneScpO1xyXG4gICAgY29uc29sZS5sb2coJ+KEue+4jyBDYWNoZSB3aWxsIGJlIGxvYWRlZCBvbiBmaXJzdCB1c2UgKDBtcyBpZiBubyBzZWNvbmRhcnkgY3JpdGVyaWEgYWN0aXZlKScpO1xyXG4gICAgLy8gTmUgcmllbiBmYWlyZSAtIGxlIGxhenkgbG9hZGluZyBzJ29jY3VwZSBkZSB0b3V0XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXRvdXJuZSB0b3VzIGxlcyBjcml0w6hyZXMgcHJpbWFpcmVzIGFjdGlmcyAocG91ciBHU0kpXHJcbiAgICogU1lOQ0hST05FIC0gTGVzIGNyaXTDqHJlcyBwcmltYWlyZXMgc29udCBlbiBkdXJcclxuICAgKi9cclxuICBzdGF0aWMgZ2V0QWN0aXZlUHJpbWFyeUNyaXRlcmlhKCk6IHN0cmluZ1tdIHtcclxuICAgIHJldHVybiB0aGlzLlBSSU1BUllfQ1JJVEVSSUFcclxuICAgICAgLmZpbHRlcihjID0+IGMuZW5hYmxlZClcclxuICAgICAgLnNvcnQoKGEsIGIpID0+IChhLnByaW9yaXR5IHx8IDApIC0gKGIucHJpb3JpdHkgfHwgMCkpXHJcbiAgICAgIC5tYXAoYyA9PiBjLm5hbWUpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0b3VybmUgdG91cyBsZXMgY3JpdMOocmVzIHNlY29uZGFpcmVzIGFjdGlmcyAocG91ciBGaWx0ZXJFeHByZXNzaW9uKVxyXG4gICAqIEFTWU5DSFJPTkUgLSBMZXMgY3JpdMOocmVzIHNlY29uZGFpcmVzIHNvbnQgY2hhcmfDqXMgZGVwdWlzIFBhcmFtZXRlciBTdG9yZVxyXG4gICAqIFxyXG4gICAqIEZBTExCQUNLIDogU2kgUGFyYW1ldGVyIFN0b3JlIHJldG91cm5lIHZpZGUsIHV0aWxpc2UgbGVzIGNyaXTDqHJlcyBlbiBkdXJcclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgZ2V0QWN0aXZlU2Vjb25kYXJ5Q3JpdGVyaWEoKTogUHJvbWlzZTxzdHJpbmdbXT4ge1xyXG4gICAgY29uc29sZS5sb2coJ1tIWUJSSURdIExvYWRpbmcgc2Vjb25kYXJ5IGNyaXRlcmlhIGZyb20gUGFyYW1ldGVyIFN0b3JlLi4uJyk7XHJcbiAgICBjb25zdCBzZWNvbmRhcnlDcml0ZXJpYSA9IGF3YWl0IENyaXRlcmlhUGFyYW1ldGVyU3RvcmUubG9hZEFsbCgpO1xyXG4gICAgY29uc29sZS5sb2coJ1tIWUJSSURdIFRvdGFsIGNyaXRlcmlhIGxvYWRlZDonLCBzZWNvbmRhcnlDcml0ZXJpYS5sZW5ndGgpO1xyXG4gICAgXHJcbiAgICAvLyDimqDvuI8gRkFMTEJBQ0sgOiBTaSBQYXJhbWV0ZXIgU3RvcmUgcmV0b3VybmUgdmlkZSwgdXRpbGlzZXIgbGVzIGNyaXTDqHJlcyBlbiBkdXJcclxuICAgIGlmIChzZWNvbmRhcnlDcml0ZXJpYS5sZW5ndGggPT09IDApIHtcclxuICAgICAgY29uc29sZS53YXJuKCdbSFlCUklEXSBQYXJhbWV0ZXIgU3RvcmUgcmV0dXJuZWQgZW1wdHkgLSB1c2luZyBGQUxMQkFDSyBjcml0ZXJpYScpO1xyXG4gICAgICBjb25zdCBmYWxsYmFja0FjdGl2ZSA9IHRoaXMuU0VDT05EQVJZX0NSSVRFUklBX0ZBTExCQUNLLmZpbHRlcihjID0+IGMuZW5hYmxlZCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdbSFlCUklEXSBGYWxsYmFjayBjcml0ZXJpYTonLCBmYWxsYmFja0FjdGl2ZS5sZW5ndGgsICdhY3RpdmUgb3V0IG9mJywgdGhpcy5TRUNPTkRBUllfQ1JJVEVSSUFfRkFMTEJBQ0subGVuZ3RoKTtcclxuICAgICAgZmFsbGJhY2tBY3RpdmUuZm9yRWFjaChjID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZygnW0hZQlJJRF0gRmFsbGJhY2sgY3JpdGVyaW9uOicsIGMubmFtZSwgJ2VuYWJsZWQ6JywgYy5lbmFibGVkKTtcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiBmYWxsYmFja0FjdGl2ZS5tYXAoYyA9PiBjLm5hbWUpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBjb25zdCBhY3RpdmVDcml0ZXJpYSA9IHNlY29uZGFyeUNyaXRlcmlhLmZpbHRlcihjID0+IGMuZW5hYmxlZCk7XHJcbiAgICBjb25zb2xlLmxvZygnW0hZQlJJRF0gQWN0aXZlIGNyaXRlcmlhOicsIGFjdGl2ZUNyaXRlcmlhLmxlbmd0aCk7XHJcbiAgICBhY3RpdmVDcml0ZXJpYS5mb3JFYWNoKGMgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygnW0hZQlJJRF0gQWN0aXZlIGNyaXRlcmlvbjonLCBjLm5hbWUsICdlbmFibGVkOicsIGMuZW5hYmxlZCk7XHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgcmV0dXJuIGFjdGl2ZUNyaXRlcmlhLm1hcChjID0+IGMubmFtZSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXRvdXJuZSBUT1VTIGxlcyBjcml0w6hyZXMgYWN0aWZzIChwcmltYWlyZXMgKyBzZWNvbmRhaXJlcylcclxuICAgKiBBU1lOQ0hST05FIC0gQ29tYmluZSBsZXMgY3JpdMOocmVzIHByaW1haXJlcyAoZW4gZHVyKSBldCBzZWNvbmRhaXJlcyAoUGFyYW1ldGVyIFN0b3JlKVxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBnZXRBbGxBY3RpdmVDcml0ZXJpYSgpOiBQcm9taXNlPHN0cmluZ1tdPiB7XHJcbiAgICBjb25zdCBwcmltYXJ5TmFtZXMgPSB0aGlzLmdldEFjdGl2ZVByaW1hcnlDcml0ZXJpYSgpO1xyXG4gICAgY29uc3Qgc2Vjb25kYXJ5TmFtZXMgPSBhd2FpdCB0aGlzLmdldEFjdGl2ZVNlY29uZGFyeUNyaXRlcmlhKCk7XHJcbiAgICBcclxuICAgIHJldHVybiBbLi4ucHJpbWFyeU5hbWVzLCAuLi5zZWNvbmRhcnlOYW1lc107XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBWw6lyaWZpZSBzaSB1biBjcml0w6hyZSBlc3QgcHJpbWFpcmUgKEdTSSlcclxuICAgKiBTWU5DSFJPTkUgLSBMZXMgY3JpdMOocmVzIHByaW1haXJlcyBzb250IGVuIGR1clxyXG4gICAqL1xyXG4gIHN0YXRpYyBpc1ByaW1hcnlDcml0ZXJpYShjcml0ZXJpYU5hbWU6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgY29uc3QgY3JpdGVyaWEgPSB0aGlzLlBSSU1BUllfQ1JJVEVSSUEuZmluZChjID0+IGMubmFtZSA9PT0gY3JpdGVyaWFOYW1lKTtcclxuICAgIHJldHVybiBjcml0ZXJpYSA/IGNyaXRlcmlhLmVuYWJsZWQgOiBmYWxzZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFbDqXJpZmllIHNpIHVuIGNyaXTDqHJlIGVzdCBzZWNvbmRhaXJlIChGaWx0ZXJFeHByZXNzaW9uKVxyXG4gICAqIEFTWU5DSFJPTkUgLSBMZXMgY3JpdMOocmVzIHNlY29uZGFpcmVzIHNvbnQgZGFucyBQYXJhbWV0ZXIgU3RvcmVcclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgaXNTZWNvbmRhcnlDcml0ZXJpYShjcml0ZXJpYU5hbWU6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gICAgY29uc3Qgc2Vjb25kYXJ5Q3JpdGVyaWEgPSBhd2FpdCBDcml0ZXJpYVBhcmFtZXRlclN0b3JlLmxvYWRBbGwoKTtcclxuICAgIGNvbnN0IGNyaXRlcmlhID0gc2Vjb25kYXJ5Q3JpdGVyaWEuZmluZChjID0+IGMubmFtZSA9PT0gY3JpdGVyaWFOYW1lKTtcclxuICAgIHJldHVybiBjcml0ZXJpYSA/IGNyaXRlcmlhLmVuYWJsZWQgOiBmYWxzZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEFjdGl2ZS9kw6lzYWN0aXZlIHVuIGNyaXTDqHJlIFNFQ09OREFJUkVcclxuICAgKiBBU1lOQ0hST05FIC0gTW9kaWZpZSBsZSBjcml0w6hyZSBkYW5zIFBhcmFtZXRlciBTdG9yZVxyXG4gICAqIFxyXG4gICAqIE5vdGUgOiBMZXMgY3JpdMOocmVzIHByaW1haXJlcyBuZSBwZXV2ZW50IHBhcyDDqnRyZSBtb2RpZmnDqXMgZHluYW1pcXVlbWVudFxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyB0b2dnbGVTZWNvbmRhcnlDcml0ZXJpYShjcml0ZXJpYU5hbWU6IHN0cmluZywgZW5hYmxlZDogYm9vbGVhbik6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gUsOpY3Vww6lyZXIgbGUgY3JpdMOocmUgZXhpc3RhbnRcclxuICAgICAgY29uc3QgY3JpdGVyaWEgPSBhd2FpdCBDcml0ZXJpYVBhcmFtZXRlclN0b3JlLmdldENyaXRlcmlhKGNyaXRlcmlhTmFtZSk7XHJcbiAgICAgIFxyXG4gICAgICBpZiAoIWNyaXRlcmlhKSB7XHJcbiAgICAgICAgY29uc29sZS53YXJuKGDimqDvuI8gU2Vjb25kYXJ5IGNyaXRlcmlhICR7Y3JpdGVyaWFOYW1lfSBub3QgZm91bmRgKTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIE1ldHRyZSDDoCBqb3VyIGxlIGNyaXTDqHJlXHJcbiAgICAgIGNyaXRlcmlhLmVuYWJsZWQgPSBlbmFibGVkO1xyXG4gICAgICBhd2FpdCBDcml0ZXJpYVBhcmFtZXRlclN0b3JlLnB1dENyaXRlcmlhKGNyaXRlcmlhKTtcclxuICAgICAgXHJcbiAgICAgIGNvbnNvbGUubG9nKGDinIUgU2Vjb25kYXJ5IGNyaXRlcmlhICR7Y3JpdGVyaWFOYW1lfSAke2VuYWJsZWQgPyAnZW5hYmxlZCcgOiAnZGlzYWJsZWQnfWApO1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGDinYwgRmFpbGVkIHRvIHRvZ2dsZSBjcml0ZXJpYSAke2NyaXRlcmlhTmFtZX06YCwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBam91dGUgdW4gbm91dmVhdSBjcml0w6hyZSBzZWNvbmRhaXJlXHJcbiAgICogQVNZTkNIUk9ORSAtIEFqb3V0ZSBsZSBjcml0w6hyZSBkYW5zIFBhcmFtZXRlciBTdG9yZVxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBhZGRTZWNvbmRhcnlDcml0ZXJpYShcclxuICAgIG5hbWU6IHN0cmluZywgXHJcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nLCBcclxuICAgIGJ1c2luZXNzSnVzdGlmaWNhdGlvbjogc3RyaW5nXHJcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBWw6lyaWZpZXIgcXVlIGxlIGNyaXTDqHJlIG4nZXhpc3RlIHBhcyBkw6lqw6BcclxuICAgICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDcml0ZXJpYVBhcmFtZXRlclN0b3JlLmdldENyaXRlcmlhKG5hbWUpO1xyXG4gICAgICBpZiAoZXhpc3RpbmcpIHtcclxuICAgICAgICBjb25zb2xlLndhcm4oYOKaoO+4jyBTZWNvbmRhcnkgY3JpdGVyaWEgJHtuYW1lfSBhbHJlYWR5IGV4aXN0c2ApO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gQ3LDqWVyIGxlIG5vdXZlYXUgY3JpdMOocmVcclxuICAgICAgY29uc3QgbmV3Q3JpdGVyaWE6IFNlY29uZGFyeUNyaXRlcmlhQ29uZmlnID0ge1xyXG4gICAgICAgIG5hbWUsXHJcbiAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICBkZXNjcmlwdGlvbixcclxuICAgICAgICBidXNpbmVzc0p1c3RpZmljYXRpb24sXHJcbiAgICAgICAgYWRkZWREYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXVxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXdhaXQgQ3JpdGVyaWFQYXJhbWV0ZXJTdG9yZS5wdXRDcml0ZXJpYShuZXdDcml0ZXJpYSk7XHJcbiAgICAgIFxyXG4gICAgICBjb25zb2xlLmxvZyhg4pyFIE5ldyBzZWNvbmRhcnkgY3JpdGVyaWEgJHtuYW1lfSBhZGRlZCBzdWNjZXNzZnVsbHlgKTtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgIFxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihg4p2MIEZhaWxlZCB0byBhZGQgY3JpdGVyaWEgJHtuYW1lfTpgLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFN1cHByaW1lIHVuIGNyaXTDqHJlIHNlY29uZGFpcmVcclxuICAgKiBBU1lOQ0hST05FIC0gU3VwcHJpbWUgbGUgY3JpdMOocmUgZGUgUGFyYW1ldGVyIFN0b3JlXHJcbiAgICovXHJcbiAgc3RhdGljIGFzeW5jIGRlbGV0ZVNlY29uZGFyeUNyaXRlcmlhKGNyaXRlcmlhTmFtZTogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBDcml0ZXJpYVBhcmFtZXRlclN0b3JlLmRlbGV0ZUNyaXRlcmlhKGNyaXRlcmlhTmFtZSk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGDinIUgU2Vjb25kYXJ5IGNyaXRlcmlhICR7Y3JpdGVyaWFOYW1lfSBkZWxldGVkIHN1Y2Nlc3NmdWxseWApO1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGDinYwgRmFpbGVkIHRvIGRlbGV0ZSBjcml0ZXJpYSAke2NyaXRlcmlhTmFtZX06YCwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXRvdXJuZSBsZXMgc3RhdGlzdGlxdWVzIGRlcyBjcml0w6hyZXNcclxuICAgKiBBU1lOQ0hST05FIC0gSW5jbHV0IGxlcyBjcml0w6hyZXMgc2Vjb25kYWlyZXMgZGVwdWlzIFBhcmFtZXRlciBTdG9yZVxyXG4gICAqIFxyXG4gICAqIEZBTExCQUNLIDogU2kgUGFyYW1ldGVyIFN0b3JlIHJldG91cm5lIHZpZGUsIHV0aWxpc2UgbGVzIGNyaXTDqHJlcyBlbiBkdXJcclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgZ2V0Q3JpdGVyaWFTdGF0cygpOiBQcm9taXNlPENyaXRlcmlhU3RhdHM+IHtcclxuICAgIGNvbnN0IHByaW1hcnlDcml0ZXJpYSA9IHRoaXMuUFJJTUFSWV9DUklURVJJQTtcclxuICAgIGNvbnN0IHNlY29uZGFyeUNyaXRlcmlhID0gYXdhaXQgQ3JpdGVyaWFQYXJhbWV0ZXJTdG9yZS5sb2FkQWxsKCk7XHJcbiAgICBcclxuICAgIC8vIOKaoO+4jyBGQUxMQkFDSyA6IFNpIFBhcmFtZXRlciBTdG9yZSByZXRvdXJuZSB2aWRlLCB1dGlsaXNlciBsZXMgY3JpdMOocmVzIGVuIGR1clxyXG4gICAgY29uc3QgY3JpdGVyaWFUb1VzZSA9IHNlY29uZGFyeUNyaXRlcmlhLmxlbmd0aCA+IDAgXHJcbiAgICAgID8gc2Vjb25kYXJ5Q3JpdGVyaWEgXHJcbiAgICAgIDogdGhpcy5TRUNPTkRBUllfQ1JJVEVSSUFfRkFMTEJBQ0s7XHJcbiAgICBcclxuICAgIGlmIChzZWNvbmRhcnlDcml0ZXJpYS5sZW5ndGggPT09IDApIHtcclxuICAgICAgY29uc29sZS53YXJuKCfimqDvuI8gVXNpbmcgRkFMTEJBQ0sgY3JpdGVyaWEgaW4gZ2V0Q3JpdGVyaWFTdGF0cygpJyk7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGNvbnN0IGVuYWJsZWRQcmltYXJ5ID0gcHJpbWFyeUNyaXRlcmlhLmZpbHRlcihjID0+IGMuZW5hYmxlZCk7XHJcbiAgICBjb25zdCBlbmFibGVkU2Vjb25kYXJ5ID0gY3JpdGVyaWFUb1VzZS5maWx0ZXIoYyA9PiBjLmVuYWJsZWQpO1xyXG5cclxuICAgIC8vIEVzdGltYXRpb24gZHUgY2/Du3QgR1NJICg14oKsIHBhciBHU0kgYWN0aWYpXHJcbiAgICBjb25zdCBnc2lDb3N0ID0gYCR7ZW5hYmxlZFByaW1hcnkubGVuZ3RoICogNX3igqwvbW9pc2A7XHJcblxyXG4gICAgLy8gRXN0aW1hdGlvbiBkZSBwZXJmb3JtYW5jZVxyXG4gICAgY29uc3QgZXN0aW1hdGVkUGVyZm9ybWFuY2UgPSBlbmFibGVkUHJpbWFyeS5sZW5ndGggPiAwID8gXHJcbiAgICAgIGAkezg1ICsgTWF0aC5taW4oZW5hYmxlZFNlY29uZGFyeS5sZW5ndGggKiAyLCAxMyl9JSByw6lkdWN0aW9uYCA6IFxyXG4gICAgICBgJHtNYXRoLm1pbihlbmFibGVkU2Vjb25kYXJ5Lmxlbmd0aCAqIDUsIDYwKX0lIHLDqWR1Y3Rpb25gO1xyXG5cclxuICAgIC8vIE3DqXRyaXF1ZXMgZHUgY2FjaGVcclxuICAgIGNvbnN0IGNhY2hlTWV0cmljcyA9IENyaXRlcmlhUGFyYW1ldGVyU3RvcmUuZ2V0TWV0cmljcygpO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsQ3JpdGVyaWE6IHByaW1hcnlDcml0ZXJpYS5sZW5ndGggKyBjcml0ZXJpYVRvVXNlLmxlbmd0aCxcclxuICAgICAgcHJpbWFyeUNvdW50OiBwcmltYXJ5Q3JpdGVyaWEubGVuZ3RoLFxyXG4gICAgICBzZWNvbmRhcnlDb3VudDogY3JpdGVyaWFUb1VzZS5sZW5ndGgsXHJcbiAgICAgIGVuYWJsZWRQcmltYXJ5OiBlbmFibGVkUHJpbWFyeS5sZW5ndGgsXHJcbiAgICAgIGVuYWJsZWRTZWNvbmRhcnk6IGVuYWJsZWRTZWNvbmRhcnkubGVuZ3RoLFxyXG4gICAgICBnc2lDb3N0LFxyXG4gICAgICBlc3RpbWF0ZWRQZXJmb3JtYW5jZSxcclxuICAgICAgY2FjaGVNZXRyaWNzXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0b3VybmUgbGEgY29uZmlndXJhdGlvbiBjb21wbMOodGUgKHByaW1haXJlcyArIHNlY29uZGFpcmVzKVxyXG4gICAqIEFTWU5DSFJPTkUgLSBJbmNsdXQgbGVzIGNyaXTDqHJlcyBzZWNvbmRhaXJlcyBkZXB1aXMgUGFyYW1ldGVyIFN0b3JlXHJcbiAgICogXHJcbiAgICogRkFMTEJBQ0sgOiBTaSBQYXJhbWV0ZXIgU3RvcmUgcmV0b3VybmUgdmlkZSwgdXRpbGlzZSBsZXMgY3JpdMOocmVzIGVuIGR1clxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBnZXRGdWxsQ29uZmlndXJhdGlvbigpOiBQcm9taXNlPENyaXRlcmlhQ29uZmlnW10+IHtcclxuICAgIGNvbnN0IHNlY29uZGFyeUNyaXRlcmlhID0gYXdhaXQgQ3JpdGVyaWFQYXJhbWV0ZXJTdG9yZS5sb2FkQWxsKCk7XHJcbiAgICBcclxuICAgIC8vIOKaoO+4jyBGQUxMQkFDSyA6IFNpIFBhcmFtZXRlciBTdG9yZSByZXRvdXJuZSB2aWRlLCB1dGlsaXNlciBsZXMgY3JpdMOocmVzIGVuIGR1clxyXG4gICAgY29uc3QgY3JpdGVyaWFUb1VzZSA9IHNlY29uZGFyeUNyaXRlcmlhLmxlbmd0aCA+IDAgXHJcbiAgICAgID8gc2Vjb25kYXJ5Q3JpdGVyaWEgXHJcbiAgICAgIDogdGhpcy5TRUNPTkRBUllfQ1JJVEVSSUFfRkFMTEJBQ0s7XHJcbiAgICBcclxuICAgIGlmIChzZWNvbmRhcnlDcml0ZXJpYS5sZW5ndGggPT09IDApIHtcclxuICAgICAgY29uc29sZS53YXJuKCfimqDvuI8gVXNpbmcgRkFMTEJBQ0sgY3JpdGVyaWEgaW4gZ2V0RnVsbENvbmZpZ3VyYXRpb24oKScpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBDb252ZXJ0aXIgbGVzIGNyaXTDqHJlcyBzZWNvbmRhaXJlcyBhdSBmb3JtYXQgQ3JpdGVyaWFDb25maWdcclxuICAgIGNvbnN0IHNlY29uZGFyeUFzQ29uZmlnOiBDcml0ZXJpYUNvbmZpZ1tdID0gY3JpdGVyaWFUb1VzZS5tYXAoYyA9PiAoe1xyXG4gICAgICBuYW1lOiBjLm5hbWUsXHJcbiAgICAgIHR5cGU6ICdzZWNvbmRhcnknIGFzIGNvbnN0LFxyXG4gICAgICBlbmFibGVkOiBjLmVuYWJsZWQsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBjLmRlc2NyaXB0aW9uLFxyXG4gICAgICBidXNpbmVzc0p1c3RpZmljYXRpb246IGMuYnVzaW5lc3NKdXN0aWZpY2F0aW9uLFxyXG4gICAgICBhZGRlZERhdGU6IGMuYWRkZWREYXRlXHJcbiAgICB9KSk7XHJcblxyXG4gICAgcmV0dXJuIFsuLi50aGlzLlBSSU1BUllfQ1JJVEVSSUEsIC4uLnNlY29uZGFyeUFzQ29uZmlnXTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFZhbGlkZSBxdSd1biBlbnNlbWJsZSBkJ2F0dHJpYnV0cyBjb250aWVudCBkZXMgY3JpdMOocmVzIGNvbm51c1xyXG4gICAqIEFTWU5DSFJPTkUgLSBWw6lyaWZpZSBjb250cmUgbGVzIGNyaXTDqHJlcyBwcmltYWlyZXMgZXQgc2Vjb25kYWlyZXNcclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgdmFsaWRhdGVDb250YWN0QXR0cmlidXRlcyhjb250YWN0QXR0cmlidXRlczogUmVjb3JkPHN0cmluZywgYW55Pik6IFByb21pc2U8e1xyXG4gICAga25vd25Dcml0ZXJpYTogc3RyaW5nW107XHJcbiAgICB1bmtub3duQ3JpdGVyaWE6IHN0cmluZ1tdO1xyXG4gICAgcHJpbWFyeUNyaXRlcmlhRm91bmQ6IHN0cmluZ1tdO1xyXG4gICAgc2Vjb25kYXJ5Q3JpdGVyaWFGb3VuZDogc3RyaW5nW107XHJcbiAgfT4ge1xyXG4gICAgY29uc3QgYWxsS25vd25Dcml0ZXJpYSA9IGF3YWl0IHRoaXMuZ2V0QWxsQWN0aXZlQ3JpdGVyaWEoKTtcclxuICAgIGNvbnN0IGF0dHJpYnV0ZUtleXMgPSBPYmplY3Qua2V5cyhjb250YWN0QXR0cmlidXRlcyk7XHJcblxyXG4gICAgY29uc3Qga25vd25Dcml0ZXJpYSA9IGF0dHJpYnV0ZUtleXMuZmlsdGVyKGtleSA9PiBhbGxLbm93bkNyaXRlcmlhLmluY2x1ZGVzKGtleSkpO1xyXG4gICAgY29uc3QgdW5rbm93bkNyaXRlcmlhID0gYXR0cmlidXRlS2V5cy5maWx0ZXIoa2V5ID0+ICFhbGxLbm93bkNyaXRlcmlhLmluY2x1ZGVzKGtleSkpO1xyXG4gICAgXHJcbiAgICAvLyBWw6lyaWZpZXIgbGVzIGNyaXTDqHJlcyBwcmltYWlyZXMgKHN5bmNocm9uZSlcclxuICAgIGNvbnN0IHByaW1hcnlDcml0ZXJpYUZvdW5kID0ga25vd25Dcml0ZXJpYS5maWx0ZXIoa2V5ID0+IHRoaXMuaXNQcmltYXJ5Q3JpdGVyaWEoa2V5KSk7XHJcbiAgICBcclxuICAgIC8vIFbDqXJpZmllciBsZXMgY3JpdMOocmVzIHNlY29uZGFpcmVzIChhc3luY2hyb25lKVxyXG4gICAgY29uc3Qgc2Vjb25kYXJ5Q3JpdGVyaWFDaGVja3MgPSBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAga25vd25Dcml0ZXJpYS5tYXAoYXN5bmMga2V5ID0+ICh7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIGlzU2Vjb25kYXJ5OiBhd2FpdCB0aGlzLmlzU2Vjb25kYXJ5Q3JpdGVyaWEoa2V5KVxyXG4gICAgICB9KSlcclxuICAgICk7XHJcbiAgICBjb25zdCBzZWNvbmRhcnlDcml0ZXJpYUZvdW5kID0gc2Vjb25kYXJ5Q3JpdGVyaWFDaGVja3NcclxuICAgICAgLmZpbHRlcihjID0+IGMuaXNTZWNvbmRhcnkpXHJcbiAgICAgIC5tYXAoYyA9PiBjLmtleSk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAga25vd25Dcml0ZXJpYSxcclxuICAgICAgdW5rbm93bkNyaXRlcmlhLFxyXG4gICAgICBwcmltYXJ5Q3JpdGVyaWFGb3VuZCxcclxuICAgICAgc2Vjb25kYXJ5Q3JpdGVyaWFGb3VuZFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbmZpZ3VyZSBsZSBUVEwgZHUgY2FjaGUgUGFyYW1ldGVyIFN0b3JlXHJcbiAgICovXHJcbiAgc3RhdGljIHNldENhY2hlVFRMKHR0bDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICBDcml0ZXJpYVBhcmFtZXRlclN0b3JlLnNldENhY2hlVFRMKHR0bCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBJbnZhbGlkZSBsZSBjYWNoZSBQYXJhbWV0ZXIgU3RvcmUgKGZvcmNlIHVuIHJlZnJlc2gpXHJcbiAgICovXHJcbiAgc3RhdGljIGludmFsaWRhdGVDYWNoZSgpOiB2b2lkIHtcclxuICAgIENyaXRlcmlhUGFyYW1ldGVyU3RvcmUuaW52YWxpZGF0ZUNhY2hlKCk7XHJcbiAgfVxyXG59XHJcbiJdfQ==
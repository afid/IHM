import { ContactAttributes, QualificationRule, EvaluationResult } from '../../types/decision-engine';
export declare class RuleEvaluator {
    evaluateRules(contactAttributes: ContactAttributes, rules: QualificationRule[]): EvaluationResult;
    private evaluateRuleAgainstContactAttributes;
    /**
     * Checks if a rule mentions a specific contact attribute key
     * This is used for optimization and missing criteria handling
     */
    private ruleReferencesAttribute;
    /**
     * Handles missing criteria according to requirements:
     * - If a criterion is absent from a rule, retain that rule in the eligible set
     * - If a criterion value conflicts with a rule condition, eliminate that rule
     * - If a criterion value matches a rule condition, retain that rule
     */
    private handleMissingCriteria;
    /**
     * Recursively extracts all identifier names from an AST
     */
    private extractIdentifiersFromAST;
    private selectFinalRule;
    /**
     * Validates that a rule has a valid distribution segment
     * Handles missing segment mapping errors as required by task 6.4
     */
    private validateDistributionSegment;
}

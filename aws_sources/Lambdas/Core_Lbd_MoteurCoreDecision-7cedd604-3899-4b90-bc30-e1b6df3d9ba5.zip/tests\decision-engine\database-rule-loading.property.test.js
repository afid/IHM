"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
/**
 * **Feature: decision-engine, Property 2: Database rule loading**
 * **Validates: Requirements 1.1**
 *
 * Property: For any qualification request, the system should successfully load
 * all available rules from the database before processing
 */
// Mock DynamoDB for property testing
const mockSend = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => ({
    DynamoDBClient: jest.fn().mockImplementation(() => ({}))
}));
jest.mock('@aws-sdk/lib-dynamodb', () => ({
    DynamoDBDocumentClient: {
        from: jest.fn().mockReturnValue({ send: mockSend })
    },
    ScanCommand: jest.fn().mockImplementation((params) => params)
}));
describe('Property Test: Database Rule Loading', () => {
    beforeEach(() => {
        // Reset mocks before each test
        jest.clearAllMocks();
        mockSend.mockReset();
    });
    /**
     * Property: Database rule loading consistency
     * For any set of rules stored in the database, loadAllRules() should return
     * exactly those rules without modification, sorted by weight descending
     */
    test('should load all available rules from database consistently', async () => {
        // Manual property testing: Generate multiple test cases to simulate property-based testing
        const generateRule = (id, weight) => ({
            id,
            name: `Test Rule ${id}`,
            expression: ['NouveauSinistre == true', 'Client == "VIP"', 'Score > 80'][Math.floor(Math.random() * 3)],
            weight,
            distributionSegment: `segment-${id}`,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
        // Test cases representing different scenarios (simulating property-based testing)
        const testCases = [
            // Empty rules
            [],
            // Single rule
            [generateRule('1', 10)],
            // Multiple rules with different weights
            [generateRule('1', 10), generateRule('2', 20), generateRule('3', 5)],
            // Rules with same weights (edge case)
            [generateRule('1', 15), generateRule('2', 15)],
            // Large number of rules
            Array.from({ length: 10 }, (_, i) => generateRule(`rule-${i}`, Math.floor(Math.random() * 100) + 1)),
            // Rules with extreme weights
            [generateRule('min', 1), generateRule('max', 1000)],
            // Mixed weight scenarios
            [generateRule('a', 50), generateRule('b', 25), generateRule('c', 75), generateRule('d', 25)]
        ];
        // Run property test for each generated test case (100 iterations as specified)
        for (let iteration = 0; iteration < 100; iteration++) {
            const testCaseIndex = iteration % testCases.length;
            const generatedRules = testCases[testCaseIndex];
            // Setup mock to return the generated rules
            mockSend.mockResolvedValueOnce({
                Items: generatedRules
            });
            // Create repository instance
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Load rules from database
            const loadedRules = await repository.loadAllRules();
            // Property 1: All generated rules should be loaded
            expect(loadedRules).toHaveLength(generatedRules.length);
            // Property 2: Rules should be sorted by weight descending
            const expectedRules = [...generatedRules].sort((a, b) => b.weight - a.weight);
            expect(loadedRules).toEqual(expectedRules);
            // Property 3: DynamoDB should be called with correct parameters
            expect(mockSend).toHaveBeenCalledWith(expect.objectContaining({
                TableName: 'test-table',
                FilterExpression: 'attribute_not_exists(active) OR active = :active',
                ExpressionAttributeValues: {
                    ':active': 'true'
                }
            }));
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Empty database handling
     * When the database contains no rules, loadAllRules() should return an empty array
     */
    test('should handle empty database correctly', async () => {
        // Setup mock to return empty result
        mockSend.mockResolvedValueOnce({
            Items: undefined // DynamoDB returns undefined for empty results
        });
        const repository = new RuleRepository_1.RuleRepository('test-table');
        const loadedRules = await repository.loadAllRules();
        // Should return empty array
        expect(loadedRules).toEqual([]);
        expect(loadedRules).toHaveLength(0);
    });
    /**
     * Property: Database error handling
     * When database operations fail, loadAllRules() should throw a meaningful error
     */
    test('should handle database errors gracefully', async () => {
        // Manual property testing: Test various error scenarios
        const errorTypes = [
            new Error('Network timeout'),
            new Error('Access denied'),
            new Error('Table not found'),
            new Error('Connection failed'),
            new Error('ResourceNotFoundException'),
            new Error('ThrottlingException'),
            new Error('ValidationException'),
            new Error('ServiceUnavailableException')
        ];
        // Test each error type multiple times (50 iterations total)
        for (let iteration = 0; iteration < 50; iteration++) {
            const errorIndex = iteration % errorTypes.length;
            const error = errorTypes[errorIndex];
            // Setup mock to throw error
            mockSend.mockRejectedValueOnce(error);
            const repository = new RuleRepository_1.RuleRepository('test-table');
            // Property: Should throw a meaningful error containing the expected message
            await expect(repository.loadAllRules()).rejects.toThrow(expect.stringContaining('Failed to load qualification rules'));
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Caching behavior consistency
     * Multiple calls to loadAllRules() within cache TTL should return the same results
     * without additional database calls
     */
    test('should cache rules consistently within TTL', async () => {
        const generatedRules = [
            {
                id: 'rule1',
                name: 'Cached Rule 1',
                expression: 'NouveauSinistre == true',
                weight: 15,
                distributionSegment: 'segment1',
                createdAt: '2023-01-01T00:00:00.000Z',
                updatedAt: '2023-01-01T00:00:00.000Z'
            },
            {
                id: 'rule2',
                name: 'Cached Rule 2',
                expression: 'Client == "VIP"',
                weight: 25,
                distributionSegment: 'segment2',
                createdAt: '2023-01-02T00:00:00.000Z',
                updatedAt: '2023-01-02T00:00:00.000Z'
            }
        ];
        // Setup mock to return rules only once
        mockSend.mockResolvedValueOnce({
            Items: generatedRules
        });
        const repository = new RuleRepository_1.RuleRepository('test-table');
        // First call should load from database
        const firstLoad = await repository.loadAllRules();
        // Second call should use cache (no additional DB call)
        const secondLoad = await repository.loadAllRules();
        // Results should be identical
        expect(firstLoad).toEqual(secondLoad);
        // Database should only be called once
        expect(mockSend).toHaveBeenCalledTimes(1);
    });
    /**
     * Property: Rule sorting consistency
     * Rules should always be returned sorted by weight in descending order
     */
    test('should always return rules sorted by weight descending', async () => {
        // Manual property testing: Generate various unsorted rule sets to test sorting
        const generateUnsortedRules = (count) => {
            const rules = [];
            for (let i = 0; i < count; i++) {
                rules.push({
                    id: `rule-${i}`,
                    name: `Test Rule ${i}`,
                    expression: 'NouveauSinistre == true',
                    weight: Math.floor(Math.random() * 1000) + 1, // Random weight 1-1000
                    distributionSegment: `segment-${i}`,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                });
            }
            return rules;
        };
        // Test multiple scenarios with different rule counts (100 iterations)
        for (let iteration = 0; iteration < 100; iteration++) {
            const ruleCount = Math.floor(Math.random() * 10) + 2; // 2-11 rules
            const generatedRules = generateUnsortedRules(ruleCount);
            // Setup mock to return the generated rules (potentially unsorted)
            mockSend.mockResolvedValueOnce({
                Items: generatedRules
            });
            const repository = new RuleRepository_1.RuleRepository('test-table');
            const loadedRules = await repository.loadAllRules();
            // Property: Rules should be sorted by weight in descending order
            for (let i = 0; i < loadedRules.length - 1; i++) {
                expect(loadedRules[i].weight).toBeGreaterThanOrEqual(loadedRules[i + 1].weight);
            }
            // Additional property: The result should contain all original rules
            expect(loadedRules).toHaveLength(generatedRules.length);
            // Reset mock for next iteration
            mockSend.mockClear();
        }
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YWJhc2UtcnVsZS1sb2FkaW5nLnByb3BlcnR5LnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdGVzdHMvZGVjaXNpb24tZW5naW5lL2RhdGFiYXNlLXJ1bGUtbG9hZGluZy5wcm9wZXJ0eS50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsa0ZBQStFO0FBRy9FOzs7Ozs7R0FNRztBQUVILHFDQUFxQztBQUNyQyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7QUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQzNDLGNBQWMsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsa0JBQWtCLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztDQUN6RCxDQUFDLENBQUMsQ0FBQztBQUNKLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUN4QyxzQkFBc0IsRUFBRTtRQUN0QixJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLGVBQWUsQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQztLQUNwRDtJQUNELFdBQVcsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQztDQUM5RCxDQUFDLENBQUMsQ0FBQztBQUVKLFFBQVEsQ0FBQyxzQ0FBc0MsRUFBRSxHQUFHLEVBQUU7SUFDcEQsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLCtCQUErQjtRQUMvQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQyw0REFBNEQsRUFBRSxLQUFLLElBQUksRUFBRTtRQUM1RSwyRkFBMkY7UUFDM0YsTUFBTSxZQUFZLEdBQUcsQ0FBQyxFQUFVLEVBQUUsTUFBYyxFQUFxQixFQUFFLENBQUMsQ0FBQztZQUN2RSxFQUFFO1lBQ0YsSUFBSSxFQUFFLGFBQWEsRUFBRSxFQUFFO1lBQ3ZCLFVBQVUsRUFBRSxDQUFDLHlCQUF5QixFQUFFLGlCQUFpQixFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3ZHLE1BQU07WUFDTixtQkFBbUIsRUFBRSxXQUFXLEVBQUUsRUFBRTtZQUNwQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1NBQ3BDLENBQUMsQ0FBQztRQUVILGtGQUFrRjtRQUNsRixNQUFNLFNBQVMsR0FBRztZQUNoQixjQUFjO1lBQ2QsRUFBRTtZQUNGLGNBQWM7WUFDZCxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdkIsd0NBQXdDO1lBQ3hDLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDcEUsc0NBQXNDO1lBQ3RDLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLHdCQUF3QjtZQUN4QixLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDcEcsNkJBQTZCO1lBQzdCLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ25ELHlCQUF5QjtZQUN6QixDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDN0YsQ0FBQztRQUVGLCtFQUErRTtRQUMvRSxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDckQsTUFBTSxhQUFhLEdBQUcsU0FBUyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUM7WUFDbkQsTUFBTSxjQUFjLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRWhELDJDQUEyQztZQUMzQyxRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxjQUFjO2FBQ3RCLENBQUMsQ0FBQztZQUVILDZCQUE2QjtZQUM3QixNQUFNLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFcEQsMkJBQTJCO1lBQzNCLE1BQU0sV0FBVyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRXBELG1EQUFtRDtZQUNuRCxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV4RCwwREFBMEQ7WUFDMUQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzlFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFM0MsZ0VBQWdFO1lBQ2hFLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxvQkFBb0IsQ0FDbkMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO2dCQUN0QixTQUFTLEVBQUUsWUFBWTtnQkFDdkIsZ0JBQWdCLEVBQUUsa0RBQWtEO2dCQUNwRSx5QkFBeUIsRUFBRTtvQkFDekIsU0FBUyxFQUFFLE1BQU07aUJBQ2xCO2FBQ0YsQ0FBQyxDQUNILENBQUM7WUFFRixnQ0FBZ0M7WUFDaEMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVIOzs7T0FHRztJQUNILElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxLQUFLLElBQUksRUFBRTtRQUN4RCxvQ0FBb0M7UUFDcEMsUUFBUSxDQUFDLHFCQUFxQixDQUFDO1lBQzdCLEtBQUssRUFBRSxTQUFTLENBQUMsK0NBQStDO1NBQ2pFLENBQUMsQ0FBQztRQUVILE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNwRCxNQUFNLFdBQVcsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUVwRCw0QkFBNEI7UUFDNUIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBRUg7OztPQUdHO0lBQ0gsSUFBSSxDQUFDLDBDQUEwQyxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQzFELHdEQUF3RDtRQUN4RCxNQUFNLFVBQVUsR0FBRztZQUNqQixJQUFJLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztZQUM1QixJQUFJLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDMUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDNUIsSUFBSSxLQUFLLENBQUMsbUJBQW1CLENBQUM7WUFDOUIsSUFBSSxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFDdEMsSUFBSSxLQUFLLENBQUMscUJBQXFCLENBQUM7WUFDaEMsSUFBSSxLQUFLLENBQUMscUJBQXFCLENBQUM7WUFDaEMsSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUM7U0FDekMsQ0FBQztRQUVGLDREQUE0RDtRQUM1RCxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDcEQsTUFBTSxVQUFVLEdBQUcsU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFDakQsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXJDLDRCQUE0QjtZQUM1QixRQUFRLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFdEMsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRXBELDRFQUE0RTtZQUM1RSxNQUFNLE1BQU0sQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUNyRCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsb0NBQW9DLENBQUMsQ0FDOUQsQ0FBQztZQUVGLGdDQUFnQztZQUNoQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQyw0Q0FBNEMsRUFBRSxLQUFLLElBQUksRUFBRTtRQUM1RCxNQUFNLGNBQWMsR0FBRztZQUNyQjtnQkFDRSxFQUFFLEVBQUUsT0FBTztnQkFDWCxJQUFJLEVBQUUsZUFBZTtnQkFDckIsVUFBVSxFQUFFLHlCQUF5QjtnQkFDckMsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsbUJBQW1CLEVBQUUsVUFBVTtnQkFDL0IsU0FBUyxFQUFFLDBCQUEwQjtnQkFDckMsU0FBUyxFQUFFLDBCQUEwQjthQUN0QztZQUNEO2dCQUNFLEVBQUUsRUFBRSxPQUFPO2dCQUNYLElBQUksRUFBRSxlQUFlO2dCQUNyQixVQUFVLEVBQUUsaUJBQWlCO2dCQUM3QixNQUFNLEVBQUUsRUFBRTtnQkFDVixtQkFBbUIsRUFBRSxVQUFVO2dCQUMvQixTQUFTLEVBQUUsMEJBQTBCO2dCQUNyQyxTQUFTLEVBQUUsMEJBQTBCO2FBQ3RDO1NBQ0YsQ0FBQztRQUVGLHVDQUF1QztRQUN2QyxRQUFRLENBQUMscUJBQXFCLENBQUM7WUFDN0IsS0FBSyxFQUFFLGNBQWM7U0FDdEIsQ0FBQyxDQUFDO1FBRUgsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRXBELHVDQUF1QztRQUN2QyxNQUFNLFNBQVMsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUVsRCx1REFBdUQ7UUFDdkQsTUFBTSxVQUFVLEdBQUcsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFbkQsOEJBQThCO1FBQzlCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFdEMsc0NBQXNDO1FBQ3RDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM1QyxDQUFDLENBQUMsQ0FBQztJQUVIOzs7T0FHRztJQUNILElBQUksQ0FBQyx3REFBd0QsRUFBRSxLQUFLLElBQUksRUFBRTtRQUN4RSwrRUFBK0U7UUFDL0UsTUFBTSxxQkFBcUIsR0FBRyxDQUFDLEtBQWEsRUFBdUIsRUFBRTtZQUNuRSxNQUFNLEtBQUssR0FBd0IsRUFBRSxDQUFDO1lBQ3RDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDL0IsS0FBSyxDQUFDLElBQUksQ0FBQztvQkFDVCxFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUU7b0JBQ2YsSUFBSSxFQUFFLGFBQWEsQ0FBQyxFQUFFO29CQUN0QixVQUFVLEVBQUUseUJBQXlCO29CQUNyQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLHVCQUF1QjtvQkFDckUsbUJBQW1CLEVBQUUsV0FBVyxDQUFDLEVBQUU7b0JBQ25DLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtvQkFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2lCQUNwQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBQ0QsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDLENBQUM7UUFFRixzRUFBc0U7UUFDdEUsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUcsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3JELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGFBQWE7WUFDbkUsTUFBTSxjQUFjLEdBQUcscUJBQXFCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFeEQsa0VBQWtFO1lBQ2xFLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0IsS0FBSyxFQUFFLGNBQWM7YUFDdEIsQ0FBQyxDQUFDO1lBRUgsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3BELE1BQU0sV0FBVyxHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRXBELGlFQUFpRTtZQUNqRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDaEQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2xGLENBQUM7WUFFRCxvRUFBb0U7WUFDcEUsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFeEQsZ0NBQWdDO1lBQ2hDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJ1bGVSZXBvc2l0b3J5IH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL1J1bGVSZXBvc2l0b3J5JztcclxuaW1wb3J0IHsgUXVhbGlmaWNhdGlvblJ1bGUgfSBmcm9tICcuLi8uLi90eXBlcy9kZWNpc2lvbi1lbmdpbmUnO1xyXG5cclxuLyoqXHJcbiAqICoqRmVhdHVyZTogZGVjaXNpb24tZW5naW5lLCBQcm9wZXJ0eSAyOiBEYXRhYmFzZSBydWxlIGxvYWRpbmcqKlxyXG4gKiAqKlZhbGlkYXRlczogUmVxdWlyZW1lbnRzIDEuMSoqXHJcbiAqIFxyXG4gKiBQcm9wZXJ0eTogRm9yIGFueSBxdWFsaWZpY2F0aW9uIHJlcXVlc3QsIHRoZSBzeXN0ZW0gc2hvdWxkIHN1Y2Nlc3NmdWxseSBsb2FkIFxyXG4gKiBhbGwgYXZhaWxhYmxlIHJ1bGVzIGZyb20gdGhlIGRhdGFiYXNlIGJlZm9yZSBwcm9jZXNzaW5nXHJcbiAqL1xyXG5cclxuLy8gTW9jayBEeW5hbW9EQiBmb3IgcHJvcGVydHkgdGVzdGluZ1xyXG5jb25zdCBtb2NrU2VuZCA9IGplc3QuZm4oKTtcclxuamVzdC5tb2NrKCdAYXdzLXNkay9jbGllbnQtZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCQ2xpZW50OiBqZXN0LmZuKCkubW9ja0ltcGxlbWVudGF0aW9uKCgpID0+ICh7fSkpXHJcbn0pKTtcclxuamVzdC5tb2NrKCdAYXdzLXNkay9saWItZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCRG9jdW1lbnRDbGllbnQ6IHtcclxuICAgIGZyb206IGplc3QuZm4oKS5tb2NrUmV0dXJuVmFsdWUoeyBzZW5kOiBtb2NrU2VuZCB9KVxyXG4gIH0sXHJcbiAgU2NhbkNvbW1hbmQ6IGplc3QuZm4oKS5tb2NrSW1wbGVtZW50YXRpb24oKHBhcmFtcykgPT4gcGFyYW1zKVxyXG59KSk7XHJcblxyXG5kZXNjcmliZSgnUHJvcGVydHkgVGVzdDogRGF0YWJhc2UgUnVsZSBMb2FkaW5nJywgKCkgPT4ge1xyXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgLy8gUmVzZXQgbW9ja3MgYmVmb3JlIGVhY2ggdGVzdFxyXG4gICAgamVzdC5jbGVhckFsbE1vY2tzKCk7XHJcbiAgICBtb2NrU2VuZC5tb2NrUmVzZXQoKTtcclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IERhdGFiYXNlIHJ1bGUgbG9hZGluZyBjb25zaXN0ZW5jeVxyXG4gICAqIEZvciBhbnkgc2V0IG9mIHJ1bGVzIHN0b3JlZCBpbiB0aGUgZGF0YWJhc2UsIGxvYWRBbGxSdWxlcygpIHNob3VsZCByZXR1cm4gXHJcbiAgICogZXhhY3RseSB0aG9zZSBydWxlcyB3aXRob3V0IG1vZGlmaWNhdGlvbiwgc29ydGVkIGJ5IHdlaWdodCBkZXNjZW5kaW5nXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIGxvYWQgYWxsIGF2YWlsYWJsZSBydWxlcyBmcm9tIGRhdGFiYXNlIGNvbnNpc3RlbnRseScsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIE1hbnVhbCBwcm9wZXJ0eSB0ZXN0aW5nOiBHZW5lcmF0ZSBtdWx0aXBsZSB0ZXN0IGNhc2VzIHRvIHNpbXVsYXRlIHByb3BlcnR5LWJhc2VkIHRlc3RpbmdcclxuICAgIGNvbnN0IGdlbmVyYXRlUnVsZSA9IChpZDogc3RyaW5nLCB3ZWlnaHQ6IG51bWJlcik6IFF1YWxpZmljYXRpb25SdWxlID0+ICh7XHJcbiAgICAgIGlkLFxyXG4gICAgICBuYW1lOiBgVGVzdCBSdWxlICR7aWR9YCxcclxuICAgICAgZXhwcmVzc2lvbjogWydOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZScsICdDbGllbnQgPT0gXCJWSVBcIicsICdTY29yZSA+IDgwJ11bTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMyldLFxyXG4gICAgICB3ZWlnaHQsXHJcbiAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6IGBzZWdtZW50LSR7aWR9YCxcclxuICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBUZXN0IGNhc2VzIHJlcHJlc2VudGluZyBkaWZmZXJlbnQgc2NlbmFyaW9zIChzaW11bGF0aW5nIHByb3BlcnR5LWJhc2VkIHRlc3RpbmcpXHJcbiAgICBjb25zdCB0ZXN0Q2FzZXMgPSBbXHJcbiAgICAgIC8vIEVtcHR5IHJ1bGVzXHJcbiAgICAgIFtdLFxyXG4gICAgICAvLyBTaW5nbGUgcnVsZVxyXG4gICAgICBbZ2VuZXJhdGVSdWxlKCcxJywgMTApXSxcclxuICAgICAgLy8gTXVsdGlwbGUgcnVsZXMgd2l0aCBkaWZmZXJlbnQgd2VpZ2h0c1xyXG4gICAgICBbZ2VuZXJhdGVSdWxlKCcxJywgMTApLCBnZW5lcmF0ZVJ1bGUoJzInLCAyMCksIGdlbmVyYXRlUnVsZSgnMycsIDUpXSxcclxuICAgICAgLy8gUnVsZXMgd2l0aCBzYW1lIHdlaWdodHMgKGVkZ2UgY2FzZSlcclxuICAgICAgW2dlbmVyYXRlUnVsZSgnMScsIDE1KSwgZ2VuZXJhdGVSdWxlKCcyJywgMTUpXSxcclxuICAgICAgLy8gTGFyZ2UgbnVtYmVyIG9mIHJ1bGVzXHJcbiAgICAgIEFycmF5LmZyb20oeyBsZW5ndGg6IDEwIH0sIChfLCBpKSA9PiBnZW5lcmF0ZVJ1bGUoYHJ1bGUtJHtpfWAsIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMCkgKyAxKSksXHJcbiAgICAgIC8vIFJ1bGVzIHdpdGggZXh0cmVtZSB3ZWlnaHRzXHJcbiAgICAgIFtnZW5lcmF0ZVJ1bGUoJ21pbicsIDEpLCBnZW5lcmF0ZVJ1bGUoJ21heCcsIDEwMDApXSxcclxuICAgICAgLy8gTWl4ZWQgd2VpZ2h0IHNjZW5hcmlvc1xyXG4gICAgICBbZ2VuZXJhdGVSdWxlKCdhJywgNTApLCBnZW5lcmF0ZVJ1bGUoJ2InLCAyNSksIGdlbmVyYXRlUnVsZSgnYycsIDc1KSwgZ2VuZXJhdGVSdWxlKCdkJywgMjUpXVxyXG4gICAgXTtcclxuXHJcbiAgICAvLyBSdW4gcHJvcGVydHkgdGVzdCBmb3IgZWFjaCBnZW5lcmF0ZWQgdGVzdCBjYXNlICgxMDAgaXRlcmF0aW9ucyBhcyBzcGVjaWZpZWQpXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAxMDA7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIGNvbnN0IHRlc3RDYXNlSW5kZXggPSBpdGVyYXRpb24gJSB0ZXN0Q2FzZXMubGVuZ3RoO1xyXG4gICAgICBjb25zdCBnZW5lcmF0ZWRSdWxlcyA9IHRlc3RDYXNlc1t0ZXN0Q2FzZUluZGV4XTtcclxuXHJcbiAgICAgIC8vIFNldHVwIG1vY2sgdG8gcmV0dXJuIHRoZSBnZW5lcmF0ZWQgcnVsZXNcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogZ2VuZXJhdGVkUnVsZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBDcmVhdGUgcmVwb3NpdG9yeSBpbnN0YW5jZVxyXG4gICAgICBjb25zdCByZXBvc2l0b3J5ID0gbmV3IFJ1bGVSZXBvc2l0b3J5KCd0ZXN0LXRhYmxlJyk7XHJcblxyXG4gICAgICAvLyBMb2FkIHJ1bGVzIGZyb20gZGF0YWJhc2VcclxuICAgICAgY29uc3QgbG9hZGVkUnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMTogQWxsIGdlbmVyYXRlZCBydWxlcyBzaG91bGQgYmUgbG9hZGVkXHJcbiAgICAgIGV4cGVjdChsb2FkZWRSdWxlcykudG9IYXZlTGVuZ3RoKGdlbmVyYXRlZFJ1bGVzLmxlbmd0aCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAyOiBSdWxlcyBzaG91bGQgYmUgc29ydGVkIGJ5IHdlaWdodCBkZXNjZW5kaW5nXHJcbiAgICAgIGNvbnN0IGV4cGVjdGVkUnVsZXMgPSBbLi4uZ2VuZXJhdGVkUnVsZXNdLnNvcnQoKGEsIGIpID0+IGIud2VpZ2h0IC0gYS53ZWlnaHQpO1xyXG4gICAgICBleHBlY3QobG9hZGVkUnVsZXMpLnRvRXF1YWwoZXhwZWN0ZWRSdWxlcyk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBEeW5hbW9EQiBzaG91bGQgYmUgY2FsbGVkIHdpdGggY29ycmVjdCBwYXJhbWV0ZXJzXHJcbiAgICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXHJcbiAgICAgICAgZXhwZWN0Lm9iamVjdENvbnRhaW5pbmcoe1xyXG4gICAgICAgICAgVGFibGVOYW1lOiAndGVzdC10YWJsZScsXHJcbiAgICAgICAgICBGaWx0ZXJFeHByZXNzaW9uOiAnYXR0cmlidXRlX25vdF9leGlzdHMoYWN0aXZlKSBPUiBhY3RpdmUgPSA6YWN0aXZlJyxcclxuICAgICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IHtcclxuICAgICAgICAgICAgJzphY3RpdmUnOiAndHJ1ZSdcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICApO1xyXG5cclxuICAgICAgLy8gUmVzZXQgbW9jayBmb3IgbmV4dCBpdGVyYXRpb25cclxuICAgICAgbW9ja1NlbmQubW9ja0NsZWFyKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBFbXB0eSBkYXRhYmFzZSBoYW5kbGluZ1xyXG4gICAqIFdoZW4gdGhlIGRhdGFiYXNlIGNvbnRhaW5zIG5vIHJ1bGVzLCBsb2FkQWxsUnVsZXMoKSBzaG91bGQgcmV0dXJuIGFuIGVtcHR5IGFycmF5XHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIGhhbmRsZSBlbXB0eSBkYXRhYmFzZSBjb3JyZWN0bHknLCBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBTZXR1cCBtb2NrIHRvIHJldHVybiBlbXB0eSByZXN1bHRcclxuICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgIEl0ZW1zOiB1bmRlZmluZWQgLy8gRHluYW1vREIgcmV0dXJucyB1bmRlZmluZWQgZm9yIGVtcHR5IHJlc3VsdHNcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuICAgIGNvbnN0IGxvYWRlZFJ1bGVzID0gYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuXHJcbiAgICAvLyBTaG91bGQgcmV0dXJuIGVtcHR5IGFycmF5XHJcbiAgICBleHBlY3QobG9hZGVkUnVsZXMpLnRvRXF1YWwoW10pO1xyXG4gICAgZXhwZWN0KGxvYWRlZFJ1bGVzKS50b0hhdmVMZW5ndGgoMCk7XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBEYXRhYmFzZSBlcnJvciBoYW5kbGluZ1xyXG4gICAqIFdoZW4gZGF0YWJhc2Ugb3BlcmF0aW9ucyBmYWlsLCBsb2FkQWxsUnVsZXMoKSBzaG91bGQgdGhyb3cgYSBtZWFuaW5nZnVsIGVycm9yXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIGhhbmRsZSBkYXRhYmFzZSBlcnJvcnMgZ3JhY2VmdWxseScsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIE1hbnVhbCBwcm9wZXJ0eSB0ZXN0aW5nOiBUZXN0IHZhcmlvdXMgZXJyb3Igc2NlbmFyaW9zXHJcbiAgICBjb25zdCBlcnJvclR5cGVzID0gW1xyXG4gICAgICBuZXcgRXJyb3IoJ05ldHdvcmsgdGltZW91dCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ0FjY2VzcyBkZW5pZWQnKSxcclxuICAgICAgbmV3IEVycm9yKCdUYWJsZSBub3QgZm91bmQnKSxcclxuICAgICAgbmV3IEVycm9yKCdDb25uZWN0aW9uIGZhaWxlZCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ1Jlc291cmNlTm90Rm91bmRFeGNlcHRpb24nKSxcclxuICAgICAgbmV3IEVycm9yKCdUaHJvdHRsaW5nRXhjZXB0aW9uJyksXHJcbiAgICAgIG5ldyBFcnJvcignVmFsaWRhdGlvbkV4Y2VwdGlvbicpLFxyXG4gICAgICBuZXcgRXJyb3IoJ1NlcnZpY2VVbmF2YWlsYWJsZUV4Y2VwdGlvbicpXHJcbiAgICBdO1xyXG5cclxuICAgIC8vIFRlc3QgZWFjaCBlcnJvciB0eXBlIG11bHRpcGxlIHRpbWVzICg1MCBpdGVyYXRpb25zIHRvdGFsKVxyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgNTA7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIGNvbnN0IGVycm9ySW5kZXggPSBpdGVyYXRpb24gJSBlcnJvclR5cGVzLmxlbmd0aDtcclxuICAgICAgY29uc3QgZXJyb3IgPSBlcnJvclR5cGVzW2Vycm9ySW5kZXhdO1xyXG5cclxuICAgICAgLy8gU2V0dXAgbW9jayB0byB0aHJvdyBlcnJvclxyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVqZWN0ZWRWYWx1ZU9uY2UoZXJyb3IpO1xyXG5cclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IFNob3VsZCB0aHJvdyBhIG1lYW5pbmdmdWwgZXJyb3IgY29udGFpbmluZyB0aGUgZXhwZWN0ZWQgbWVzc2FnZVxyXG4gICAgICBhd2FpdCBleHBlY3QocmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKSkucmVqZWN0cy50b1Rocm93KFxyXG4gICAgICAgIGV4cGVjdC5zdHJpbmdDb250YWluaW5nKCdGYWlsZWQgdG8gbG9hZCBxdWFsaWZpY2F0aW9uIHJ1bGVzJylcclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2sgZm9yIG5leHQgaXRlcmF0aW9uXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tDbGVhcigpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICAvKipcclxuICAgKiBQcm9wZXJ0eTogQ2FjaGluZyBiZWhhdmlvciBjb25zaXN0ZW5jeVxyXG4gICAqIE11bHRpcGxlIGNhbGxzIHRvIGxvYWRBbGxSdWxlcygpIHdpdGhpbiBjYWNoZSBUVEwgc2hvdWxkIHJldHVybiB0aGUgc2FtZSByZXN1bHRzXHJcbiAgICogd2l0aG91dCBhZGRpdGlvbmFsIGRhdGFiYXNlIGNhbGxzXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIGNhY2hlIHJ1bGVzIGNvbnNpc3RlbnRseSB3aXRoaW4gVFRMJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3QgZ2VuZXJhdGVkUnVsZXMgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogJ3J1bGUxJyxcclxuICAgICAgICBuYW1lOiAnQ2FjaGVkIFJ1bGUgMScsXHJcbiAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJyxcclxuICAgICAgICB3ZWlnaHQ6IDE1LFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50MScsXHJcbiAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogJ3J1bGUyJyxcclxuICAgICAgICBuYW1lOiAnQ2FjaGVkIFJ1bGUgMicsXHJcbiAgICAgICAgZXhwcmVzc2lvbjogJ0NsaWVudCA9PSBcIlZJUFwiJyxcclxuICAgICAgICB3ZWlnaHQ6IDI1LFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50MicsXHJcbiAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMlQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAyVDAwOjAwOjAwLjAwMFonXHJcbiAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgLy8gU2V0dXAgbW9jayB0byByZXR1cm4gcnVsZXMgb25seSBvbmNlXHJcbiAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xyXG4gICAgICBJdGVtczogZ2VuZXJhdGVkUnVsZXNcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuXHJcbiAgICAvLyBGaXJzdCBjYWxsIHNob3VsZCBsb2FkIGZyb20gZGF0YWJhc2VcclxuICAgIGNvbnN0IGZpcnN0TG9hZCA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcbiAgICBcclxuICAgIC8vIFNlY29uZCBjYWxsIHNob3VsZCB1c2UgY2FjaGUgKG5vIGFkZGl0aW9uYWwgREIgY2FsbClcclxuICAgIGNvbnN0IHNlY29uZExvYWQgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG5cclxuICAgIC8vIFJlc3VsdHMgc2hvdWxkIGJlIGlkZW50aWNhbFxyXG4gICAgZXhwZWN0KGZpcnN0TG9hZCkudG9FcXVhbChzZWNvbmRMb2FkKTtcclxuICAgIFxyXG4gICAgLy8gRGF0YWJhc2Ugc2hvdWxkIG9ubHkgYmUgY2FsbGVkIG9uY2VcclxuICAgIGV4cGVjdChtb2NrU2VuZCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xyXG4gIH0pO1xyXG5cclxuICAvKipcclxuICAgKiBQcm9wZXJ0eTogUnVsZSBzb3J0aW5nIGNvbnNpc3RlbmN5XHJcbiAgICogUnVsZXMgc2hvdWxkIGFsd2F5cyBiZSByZXR1cm5lZCBzb3J0ZWQgYnkgd2VpZ2h0IGluIGRlc2NlbmRpbmcgb3JkZXJcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgYWx3YXlzIHJldHVybiBydWxlcyBzb3J0ZWQgYnkgd2VpZ2h0IGRlc2NlbmRpbmcnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBNYW51YWwgcHJvcGVydHkgdGVzdGluZzogR2VuZXJhdGUgdmFyaW91cyB1bnNvcnRlZCBydWxlIHNldHMgdG8gdGVzdCBzb3J0aW5nXHJcbiAgICBjb25zdCBnZW5lcmF0ZVVuc29ydGVkUnVsZXMgPSAoY291bnQ6IG51bWJlcik6IFF1YWxpZmljYXRpb25SdWxlW10gPT4ge1xyXG4gICAgICBjb25zdCBydWxlczogUXVhbGlmaWNhdGlvblJ1bGVbXSA9IFtdO1xyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50OyBpKyspIHtcclxuICAgICAgICBydWxlcy5wdXNoKHtcclxuICAgICAgICAgIGlkOiBgcnVsZS0ke2l9YCxcclxuICAgICAgICAgIG5hbWU6IGBUZXN0IFJ1bGUgJHtpfWAsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgICAgICAgd2VpZ2h0OiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDAwKSArIDEsIC8vIFJhbmRvbSB3ZWlnaHQgMS0xMDAwXHJcbiAgICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiBgc2VnbWVudC0ke2l9YCxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gcnVsZXM7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIFRlc3QgbXVsdGlwbGUgc2NlbmFyaW9zIHdpdGggZGlmZmVyZW50IHJ1bGUgY291bnRzICgxMDAgaXRlcmF0aW9ucylcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDEwMDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3QgcnVsZUNvdW50ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTApICsgMjsgLy8gMi0xMSBydWxlc1xyXG4gICAgICBjb25zdCBnZW5lcmF0ZWRSdWxlcyA9IGdlbmVyYXRlVW5zb3J0ZWRSdWxlcyhydWxlQ291bnQpO1xyXG5cclxuICAgICAgLy8gU2V0dXAgbW9jayB0byByZXR1cm4gdGhlIGdlbmVyYXRlZCBydWxlcyAocG90ZW50aWFsbHkgdW5zb3J0ZWQpXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgICAgSXRlbXM6IGdlbmVyYXRlZFJ1bGVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG4gICAgICBjb25zdCBsb2FkZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogUnVsZXMgc2hvdWxkIGJlIHNvcnRlZCBieSB3ZWlnaHQgaW4gZGVzY2VuZGluZyBvcmRlclxyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxvYWRlZFJ1bGVzLmxlbmd0aCAtIDE7IGkrKykge1xyXG4gICAgICAgIGV4cGVjdChsb2FkZWRSdWxlc1tpXS53ZWlnaHQpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwobG9hZGVkUnVsZXNbaSArIDFdLndlaWdodCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEFkZGl0aW9uYWwgcHJvcGVydHk6IFRoZSByZXN1bHQgc2hvdWxkIGNvbnRhaW4gYWxsIG9yaWdpbmFsIHJ1bGVzXHJcbiAgICAgIGV4cGVjdChsb2FkZWRSdWxlcykudG9IYXZlTGVuZ3RoKGdlbmVyYXRlZFJ1bGVzLmxlbmd0aCk7XHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxufSk7Il19
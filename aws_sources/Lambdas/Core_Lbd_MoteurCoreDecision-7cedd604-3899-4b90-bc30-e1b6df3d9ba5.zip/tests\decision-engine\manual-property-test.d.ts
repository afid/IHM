/**
 * Manual Property Test Runner for Database Rule Loading
 * **Feature: decision-engine, Property 2: Database rule loading**
 * **Validates: Requirements 1.1**
 *
 * This is a standalone test that can be run without Jest to verify the property
 */
declare function testDatabaseRuleLoadingProperty(): Promise<void>;
export { testDatabaseRuleLoadingProperty };

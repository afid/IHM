"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ValidationUtils_1 = require("../../utils/decision-engine/ValidationUtils");
const LoggingUtils_1 = require("../../utils/decision-engine/LoggingUtils");
describe('Error Handling Unit Tests', () => {
    let mockConsoleError;
    const testContext = {
        requestId: 'test-request-123',
        interactionId: 'test-interaction-456',
        timestamp: '2023-12-01T10:00:00.000Z'
    };
    beforeEach(() => {
        mockConsoleError = jest.spyOn(console, 'error').mockImplementation();
        LoggingUtils_1.LoggingUtils.clearAuditTrails();
    });
    afterEach(() => {
        mockConsoleError.mockRestore();
        LoggingUtils_1.LoggingUtils.clearAuditTrails();
    });
    describe('ValidationUtils', () => {
        describe('validateQualificationRequest', () => {
            test('should validate valid qualification request', () => {
                const request = {
                    interactionId: 'test-123',
                    contactAttributes: {
                        NouveauSinistre: true,
                        Client: 'VIP'
                    }
                };
                const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(request);
                expect(result.isValid).toBe(true);
                expect(result.error).toBeUndefined();
            });
            test('should reject request without interactionId', () => {
                const request = {
                    contactAttributes: { Client: 'VIP' }
                };
                const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(request);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('interactionId is required');
            });
            test('should reject request with invalid interactionId type', () => {
                const request = {
                    interactionId: 123,
                    contactAttributes: { Client: 'VIP' }
                };
                const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(request);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('interactionId is required and must be a string');
            });
            test('should reject request without contactAttributes', () => {
                const request = {
                    interactionId: 'test-123'
                };
                const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(request);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('contactAttributes is required');
            });
            test('should reject null request', () => {
                const result = ValidationUtils_1.ValidationUtils.validateQualificationRequest(null);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('Request body is required');
            });
        });
        describe('validateContactAttributes', () => {
            test('should validate valid contact attributes', () => {
                const attributes = {
                    NouveauSinistre: true,
                    Client: 'VIP',
                    Age: 35,
                    Score: 85.5
                };
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
                expect(result.isValid).toBe(true);
                expect(result.error).toBeUndefined();
            });
            test('should reject non-object attributes', () => {
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes('invalid');
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('Contact attributes must be an object');
            });
            test('should reject array attributes', () => {
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes([1, 2, 3]);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('Contact attributes must be an object');
            });
            test('should reject empty key', () => {
                const attributes = { '': 'value' };
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('non-empty strings');
            });
            test('should reject invalid value types', () => {
                const attributes = {
                    validKey: 'validValue',
                    invalidKey: { nested: 'object' }
                };
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('invalid type');
            });
            test('should reject string values exceeding maximum length', () => {
                const longString = 'a'.repeat(1001);
                const attributes = { longKey: longString };
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('exceeds maximum length');
            });
            test('should reject infinite number values', () => {
                const attributes = { infiniteKey: Infinity };
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('finite number');
            });
            test('should reject NaN values', () => {
                const attributes = { nanKey: NaN };
                const result = ValidationUtils_1.ValidationUtils.validateContactAttributes(attributes);
                expect(result.isValid).toBe(false);
                expect(result.error).toContain('finite number');
            });
        });
        describe('sanitizeContactAttributes', () => {
            test('should trim string keys and values', () => {
                const attributes = {
                    '  Client  ': '  VIP  ',
                    'NouveauSinistre': true,
                    'Age': 35
                };
                const sanitized = ValidationUtils_1.ValidationUtils.sanitizeContactAttributes(attributes);
                expect(sanitized).toEqual({
                    'Client': 'VIP',
                    'NouveauSinistre': true,
                    'Age': 35
                });
            });
            test('should remove empty keys after trimming', () => {
                const attributes = {
                    '   ': 'value',
                    'validKey': 'validValue'
                };
                const sanitized = ValidationUtils_1.ValidationUtils.sanitizeContactAttributes(attributes);
                expect(sanitized).toEqual({
                    'validKey': 'validValue'
                });
            });
            test('should preserve non-string values', () => {
                const attributes = {
                    booleanKey: true,
                    numberKey: 42,
                    stringKey: '  trimmed  '
                };
                const sanitized = ValidationUtils_1.ValidationUtils.sanitizeContactAttributes(attributes);
                expect(sanitized).toEqual({
                    booleanKey: true,
                    numberKey: 42,
                    stringKey: 'trimmed'
                });
            });
        });
        describe('formatErrorResponse', () => {
            test('should format error response correctly', () => {
                const error = 'Test error message';
                const errorCode = 'TEST_ERROR';
                const requestId = 'test-123';
                const details = { additional: 'info' };
                const response = ValidationUtils_1.ValidationUtils.formatErrorResponse(error, errorCode, requestId, details);
                expect(response.success).toBe(false);
                expect(response.error).toBe(error);
                expect(response.errorCode).toBe(errorCode);
                expect(response.requestId).toBe(requestId);
                expect(response.details).toEqual(details);
                expect(response.timestamp).toBeDefined();
            });
        });
        describe('formatValidationError', () => {
            test('should format validation error with French message', () => {
                const validationError = 'Invalid format';
                const requestId = 'test-123';
                const response = ValidationUtils_1.ValidationUtils.formatValidationError(validationError, requestId);
                expect(response.success).toBe(false);
                expect(response.error).toContain('Format de contact attributes invalide');
                expect(response.error).toContain(validationError);
                expect(response.errorCode).toBe('VALIDATION_ERROR');
                expect(response.requestId).toBe(requestId);
            });
        });
    });
    describe('ErrorHandlingFramework', () => {
        describe('handleDatabaseError', () => {
            test('should handle database error with logging', () => {
                const error = new Error('Connection timeout');
                const operation = 'loadRules';
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleDatabaseError(error, operation, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.DATABASE);
                expect(errorDetails.code).toBe('DATABASE_ERROR');
                expect(errorDetails.message).toContain('Database operation');
                expect(errorDetails.message).toContain(operation);
                expect(errorDetails.userMessage).toContain('Erreur de base de données');
                expect(errorDetails.retryable).toBe(true);
                expect(errorDetails.originalError).toBe(error);
                // Verify logging was called
                expect(mockConsoleError).toHaveBeenCalledWith(expect.stringContaining('"level":"ERROR"'));
            });
            test('should handle database error without context', () => {
                const error = new Error('Connection failed');
                const operation = 'saveRule';
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleDatabaseError(error, operation);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.DATABASE);
                expect(errorDetails.retryable).toBe(true);
                expect(mockConsoleError).not.toHaveBeenCalled();
            });
        });
        describe('handleRuleProcessingError', () => {
            test('should handle rule processing error with logging', () => {
                const error = new Error('Invalid expression syntax');
                const ruleId = 'rule-123';
                const expression = 'invalid && syntax';
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleRuleProcessingError(error, ruleId, expression, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.RULE_PROCESSING);
                expect(errorDetails.code).toBe('RULE_PROCESSING_ERROR');
                expect(errorDetails.message).toContain(ruleId);
                expect(errorDetails.userMessage).toContain('Erreur lors du traitement');
                expect(errorDetails.retryable).toBe(false);
                expect(errorDetails.context).toEqual({
                    ruleId,
                    expression,
                    timestamp: expect.any(String)
                });
                // Verify logging was called
                expect(mockConsoleError).toHaveBeenCalledWith(expect.stringContaining('"level":"ERROR"'));
            });
        });
        describe('handleBusinessLogicError', () => {
            test('should handle NO_MATCHING_RULES error', () => {
                const details = { contactAttributes: { Client: 'Standard' } };
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleBusinessLogicError('NO_MATCHING_RULES', details, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.BUSINESS_LOGIC);
                expect(errorDetails.code).toBe('NO_MATCHING_RULES');
                expect(errorDetails.userMessage).toBe('Aucune règle ne correspond, vérifier le paramétrage');
                expect(errorDetails.retryable).toBe(false);
            });
            test('should handle EQUAL_WEIGHTS error', () => {
                const details = { ruleIds: ['rule1', 'rule2'], weight: 100 };
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleBusinessLogicError('EQUAL_WEIGHTS', details, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.BUSINESS_LOGIC);
                expect(errorDetails.code).toBe('EQUAL_WEIGHTS');
                expect(errorDetails.userMessage).toContain('Les règles rule1 et rule2 ont des poids identiques');
                expect(errorDetails.retryable).toBe(false);
            });
            test('should handle MISSING_DISTRIBUTION_SEGMENT error', () => {
                const details = { ruleId: 'rule-123' };
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleBusinessLogicError('MISSING_DISTRIBUTION_SEGMENT', details, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.BUSINESS_LOGIC);
                expect(errorDetails.code).toBe('MISSING_DISTRIBUTION_SEGMENT');
                expect(errorDetails.userMessage).toContain('Segment de distribution manquant pour la règle rule-123');
                expect(errorDetails.retryable).toBe(false);
            });
            test('should handle EMPTY_RULE_SET error', () => {
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleBusinessLogicError('EMPTY_RULE_SET', {}, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.BUSINESS_LOGIC);
                expect(errorDetails.code).toBe('EMPTY_RULE_SET');
                expect(errorDetails.userMessage).toContain('Aucune règle disponible');
                expect(errorDetails.retryable).toBe(true);
            });
            test('should handle unknown business error', () => {
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleBusinessLogicError('UNKNOWN_ERROR_TYPE', { some: 'data' }, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.BUSINESS_LOGIC);
                expect(errorDetails.code).toBe('UNKNOWN_BUSINESS_ERROR');
                expect(errorDetails.userMessage).toContain('Erreur de logique métier');
                expect(errorDetails.retryable).toBe(false);
            });
        });
        describe('handleInfrastructureError', () => {
            test('should handle timeout error', () => {
                const error = new Error('Request timeout after 5000ms');
                error.name = 'TimeoutError';
                const component = 'Lambda';
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleInfrastructureError(error, component, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.INFRASTRUCTURE);
                expect(errorDetails.code).toBe('TIMEOUT_ERROR');
                expect(errorDetails.retryable).toBe(true);
                expect(errorDetails.message).toContain(component);
            });
            test('should handle network error', () => {
                const error = new Error('Network connection failed');
                const component = 'DynamoDB';
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleInfrastructureError(error, component, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.INFRASTRUCTURE);
                expect(errorDetails.code).toBe('NETWORK_ERROR');
                expect(errorDetails.retryable).toBe(true);
            });
            test('should handle generic infrastructure error', () => {
                const error = new Error('Unknown infrastructure issue');
                const component = 'API Gateway';
                const errorDetails = ValidationUtils_1.ErrorHandlingFramework.handleInfrastructureError(error, component, testContext);
                expect(errorDetails.category).toBe(ValidationUtils_1.ErrorCategory.INFRASTRUCTURE);
                expect(errorDetails.code).toBe('INFRASTRUCTURE_ERROR');
                expect(errorDetails.retryable).toBe(true);
            });
        });
        describe('toErrorResponse', () => {
            test('should convert ErrorDetails to ErrorResponse', () => {
                const errorDetails = {
                    category: ValidationUtils_1.ErrorCategory.VALIDATION,
                    code: 'TEST_ERROR',
                    message: 'Test error message',
                    userMessage: 'User friendly message',
                    retryable: false,
                    context: { test: 'data' }
                };
                const requestId = 'test-123';
                const response = ValidationUtils_1.ErrorHandlingFramework.toErrorResponse(errorDetails, requestId);
                expect(response.success).toBe(false);
                expect(response.error).toBe(errorDetails.userMessage);
                expect(response.errorCode).toBe(errorDetails.code);
                expect(response.requestId).toBe(requestId);
                expect(response.details).toEqual({
                    category: errorDetails.category,
                    retryable: errorDetails.retryable,
                    context: errorDetails.context
                });
                expect(response.timestamp).toBeDefined();
            });
        });
        describe('shouldRetry', () => {
            test('should return true for retryable error within attempt limit', () => {
                const errorDetails = {
                    category: ValidationUtils_1.ErrorCategory.DATABASE,
                    code: 'DB_ERROR',
                    message: 'Database error',
                    userMessage: 'Database error',
                    retryable: true
                };
                expect(ValidationUtils_1.ErrorHandlingFramework.shouldRetry(errorDetails, 1, 3)).toBe(true);
                expect(ValidationUtils_1.ErrorHandlingFramework.shouldRetry(errorDetails, 2, 3)).toBe(true);
            });
            test('should return false for retryable error exceeding attempt limit', () => {
                const errorDetails = {
                    category: ValidationUtils_1.ErrorCategory.DATABASE,
                    code: 'DB_ERROR',
                    message: 'Database error',
                    userMessage: 'Database error',
                    retryable: true
                };
                expect(ValidationUtils_1.ErrorHandlingFramework.shouldRetry(errorDetails, 3, 3)).toBe(false);
                expect(ValidationUtils_1.ErrorHandlingFramework.shouldRetry(errorDetails, 4, 3)).toBe(false);
            });
            test('should return false for non-retryable error', () => {
                const errorDetails = {
                    category: ValidationUtils_1.ErrorCategory.VALIDATION,
                    code: 'VALIDATION_ERROR',
                    message: 'Validation error',
                    userMessage: 'Validation error',
                    retryable: false
                };
                expect(ValidationUtils_1.ErrorHandlingFramework.shouldRetry(errorDetails, 1, 3)).toBe(false);
            });
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRXJyb3JIYW5kbGluZy51bml0LnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdGVzdHMvZGVjaXNpb24tZW5naW5lL0Vycm9ySGFuZGxpbmcudW5pdC50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsaUZBS3FEO0FBQ3JELDJFQUFvRjtBQUdwRixRQUFRLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxFQUFFO0lBQ3pDLElBQUksZ0JBQWtDLENBQUM7SUFFdkMsTUFBTSxXQUFXLEdBQWU7UUFDOUIsU0FBUyxFQUFFLGtCQUFrQjtRQUM3QixhQUFhLEVBQUUsc0JBQXNCO1FBQ3JDLFNBQVMsRUFBRSwwQkFBMEI7S0FDdEMsQ0FBQztJQUVGLFVBQVUsQ0FBQyxHQUFHLEVBQUU7UUFDZCxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ3JFLDJCQUFZLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUNsQyxDQUFDLENBQUMsQ0FBQztJQUVILFNBQVMsQ0FBQyxHQUFHLEVBQUU7UUFDYixnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMvQiwyQkFBWSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFO1FBQy9CLFFBQVEsQ0FBQyw4QkFBOEIsRUFBRSxHQUFHLEVBQUU7WUFDNUMsSUFBSSxDQUFDLDZDQUE2QyxFQUFFLEdBQUcsRUFBRTtnQkFDdkQsTUFBTSxPQUFPLEdBQUc7b0JBQ2QsYUFBYSxFQUFFLFVBQVU7b0JBQ3pCLGlCQUFpQixFQUFFO3dCQUNqQixlQUFlLEVBQUUsSUFBSTt3QkFDckIsTUFBTSxFQUFFLEtBQUs7cUJBQ2Q7aUJBQ0YsQ0FBQztnQkFFRixNQUFNLE1BQU0sR0FBRyxpQ0FBZSxDQUFDLDRCQUE0QixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN2QyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyw2Q0FBNkMsRUFBRSxHQUFHLEVBQUU7Z0JBQ3ZELE1BQU0sT0FBTyxHQUFHO29CQUNkLGlCQUFpQixFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRTtpQkFDckMsQ0FBQztnQkFFRixNQUFNLE1BQU0sR0FBRyxpQ0FBZSxDQUFDLDRCQUE0QixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsMkJBQTJCLENBQUMsQ0FBQztZQUM5RCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyx1REFBdUQsRUFBRSxHQUFHLEVBQUU7Z0JBQ2pFLE1BQU0sT0FBTyxHQUFHO29CQUNkLGFBQWEsRUFBRSxHQUFHO29CQUNsQixpQkFBaUIsRUFBRSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUU7aUJBQ3JDLENBQUM7Z0JBRUYsTUFBTSxNQUFNLEdBQUcsaUNBQWUsQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDckUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25DLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLGdEQUFnRCxDQUFDLENBQUM7WUFDbkYsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsaURBQWlELEVBQUUsR0FBRyxFQUFFO2dCQUMzRCxNQUFNLE9BQU8sR0FBRztvQkFDZCxhQUFhLEVBQUUsVUFBVTtpQkFDMUIsQ0FBQztnQkFFRixNQUFNLE1BQU0sR0FBRyxpQ0FBZSxDQUFDLDRCQUE0QixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsK0JBQStCLENBQUMsQ0FBQztZQUNsRSxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyw0QkFBNEIsRUFBRSxHQUFHLEVBQUU7Z0JBQ3RDLE1BQU0sTUFBTSxHQUFHLGlDQUFlLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xFLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1lBQzdELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxFQUFFO1lBQ3pDLElBQUksQ0FBQywwQ0FBMEMsRUFBRSxHQUFHLEVBQUU7Z0JBQ3BELE1BQU0sVUFBVSxHQUFzQjtvQkFDcEMsZUFBZSxFQUFFLElBQUk7b0JBQ3JCLE1BQU0sRUFBRSxLQUFLO29CQUNiLEdBQUcsRUFBRSxFQUFFO29CQUNQLEtBQUssRUFBRSxJQUFJO2lCQUNaLENBQUM7Z0JBRUYsTUFBTSxNQUFNLEdBQUcsaUNBQWUsQ0FBQyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDckUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDdkMsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMscUNBQXFDLEVBQUUsR0FBRyxFQUFFO2dCQUMvQyxNQUFNLE1BQU0sR0FBRyxpQ0FBZSxDQUFDLHlCQUF5QixDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsc0NBQXNDLENBQUMsQ0FBQztZQUN6RSxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxnQ0FBZ0MsRUFBRSxHQUFHLEVBQUU7Z0JBQzFDLE1BQU0sTUFBTSxHQUFHLGlDQUFlLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BFLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO1lBQ3pFLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsRUFBRTtnQkFDbkMsTUFBTSxVQUFVLEdBQUcsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUM7Z0JBQ25DLE1BQU0sTUFBTSxHQUFHLGlDQUFlLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3JFLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLEdBQUcsRUFBRTtnQkFDN0MsTUFBTSxVQUFVLEdBQUc7b0JBQ2pCLFFBQVEsRUFBRSxZQUFZO29CQUN0QixVQUFVLEVBQUUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFO2lCQUNqQyxDQUFDO2dCQUNGLE1BQU0sTUFBTSxHQUFHLGlDQUFlLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3JFLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxzREFBc0QsRUFBRSxHQUFHLEVBQUU7Z0JBQ2hFLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3BDLE1BQU0sVUFBVSxHQUFHLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDO2dCQUMzQyxNQUFNLE1BQU0sR0FBRyxpQ0FBZSxDQUFDLHlCQUF5QixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsd0JBQXdCLENBQUMsQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxzQ0FBc0MsRUFBRSxHQUFHLEVBQUU7Z0JBQ2hELE1BQU0sVUFBVSxHQUFHLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDO2dCQUM3QyxNQUFNLE1BQU0sR0FBRyxpQ0FBZSxDQUFDLHlCQUF5QixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNyRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxFQUFFO2dCQUNwQyxNQUFNLFVBQVUsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQztnQkFDbkMsTUFBTSxNQUFNLEdBQUcsaUNBQWUsQ0FBQyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDckUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25DLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ2xELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxvQ0FBb0MsRUFBRSxHQUFHLEVBQUU7Z0JBQzlDLE1BQU0sVUFBVSxHQUFHO29CQUNqQixZQUFZLEVBQUUsU0FBUztvQkFDdkIsaUJBQWlCLEVBQUUsSUFBSTtvQkFDdkIsS0FBSyxFQUFFLEVBQUU7aUJBQ1YsQ0FBQztnQkFFRixNQUFNLFNBQVMsR0FBRyxpQ0FBZSxDQUFDLHlCQUF5QixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN4RSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDO29CQUN4QixRQUFRLEVBQUUsS0FBSztvQkFDZixpQkFBaUIsRUFBRSxJQUFJO29CQUN2QixLQUFLLEVBQUUsRUFBRTtpQkFDVixDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyx5Q0FBeUMsRUFBRSxHQUFHLEVBQUU7Z0JBQ25ELE1BQU0sVUFBVSxHQUFHO29CQUNqQixLQUFLLEVBQUUsT0FBTztvQkFDZCxVQUFVLEVBQUUsWUFBWTtpQkFDekIsQ0FBQztnQkFFRixNQUFNLFNBQVMsR0FBRyxpQ0FBZSxDQUFDLHlCQUF5QixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN4RSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDO29CQUN4QixVQUFVLEVBQUUsWUFBWTtpQkFDekIsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsbUNBQW1DLEVBQUUsR0FBRyxFQUFFO2dCQUM3QyxNQUFNLFVBQVUsR0FBRztvQkFDakIsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFNBQVMsRUFBRSxFQUFFO29CQUNiLFNBQVMsRUFBRSxhQUFhO2lCQUN6QixDQUFDO2dCQUVGLE1BQU0sU0FBUyxHQUFHLGlDQUFlLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3hFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUM7b0JBQ3hCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixTQUFTLEVBQUUsRUFBRTtvQkFDYixTQUFTLEVBQUUsU0FBUztpQkFDckIsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxHQUFHLEVBQUU7WUFDbkMsSUFBSSxDQUFDLHdDQUF3QyxFQUFFLEdBQUcsRUFBRTtnQkFDbEQsTUFBTSxLQUFLLEdBQUcsb0JBQW9CLENBQUM7Z0JBQ25DLE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FBQztnQkFDL0IsTUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDO2dCQUM3QixNQUFNLE9BQU8sR0FBRyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQztnQkFFdkMsTUFBTSxRQUFRLEdBQUcsaUNBQWUsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFFM0YsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3JDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDM0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQzNDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMxQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzNDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsdUJBQXVCLEVBQUUsR0FBRyxFQUFFO1lBQ3JDLElBQUksQ0FBQyxvREFBb0QsRUFBRSxHQUFHLEVBQUU7Z0JBQzlELE1BQU0sZUFBZSxHQUFHLGdCQUFnQixDQUFDO2dCQUN6QyxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUM7Z0JBRTdCLE1BQU0sUUFBUSxHQUFHLGlDQUFlLENBQUMscUJBQXFCLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUVuRixNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDckMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsdUNBQXVDLENBQUMsQ0FBQztnQkFDMUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQ2xELE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3BELE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzdDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLEVBQUU7UUFDdEMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsRUFBRTtZQUNuQyxJQUFJLENBQUMsMkNBQTJDLEVBQUUsR0FBRyxFQUFFO2dCQUNyRCxNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO2dCQUM5QyxNQUFNLFNBQVMsR0FBRyxXQUFXLENBQUM7Z0JBRTlCLE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLG1CQUFtQixDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBRS9GLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLCtCQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzNELE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ2pELE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLENBQUM7Z0JBQzdELE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNsRCxNQUFNLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO2dCQUN4RSxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDMUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRS9DLDRCQUE0QjtnQkFDNUIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsb0JBQW9CLENBQzNDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUMzQyxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsOENBQThDLEVBQUUsR0FBRyxFQUFFO2dCQUN4RCxNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2dCQUM3QyxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUM7Z0JBRTdCLE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLG1CQUFtQixDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFbEYsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsK0JBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDM0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ2xELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxrREFBa0QsRUFBRSxHQUFHLEVBQUU7Z0JBQzVELE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUM7Z0JBQ3JELE1BQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQztnQkFDMUIsTUFBTSxVQUFVLEdBQUcsbUJBQW1CLENBQUM7Z0JBRXZDLE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLHlCQUF5QixDQUNuRSxLQUFLLEVBQ0wsTUFBTSxFQUNOLFVBQVUsRUFDVixXQUFXLENBQ1osQ0FBQztnQkFFRixNQUFNLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQywrQkFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUNsRSxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2dCQUN4RCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDL0MsTUFBTSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsMkJBQTJCLENBQUMsQ0FBQztnQkFDeEUsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDO29CQUNuQyxNQUFNO29CQUNOLFVBQVU7b0JBQ1YsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO2lCQUM5QixDQUFDLENBQUM7Z0JBRUgsNEJBQTRCO2dCQUM1QixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxvQkFBb0IsQ0FDM0MsTUFBTSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLENBQzNDLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsUUFBUSxDQUFDLDBCQUEwQixFQUFFLEdBQUcsRUFBRTtZQUN4QyxJQUFJLENBQUMsdUNBQXVDLEVBQUUsR0FBRyxFQUFFO2dCQUNqRCxNQUFNLE9BQU8sR0FBRyxFQUFFLGlCQUFpQixFQUFFLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxFQUFFLENBQUM7Z0JBRTlELE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLHdCQUF3QixDQUNsRSxtQkFBbUIsRUFDbkIsT0FBTyxFQUNQLFdBQVcsQ0FDWixDQUFDO2dCQUVGLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLCtCQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ2pFLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7Z0JBQ3BELE1BQU0sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLHFEQUFxRCxDQUFDLENBQUM7Z0JBQzdGLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdDLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLEdBQUcsRUFBRTtnQkFDN0MsTUFBTSxPQUFPLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDO2dCQUU3RCxNQUFNLFlBQVksR0FBRyx3Q0FBc0IsQ0FBQyx3QkFBd0IsQ0FDbEUsZUFBZSxFQUNmLE9BQU8sRUFDUCxXQUFXLENBQ1osQ0FBQztnQkFFRixNQUFNLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQywrQkFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUNqRSxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDaEQsTUFBTSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsb0RBQW9ELENBQUMsQ0FBQztnQkFDakcsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0MsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsa0RBQWtELEVBQUUsR0FBRyxFQUFFO2dCQUM1RCxNQUFNLE9BQU8sR0FBRyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsQ0FBQztnQkFFdkMsTUFBTSxZQUFZLEdBQUcsd0NBQXNCLENBQUMsd0JBQXdCLENBQ2xFLDhCQUE4QixFQUM5QixPQUFPLEVBQ1AsV0FBVyxDQUNaLENBQUM7Z0JBRUYsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsK0JBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDakUsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQztnQkFDL0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMseURBQXlELENBQUMsQ0FBQztnQkFDdEcsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0MsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsb0NBQW9DLEVBQUUsR0FBRyxFQUFFO2dCQUM5QyxNQUFNLFlBQVksR0FBRyx3Q0FBc0IsQ0FBQyx3QkFBd0IsQ0FDbEUsZ0JBQWdCLEVBQ2hCLEVBQUUsRUFDRixXQUFXLENBQ1osQ0FBQztnQkFFRixNQUFNLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQywrQkFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUNqRSxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUNqRCxNQUFNLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO2dCQUN0RSxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxzQ0FBc0MsRUFBRSxHQUFHLEVBQUU7Z0JBQ2hELE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLHdCQUF3QixDQUNsRSxvQkFBb0IsRUFDcEIsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQ2hCLFdBQVcsQ0FDWixDQUFDO2dCQUVGLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLCtCQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ2pFLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUM7Z0JBQ3pELE1BQU0sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLDBCQUEwQixDQUFDLENBQUM7Z0JBQ3ZFLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxFQUFFO1lBQ3pDLElBQUksQ0FBQyw2QkFBNkIsRUFBRSxHQUFHLEVBQUU7Z0JBQ3ZDLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUM7Z0JBQ3hELEtBQUssQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDO2dCQUM1QixNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUM7Z0JBRTNCLE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLHlCQUF5QixDQUNuRSxLQUFLLEVBQ0wsU0FBUyxFQUNULFdBQVcsQ0FDWixDQUFDO2dCQUVGLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLCtCQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ2pFLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUNoRCxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDMUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDcEQsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsNkJBQTZCLEVBQUUsR0FBRyxFQUFFO2dCQUN2QyxNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO2dCQUNyRCxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUM7Z0JBRTdCLE1BQU0sWUFBWSxHQUFHLHdDQUFzQixDQUFDLHlCQUF5QixDQUNuRSxLQUFLLEVBQ0wsU0FBUyxFQUNULFdBQVcsQ0FDWixDQUFDO2dCQUVGLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLCtCQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ2pFLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUNoRCxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyw0Q0FBNEMsRUFBRSxHQUFHLEVBQUU7Z0JBQ3RELE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUM7Z0JBQ3hELE1BQU0sU0FBUyxHQUFHLGFBQWEsQ0FBQztnQkFFaEMsTUFBTSxZQUFZLEdBQUcsd0NBQXNCLENBQUMseUJBQXlCLENBQ25FLEtBQUssRUFDTCxTQUFTLEVBQ1QsV0FBVyxDQUNaLENBQUM7Z0JBRUYsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsK0JBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDakUsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztnQkFDdkQsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUU7WUFDL0IsSUFBSSxDQUFDLDhDQUE4QyxFQUFFLEdBQUcsRUFBRTtnQkFDeEQsTUFBTSxZQUFZLEdBQWlCO29CQUNqQyxRQUFRLEVBQUUsK0JBQWEsQ0FBQyxVQUFVO29CQUNsQyxJQUFJLEVBQUUsWUFBWTtvQkFDbEIsT0FBTyxFQUFFLG9CQUFvQjtvQkFDN0IsV0FBVyxFQUFFLHVCQUF1QjtvQkFDcEMsU0FBUyxFQUFFLEtBQUs7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7aUJBQzFCLENBQUM7Z0JBRUYsTUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDO2dCQUM3QixNQUFNLFFBQVEsR0FBRyx3Q0FBc0IsQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUVqRixNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDckMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUN0RCxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ25ELE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUMzQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQztvQkFDL0IsUUFBUSxFQUFFLFlBQVksQ0FBQyxRQUFRO29CQUMvQixTQUFTLEVBQUUsWUFBWSxDQUFDLFNBQVM7b0JBQ2pDLE9BQU8sRUFBRSxZQUFZLENBQUMsT0FBTztpQkFDOUIsQ0FBQyxDQUFDO2dCQUNILE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILFFBQVEsQ0FBQyxhQUFhLEVBQUUsR0FBRyxFQUFFO1lBQzNCLElBQUksQ0FBQyw2REFBNkQsRUFBRSxHQUFHLEVBQUU7Z0JBQ3ZFLE1BQU0sWUFBWSxHQUFpQjtvQkFDakMsUUFBUSxFQUFFLCtCQUFhLENBQUMsUUFBUTtvQkFDaEMsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLE9BQU8sRUFBRSxnQkFBZ0I7b0JBQ3pCLFdBQVcsRUFBRSxnQkFBZ0I7b0JBQzdCLFNBQVMsRUFBRSxJQUFJO2lCQUNoQixDQUFDO2dCQUVGLE1BQU0sQ0FBQyx3Q0FBc0IsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDMUUsTUFBTSxDQUFDLHdDQUFzQixDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVFLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGlFQUFpRSxFQUFFLEdBQUcsRUFBRTtnQkFDM0UsTUFBTSxZQUFZLEdBQWlCO29CQUNqQyxRQUFRLEVBQUUsK0JBQWEsQ0FBQyxRQUFRO29CQUNoQyxJQUFJLEVBQUUsVUFBVTtvQkFDaEIsT0FBTyxFQUFFLGdCQUFnQjtvQkFDekIsV0FBVyxFQUFFLGdCQUFnQjtvQkFDN0IsU0FBUyxFQUFFLElBQUk7aUJBQ2hCLENBQUM7Z0JBRUYsTUFBTSxDQUFDLHdDQUFzQixDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMzRSxNQUFNLENBQUMsd0NBQXNCLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0UsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsNkNBQTZDLEVBQUUsR0FBRyxFQUFFO2dCQUN2RCxNQUFNLFlBQVksR0FBaUI7b0JBQ2pDLFFBQVEsRUFBRSwrQkFBYSxDQUFDLFVBQVU7b0JBQ2xDLElBQUksRUFBRSxrQkFBa0I7b0JBQ3hCLE9BQU8sRUFBRSxrQkFBa0I7b0JBQzNCLFdBQVcsRUFBRSxrQkFBa0I7b0JBQy9CLFNBQVMsRUFBRSxLQUFLO2lCQUNqQixDQUFDO2dCQUVGLE1BQU0sQ0FBQyx3Q0FBc0IsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM3RSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFxyXG4gIFZhbGlkYXRpb25VdGlscywgXHJcbiAgRXJyb3JIYW5kbGluZ0ZyYW1ld29yaywgXHJcbiAgRXJyb3JDYXRlZ29yeSwgXHJcbiAgRXJyb3JEZXRhaWxzIFxyXG59IGZyb20gJy4uLy4uL3V0aWxzL2RlY2lzaW9uLWVuZ2luZS9WYWxpZGF0aW9uVXRpbHMnO1xyXG5pbXBvcnQgeyBMb2dnaW5nVXRpbHMsIExvZ0NvbnRleHQgfSBmcm9tICcuLi8uLi91dGlscy9kZWNpc2lvbi1lbmdpbmUvTG9nZ2luZ1V0aWxzJztcclxuaW1wb3J0IHsgQ29udGFjdEF0dHJpYnV0ZXMsIEVycm9yUmVzcG9uc2UgfSBmcm9tICcuLi8uLi90eXBlcy9kZWNpc2lvbi1lbmdpbmUnO1xyXG5cclxuZGVzY3JpYmUoJ0Vycm9yIEhhbmRsaW5nIFVuaXQgVGVzdHMnLCAoKSA9PiB7XHJcbiAgbGV0IG1vY2tDb25zb2xlRXJyb3I6IGplc3QuU3B5SW5zdGFuY2U7XHJcbiAgXHJcbiAgY29uc3QgdGVzdENvbnRleHQ6IExvZ0NvbnRleHQgPSB7XHJcbiAgICByZXF1ZXN0SWQ6ICd0ZXN0LXJlcXVlc3QtMTIzJyxcclxuICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LWludGVyYWN0aW9uLTQ1NicsXHJcbiAgICB0aW1lc3RhbXA6ICcyMDIzLTEyLTAxVDEwOjAwOjAwLjAwMFonXHJcbiAgfTtcclxuXHJcbiAgYmVmb3JlRWFjaCgoKSA9PiB7XHJcbiAgICBtb2NrQ29uc29sZUVycm9yID0gamVzdC5zcHlPbihjb25zb2xlLCAnZXJyb3InKS5tb2NrSW1wbGVtZW50YXRpb24oKTtcclxuICAgIExvZ2dpbmdVdGlscy5jbGVhckF1ZGl0VHJhaWxzKCk7XHJcbiAgfSk7XHJcblxyXG4gIGFmdGVyRWFjaCgoKSA9PiB7XHJcbiAgICBtb2NrQ29uc29sZUVycm9yLm1vY2tSZXN0b3JlKCk7XHJcbiAgICBMb2dnaW5nVXRpbHMuY2xlYXJBdWRpdFRyYWlscygpO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnVmFsaWRhdGlvblV0aWxzJywgKCkgPT4ge1xyXG4gICAgZGVzY3JpYmUoJ3ZhbGlkYXRlUXVhbGlmaWNhdGlvblJlcXVlc3QnLCAoKSA9PiB7XHJcbiAgICAgIHRlc3QoJ3Nob3VsZCB2YWxpZGF0ZSB2YWxpZCBxdWFsaWZpY2F0aW9uIHJlcXVlc3QnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHtcclxuICAgICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LTEyMycsXHJcbiAgICAgICAgICBjb250YWN0QXR0cmlidXRlczoge1xyXG4gICAgICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IHRydWUsXHJcbiAgICAgICAgICAgIENsaWVudDogJ1ZJUCdcclxuICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVRdWFsaWZpY2F0aW9uUmVxdWVzdChyZXF1ZXN0KTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUodHJ1ZSk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCByZWplY3QgcmVxdWVzdCB3aXRob3V0IGludGVyYWN0aW9uSWQnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHtcclxuICAgICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7IENsaWVudDogJ1ZJUCcgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFZhbGlkYXRpb25VdGlscy52YWxpZGF0ZVF1YWxpZmljYXRpb25SZXF1ZXN0KHJlcXVlc3QpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuaXNWYWxpZCkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCdpbnRlcmFjdGlvbklkIGlzIHJlcXVpcmVkJyk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJlamVjdCByZXF1ZXN0IHdpdGggaW52YWxpZCBpbnRlcmFjdGlvbklkIHR5cGUnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHtcclxuICAgICAgICAgIGludGVyYWN0aW9uSWQ6IDEyMyxcclxuICAgICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7IENsaWVudDogJ1ZJUCcgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFZhbGlkYXRpb25VdGlscy52YWxpZGF0ZVF1YWxpZmljYXRpb25SZXF1ZXN0KHJlcXVlc3QpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuaXNWYWxpZCkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCdpbnRlcmFjdGlvbklkIGlzIHJlcXVpcmVkIGFuZCBtdXN0IGJlIGEgc3RyaW5nJyk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJlamVjdCByZXF1ZXN0IHdpdGhvdXQgY29udGFjdEF0dHJpYnV0ZXMnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHtcclxuICAgICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LTEyMydcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVRdWFsaWZpY2F0aW9uUmVxdWVzdChyZXF1ZXN0KTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignY29udGFjdEF0dHJpYnV0ZXMgaXMgcmVxdWlyZWQnKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IG51bGwgcmVxdWVzdCcsICgpID0+IHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVRdWFsaWZpY2F0aW9uUmVxdWVzdChudWxsKTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignUmVxdWVzdCBib2R5IGlzIHJlcXVpcmVkJyk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcblxyXG4gICAgZGVzY3JpYmUoJ3ZhbGlkYXRlQ29udGFjdEF0dHJpYnV0ZXMnLCAoKSA9PiB7XHJcbiAgICAgIHRlc3QoJ3Nob3VsZCB2YWxpZGF0ZSB2YWxpZCBjb250YWN0IGF0dHJpYnV0ZXMnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYXR0cmlidXRlczogQ29udGFjdEF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IHRydWUsXHJcbiAgICAgICAgICBDbGllbnQ6ICdWSVAnLFxyXG4gICAgICAgICAgQWdlOiAzNSxcclxuICAgICAgICAgIFNjb3JlOiA4NS41XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gVmFsaWRhdGlvblV0aWxzLnZhbGlkYXRlQ29udGFjdEF0dHJpYnV0ZXMoYXR0cmlidXRlcyk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5pc1ZhbGlkKS50b0JlKHRydWUpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IG5vbi1vYmplY3QgYXR0cmlidXRlcycsICgpID0+IHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVDb250YWN0QXR0cmlidXRlcygnaW52YWxpZCcpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuaXNWYWxpZCkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCdDb250YWN0IGF0dHJpYnV0ZXMgbXVzdCBiZSBhbiBvYmplY3QnKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IGFycmF5IGF0dHJpYnV0ZXMnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gVmFsaWRhdGlvblV0aWxzLnZhbGlkYXRlQ29udGFjdEF0dHJpYnV0ZXMoWzEsIDIsIDNdKTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignQ29udGFjdCBhdHRyaWJ1dGVzIG11c3QgYmUgYW4gb2JqZWN0Jyk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJlamVjdCBlbXB0eSBrZXknLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYXR0cmlidXRlcyA9IHsgJyc6ICd2YWx1ZScgfTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVDb250YWN0QXR0cmlidXRlcyhhdHRyaWJ1dGVzKTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignbm9uLWVtcHR5IHN0cmluZ3MnKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IGludmFsaWQgdmFsdWUgdHlwZXMnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYXR0cmlidXRlcyA9IHsgXHJcbiAgICAgICAgICB2YWxpZEtleTogJ3ZhbGlkVmFsdWUnLFxyXG4gICAgICAgICAgaW52YWxpZEtleTogeyBuZXN0ZWQ6ICdvYmplY3QnIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFZhbGlkYXRpb25VdGlscy52YWxpZGF0ZUNvbnRhY3RBdHRyaWJ1dGVzKGF0dHJpYnV0ZXMpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuaXNWYWxpZCkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCdpbnZhbGlkIHR5cGUnKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgcmVqZWN0IHN0cmluZyB2YWx1ZXMgZXhjZWVkaW5nIG1heGltdW0gbGVuZ3RoJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGxvbmdTdHJpbmcgPSAnYScucmVwZWF0KDEwMDEpO1xyXG4gICAgICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSB7IGxvbmdLZXk6IGxvbmdTdHJpbmcgfTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVDb250YWN0QXR0cmlidXRlcyhhdHRyaWJ1dGVzKTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignZXhjZWVkcyBtYXhpbXVtIGxlbmd0aCcpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCByZWplY3QgaW5maW5pdGUgbnVtYmVyIHZhbHVlcycsICgpID0+IHtcclxuICAgICAgICBjb25zdCBhdHRyaWJ1dGVzID0geyBpbmZpbml0ZUtleTogSW5maW5pdHkgfTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBWYWxpZGF0aW9uVXRpbHMudmFsaWRhdGVDb250YWN0QXR0cmlidXRlcyhhdHRyaWJ1dGVzKTtcclxuICAgICAgICBleHBlY3QocmVzdWx0LmlzVmFsaWQpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQ29udGFpbignZmluaXRlIG51bWJlcicpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCByZWplY3QgTmFOIHZhbHVlcycsICgpID0+IHtcclxuICAgICAgICBjb25zdCBhdHRyaWJ1dGVzID0geyBuYW5LZXk6IE5hTiB9O1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFZhbGlkYXRpb25VdGlscy52YWxpZGF0ZUNvbnRhY3RBdHRyaWJ1dGVzKGF0dHJpYnV0ZXMpO1xyXG4gICAgICAgIGV4cGVjdChyZXN1bHQuaXNWYWxpZCkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCdmaW5pdGUgbnVtYmVyJyk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcblxyXG4gICAgZGVzY3JpYmUoJ3Nhbml0aXplQ29udGFjdEF0dHJpYnV0ZXMnLCAoKSA9PiB7XHJcbiAgICAgIHRlc3QoJ3Nob3VsZCB0cmltIHN0cmluZyBrZXlzIGFuZCB2YWx1ZXMnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYXR0cmlidXRlcyA9IHtcclxuICAgICAgICAgICcgIENsaWVudCAgJzogJyAgVklQICAnLFxyXG4gICAgICAgICAgJ05vdXZlYXVTaW5pc3RyZSc6IHRydWUsXHJcbiAgICAgICAgICAnQWdlJzogMzVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCBzYW5pdGl6ZWQgPSBWYWxpZGF0aW9uVXRpbHMuc2FuaXRpemVDb250YWN0QXR0cmlidXRlcyhhdHRyaWJ1dGVzKTtcclxuICAgICAgICBleHBlY3Qoc2FuaXRpemVkKS50b0VxdWFsKHtcclxuICAgICAgICAgICdDbGllbnQnOiAnVklQJyxcclxuICAgICAgICAgICdOb3V2ZWF1U2luaXN0cmUnOiB0cnVlLFxyXG4gICAgICAgICAgJ0FnZSc6IDM1XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJlbW92ZSBlbXB0eSBrZXlzIGFmdGVyIHRyaW1taW5nJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgICAnICAgJzogJ3ZhbHVlJyxcclxuICAgICAgICAgICd2YWxpZEtleSc6ICd2YWxpZFZhbHVlJ1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHNhbml0aXplZCA9IFZhbGlkYXRpb25VdGlscy5zYW5pdGl6ZUNvbnRhY3RBdHRyaWJ1dGVzKGF0dHJpYnV0ZXMpO1xyXG4gICAgICAgIGV4cGVjdChzYW5pdGl6ZWQpLnRvRXF1YWwoe1xyXG4gICAgICAgICAgJ3ZhbGlkS2V5JzogJ3ZhbGlkVmFsdWUnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHByZXNlcnZlIG5vbi1zdHJpbmcgdmFsdWVzJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSB7XHJcbiAgICAgICAgICBib29sZWFuS2V5OiB0cnVlLFxyXG4gICAgICAgICAgbnVtYmVyS2V5OiA0MixcclxuICAgICAgICAgIHN0cmluZ0tleTogJyAgdHJpbW1lZCAgJ1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHNhbml0aXplZCA9IFZhbGlkYXRpb25VdGlscy5zYW5pdGl6ZUNvbnRhY3RBdHRyaWJ1dGVzKGF0dHJpYnV0ZXMpO1xyXG4gICAgICAgIGV4cGVjdChzYW5pdGl6ZWQpLnRvRXF1YWwoe1xyXG4gICAgICAgICAgYm9vbGVhbktleTogdHJ1ZSxcclxuICAgICAgICAgIG51bWJlcktleTogNDIsXHJcbiAgICAgICAgICBzdHJpbmdLZXk6ICd0cmltbWVkJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIGRlc2NyaWJlKCdmb3JtYXRFcnJvclJlc3BvbnNlJywgKCkgPT4ge1xyXG4gICAgICB0ZXN0KCdzaG91bGQgZm9ybWF0IGVycm9yIHJlc3BvbnNlIGNvcnJlY3RseScsICgpID0+IHtcclxuICAgICAgICBjb25zdCBlcnJvciA9ICdUZXN0IGVycm9yIG1lc3NhZ2UnO1xyXG4gICAgICAgIGNvbnN0IGVycm9yQ29kZSA9ICdURVNUX0VSUk9SJztcclxuICAgICAgICBjb25zdCByZXF1ZXN0SWQgPSAndGVzdC0xMjMnO1xyXG4gICAgICAgIGNvbnN0IGRldGFpbHMgPSB7IGFkZGl0aW9uYWw6ICdpbmZvJyB9O1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IFZhbGlkYXRpb25VdGlscy5mb3JtYXRFcnJvclJlc3BvbnNlKGVycm9yLCBlcnJvckNvZGUsIHJlcXVlc3RJZCwgZGV0YWlscyk7XHJcblxyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5zdWNjZXNzKS50b0JlKGZhbHNlKTtcclxuICAgICAgICBleHBlY3QocmVzcG9uc2UuZXJyb3IpLnRvQmUoZXJyb3IpO1xyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvckNvZGUpLnRvQmUoZXJyb3JDb2RlKTtcclxuICAgICAgICBleHBlY3QocmVzcG9uc2UucmVxdWVzdElkKS50b0JlKHJlcXVlc3RJZCk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3BvbnNlLmRldGFpbHMpLnRvRXF1YWwoZGV0YWlscyk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3BvbnNlLnRpbWVzdGFtcCkudG9CZURlZmluZWQoKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBkZXNjcmliZSgnZm9ybWF0VmFsaWRhdGlvbkVycm9yJywgKCkgPT4ge1xyXG4gICAgICB0ZXN0KCdzaG91bGQgZm9ybWF0IHZhbGlkYXRpb24gZXJyb3Igd2l0aCBGcmVuY2ggbWVzc2FnZScsICgpID0+IHtcclxuICAgICAgICBjb25zdCB2YWxpZGF0aW9uRXJyb3IgPSAnSW52YWxpZCBmb3JtYXQnO1xyXG4gICAgICAgIGNvbnN0IHJlcXVlc3RJZCA9ICd0ZXN0LTEyMyc7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gVmFsaWRhdGlvblV0aWxzLmZvcm1hdFZhbGlkYXRpb25FcnJvcih2YWxpZGF0aW9uRXJyb3IsIHJlcXVlc3RJZCk7XHJcblxyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5zdWNjZXNzKS50b0JlKGZhbHNlKTtcclxuICAgICAgICBleHBlY3QocmVzcG9uc2UuZXJyb3IpLnRvQ29udGFpbignRm9ybWF0IGRlIGNvbnRhY3QgYXR0cmlidXRlcyBpbnZhbGlkZScpO1xyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvcikudG9Db250YWluKHZhbGlkYXRpb25FcnJvcik7XHJcbiAgICAgICAgZXhwZWN0KHJlc3BvbnNlLmVycm9yQ29kZSkudG9CZSgnVkFMSURBVElPTl9FUlJPUicpO1xyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5yZXF1ZXN0SWQpLnRvQmUocmVxdWVzdElkKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9KTtcclxuXHJcbiAgZGVzY3JpYmUoJ0Vycm9ySGFuZGxpbmdGcmFtZXdvcmsnLCAoKSA9PiB7XHJcbiAgICBkZXNjcmliZSgnaGFuZGxlRGF0YWJhc2VFcnJvcicsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIGhhbmRsZSBkYXRhYmFzZSBlcnJvciB3aXRoIGxvZ2dpbmcnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZXJyb3IgPSBuZXcgRXJyb3IoJ0Nvbm5lY3Rpb24gdGltZW91dCcpO1xyXG4gICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9ICdsb2FkUnVsZXMnO1xyXG5cclxuICAgICAgICBjb25zdCBlcnJvckRldGFpbHMgPSBFcnJvckhhbmRsaW5nRnJhbWV3b3JrLmhhbmRsZURhdGFiYXNlRXJyb3IoZXJyb3IsIG9wZXJhdGlvbiwgdGVzdENvbnRleHQpO1xyXG5cclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNhdGVnb3J5KS50b0JlKEVycm9yQ2F0ZWdvcnkuREFUQUJBU0UpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMuY29kZSkudG9CZSgnREFUQUJBU0VfRVJST1InKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLm1lc3NhZ2UpLnRvQ29udGFpbignRGF0YWJhc2Ugb3BlcmF0aW9uJyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5tZXNzYWdlKS50b0NvbnRhaW4ob3BlcmF0aW9uKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLnVzZXJNZXNzYWdlKS50b0NvbnRhaW4oJ0VycmV1ciBkZSBiYXNlIGRlIGRvbm7DqWVzJyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5yZXRyeWFibGUpLnRvQmUodHJ1ZSk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5vcmlnaW5hbEVycm9yKS50b0JlKGVycm9yKTtcclxuXHJcbiAgICAgICAgLy8gVmVyaWZ5IGxvZ2dpbmcgd2FzIGNhbGxlZFxyXG4gICAgICAgIGV4cGVjdChtb2NrQ29uc29sZUVycm9yKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcclxuICAgICAgICAgIGV4cGVjdC5zdHJpbmdDb250YWluaW5nKCdcImxldmVsXCI6XCJFUlJPUlwiJylcclxuICAgICAgICApO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgZGF0YWJhc2UgZXJyb3Igd2l0aG91dCBjb250ZXh0JywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdDb25uZWN0aW9uIGZhaWxlZCcpO1xyXG4gICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9ICdzYXZlUnVsZSc7XHJcblxyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuaGFuZGxlRGF0YWJhc2VFcnJvcihlcnJvciwgb3BlcmF0aW9uKTtcclxuXHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5jYXRlZ29yeSkudG9CZShFcnJvckNhdGVnb3J5LkRBVEFCQVNFKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLnJldHJ5YWJsZSkudG9CZSh0cnVlKTtcclxuICAgICAgICBleHBlY3QobW9ja0NvbnNvbGVFcnJvcikubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBkZXNjcmliZSgnaGFuZGxlUnVsZVByb2Nlc3NpbmdFcnJvcicsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIGhhbmRsZSBydWxlIHByb2Nlc3NpbmcgZXJyb3Igd2l0aCBsb2dnaW5nJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdJbnZhbGlkIGV4cHJlc3Npb24gc3ludGF4Jyk7XHJcbiAgICAgICAgY29uc3QgcnVsZUlkID0gJ3J1bGUtMTIzJztcclxuICAgICAgICBjb25zdCBleHByZXNzaW9uID0gJ2ludmFsaWQgJiYgc3ludGF4JztcclxuXHJcbiAgICAgICAgY29uc3QgZXJyb3JEZXRhaWxzID0gRXJyb3JIYW5kbGluZ0ZyYW1ld29yay5oYW5kbGVSdWxlUHJvY2Vzc2luZ0Vycm9yKFxyXG4gICAgICAgICAgZXJyb3IsIFxyXG4gICAgICAgICAgcnVsZUlkLCBcclxuICAgICAgICAgIGV4cHJlc3Npb24sIFxyXG4gICAgICAgICAgdGVzdENvbnRleHRcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNhdGVnb3J5KS50b0JlKEVycm9yQ2F0ZWdvcnkuUlVMRV9QUk9DRVNTSU5HKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNvZGUpLnRvQmUoJ1JVTEVfUFJPQ0VTU0lOR19FUlJPUicpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMubWVzc2FnZSkudG9Db250YWluKHJ1bGVJZCk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy51c2VyTWVzc2FnZSkudG9Db250YWluKCdFcnJldXIgbG9ycyBkdSB0cmFpdGVtZW50Jyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5yZXRyeWFibGUpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMuY29udGV4dCkudG9FcXVhbCh7XHJcbiAgICAgICAgICBydWxlSWQsXHJcbiAgICAgICAgICBleHByZXNzaW9uLFxyXG4gICAgICAgICAgdGltZXN0YW1wOiBleHBlY3QuYW55KFN0cmluZylcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gVmVyaWZ5IGxvZ2dpbmcgd2FzIGNhbGxlZFxyXG4gICAgICAgIGV4cGVjdChtb2NrQ29uc29sZUVycm9yKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcclxuICAgICAgICAgIGV4cGVjdC5zdHJpbmdDb250YWluaW5nKCdcImxldmVsXCI6XCJFUlJPUlwiJylcclxuICAgICAgICApO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIGRlc2NyaWJlKCdoYW5kbGVCdXNpbmVzc0xvZ2ljRXJyb3InLCAoKSA9PiB7XHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgTk9fTUFUQ0hJTkdfUlVMRVMgZXJyb3InLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZGV0YWlscyA9IHsgY29udGFjdEF0dHJpYnV0ZXM6IHsgQ2xpZW50OiAnU3RhbmRhcmQnIH0gfTtcclxuXHJcbiAgICAgICAgY29uc3QgZXJyb3JEZXRhaWxzID0gRXJyb3JIYW5kbGluZ0ZyYW1ld29yay5oYW5kbGVCdXNpbmVzc0xvZ2ljRXJyb3IoXHJcbiAgICAgICAgICAnTk9fTUFUQ0hJTkdfUlVMRVMnLFxyXG4gICAgICAgICAgZGV0YWlscyxcclxuICAgICAgICAgIHRlc3RDb250ZXh0XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5jYXRlZ29yeSkudG9CZShFcnJvckNhdGVnb3J5LkJVU0lORVNTX0xPR0lDKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNvZGUpLnRvQmUoJ05PX01BVENISU5HX1JVTEVTJyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy51c2VyTWVzc2FnZSkudG9CZSgnQXVjdW5lIHLDqGdsZSBuZSBjb3JyZXNwb25kLCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlJyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5yZXRyeWFibGUpLnRvQmUoZmFsc2UpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgRVFVQUxfV0VJR0hUUyBlcnJvcicsICgpID0+IHtcclxuICAgICAgICBjb25zdCBkZXRhaWxzID0geyBydWxlSWRzOiBbJ3J1bGUxJywgJ3J1bGUyJ10sIHdlaWdodDogMTAwIH07XHJcblxyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuaGFuZGxlQnVzaW5lc3NMb2dpY0Vycm9yKFxyXG4gICAgICAgICAgJ0VRVUFMX1dFSUdIVFMnLFxyXG4gICAgICAgICAgZGV0YWlscyxcclxuICAgICAgICAgIHRlc3RDb250ZXh0XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5jYXRlZ29yeSkudG9CZShFcnJvckNhdGVnb3J5LkJVU0lORVNTX0xPR0lDKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNvZGUpLnRvQmUoJ0VRVUFMX1dFSUdIVFMnKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLnVzZXJNZXNzYWdlKS50b0NvbnRhaW4oJ0xlcyByw6hnbGVzIHJ1bGUxIGV0IHJ1bGUyIG9udCBkZXMgcG9pZHMgaWRlbnRpcXVlcycpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMucmV0cnlhYmxlKS50b0JlKGZhbHNlKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZXN0KCdzaG91bGQgaGFuZGxlIE1JU1NJTkdfRElTVFJJQlVUSU9OX1NFR01FTlQgZXJyb3InLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZGV0YWlscyA9IHsgcnVsZUlkOiAncnVsZS0xMjMnIH07XHJcblxyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuaGFuZGxlQnVzaW5lc3NMb2dpY0Vycm9yKFxyXG4gICAgICAgICAgJ01JU1NJTkdfRElTVFJJQlVUSU9OX1NFR01FTlQnLFxyXG4gICAgICAgICAgZGV0YWlscyxcclxuICAgICAgICAgIHRlc3RDb250ZXh0XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5jYXRlZ29yeSkudG9CZShFcnJvckNhdGVnb3J5LkJVU0lORVNTX0xPR0lDKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNvZGUpLnRvQmUoJ01JU1NJTkdfRElTVFJJQlVUSU9OX1NFR01FTlQnKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLnVzZXJNZXNzYWdlKS50b0NvbnRhaW4oJ1NlZ21lbnQgZGUgZGlzdHJpYnV0aW9uIG1hbnF1YW50IHBvdXIgbGEgcsOoZ2xlIHJ1bGUtMTIzJyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5yZXRyeWFibGUpLnRvQmUoZmFsc2UpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgRU1QVFlfUlVMRV9TRVQgZXJyb3InLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZXJyb3JEZXRhaWxzID0gRXJyb3JIYW5kbGluZ0ZyYW1ld29yay5oYW5kbGVCdXNpbmVzc0xvZ2ljRXJyb3IoXHJcbiAgICAgICAgICAnRU1QVFlfUlVMRV9TRVQnLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB0ZXN0Q29udGV4dFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMuY2F0ZWdvcnkpLnRvQmUoRXJyb3JDYXRlZ29yeS5CVVNJTkVTU19MT0dJQyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5jb2RlKS50b0JlKCdFTVBUWV9SVUxFX1NFVCcpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMudXNlck1lc3NhZ2UpLnRvQ29udGFpbignQXVjdW5lIHLDqGdsZSBkaXNwb25pYmxlJyk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5yZXRyeWFibGUpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIGhhbmRsZSB1bmtub3duIGJ1c2luZXNzIGVycm9yJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuaGFuZGxlQnVzaW5lc3NMb2dpY0Vycm9yKFxyXG4gICAgICAgICAgJ1VOS05PV05fRVJST1JfVFlQRScsXHJcbiAgICAgICAgICB7IHNvbWU6ICdkYXRhJyB9LFxyXG4gICAgICAgICAgdGVzdENvbnRleHRcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNhdGVnb3J5KS50b0JlKEVycm9yQ2F0ZWdvcnkuQlVTSU5FU1NfTE9HSUMpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMuY29kZSkudG9CZSgnVU5LTk9XTl9CVVNJTkVTU19FUlJPUicpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMudXNlck1lc3NhZ2UpLnRvQ29udGFpbignRXJyZXVyIGRlIGxvZ2lxdWUgbcOpdGllcicpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMucmV0cnlhYmxlKS50b0JlKGZhbHNlKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBkZXNjcmliZSgnaGFuZGxlSW5mcmFzdHJ1Y3R1cmVFcnJvcicsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIGhhbmRsZSB0aW1lb3V0IGVycm9yJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdSZXF1ZXN0IHRpbWVvdXQgYWZ0ZXIgNTAwMG1zJyk7XHJcbiAgICAgICAgZXJyb3IubmFtZSA9ICdUaW1lb3V0RXJyb3InO1xyXG4gICAgICAgIGNvbnN0IGNvbXBvbmVudCA9ICdMYW1iZGEnO1xyXG5cclxuICAgICAgICBjb25zdCBlcnJvckRldGFpbHMgPSBFcnJvckhhbmRsaW5nRnJhbWV3b3JrLmhhbmRsZUluZnJhc3RydWN0dXJlRXJyb3IoXHJcbiAgICAgICAgICBlcnJvcixcclxuICAgICAgICAgIGNvbXBvbmVudCxcclxuICAgICAgICAgIHRlc3RDb250ZXh0XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgZXhwZWN0KGVycm9yRGV0YWlscy5jYXRlZ29yeSkudG9CZShFcnJvckNhdGVnb3J5LklORlJBU1RSVUNUVVJFKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNvZGUpLnRvQmUoJ1RJTUVPVVRfRVJST1InKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLnJldHJ5YWJsZSkudG9CZSh0cnVlKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLm1lc3NhZ2UpLnRvQ29udGFpbihjb21wb25lbnQpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgbmV0d29yayBlcnJvcicsICgpID0+IHtcclxuICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignTmV0d29yayBjb25uZWN0aW9uIGZhaWxlZCcpO1xyXG4gICAgICAgIGNvbnN0IGNvbXBvbmVudCA9ICdEeW5hbW9EQic7XHJcblxyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuaGFuZGxlSW5mcmFzdHJ1Y3R1cmVFcnJvcihcclxuICAgICAgICAgIGVycm9yLFxyXG4gICAgICAgICAgY29tcG9uZW50LFxyXG4gICAgICAgICAgdGVzdENvbnRleHRcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNhdGVnb3J5KS50b0JlKEVycm9yQ2F0ZWdvcnkuSU5GUkFTVFJVQ1RVUkUpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMuY29kZSkudG9CZSgnTkVUV09SS19FUlJPUicpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMucmV0cnlhYmxlKS50b0JlKHRydWUpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgZ2VuZXJpYyBpbmZyYXN0cnVjdHVyZSBlcnJvcicsICgpID0+IHtcclxuICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignVW5rbm93biBpbmZyYXN0cnVjdHVyZSBpc3N1ZScpO1xyXG4gICAgICAgIGNvbnN0IGNvbXBvbmVudCA9ICdBUEkgR2F0ZXdheSc7XHJcblxyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlscyA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuaGFuZGxlSW5mcmFzdHJ1Y3R1cmVFcnJvcihcclxuICAgICAgICAgIGVycm9yLFxyXG4gICAgICAgICAgY29tcG9uZW50LFxyXG4gICAgICAgICAgdGVzdENvbnRleHRcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLmNhdGVnb3J5KS50b0JlKEVycm9yQ2F0ZWdvcnkuSU5GUkFTVFJVQ1RVUkUpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckRldGFpbHMuY29kZSkudG9CZSgnSU5GUkFTVFJVQ1RVUkVfRVJST1InKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JEZXRhaWxzLnJldHJ5YWJsZSkudG9CZSh0cnVlKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBkZXNjcmliZSgndG9FcnJvclJlc3BvbnNlJywgKCkgPT4ge1xyXG4gICAgICB0ZXN0KCdzaG91bGQgY29udmVydCBFcnJvckRldGFpbHMgdG8gRXJyb3JSZXNwb25zZScsICgpID0+IHtcclxuICAgICAgICBjb25zdCBlcnJvckRldGFpbHM6IEVycm9yRGV0YWlscyA9IHtcclxuICAgICAgICAgIGNhdGVnb3J5OiBFcnJvckNhdGVnb3J5LlZBTElEQVRJT04sXHJcbiAgICAgICAgICBjb2RlOiAnVEVTVF9FUlJPUicsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnVGVzdCBlcnJvciBtZXNzYWdlJyxcclxuICAgICAgICAgIHVzZXJNZXNzYWdlOiAnVXNlciBmcmllbmRseSBtZXNzYWdlJyxcclxuICAgICAgICAgIHJldHJ5YWJsZTogZmFsc2UsXHJcbiAgICAgICAgICBjb250ZXh0OiB7IHRlc3Q6ICdkYXRhJyB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVxdWVzdElkID0gJ3Rlc3QtMTIzJztcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IEVycm9ySGFuZGxpbmdGcmFtZXdvcmsudG9FcnJvclJlc3BvbnNlKGVycm9yRGV0YWlscywgcmVxdWVzdElkKTtcclxuXHJcbiAgICAgICAgZXhwZWN0KHJlc3BvbnNlLnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvcikudG9CZShlcnJvckRldGFpbHMudXNlck1lc3NhZ2UpO1xyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvckNvZGUpLnRvQmUoZXJyb3JEZXRhaWxzLmNvZGUpO1xyXG4gICAgICAgIGV4cGVjdChyZXNwb25zZS5yZXF1ZXN0SWQpLnRvQmUocmVxdWVzdElkKTtcclxuICAgICAgICBleHBlY3QocmVzcG9uc2UuZGV0YWlscykudG9FcXVhbCh7XHJcbiAgICAgICAgICBjYXRlZ29yeTogZXJyb3JEZXRhaWxzLmNhdGVnb3J5LFxyXG4gICAgICAgICAgcmV0cnlhYmxlOiBlcnJvckRldGFpbHMucmV0cnlhYmxlLFxyXG4gICAgICAgICAgY29udGV4dDogZXJyb3JEZXRhaWxzLmNvbnRleHRcclxuICAgICAgICB9KTtcclxuICAgICAgICBleHBlY3QocmVzcG9uc2UudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIGRlc2NyaWJlKCdzaG91bGRSZXRyeScsICgpID0+IHtcclxuICAgICAgdGVzdCgnc2hvdWxkIHJldHVybiB0cnVlIGZvciByZXRyeWFibGUgZXJyb3Igd2l0aGluIGF0dGVtcHQgbGltaXQnLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZXJyb3JEZXRhaWxzOiBFcnJvckRldGFpbHMgPSB7XHJcbiAgICAgICAgICBjYXRlZ29yeTogRXJyb3JDYXRlZ29yeS5EQVRBQkFTRSxcclxuICAgICAgICAgIGNvZGU6ICdEQl9FUlJPUicsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnRGF0YWJhc2UgZXJyb3InLFxyXG4gICAgICAgICAgdXNlck1lc3NhZ2U6ICdEYXRhYmFzZSBlcnJvcicsXHJcbiAgICAgICAgICByZXRyeWFibGU6IHRydWVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBleHBlY3QoRXJyb3JIYW5kbGluZ0ZyYW1ld29yay5zaG91bGRSZXRyeShlcnJvckRldGFpbHMsIDEsIDMpKS50b0JlKHRydWUpO1xyXG4gICAgICAgIGV4cGVjdChFcnJvckhhbmRsaW5nRnJhbWV3b3JrLnNob3VsZFJldHJ5KGVycm9yRGV0YWlscywgMiwgMykpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJldHVybiBmYWxzZSBmb3IgcmV0cnlhYmxlIGVycm9yIGV4Y2VlZGluZyBhdHRlbXB0IGxpbWl0JywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVycm9yRGV0YWlsczogRXJyb3JEZXRhaWxzID0ge1xyXG4gICAgICAgICAgY2F0ZWdvcnk6IEVycm9yQ2F0ZWdvcnkuREFUQUJBU0UsXHJcbiAgICAgICAgICBjb2RlOiAnREJfRVJST1InLFxyXG4gICAgICAgICAgbWVzc2FnZTogJ0RhdGFiYXNlIGVycm9yJyxcclxuICAgICAgICAgIHVzZXJNZXNzYWdlOiAnRGF0YWJhc2UgZXJyb3InLFxyXG4gICAgICAgICAgcmV0cnlhYmxlOiB0cnVlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZXhwZWN0KEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuc2hvdWxkUmV0cnkoZXJyb3JEZXRhaWxzLCAzLCAzKSkudG9CZShmYWxzZSk7XHJcbiAgICAgICAgZXhwZWN0KEVycm9ySGFuZGxpbmdGcmFtZXdvcmsuc2hvdWxkUmV0cnkoZXJyb3JEZXRhaWxzLCA0LCAzKSkudG9CZShmYWxzZSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgdGVzdCgnc2hvdWxkIHJldHVybiBmYWxzZSBmb3Igbm9uLXJldHJ5YWJsZSBlcnJvcicsICgpID0+IHtcclxuICAgICAgICBjb25zdCBlcnJvckRldGFpbHM6IEVycm9yRGV0YWlscyA9IHtcclxuICAgICAgICAgIGNhdGVnb3J5OiBFcnJvckNhdGVnb3J5LlZBTElEQVRJT04sXHJcbiAgICAgICAgICBjb2RlOiAnVkFMSURBVElPTl9FUlJPUicsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnVmFsaWRhdGlvbiBlcnJvcicsXHJcbiAgICAgICAgICB1c2VyTWVzc2FnZTogJ1ZhbGlkYXRpb24gZXJyb3InLFxyXG4gICAgICAgICAgcmV0cnlhYmxlOiBmYWxzZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGV4cGVjdChFcnJvckhhbmRsaW5nRnJhbWV3b3JrLnNob3VsZFJldHJ5KGVycm9yRGV0YWlscywgMSwgMykpLnRvQmUoZmFsc2UpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59KTsiXX0=
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DecisionEngine_1 = require("../../services/decision-engine/DecisionEngine");
const LoggingUtils_1 = require("../../utils/decision-engine/LoggingUtils");
/**
 * **Feature: decision-engine, Property 9: Comprehensive logging**
 * **Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5**
 *
 * Property: For any decision process, the system should log input contact attributes,
 * elimination steps, selected rule, distribution segment, decision rationale, and any
 * errors with timestamps and request identifiers
 */
// Mock DynamoDB for property testing
const mockSend = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => ({
    DynamoDBClient: jest.fn().mockImplementation(() => ({}))
}));
jest.mock('@aws-sdk/lib-dynamodb', () => ({
    DynamoDBDocumentClient: {
        from: jest.fn().mockReturnValue({ send: mockSend })
    },
    ScanCommand: jest.fn().mockImplementation((params) => params)
}));
// Mock console methods to capture log output
const mockConsoleLog = jest.spyOn(console, 'log').mockImplementation();
const mockConsoleError = jest.spyOn(console, 'error').mockImplementation();
describe('Property Test: Comprehensive Logging', () => {
    beforeEach(() => {
        // Reset mocks and clear audit trails before each test
        jest.clearAllMocks();
        mockSend.mockReset();
        mockConsoleLog.mockClear();
        mockConsoleError.mockClear();
        LoggingUtils_1.LoggingUtils.clearAuditTrails();
    });
    afterAll(() => {
        // Restore console methods
        mockConsoleLog.mockRestore();
        mockConsoleError.mockRestore();
    });
    /**
     * Property: Complete logging for successful decision processes
     * For any valid qualification request with matching rules, all required logging
     * elements should be present with proper timestamps and request identifiers
     */
    test('should log all required elements for successful decision processes', async () => {
        // Generate test cases for property-based testing (100 iterations)
        for (let iteration = 0; iteration < 100; iteration++) {
            // Generate random contact attributes
            const generateContactAttributes = () => {
                const attributes = {};
                const keys = ['NouveauSinistre', 'Client', 'Score', 'Region', 'Priority'];
                const numAttributes = Math.floor(Math.random() * keys.length) + 1;
                for (let i = 0; i < numAttributes; i++) {
                    const key = keys[i];
                    const valueType = Math.random();
                    if (valueType < 0.33) {
                        attributes[key] = Math.random() > 0.5; // boolean
                    }
                    else if (valueType < 0.66) {
                        attributes[key] = ['VIP', 'Standard', 'Premium'][Math.floor(Math.random() * 3)]; // string
                    }
                    else {
                        attributes[key] = Math.floor(Math.random() * 100) + 1; // number
                    }
                }
                return attributes;
            };
            // Generate random rules that will match the attributes
            const generateMatchingRules = (attributes) => {
                const rules = [];
                const ruleCount = Math.floor(Math.random() * 5) + 1; // 1-5 rules
                for (let i = 0; i < ruleCount; i++) {
                    rules.push({
                        id: `rule-${iteration}-${i}`,
                        name: `Test Rule ${iteration}-${i}`,
                        expression: 'NouveauSinistre == true', // Simple expression that won't conflict
                        weight: Math.floor(Math.random() * 100) + 1,
                        distributionSegment: `segment-${iteration}-${i}`,
                        createdAt: new Date().toISOString(),
                        updatedAt: new Date().toISOString()
                    });
                }
                // Ensure rules have unique weights to avoid equal weight errors
                rules.forEach((rule, index) => {
                    rule.weight = (index + 1) * 10;
                });
                return rules.sort((a, b) => b.weight - a.weight);
            };
            const contactAttributes = generateContactAttributes();
            const rules = generateMatchingRules(contactAttributes);
            const request = {
                interactionId: `test-${iteration}-${Date.now()}`,
                contactAttributes
            };
            // Setup mock to return the generated rules
            mockSend.mockResolvedValueOnce({
                Items: rules
            });
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 1: Decision should be successful
            expect(response.success).toBe(true);
            // Property 2: All console.log calls should contain required logging elements
            const logCalls = mockConsoleLog.mock.calls;
            expect(logCalls.length).toBeGreaterThan(0);
            // Parse all log entries
            const logEntries = logCalls.map(call => {
                try {
                    return JSON.parse(call[0]);
                }
                catch (_a) {
                    return null;
                }
            }).filter(entry => entry !== null);
            // Property 3: Audit trail creation log (Requirements 5.5)
            const auditTrailLog = logEntries.find(entry => entry.message === 'Audit trail created' &&
                entry.requestId === request.interactionId);
            expect(auditTrailLog).toBeDefined();
            expect(auditTrailLog.timestamp).toBeDefined();
            expect(auditTrailLog.interactionId).toBe(request.interactionId);
            // Property 4: Decision start log with input criteria (Requirements 5.1)
            const startLog = logEntries.find(entry => entry.message === 'Decision process started' &&
                entry.requestId === request.interactionId);
            expect(startLog).toBeDefined();
            expect(startLog.contactAttributes).toEqual(contactAttributes);
            expect(startLog.timestamp).toBeDefined();
            expect(startLog.attributeCount).toBe(Object.keys(contactAttributes).length);
            expect(startLog.attributeKeys).toEqual(Object.keys(contactAttributes));
            // Property 5: Rules loaded log (Requirements 5.1)
            const rulesLoadedLog = logEntries.find(entry => entry.message === 'Rules loaded from database' &&
                entry.requestId === request.interactionId);
            expect(rulesLoadedLog).toBeDefined();
            expect(rulesLoadedLog.ruleCount).toBe(rules.length);
            expect(rulesLoadedLog.ruleSummary).toBeDefined();
            expect(rulesLoadedLog.weightRange).toBeDefined();
            // Property 6: Rule selection log with decision rationale (Requirements 5.3)
            const ruleSelectedLog = logEntries.find(entry => entry.message === 'Rule selected for decision' &&
                entry.requestId === request.interactionId);
            expect(ruleSelectedLog).toBeDefined();
            expect(ruleSelectedLog.selectedRule).toBeDefined();
            expect(ruleSelectedLog.selectedRule.id).toBe(rules[0].id); // Highest weight rule
            expect(ruleSelectedLog.decisionRationale).toBeDefined();
            expect(ruleSelectedLog.decisionRationale.selectedWeight).toBe(rules[0].weight);
            expect(ruleSelectedLog.decisionRationale.selectionCriteria).toBe('highest_weight');
            // Property 7: Decision completion log (Requirements 5.1, 5.3)
            const completionLog = logEntries.find(entry => entry.message === 'Decision process completed' &&
                entry.requestId === request.interactionId);
            expect(completionLog).toBeDefined();
            expect(completionLog.success).toBe(true);
            expect(completionLog.distributionSegment).toBe(rules[0].distributionSegment);
            expect(completionLog.processSummary).toBeDefined();
            expect(completionLog.processSummary.inputAttributeCount).toBe(Object.keys(contactAttributes).length);
            expect(completionLog.processSummary.rulesLoaded).toBe(rules.length);
            // Property 8: All log entries should have timestamps and request identifiers (Requirements 5.5)
            logEntries.forEach(entry => {
                expect(entry.timestamp).toBeDefined();
                expect(entry.requestId).toBe(request.interactionId);
                expect(entry.interactionId).toBe(request.interactionId);
            });
            // Reset mocks for next iteration
            mockConsoleLog.mockClear();
            mockConsoleError.mockClear();
            mockSend.mockClear();
        }
    });
    /**
     * Property: Complete error logging for failed decision processes
     * For any decision process that encounters errors, all error details should be
     * logged with proper context and troubleshooting information
     */
    test('should log comprehensive error information for failed processes', async () => {
        // Test various error scenarios (50 iterations)
        const errorScenarios = [
            {
                name: 'database_error',
                setupMock: () => mockSend.mockRejectedValueOnce(new Error('Database connection failed')),
                expectedErrorCode: 'DATABASE_ERROR'
            },
            {
                name: 'empty_rules',
                setupMock: () => mockSend.mockResolvedValueOnce({ Items: [] }),
                expectedErrorCode: 'EMPTY_RULE_SET'
            },
            {
                name: 'no_matching_rules',
                setupMock: () => mockSend.mockResolvedValueOnce({
                    Items: [{
                            id: 'rule1',
                            name: 'Non-matching Rule',
                            expression: 'NouveauSinistre == false', // Will not match our test data
                            weight: 10,
                            distributionSegment: 'segment1',
                            createdAt: new Date().toISOString(),
                            updatedAt: new Date().toISOString()
                        }]
                }),
                expectedErrorCode: 'NO_MATCHING_RULES'
            }
        ];
        for (let iteration = 0; iteration < 50; iteration++) {
            const scenarioIndex = iteration % errorScenarios.length;
            const scenario = errorScenarios[scenarioIndex];
            const request = {
                interactionId: `error-test-${iteration}-${Date.now()}`,
                contactAttributes: { NouveauSinistre: true, Client: 'VIP' }
            };
            // Setup mock according to scenario
            scenario.setupMock();
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 1: Decision should fail
            expect(response.success).toBe(false);
            // Property 2: Error should be logged (Requirements 5.4)
            const errorCalls = mockConsoleError.mock.calls;
            const logCalls = mockConsoleLog.mock.calls;
            // Parse error log entries
            const errorEntries = errorCalls.map(call => {
                try {
                    return JSON.parse(call[0]);
                }
                catch (_a) {
                    return null;
                }
            }).filter(entry => entry !== null);
            // Parse regular log entries
            const logEntries = logCalls.map(call => {
                try {
                    return JSON.parse(call[0]);
                }
                catch (_a) {
                    return null;
                }
            }).filter(entry => entry !== null);
            // Property 3: Error log should contain detailed information (Requirements 5.4)
            const errorLog = errorEntries.find(entry => entry.level === 'ERROR' &&
                entry.requestId === request.interactionId);
            if (errorLog) {
                expect(errorLog.message).toContain('error');
                expect(errorLog.errorCode).toBeDefined();
                expect(errorLog.timestamp).toBeDefined();
                expect(errorLog.requestId).toBe(request.interactionId);
                expect(errorLog.interactionId).toBe(request.interactionId);
            }
            // Property 4: Decision completion log should indicate failure (Requirements 5.1)
            const completionLog = logEntries.find(entry => entry.message === 'Decision process completed' &&
                entry.requestId === request.interactionId);
            expect(completionLog).toBeDefined();
            expect(completionLog.success).toBe(false);
            expect(completionLog.errorCode).toBeDefined();
            // Property 5: All log entries should have timestamps and request identifiers (Requirements 5.5)
            [...errorEntries, ...logEntries].forEach(entry => {
                expect(entry.timestamp).toBeDefined();
                expect(entry.requestId).toBe(request.interactionId);
                expect(entry.interactionId).toBe(request.interactionId);
            });
            // Reset mocks for next iteration
            mockConsoleLog.mockClear();
            mockConsoleError.mockClear();
            mockSend.mockClear();
        }
    });
    /**
     * Property: Elimination step logging completeness
     * For any decision process with rule elimination, all elimination steps should
     * be logged with detailed tracking information
     */
    test('should log all elimination steps with detailed tracking', async () => {
        // Generate test cases with guaranteed elimination (25 iterations)
        for (let iteration = 0; iteration < 25; iteration++) {
            const request = {
                interactionId: `elimination-test-${iteration}-${Date.now()}`,
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP',
                    Score: 85
                }
            };
            // Generate rules that will cause elimination
            const rules = [
                {
                    id: `matching-rule-${iteration}`,
                    name: 'Matching Rule',
                    expression: 'NouveauSinistre == true',
                    weight: 30,
                    distributionSegment: 'segment-match',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                },
                {
                    id: `eliminating-rule-${iteration}`,
                    name: 'Eliminating Rule',
                    expression: 'NouveauSinistre == false', // Will be eliminated
                    weight: 20,
                    distributionSegment: 'segment-eliminate',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                }
            ];
            // Setup mock to return rules
            mockSend.mockResolvedValueOnce({
                Items: rules
            });
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 1: Decision should be successful
            expect(response.success).toBe(true);
            // Property 2: Elimination steps should be logged (Requirements 5.2)
            const logCalls = mockConsoleLog.mock.calls;
            const logEntries = logCalls.map(call => {
                try {
                    return JSON.parse(call[0]);
                }
                catch (_a) {
                    return null;
                }
            }).filter(entry => entry !== null);
            // Property 3: Find elimination step logs
            const eliminationLogs = logEntries.filter(entry => entry.message === 'Rule elimination step executed' &&
                entry.requestId === request.interactionId);
            // Property 4: Should have elimination step logs (Requirements 5.2)
            expect(eliminationLogs.length).toBeGreaterThan(0);
            eliminationLogs.forEach(eliminationLog => {
                // Property 5: Each elimination log should contain required information
                expect(eliminationLog.eliminationStep).toBeDefined();
                expect(eliminationLog.eliminationStep.contactAttributeKey).toBeDefined();
                expect(eliminationLog.eliminationStep.contactAttributeValue).toBeDefined();
                expect(eliminationLog.eliminationStep.remainingRules).toBeDefined();
                expect(eliminationLog.eliminationStep.eliminatedCount).toBeDefined();
                expect(eliminationLog.progressSummary).toBeDefined();
                expect(eliminationLog.timestamp).toBeDefined();
                expect(eliminationLog.requestId).toBe(request.interactionId);
            });
            // Reset mocks for next iteration
            mockConsoleLog.mockClear();
            mockSend.mockClear();
        }
    });
    /**
     * Property: Audit trail consistency
     * For any decision process, the audit trail should be created, maintained,
     * and cleaned up properly with all required information
     */
    test('should maintain consistent audit trails throughout decision process', async () => {
        // Test audit trail consistency (25 iterations)
        for (let iteration = 0; iteration < 25; iteration++) {
            const request = {
                interactionId: `audit-test-${iteration}-${Date.now()}`,
                contactAttributes: { NouveauSinistre: true }
            };
            const rules = [{
                    id: `audit-rule-${iteration}`,
                    name: 'Audit Test Rule',
                    expression: 'NouveauSinistre == true',
                    weight: 15,
                    distributionSegment: 'audit-segment',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                }];
            // Setup mock
            mockSend.mockResolvedValueOnce({
                Items: rules
            });
            // Property 1: Audit trail should not exist before process
            expect(LoggingUtils_1.LoggingUtils.getAuditTrail(request.interactionId)).toBeUndefined();
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 2: Decision should be successful
            expect(response.success).toBe(true);
            // Property 3: Audit trail should be cleaned up after completion (Requirements 5.5)
            expect(LoggingUtils_1.LoggingUtils.getAuditTrail(request.interactionId)).toBeUndefined();
            // Reset mocks for next iteration
            mockConsoleLog.mockClear();
            mockSend.mockClear();
        }
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcHJlaGVuc2l2ZS1sb2dnaW5nLnByb3BlcnR5LnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdGVzdHMvZGVjaXNpb24tZW5naW5lL2NvbXByZWhlbnNpdmUtbG9nZ2luZy5wcm9wZXJ0eS50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsa0ZBQStFO0FBQy9FLDJFQUF3RTtBQUd4RTs7Ozs7OztHQU9HO0FBRUgscUNBQXFDO0FBQ3JDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLDBCQUEwQixFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDM0MsY0FBYyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3pELENBQUMsQ0FBQyxDQUFDO0FBQ0osSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLHNCQUFzQixFQUFFO1FBQ3RCLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsZUFBZSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsV0FBVyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDO0NBQzlELENBQUMsQ0FBQyxDQUFDO0FBRUosNkNBQTZDO0FBQzdDLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixFQUFFLENBQUM7QUFDdkUsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0FBRTNFLFFBQVEsQ0FBQyxzQ0FBc0MsRUFBRSxHQUFHLEVBQUU7SUFDcEQsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLHNEQUFzRDtRQUN0RCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3JCLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUMzQixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUM3QiwyQkFBWSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsR0FBRyxFQUFFO1FBQ1osMEJBQTBCO1FBQzFCLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM3QixnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNqQyxDQUFDLENBQUMsQ0FBQztJQUVIOzs7O09BSUc7SUFDSCxJQUFJLENBQUMsb0VBQW9FLEVBQUUsS0FBSyxJQUFJLEVBQUU7UUFDcEYsa0VBQWtFO1FBQ2xFLEtBQUssSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztZQUNyRCxxQ0FBcUM7WUFDckMsTUFBTSx5QkFBeUIsR0FBRyxHQUFzQixFQUFFO2dCQUN4RCxNQUFNLFVBQVUsR0FBc0IsRUFBRSxDQUFDO2dCQUN6QyxNQUFNLElBQUksR0FBRyxDQUFDLGlCQUFpQixFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUMxRSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVsRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQ3ZDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDcEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNoQyxJQUFJLFNBQVMsR0FBRyxJQUFJLEVBQUUsQ0FBQzt3QkFDckIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxVQUFVO29CQUNuRCxDQUFDO3lCQUFNLElBQUksU0FBUyxHQUFHLElBQUksRUFBRSxDQUFDO3dCQUM1QixVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO29CQUM1RixDQUFDO3lCQUFNLENBQUM7d0JBQ04sVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVM7b0JBQ2xFLENBQUM7Z0JBQ0gsQ0FBQztnQkFDRCxPQUFPLFVBQVUsQ0FBQztZQUNwQixDQUFDLENBQUM7WUFFRix1REFBdUQ7WUFDdkQsTUFBTSxxQkFBcUIsR0FBRyxDQUFDLFVBQTZCLEVBQXVCLEVBQUU7Z0JBQ25GLE1BQU0sS0FBSyxHQUF3QixFQUFFLENBQUM7Z0JBQ3RDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVk7Z0JBRWpFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFDbkMsS0FBSyxDQUFDLElBQUksQ0FBQzt3QkFDVCxFQUFFLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFFO3dCQUM1QixJQUFJLEVBQUUsYUFBYSxTQUFTLElBQUksQ0FBQyxFQUFFO3dCQUNuQyxVQUFVLEVBQUUseUJBQXlCLEVBQUUsd0NBQXdDO3dCQUMvRSxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQzt3QkFDM0MsbUJBQW1CLEVBQUUsV0FBVyxTQUFTLElBQUksQ0FBQyxFQUFFO3dCQUNoRCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7d0JBQ25DLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtxQkFDcEMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQsZ0VBQWdFO2dCQUNoRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO29CQUM1QixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDakMsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkQsQ0FBQyxDQUFDO1lBRUYsTUFBTSxpQkFBaUIsR0FBRyx5QkFBeUIsRUFBRSxDQUFDO1lBQ3RELE1BQU0sS0FBSyxHQUFHLHFCQUFxQixDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDdkQsTUFBTSxPQUFPLEdBQXlCO2dCQUNwQyxhQUFhLEVBQUUsUUFBUSxTQUFTLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUNoRCxpQkFBaUI7YUFDbEIsQ0FBQztZQUVGLDJDQUEyQztZQUMzQyxRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFDO1lBRUgsMkJBQTJCO1lBQzNCLE1BQU0sY0FBYyxHQUFHLElBQUksK0JBQWMsRUFBRSxDQUFDO1lBQzVDLE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUUvRCw0Q0FBNEM7WUFDNUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFcEMsNkVBQTZFO1lBQzdFLE1BQU0sUUFBUSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQzNDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTNDLHdCQUF3QjtZQUN4QixNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNyQyxJQUFJLENBQUM7b0JBQ0gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM3QixDQUFDO2dCQUFDLFdBQU0sQ0FBQztvQkFDUCxPQUFPLElBQUksQ0FBQztnQkFDZCxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDO1lBRW5DLDBEQUEwRDtZQUMxRCxNQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQzVDLEtBQUssQ0FBQyxPQUFPLEtBQUsscUJBQXFCO2dCQUN2QyxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FBQyxhQUFhLENBQzFDLENBQUM7WUFDRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDcEMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM5QyxNQUFNLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFaEUsd0VBQXdFO1lBQ3hFLE1BQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FDdkMsS0FBSyxDQUFDLE9BQU8sS0FBSywwQkFBMEI7Z0JBQzVDLEtBQUssQ0FBQyxTQUFTLEtBQUssT0FBTyxDQUFDLGFBQWEsQ0FDMUMsQ0FBQztZQUNGLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMvQixNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDOUQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN6QyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDNUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7WUFFdkUsa0RBQWtEO1lBQ2xELE1BQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FDN0MsS0FBSyxDQUFDLE9BQU8sS0FBSyw0QkFBNEI7Z0JBQzlDLEtBQUssQ0FBQyxTQUFTLEtBQUssT0FBTyxDQUFDLGFBQWEsQ0FDMUMsQ0FBQztZQUNGLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEQsTUFBTSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqRCxNQUFNLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBRWpELDRFQUE0RTtZQUM1RSxNQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQzlDLEtBQUssQ0FBQyxPQUFPLEtBQUssNEJBQTRCO2dCQUM5QyxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FBQyxhQUFhLENBQzFDLENBQUM7WUFDRixNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdEMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsc0JBQXNCO1lBQ2pGLE1BQU0sQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN4RCxNQUFNLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDL0UsTUFBTSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBRW5GLDhEQUE4RDtZQUM5RCxNQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQzVDLEtBQUssQ0FBQyxPQUFPLEtBQUssNEJBQTRCO2dCQUM5QyxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FBQyxhQUFhLENBQzFDLENBQUM7WUFDRixNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDcEMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDekMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUM3RSxNQUFNLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyRyxNQUFNLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXBFLGdHQUFnRztZQUNoRyxVQUFVLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN6QixNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN0QyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3BELE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMxRCxDQUFDLENBQUMsQ0FBQztZQUVILGlDQUFpQztZQUNqQyxjQUFjLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDM0IsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDN0IsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVIOzs7O09BSUc7SUFDSCxJQUFJLENBQUMsaUVBQWlFLEVBQUUsS0FBSyxJQUFJLEVBQUU7UUFDakYsK0NBQStDO1FBQy9DLE1BQU0sY0FBYyxHQUFHO1lBQ3JCO2dCQUNFLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ3RCLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsSUFBSSxLQUFLLENBQUMsNEJBQTRCLENBQUMsQ0FBQztnQkFDeEYsaUJBQWlCLEVBQUUsZ0JBQWdCO2FBQ3BDO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUM7Z0JBQzlELGlCQUFpQixFQUFFLGdCQUFnQjthQUNwQztZQUNEO2dCQUNFLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUM7b0JBQzlDLEtBQUssRUFBRSxDQUFDOzRCQUNOLEVBQUUsRUFBRSxPQUFPOzRCQUNYLElBQUksRUFBRSxtQkFBbUI7NEJBQ3pCLFVBQVUsRUFBRSwwQkFBMEIsRUFBRSwrQkFBK0I7NEJBQ3ZFLE1BQU0sRUFBRSxFQUFFOzRCQUNWLG1CQUFtQixFQUFFLFVBQVU7NEJBQy9CLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTs0QkFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO3lCQUNwQyxDQUFDO2lCQUNILENBQUM7Z0JBQ0YsaUJBQWlCLEVBQUUsbUJBQW1CO2FBQ3ZDO1NBQ0YsQ0FBQztRQUVGLEtBQUssSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxNQUFNLGFBQWEsR0FBRyxTQUFTLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQztZQUN4RCxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFL0MsTUFBTSxPQUFPLEdBQXlCO2dCQUNwQyxhQUFhLEVBQUUsY0FBYyxTQUFTLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUN0RCxpQkFBaUIsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRTthQUM1RCxDQUFDO1lBRUYsbUNBQW1DO1lBQ25DLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUVyQiwyQkFBMkI7WUFDM0IsTUFBTSxjQUFjLEdBQUcsSUFBSSwrQkFBYyxFQUFFLENBQUM7WUFDNUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRS9ELG1DQUFtQztZQUNuQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVyQyx3REFBd0Q7WUFDeEQsTUFBTSxVQUFVLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUMvQyxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUUzQywwQkFBMEI7WUFDMUIsTUFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDekMsSUFBSSxDQUFDO29CQUNILE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0IsQ0FBQztnQkFBQyxXQUFNLENBQUM7b0JBQ1AsT0FBTyxJQUFJLENBQUM7Z0JBQ2QsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQztZQUVuQyw0QkFBNEI7WUFDNUIsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDckMsSUFBSSxDQUFDO29CQUNILE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0IsQ0FBQztnQkFBQyxXQUFNLENBQUM7b0JBQ1AsT0FBTyxJQUFJLENBQUM7Z0JBQ2QsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQztZQUVuQywrRUFBK0U7WUFDL0UsTUFBTSxRQUFRLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUN6QyxLQUFLLENBQUMsS0FBSyxLQUFLLE9BQU87Z0JBQ3ZCLEtBQUssQ0FBQyxTQUFTLEtBQUssT0FBTyxDQUFDLGFBQWEsQ0FDMUMsQ0FBQztZQUVGLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ2IsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzVDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDdkQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQzdELENBQUM7WUFFRCxpRkFBaUY7WUFDakYsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUM1QyxLQUFLLENBQUMsT0FBTyxLQUFLLDRCQUE0QjtnQkFDOUMsS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLENBQUMsYUFBYSxDQUMxQyxDQUFDO1lBQ0YsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFFOUMsZ0dBQWdHO1lBQ2hHLENBQUMsR0FBRyxZQUFZLEVBQUUsR0FBRyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQy9DLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3RDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDcEQsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQzFELENBQUMsQ0FBQyxDQUFDO1lBRUgsaUNBQWlDO1lBQ2pDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUMzQixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUM3QixRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQyx5REFBeUQsRUFBRSxLQUFLLElBQUksRUFBRTtRQUN6RSxrRUFBa0U7UUFDbEUsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3BELE1BQU0sT0FBTyxHQUF5QjtnQkFDcEMsYUFBYSxFQUFFLG9CQUFvQixTQUFTLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUM1RCxpQkFBaUIsRUFBRTtvQkFDakIsZUFBZSxFQUFFLElBQUk7b0JBQ3JCLE1BQU0sRUFBRSxLQUFLO29CQUNiLEtBQUssRUFBRSxFQUFFO2lCQUNWO2FBQ0YsQ0FBQztZQUVGLDZDQUE2QztZQUM3QyxNQUFNLEtBQUssR0FBd0I7Z0JBQ2pDO29CQUNFLEVBQUUsRUFBRSxpQkFBaUIsU0FBUyxFQUFFO29CQUNoQyxJQUFJLEVBQUUsZUFBZTtvQkFDckIsVUFBVSxFQUFFLHlCQUF5QjtvQkFDckMsTUFBTSxFQUFFLEVBQUU7b0JBQ1YsbUJBQW1CLEVBQUUsZUFBZTtvQkFDcEMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7aUJBQ3BDO2dCQUNEO29CQUNFLEVBQUUsRUFBRSxvQkFBb0IsU0FBUyxFQUFFO29CQUNuQyxJQUFJLEVBQUUsa0JBQWtCO29CQUN4QixVQUFVLEVBQUUsMEJBQTBCLEVBQUUscUJBQXFCO29CQUM3RCxNQUFNLEVBQUUsRUFBRTtvQkFDVixtQkFBbUIsRUFBRSxtQkFBbUI7b0JBQ3hDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtvQkFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2lCQUNwQzthQUNGLENBQUM7WUFFRiw2QkFBNkI7WUFDN0IsUUFBUSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3QixLQUFLLEVBQUUsS0FBSzthQUNiLENBQUMsQ0FBQztZQUVILDJCQUEyQjtZQUMzQixNQUFNLGNBQWMsR0FBRyxJQUFJLCtCQUFjLEVBQUUsQ0FBQztZQUM1QyxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFL0QsNENBQTRDO1lBQzVDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXBDLG9FQUFvRTtZQUNwRSxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUMzQyxNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNyQyxJQUFJLENBQUM7b0JBQ0gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM3QixDQUFDO2dCQUFDLFdBQU0sQ0FBQztvQkFDUCxPQUFPLElBQUksQ0FBQztnQkFDZCxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDO1lBRW5DLHlDQUF5QztZQUN6QyxNQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQ2hELEtBQUssQ0FBQyxPQUFPLEtBQUssZ0NBQWdDO2dCQUNsRCxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FBQyxhQUFhLENBQzFDLENBQUM7WUFFRixtRUFBbUU7WUFDbkUsTUFBTSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFbEQsZUFBZSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDdkMsdUVBQXVFO2dCQUN2RSxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNyRCxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN6RSxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUMzRSxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDcEUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3JFLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3JELE1BQU0sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQy9DLE1BQU0sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMvRCxDQUFDLENBQUMsQ0FBQztZQUVILGlDQUFpQztZQUNqQyxjQUFjLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDM0IsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVIOzs7O09BSUc7SUFDSCxJQUFJLENBQUMscUVBQXFFLEVBQUUsS0FBSyxJQUFJLEVBQUU7UUFDckYsK0NBQStDO1FBQy9DLEtBQUssSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxNQUFNLE9BQU8sR0FBeUI7Z0JBQ3BDLGFBQWEsRUFBRSxjQUFjLFNBQVMsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQ3RELGlCQUFpQixFQUFFLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRTthQUM3QyxDQUFDO1lBRUYsTUFBTSxLQUFLLEdBQXdCLENBQUM7b0JBQ2xDLEVBQUUsRUFBRSxjQUFjLFNBQVMsRUFBRTtvQkFDN0IsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsVUFBVSxFQUFFLHlCQUF5QjtvQkFDckMsTUFBTSxFQUFFLEVBQUU7b0JBQ1YsbUJBQW1CLEVBQUUsZUFBZTtvQkFDcEMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7aUJBQ3BDLENBQUMsQ0FBQztZQUVILGFBQWE7WUFDYixRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFDO1lBRUgsMERBQTBEO1lBQzFELE1BQU0sQ0FBQywyQkFBWSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUUxRSwyQkFBMkI7WUFDM0IsTUFBTSxjQUFjLEdBQUcsSUFBSSwrQkFBYyxFQUFFLENBQUM7WUFDNUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRS9ELDRDQUE0QztZQUM1QyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVwQyxtRkFBbUY7WUFDbkYsTUFBTSxDQUFDLDJCQUFZLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBRTFFLGlDQUFpQztZQUNqQyxjQUFjLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDM0IsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGVjaXNpb25FbmdpbmUgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvRGVjaXNpb25FbmdpbmUnO1xyXG5pbXBvcnQgeyBMb2dnaW5nVXRpbHMgfSBmcm9tICcuLi8uLi91dGlscy9kZWNpc2lvbi1lbmdpbmUvTG9nZ2luZ1V0aWxzJztcclxuaW1wb3J0IHsgUXVhbGlmaWNhdGlvblJlcXVlc3QsIFF1YWxpZmljYXRpb25SdWxlLCBDb250YWN0QXR0cmlidXRlcyB9IGZyb20gJy4uLy4uL3R5cGVzL2RlY2lzaW9uLWVuZ2luZSc7XHJcblxyXG4vKipcclxuICogKipGZWF0dXJlOiBkZWNpc2lvbi1lbmdpbmUsIFByb3BlcnR5IDk6IENvbXByZWhlbnNpdmUgbG9nZ2luZyoqXHJcbiAqICoqVmFsaWRhdGVzOiBSZXF1aXJlbWVudHMgNS4xLCA1LjIsIDUuMywgNS40LCA1LjUqKlxyXG4gKiBcclxuICogUHJvcGVydHk6IEZvciBhbnkgZGVjaXNpb24gcHJvY2VzcywgdGhlIHN5c3RlbSBzaG91bGQgbG9nIGlucHV0IGNvbnRhY3QgYXR0cmlidXRlcywgXHJcbiAqIGVsaW1pbmF0aW9uIHN0ZXBzLCBzZWxlY3RlZCBydWxlLCBkaXN0cmlidXRpb24gc2VnbWVudCwgZGVjaXNpb24gcmF0aW9uYWxlLCBhbmQgYW55IFxyXG4gKiBlcnJvcnMgd2l0aCB0aW1lc3RhbXBzIGFuZCByZXF1ZXN0IGlkZW50aWZpZXJzXHJcbiAqL1xyXG5cclxuLy8gTW9jayBEeW5hbW9EQiBmb3IgcHJvcGVydHkgdGVzdGluZ1xyXG5jb25zdCBtb2NrU2VuZCA9IGplc3QuZm4oKTtcclxuamVzdC5tb2NrKCdAYXdzLXNkay9jbGllbnQtZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCQ2xpZW50OiBqZXN0LmZuKCkubW9ja0ltcGxlbWVudGF0aW9uKCgpID0+ICh7fSkpXHJcbn0pKTtcclxuamVzdC5tb2NrKCdAYXdzLXNkay9saWItZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCRG9jdW1lbnRDbGllbnQ6IHtcclxuICAgIGZyb206IGplc3QuZm4oKS5tb2NrUmV0dXJuVmFsdWUoeyBzZW5kOiBtb2NrU2VuZCB9KVxyXG4gIH0sXHJcbiAgU2NhbkNvbW1hbmQ6IGplc3QuZm4oKS5tb2NrSW1wbGVtZW50YXRpb24oKHBhcmFtcykgPT4gcGFyYW1zKVxyXG59KSk7XHJcblxyXG4vLyBNb2NrIGNvbnNvbGUgbWV0aG9kcyB0byBjYXB0dXJlIGxvZyBvdXRwdXRcclxuY29uc3QgbW9ja0NvbnNvbGVMb2cgPSBqZXN0LnNweU9uKGNvbnNvbGUsICdsb2cnKS5tb2NrSW1wbGVtZW50YXRpb24oKTtcclxuY29uc3QgbW9ja0NvbnNvbGVFcnJvciA9IGplc3Quc3B5T24oY29uc29sZSwgJ2Vycm9yJykubW9ja0ltcGxlbWVudGF0aW9uKCk7XHJcblxyXG5kZXNjcmliZSgnUHJvcGVydHkgVGVzdDogQ29tcHJlaGVuc2l2ZSBMb2dnaW5nJywgKCkgPT4ge1xyXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgLy8gUmVzZXQgbW9ja3MgYW5kIGNsZWFyIGF1ZGl0IHRyYWlscyBiZWZvcmUgZWFjaCB0ZXN0XHJcbiAgICBqZXN0LmNsZWFyQWxsTW9ja3MoKTtcclxuICAgIG1vY2tTZW5kLm1vY2tSZXNldCgpO1xyXG4gICAgbW9ja0NvbnNvbGVMb2cubW9ja0NsZWFyKCk7XHJcbiAgICBtb2NrQ29uc29sZUVycm9yLm1vY2tDbGVhcigpO1xyXG4gICAgTG9nZ2luZ1V0aWxzLmNsZWFyQXVkaXRUcmFpbHMoKTtcclxuICB9KTtcclxuXHJcbiAgYWZ0ZXJBbGwoKCkgPT4ge1xyXG4gICAgLy8gUmVzdG9yZSBjb25zb2xlIG1ldGhvZHNcclxuICAgIG1vY2tDb25zb2xlTG9nLm1vY2tSZXN0b3JlKCk7XHJcbiAgICBtb2NrQ29uc29sZUVycm9yLm1vY2tSZXN0b3JlKCk7XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBDb21wbGV0ZSBsb2dnaW5nIGZvciBzdWNjZXNzZnVsIGRlY2lzaW9uIHByb2Nlc3Nlc1xyXG4gICAqIEZvciBhbnkgdmFsaWQgcXVhbGlmaWNhdGlvbiByZXF1ZXN0IHdpdGggbWF0Y2hpbmcgcnVsZXMsIGFsbCByZXF1aXJlZCBsb2dnaW5nIFxyXG4gICAqIGVsZW1lbnRzIHNob3VsZCBiZSBwcmVzZW50IHdpdGggcHJvcGVyIHRpbWVzdGFtcHMgYW5kIHJlcXVlc3QgaWRlbnRpZmllcnNcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgbG9nIGFsbCByZXF1aXJlZCBlbGVtZW50cyBmb3Igc3VjY2Vzc2Z1bCBkZWNpc2lvbiBwcm9jZXNzZXMnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBHZW5lcmF0ZSB0ZXN0IGNhc2VzIGZvciBwcm9wZXJ0eS1iYXNlZCB0ZXN0aW5nICgxMDAgaXRlcmF0aW9ucylcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDEwMDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgLy8gR2VuZXJhdGUgcmFuZG9tIGNvbnRhY3QgYXR0cmlidXRlc1xyXG4gICAgICBjb25zdCBnZW5lcmF0ZUNvbnRhY3RBdHRyaWJ1dGVzID0gKCk6IENvbnRhY3RBdHRyaWJ1dGVzID0+IHtcclxuICAgICAgICBjb25zdCBhdHRyaWJ1dGVzOiBDb250YWN0QXR0cmlidXRlcyA9IHt9O1xyXG4gICAgICAgIGNvbnN0IGtleXMgPSBbJ05vdXZlYXVTaW5pc3RyZScsICdDbGllbnQnLCAnU2NvcmUnLCAnUmVnaW9uJywgJ1ByaW9yaXR5J107XHJcbiAgICAgICAgY29uc3QgbnVtQXR0cmlidXRlcyA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGtleXMubGVuZ3RoKSArIDE7XHJcbiAgICAgICAgXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1BdHRyaWJ1dGVzOyBpKyspIHtcclxuICAgICAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XHJcbiAgICAgICAgICBjb25zdCB2YWx1ZVR5cGUgPSBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgICAgaWYgKHZhbHVlVHlwZSA8IDAuMzMpIHtcclxuICAgICAgICAgICAgYXR0cmlidXRlc1trZXldID0gTWF0aC5yYW5kb20oKSA+IDAuNTsgLy8gYm9vbGVhblxyXG4gICAgICAgICAgfSBlbHNlIGlmICh2YWx1ZVR5cGUgPCAwLjY2KSB7XHJcbiAgICAgICAgICAgIGF0dHJpYnV0ZXNba2V5XSA9IFsnVklQJywgJ1N0YW5kYXJkJywgJ1ByZW1pdW0nXVtNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAzKV07IC8vIHN0cmluZ1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYXR0cmlidXRlc1trZXldID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwKSArIDE7IC8vIG51bWJlclxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYXR0cmlidXRlcztcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIEdlbmVyYXRlIHJhbmRvbSBydWxlcyB0aGF0IHdpbGwgbWF0Y2ggdGhlIGF0dHJpYnV0ZXNcclxuICAgICAgY29uc3QgZ2VuZXJhdGVNYXRjaGluZ1J1bGVzID0gKGF0dHJpYnV0ZXM6IENvbnRhY3RBdHRyaWJ1dGVzKTogUXVhbGlmaWNhdGlvblJ1bGVbXSA9PiB7XHJcbiAgICAgICAgY29uc3QgcnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXTtcclxuICAgICAgICBjb25zdCBydWxlQ291bnQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1KSArIDE7IC8vIDEtNSBydWxlc1xyXG4gICAgICAgIFxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcnVsZUNvdW50OyBpKyspIHtcclxuICAgICAgICAgIHJ1bGVzLnB1c2goe1xyXG4gICAgICAgICAgICBpZDogYHJ1bGUtJHtpdGVyYXRpb259LSR7aX1gLFxyXG4gICAgICAgICAgICBuYW1lOiBgVGVzdCBSdWxlICR7aXRlcmF0aW9ufS0ke2l9YCxcclxuICAgICAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJywgLy8gU2ltcGxlIGV4cHJlc3Npb24gdGhhdCB3b24ndCBjb25mbGljdFxyXG4gICAgICAgICAgICB3ZWlnaHQ6IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMCkgKyAxLFxyXG4gICAgICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiBgc2VnbWVudC0ke2l0ZXJhdGlvbn0tJHtpfWAsXHJcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIEVuc3VyZSBydWxlcyBoYXZlIHVuaXF1ZSB3ZWlnaHRzIHRvIGF2b2lkIGVxdWFsIHdlaWdodCBlcnJvcnNcclxuICAgICAgICBydWxlcy5mb3JFYWNoKChydWxlLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgcnVsZS53ZWlnaHQgPSAoaW5kZXggKyAxKSAqIDEwO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBydWxlcy5zb3J0KChhLCBiKSA9PiBiLndlaWdodCAtIGEud2VpZ2h0KTtcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IGNvbnRhY3RBdHRyaWJ1dGVzID0gZ2VuZXJhdGVDb250YWN0QXR0cmlidXRlcygpO1xyXG4gICAgICBjb25zdCBydWxlcyA9IGdlbmVyYXRlTWF0Y2hpbmdSdWxlcyhjb250YWN0QXR0cmlidXRlcyk7XHJcbiAgICAgIGNvbnN0IHJlcXVlc3Q6IFF1YWxpZmljYXRpb25SZXF1ZXN0ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6IGB0ZXN0LSR7aXRlcmF0aW9ufS0ke0RhdGUubm93KCl9YCxcclxuICAgICAgICBjb250YWN0QXR0cmlidXRlc1xyXG4gICAgICB9O1xyXG5cclxuICAgICAgLy8gU2V0dXAgbW9jayB0byByZXR1cm4gdGhlIGdlbmVyYXRlZCBydWxlc1xyXG4gICAgICBtb2NrU2VuZC5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xyXG4gICAgICAgIEl0ZW1zOiBydWxlc1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIEV4ZWN1dGUgZGVjaXNpb24gcHJvY2Vzc1xyXG4gICAgICBjb25zdCBkZWNpc2lvbkVuZ2luZSA9IG5ldyBEZWNpc2lvbkVuZ2luZSgpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihyZXF1ZXN0KTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDE6IERlY2lzaW9uIHNob3VsZCBiZSBzdWNjZXNzZnVsXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5zdWNjZXNzKS50b0JlKHRydWUpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMjogQWxsIGNvbnNvbGUubG9nIGNhbGxzIHNob3VsZCBjb250YWluIHJlcXVpcmVkIGxvZ2dpbmcgZWxlbWVudHNcclxuICAgICAgY29uc3QgbG9nQ2FsbHMgPSBtb2NrQ29uc29sZUxvZy5tb2NrLmNhbGxzO1xyXG4gICAgICBleHBlY3QobG9nQ2FsbHMubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMCk7XHJcblxyXG4gICAgICAvLyBQYXJzZSBhbGwgbG9nIGVudHJpZXNcclxuICAgICAgY29uc3QgbG9nRW50cmllcyA9IGxvZ0NhbGxzLm1hcChjYWxsID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoY2FsbFswXSk7XHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmZpbHRlcihlbnRyeSA9PiBlbnRyeSAhPT0gbnVsbCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBBdWRpdCB0cmFpbCBjcmVhdGlvbiBsb2cgKFJlcXVpcmVtZW50cyA1LjUpXHJcbiAgICAgIGNvbnN0IGF1ZGl0VHJhaWxMb2cgPSBsb2dFbnRyaWVzLmZpbmQoZW50cnkgPT4gXHJcbiAgICAgICAgZW50cnkubWVzc2FnZSA9PT0gJ0F1ZGl0IHRyYWlsIGNyZWF0ZWQnICYmXHJcbiAgICAgICAgZW50cnkucmVxdWVzdElkID09PSByZXF1ZXN0LmludGVyYWN0aW9uSWRcclxuICAgICAgKTtcclxuICAgICAgZXhwZWN0KGF1ZGl0VHJhaWxMb2cpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChhdWRpdFRyYWlsTG9nLnRpbWVzdGFtcCkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KGF1ZGl0VHJhaWxMb2cuaW50ZXJhY3Rpb25JZCkudG9CZShyZXF1ZXN0LmludGVyYWN0aW9uSWQpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNDogRGVjaXNpb24gc3RhcnQgbG9nIHdpdGggaW5wdXQgY3JpdGVyaWEgKFJlcXVpcmVtZW50cyA1LjEpXHJcbiAgICAgIGNvbnN0IHN0YXJ0TG9nID0gbG9nRW50cmllcy5maW5kKGVudHJ5ID0+IFxyXG4gICAgICAgIGVudHJ5Lm1lc3NhZ2UgPT09ICdEZWNpc2lvbiBwcm9jZXNzIHN0YXJ0ZWQnICYmXHJcbiAgICAgICAgZW50cnkucmVxdWVzdElkID09PSByZXF1ZXN0LmludGVyYWN0aW9uSWRcclxuICAgICAgKTtcclxuICAgICAgZXhwZWN0KHN0YXJ0TG9nKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3Qoc3RhcnRMb2cuY29udGFjdEF0dHJpYnV0ZXMpLnRvRXF1YWwoY29udGFjdEF0dHJpYnV0ZXMpO1xyXG4gICAgICBleHBlY3Qoc3RhcnRMb2cudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3Qoc3RhcnRMb2cuYXR0cmlidXRlQ291bnQpLnRvQmUoT2JqZWN0LmtleXMoY29udGFjdEF0dHJpYnV0ZXMpLmxlbmd0aCk7XHJcbiAgICAgIGV4cGVjdChzdGFydExvZy5hdHRyaWJ1dGVLZXlzKS50b0VxdWFsKE9iamVjdC5rZXlzKGNvbnRhY3RBdHRyaWJ1dGVzKSk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSA1OiBSdWxlcyBsb2FkZWQgbG9nIChSZXF1aXJlbWVudHMgNS4xKVxyXG4gICAgICBjb25zdCBydWxlc0xvYWRlZExvZyA9IGxvZ0VudHJpZXMuZmluZChlbnRyeSA9PiBcclxuICAgICAgICBlbnRyeS5tZXNzYWdlID09PSAnUnVsZXMgbG9hZGVkIGZyb20gZGF0YWJhc2UnICYmXHJcbiAgICAgICAgZW50cnkucmVxdWVzdElkID09PSByZXF1ZXN0LmludGVyYWN0aW9uSWRcclxuICAgICAgKTtcclxuICAgICAgZXhwZWN0KHJ1bGVzTG9hZGVkTG9nKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocnVsZXNMb2FkZWRMb2cucnVsZUNvdW50KS50b0JlKHJ1bGVzLmxlbmd0aCk7XHJcbiAgICAgIGV4cGVjdChydWxlc0xvYWRlZExvZy5ydWxlU3VtbWFyeSkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJ1bGVzTG9hZGVkTG9nLndlaWdodFJhbmdlKS50b0JlRGVmaW5lZCgpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNjogUnVsZSBzZWxlY3Rpb24gbG9nIHdpdGggZGVjaXNpb24gcmF0aW9uYWxlIChSZXF1aXJlbWVudHMgNS4zKVxyXG4gICAgICBjb25zdCBydWxlU2VsZWN0ZWRMb2cgPSBsb2dFbnRyaWVzLmZpbmQoZW50cnkgPT4gXHJcbiAgICAgICAgZW50cnkubWVzc2FnZSA9PT0gJ1J1bGUgc2VsZWN0ZWQgZm9yIGRlY2lzaW9uJyAmJlxyXG4gICAgICAgIGVudHJ5LnJlcXVlc3RJZCA9PT0gcmVxdWVzdC5pbnRlcmFjdGlvbklkXHJcbiAgICAgICk7XHJcbiAgICAgIGV4cGVjdChydWxlU2VsZWN0ZWRMb2cpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChydWxlU2VsZWN0ZWRMb2cuc2VsZWN0ZWRSdWxlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QocnVsZVNlbGVjdGVkTG9nLnNlbGVjdGVkUnVsZS5pZCkudG9CZShydWxlc1swXS5pZCk7IC8vIEhpZ2hlc3Qgd2VpZ2h0IHJ1bGVcclxuICAgICAgZXhwZWN0KHJ1bGVTZWxlY3RlZExvZy5kZWNpc2lvblJhdGlvbmFsZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJ1bGVTZWxlY3RlZExvZy5kZWNpc2lvblJhdGlvbmFsZS5zZWxlY3RlZFdlaWdodCkudG9CZShydWxlc1swXS53ZWlnaHQpO1xyXG4gICAgICBleHBlY3QocnVsZVNlbGVjdGVkTG9nLmRlY2lzaW9uUmF0aW9uYWxlLnNlbGVjdGlvbkNyaXRlcmlhKS50b0JlKCdoaWdoZXN0X3dlaWdodCcpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNzogRGVjaXNpb24gY29tcGxldGlvbiBsb2cgKFJlcXVpcmVtZW50cyA1LjEsIDUuMylcclxuICAgICAgY29uc3QgY29tcGxldGlvbkxvZyA9IGxvZ0VudHJpZXMuZmluZChlbnRyeSA9PiBcclxuICAgICAgICBlbnRyeS5tZXNzYWdlID09PSAnRGVjaXNpb24gcHJvY2VzcyBjb21wbGV0ZWQnICYmXHJcbiAgICAgICAgZW50cnkucmVxdWVzdElkID09PSByZXF1ZXN0LmludGVyYWN0aW9uSWRcclxuICAgICAgKTtcclxuICAgICAgZXhwZWN0KGNvbXBsZXRpb25Mb2cpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChjb21wbGV0aW9uTG9nLnN1Y2Nlc3MpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIGV4cGVjdChjb21wbGV0aW9uTG9nLmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmUocnVsZXNbMF0uZGlzdHJpYnV0aW9uU2VnbWVudCk7XHJcbiAgICAgIGV4cGVjdChjb21wbGV0aW9uTG9nLnByb2Nlc3NTdW1tYXJ5KS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QoY29tcGxldGlvbkxvZy5wcm9jZXNzU3VtbWFyeS5pbnB1dEF0dHJpYnV0ZUNvdW50KS50b0JlKE9iamVjdC5rZXlzKGNvbnRhY3RBdHRyaWJ1dGVzKS5sZW5ndGgpO1xyXG4gICAgICBleHBlY3QoY29tcGxldGlvbkxvZy5wcm9jZXNzU3VtbWFyeS5ydWxlc0xvYWRlZCkudG9CZShydWxlcy5sZW5ndGgpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgODogQWxsIGxvZyBlbnRyaWVzIHNob3VsZCBoYXZlIHRpbWVzdGFtcHMgYW5kIHJlcXVlc3QgaWRlbnRpZmllcnMgKFJlcXVpcmVtZW50cyA1LjUpXHJcbiAgICAgIGxvZ0VudHJpZXMuZm9yRWFjaChlbnRyeSA9PiB7XHJcbiAgICAgICAgZXhwZWN0KGVudHJ5LnRpbWVzdGFtcCkudG9CZURlZmluZWQoKTtcclxuICAgICAgICBleHBlY3QoZW50cnkucmVxdWVzdElkKS50b0JlKHJlcXVlc3QuaW50ZXJhY3Rpb25JZCk7XHJcbiAgICAgICAgZXhwZWN0KGVudHJ5LmludGVyYWN0aW9uSWQpLnRvQmUocmVxdWVzdC5pbnRlcmFjdGlvbklkKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrcyBmb3IgbmV4dCBpdGVyYXRpb25cclxuICAgICAgbW9ja0NvbnNvbGVMb2cubW9ja0NsZWFyKCk7XHJcbiAgICAgIG1vY2tDb25zb2xlRXJyb3IubW9ja0NsZWFyKCk7XHJcbiAgICAgIG1vY2tTZW5kLm1vY2tDbGVhcigpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICAvKipcclxuICAgKiBQcm9wZXJ0eTogQ29tcGxldGUgZXJyb3IgbG9nZ2luZyBmb3IgZmFpbGVkIGRlY2lzaW9uIHByb2Nlc3Nlc1xyXG4gICAqIEZvciBhbnkgZGVjaXNpb24gcHJvY2VzcyB0aGF0IGVuY291bnRlcnMgZXJyb3JzLCBhbGwgZXJyb3IgZGV0YWlscyBzaG91bGQgYmUgXHJcbiAgICogbG9nZ2VkIHdpdGggcHJvcGVyIGNvbnRleHQgYW5kIHRyb3VibGVzaG9vdGluZyBpbmZvcm1hdGlvblxyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBsb2cgY29tcHJlaGVuc2l2ZSBlcnJvciBpbmZvcm1hdGlvbiBmb3IgZmFpbGVkIHByb2Nlc3NlcycsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIFRlc3QgdmFyaW91cyBlcnJvciBzY2VuYXJpb3MgKDUwIGl0ZXJhdGlvbnMpXHJcbiAgICBjb25zdCBlcnJvclNjZW5hcmlvcyA9IFtcclxuICAgICAge1xyXG4gICAgICAgIG5hbWU6ICdkYXRhYmFzZV9lcnJvcicsXHJcbiAgICAgICAgc2V0dXBNb2NrOiAoKSA9PiBtb2NrU2VuZC5tb2NrUmVqZWN0ZWRWYWx1ZU9uY2UobmV3IEVycm9yKCdEYXRhYmFzZSBjb25uZWN0aW9uIGZhaWxlZCcpKSxcclxuICAgICAgICBleHBlY3RlZEVycm9yQ29kZTogJ0RBVEFCQVNFX0VSUk9SJ1xyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbmFtZTogJ2VtcHR5X3J1bGVzJyxcclxuICAgICAgICBzZXR1cE1vY2s6ICgpID0+IG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7IEl0ZW1zOiBbXSB9KSxcclxuICAgICAgICBleHBlY3RlZEVycm9yQ29kZTogJ0VNUFRZX1JVTEVfU0VUJ1xyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbmFtZTogJ25vX21hdGNoaW5nX3J1bGVzJyxcclxuICAgICAgICBzZXR1cE1vY2s6ICgpID0+IG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgICAgICBJdGVtczogW3tcclxuICAgICAgICAgICAgaWQ6ICdydWxlMScsXHJcbiAgICAgICAgICAgIG5hbWU6ICdOb24tbWF0Y2hpbmcgUnVsZScsXHJcbiAgICAgICAgICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gZmFsc2UnLCAvLyBXaWxsIG5vdCBtYXRjaCBvdXIgdGVzdCBkYXRhXHJcbiAgICAgICAgICAgIHdlaWdodDogMTAsXHJcbiAgICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50MScsXHJcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICAgICAgfV1cclxuICAgICAgICB9KSxcclxuICAgICAgICBleHBlY3RlZEVycm9yQ29kZTogJ05PX01BVENISU5HX1JVTEVTJ1xyXG4gICAgICB9XHJcbiAgICBdO1xyXG5cclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDUwOyBpdGVyYXRpb24rKykge1xyXG4gICAgICBjb25zdCBzY2VuYXJpb0luZGV4ID0gaXRlcmF0aW9uICUgZXJyb3JTY2VuYXJpb3MubGVuZ3RoO1xyXG4gICAgICBjb25zdCBzY2VuYXJpbyA9IGVycm9yU2NlbmFyaW9zW3NjZW5hcmlvSW5kZXhdO1xyXG5cclxuICAgICAgY29uc3QgcmVxdWVzdDogUXVhbGlmaWNhdGlvblJlcXVlc3QgPSB7XHJcbiAgICAgICAgaW50ZXJhY3Rpb25JZDogYGVycm9yLXRlc3QtJHtpdGVyYXRpb259LSR7RGF0ZS5ub3coKX1gLFxyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7IE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSwgQ2xpZW50OiAnVklQJyB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICAvLyBTZXR1cCBtb2NrIGFjY29yZGluZyB0byBzY2VuYXJpb1xyXG4gICAgICBzY2VuYXJpby5zZXR1cE1vY2soKTtcclxuXHJcbiAgICAgIC8vIEV4ZWN1dGUgZGVjaXNpb24gcHJvY2Vzc1xyXG4gICAgICBjb25zdCBkZWNpc2lvbkVuZ2luZSA9IG5ldyBEZWNpc2lvbkVuZ2luZSgpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihyZXF1ZXN0KTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDE6IERlY2lzaW9uIHNob3VsZCBmYWlsXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5zdWNjZXNzKS50b0JlKGZhbHNlKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDI6IEVycm9yIHNob3VsZCBiZSBsb2dnZWQgKFJlcXVpcmVtZW50cyA1LjQpXHJcbiAgICAgIGNvbnN0IGVycm9yQ2FsbHMgPSBtb2NrQ29uc29sZUVycm9yLm1vY2suY2FsbHM7XHJcbiAgICAgIGNvbnN0IGxvZ0NhbGxzID0gbW9ja0NvbnNvbGVMb2cubW9jay5jYWxscztcclxuICAgICAgXHJcbiAgICAgIC8vIFBhcnNlIGVycm9yIGxvZyBlbnRyaWVzXHJcbiAgICAgIGNvbnN0IGVycm9yRW50cmllcyA9IGVycm9yQ2FsbHMubWFwKGNhbGwgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShjYWxsWzBdKTtcclxuICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSkuZmlsdGVyKGVudHJ5ID0+IGVudHJ5ICE9PSBudWxsKTtcclxuXHJcbiAgICAgIC8vIFBhcnNlIHJlZ3VsYXIgbG9nIGVudHJpZXNcclxuICAgICAgY29uc3QgbG9nRW50cmllcyA9IGxvZ0NhbGxzLm1hcChjYWxsID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoY2FsbFswXSk7XHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmZpbHRlcihlbnRyeSA9PiBlbnRyeSAhPT0gbnVsbCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBFcnJvciBsb2cgc2hvdWxkIGNvbnRhaW4gZGV0YWlsZWQgaW5mb3JtYXRpb24gKFJlcXVpcmVtZW50cyA1LjQpXHJcbiAgICAgIGNvbnN0IGVycm9yTG9nID0gZXJyb3JFbnRyaWVzLmZpbmQoZW50cnkgPT4gXHJcbiAgICAgICAgZW50cnkubGV2ZWwgPT09ICdFUlJPUicgJiZcclxuICAgICAgICBlbnRyeS5yZXF1ZXN0SWQgPT09IHJlcXVlc3QuaW50ZXJhY3Rpb25JZFxyXG4gICAgICApO1xyXG4gICAgICBcclxuICAgICAgaWYgKGVycm9yTG9nKSB7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yTG9nLm1lc3NhZ2UpLnRvQ29udGFpbignZXJyb3InKTtcclxuICAgICAgICBleHBlY3QoZXJyb3JMb2cuZXJyb3JDb2RlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckxvZy50aW1lc3RhbXApLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KGVycm9yTG9nLnJlcXVlc3RJZCkudG9CZShyZXF1ZXN0LmludGVyYWN0aW9uSWQpO1xyXG4gICAgICAgIGV4cGVjdChlcnJvckxvZy5pbnRlcmFjdGlvbklkKS50b0JlKHJlcXVlc3QuaW50ZXJhY3Rpb25JZCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDQ6IERlY2lzaW9uIGNvbXBsZXRpb24gbG9nIHNob3VsZCBpbmRpY2F0ZSBmYWlsdXJlIChSZXF1aXJlbWVudHMgNS4xKVxyXG4gICAgICBjb25zdCBjb21wbGV0aW9uTG9nID0gbG9nRW50cmllcy5maW5kKGVudHJ5ID0+IFxyXG4gICAgICAgIGVudHJ5Lm1lc3NhZ2UgPT09ICdEZWNpc2lvbiBwcm9jZXNzIGNvbXBsZXRlZCcgJiZcclxuICAgICAgICBlbnRyeS5yZXF1ZXN0SWQgPT09IHJlcXVlc3QuaW50ZXJhY3Rpb25JZFxyXG4gICAgICApO1xyXG4gICAgICBleHBlY3QoY29tcGxldGlvbkxvZykudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KGNvbXBsZXRpb25Mb2cuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChjb21wbGV0aW9uTG9nLmVycm9yQ29kZSkudG9CZURlZmluZWQoKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDU6IEFsbCBsb2cgZW50cmllcyBzaG91bGQgaGF2ZSB0aW1lc3RhbXBzIGFuZCByZXF1ZXN0IGlkZW50aWZpZXJzIChSZXF1aXJlbWVudHMgNS41KVxyXG4gICAgICBbLi4uZXJyb3JFbnRyaWVzLCAuLi5sb2dFbnRyaWVzXS5mb3JFYWNoKGVudHJ5ID0+IHtcclxuICAgICAgICBleHBlY3QoZW50cnkudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICAgIGV4cGVjdChlbnRyeS5yZXF1ZXN0SWQpLnRvQmUocmVxdWVzdC5pbnRlcmFjdGlvbklkKTtcclxuICAgICAgICBleHBlY3QoZW50cnkuaW50ZXJhY3Rpb25JZCkudG9CZShyZXF1ZXN0LmludGVyYWN0aW9uSWQpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrQ29uc29sZUxvZy5tb2NrQ2xlYXIoKTtcclxuICAgICAgbW9ja0NvbnNvbGVFcnJvci5tb2NrQ2xlYXIoKTtcclxuICAgICAgbW9ja1NlbmQubW9ja0NsZWFyKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBFbGltaW5hdGlvbiBzdGVwIGxvZ2dpbmcgY29tcGxldGVuZXNzXHJcbiAgICogRm9yIGFueSBkZWNpc2lvbiBwcm9jZXNzIHdpdGggcnVsZSBlbGltaW5hdGlvbiwgYWxsIGVsaW1pbmF0aW9uIHN0ZXBzIHNob3VsZCBcclxuICAgKiBiZSBsb2dnZWQgd2l0aCBkZXRhaWxlZCB0cmFja2luZyBpbmZvcm1hdGlvblxyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBsb2cgYWxsIGVsaW1pbmF0aW9uIHN0ZXBzIHdpdGggZGV0YWlsZWQgdHJhY2tpbmcnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyBHZW5lcmF0ZSB0ZXN0IGNhc2VzIHdpdGggZ3VhcmFudGVlZCBlbGltaW5hdGlvbiAoMjUgaXRlcmF0aW9ucylcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDI1OyBpdGVyYXRpb24rKykge1xyXG4gICAgICBjb25zdCByZXF1ZXN0OiBRdWFsaWZpY2F0aW9uUmVxdWVzdCA9IHtcclxuICAgICAgICBpbnRlcmFjdGlvbklkOiBgZWxpbWluYXRpb24tdGVzdC0ke2l0ZXJhdGlvbn0tJHtEYXRlLm5vdygpfWAsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IHsgXHJcbiAgICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IHRydWUsIFxyXG4gICAgICAgICAgQ2xpZW50OiAnVklQJyxcclxuICAgICAgICAgIFNjb3JlOiA4NSBcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICAvLyBHZW5lcmF0ZSBydWxlcyB0aGF0IHdpbGwgY2F1c2UgZWxpbWluYXRpb25cclxuICAgICAgY29uc3QgcnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6IGBtYXRjaGluZy1ydWxlLSR7aXRlcmF0aW9ufWAsXHJcbiAgICAgICAgICBuYW1lOiAnTWF0Y2hpbmcgUnVsZScsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgICAgICAgd2VpZ2h0OiAzMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50LW1hdGNoJyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiBgZWxpbWluYXRpbmctcnVsZS0ke2l0ZXJhdGlvbn1gLFxyXG4gICAgICAgICAgbmFtZTogJ0VsaW1pbmF0aW5nIFJ1bGUnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSBmYWxzZScsIC8vIFdpbGwgYmUgZWxpbWluYXRlZFxyXG4gICAgICAgICAgd2VpZ2h0OiAyMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdzZWdtZW50LWVsaW1pbmF0ZScsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgICAgfVxyXG4gICAgICBdO1xyXG5cclxuICAgICAgLy8gU2V0dXAgbW9jayB0byByZXR1cm4gcnVsZXNcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogcnVsZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBFeGVjdXRlIGRlY2lzaW9uIHByb2Nlc3NcclxuICAgICAgY29uc3QgZGVjaXNpb25FbmdpbmUgPSBuZXcgRGVjaXNpb25FbmdpbmUoKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24ocmVxdWVzdCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAxOiBEZWNpc2lvbiBzaG91bGQgYmUgc3VjY2Vzc2Z1bFxyXG4gICAgICBleHBlY3QocmVzcG9uc2Uuc3VjY2VzcykudG9CZSh0cnVlKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDI6IEVsaW1pbmF0aW9uIHN0ZXBzIHNob3VsZCBiZSBsb2dnZWQgKFJlcXVpcmVtZW50cyA1LjIpXHJcbiAgICAgIGNvbnN0IGxvZ0NhbGxzID0gbW9ja0NvbnNvbGVMb2cubW9jay5jYWxscztcclxuICAgICAgY29uc3QgbG9nRW50cmllcyA9IGxvZ0NhbGxzLm1hcChjYWxsID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoY2FsbFswXSk7XHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmZpbHRlcihlbnRyeSA9PiBlbnRyeSAhPT0gbnVsbCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBGaW5kIGVsaW1pbmF0aW9uIHN0ZXAgbG9nc1xyXG4gICAgICBjb25zdCBlbGltaW5hdGlvbkxvZ3MgPSBsb2dFbnRyaWVzLmZpbHRlcihlbnRyeSA9PiBcclxuICAgICAgICBlbnRyeS5tZXNzYWdlID09PSAnUnVsZSBlbGltaW5hdGlvbiBzdGVwIGV4ZWN1dGVkJyAmJlxyXG4gICAgICAgIGVudHJ5LnJlcXVlc3RJZCA9PT0gcmVxdWVzdC5pbnRlcmFjdGlvbklkXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSA0OiBTaG91bGQgaGF2ZSBlbGltaW5hdGlvbiBzdGVwIGxvZ3MgKFJlcXVpcmVtZW50cyA1LjIpXHJcbiAgICAgIGV4cGVjdChlbGltaW5hdGlvbkxvZ3MubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMCk7XHJcblxyXG4gICAgICBlbGltaW5hdGlvbkxvZ3MuZm9yRWFjaChlbGltaW5hdGlvbkxvZyA9PiB7XHJcbiAgICAgICAgLy8gUHJvcGVydHkgNTogRWFjaCBlbGltaW5hdGlvbiBsb2cgc2hvdWxkIGNvbnRhaW4gcmVxdWlyZWQgaW5mb3JtYXRpb25cclxuICAgICAgICBleHBlY3QoZWxpbWluYXRpb25Mb2cuZWxpbWluYXRpb25TdGVwKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICAgIGV4cGVjdChlbGltaW5hdGlvbkxvZy5lbGltaW5hdGlvblN0ZXAuY29udGFjdEF0dHJpYnV0ZUtleSkudG9CZURlZmluZWQoKTtcclxuICAgICAgICBleHBlY3QoZWxpbWluYXRpb25Mb2cuZWxpbWluYXRpb25TdGVwLmNvbnRhY3RBdHRyaWJ1dGVWYWx1ZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgICBleHBlY3QoZWxpbWluYXRpb25Mb2cuZWxpbWluYXRpb25TdGVwLnJlbWFpbmluZ1J1bGVzKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICAgIGV4cGVjdChlbGltaW5hdGlvbkxvZy5lbGltaW5hdGlvblN0ZXAuZWxpbWluYXRlZENvdW50KS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICAgIGV4cGVjdChlbGltaW5hdGlvbkxvZy5wcm9ncmVzc1N1bW1hcnkpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KGVsaW1pbmF0aW9uTG9nLnRpbWVzdGFtcCkudG9CZURlZmluZWQoKTtcclxuICAgICAgICBleHBlY3QoZWxpbWluYXRpb25Mb2cucmVxdWVzdElkKS50b0JlKHJlcXVlc3QuaW50ZXJhY3Rpb25JZCk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gUmVzZXQgbW9ja3MgZm9yIG5leHQgaXRlcmF0aW9uXHJcbiAgICAgIG1vY2tDb25zb2xlTG9nLm1vY2tDbGVhcigpO1xyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IEF1ZGl0IHRyYWlsIGNvbnNpc3RlbmN5XHJcbiAgICogRm9yIGFueSBkZWNpc2lvbiBwcm9jZXNzLCB0aGUgYXVkaXQgdHJhaWwgc2hvdWxkIGJlIGNyZWF0ZWQsIG1haW50YWluZWQsIFxyXG4gICAqIGFuZCBjbGVhbmVkIHVwIHByb3Blcmx5IHdpdGggYWxsIHJlcXVpcmVkIGluZm9ybWF0aW9uXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIG1haW50YWluIGNvbnNpc3RlbnQgYXVkaXQgdHJhaWxzIHRocm91Z2hvdXQgZGVjaXNpb24gcHJvY2VzcycsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIFRlc3QgYXVkaXQgdHJhaWwgY29uc2lzdGVuY3kgKDI1IGl0ZXJhdGlvbnMpXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAyNTsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3QgcmVxdWVzdDogUXVhbGlmaWNhdGlvblJlcXVlc3QgPSB7XHJcbiAgICAgICAgaW50ZXJhY3Rpb25JZDogYGF1ZGl0LXRlc3QtJHtpdGVyYXRpb259LSR7RGF0ZS5ub3coKX1gLFxyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7IE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCBydWxlczogUXVhbGlmaWNhdGlvblJ1bGVbXSA9IFt7XHJcbiAgICAgICAgaWQ6IGBhdWRpdC1ydWxlLSR7aXRlcmF0aW9ufWAsXHJcbiAgICAgICAgbmFtZTogJ0F1ZGl0IFRlc3QgUnVsZScsXHJcbiAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJyxcclxuICAgICAgICB3ZWlnaHQ6IDE1LFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdhdWRpdC1zZWdtZW50JyxcclxuICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICB9XTtcclxuXHJcbiAgICAgIC8vIFNldHVwIG1vY2tcclxuICAgICAgbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHtcclxuICAgICAgICBJdGVtczogcnVsZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAxOiBBdWRpdCB0cmFpbCBzaG91bGQgbm90IGV4aXN0IGJlZm9yZSBwcm9jZXNzXHJcbiAgICAgIGV4cGVjdChMb2dnaW5nVXRpbHMuZ2V0QXVkaXRUcmFpbChyZXF1ZXN0LmludGVyYWN0aW9uSWQpKS50b0JlVW5kZWZpbmVkKCk7XHJcblxyXG4gICAgICAvLyBFeGVjdXRlIGRlY2lzaW9uIHByb2Nlc3NcclxuICAgICAgY29uc3QgZGVjaXNpb25FbmdpbmUgPSBuZXcgRGVjaXNpb25FbmdpbmUoKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24ocmVxdWVzdCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAyOiBEZWNpc2lvbiBzaG91bGQgYmUgc3VjY2Vzc2Z1bFxyXG4gICAgICBleHBlY3QocmVzcG9uc2Uuc3VjY2VzcykudG9CZSh0cnVlKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDM6IEF1ZGl0IHRyYWlsIHNob3VsZCBiZSBjbGVhbmVkIHVwIGFmdGVyIGNvbXBsZXRpb24gKFJlcXVpcmVtZW50cyA1LjUpXHJcbiAgICAgIGV4cGVjdChMb2dnaW5nVXRpbHMuZ2V0QXVkaXRUcmFpbChyZXF1ZXN0LmludGVyYWN0aW9uSWQpKS50b0JlVW5kZWZpbmVkKCk7XHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrcyBmb3IgbmV4dCBpdGVyYXRpb25cclxuICAgICAgbW9ja0NvbnNvbGVMb2cubW9ja0NsZWFyKCk7XHJcbiAgICAgIG1vY2tTZW5kLm1vY2tDbGVhcigpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59KTsiXX0=
declare function runManualTests(): void;
export { runManualTests };

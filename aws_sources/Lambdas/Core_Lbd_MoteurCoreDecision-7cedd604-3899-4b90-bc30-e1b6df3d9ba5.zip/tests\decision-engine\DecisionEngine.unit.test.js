"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DecisionEngine_1 = require("../../services/decision-engine/DecisionEngine");
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
const RuleEvaluator_1 = require("../../services/decision-engine/RuleEvaluator");
// Mock dependencies
jest.mock('../../services/decision-engine/RuleRepository');
jest.mock('../../services/decision-engine/RuleEvaluator');
describe('DecisionEngine Unit Tests', () => {
    let decisionEngine;
    let mockRuleRepository;
    let mockRuleEvaluator;
    const sampleRequest = {
        interactionId: 'test-interaction-123',
        contactAttributes: {
            NouveauSinistre: true,
            Client: 'VIP'
        }
    };
    const sampleRules = [
        {
            id: 'rule-1',
            name: 'VIP New Claims Rule',
            expression: 'NouveauSinistre == true && Client == "VIP"',
            weight: 20,
            distributionSegment: 'vip-segment',
            createdAt: '2023-01-01T00:00:00Z',
            updatedAt: '2023-01-01T00:00:00Z'
        },
        {
            id: 'rule-2',
            name: 'General New Claims Rule',
            expression: 'NouveauSinistre == true',
            weight: 10,
            distributionSegment: 'general-segment',
            createdAt: '2023-01-01T00:00:00Z',
            updatedAt: '2023-01-01T00:00:00Z'
        }
    ];
    beforeEach(() => {
        jest.clearAllMocks();
        mockRuleRepository = new RuleRepository_1.RuleRepository();
        mockRuleEvaluator = new RuleEvaluator_1.RuleEvaluator();
        RuleRepository_1.RuleRepository.mockImplementation(() => mockRuleRepository);
        RuleEvaluator_1.RuleEvaluator.mockImplementation(() => mockRuleEvaluator);
        decisionEngine = new DecisionEngine_1.DecisionEngine();
    });
    describe('Decision Workflow - Requirements 1.1, 1.2', () => {
        test('should process decision successfully with single matching rule', async () => {
            const singleRule = [sampleRules[0]];
            const evaluationResult = {
                eligibleRules: singleRule,
                eliminatedRules: [],
                selectedRule: singleRule[0],
                distributionSegment: 'vip-segment',
                eliminationTrace: []
            };
            mockRuleRepository.loadAllRules.mockResolvedValue(singleRule);
            mockRuleEvaluator.evaluateRules.mockReturnValue(evaluationResult);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result.success).toBe(true);
            expect(result.distributionSegment).toBe('vip-segment');
            expect(result.selectedRuleId).toBe('rule-1');
            expect(result.requestId).toBe('test-interaction-123');
            expect(result.timestamp).toBeDefined();
            expect(mockRuleRepository.loadAllRules).toHaveBeenCalledTimes(1);
            expect(mockRuleEvaluator.evaluateRules).toHaveBeenCalledWith(sampleRequest.contactAttributes, singleRule);
        });
        test('should process decision with weight-based selection - Requirement 2.2', async () => {
            const evaluationResult = {
                eligibleRules: sampleRules,
                eliminatedRules: [],
                selectedRule: sampleRules[0], // Higher weight rule selected
                distributionSegment: 'vip-segment',
                eliminationTrace: []
            };
            mockRuleRepository.loadAllRules.mockResolvedValue(sampleRules);
            mockRuleEvaluator.evaluateRules.mockReturnValue(evaluationResult);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result.success).toBe(true);
            expect(result.distributionSegment).toBe('vip-segment');
            expect(result.selectedRuleId).toBe('rule-1');
        });
    });
    describe('Error Scenarios', () => {
        test('should return error when no rules match criteria - Requirement 2.4', async () => {
            const evaluationResult = {
                eligibleRules: [],
                eliminatedRules: [],
                error: "Aucune règle ne correspond, vérifier le paramétrage"
            };
            mockRuleRepository.loadAllRules.mockResolvedValue(sampleRules);
            mockRuleEvaluator.evaluateRules.mockReturnValue(evaluationResult);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result.success).toBe(false);
            expect(result.error).toBe("Aucune règle ne correspond, vérifier le paramétrage");
            expect(result.errorCode).toBe('NO_MATCHING_RULES');
            expect(result.distributionSegment).toBeUndefined();
            expect(result.selectedRuleId).toBeUndefined();
            expect(result.requestId).toBe('test-interaction-123');
            expect(result.timestamp).toBeDefined();
        });
        test('should return error when multiple rules have equal weights - Requirement 2.3', async () => {
            const equalWeightError = "Les règles rule-1 et rule-2 ont des poids identiques, vérifier le paramétrage";
            const evaluationResult = {
                eligibleRules: sampleRules,
                eliminatedRules: [],
                error: equalWeightError
            };
            mockRuleRepository.loadAllRules.mockResolvedValue(sampleRules);
            mockRuleEvaluator.evaluateRules.mockReturnValue(evaluationResult);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result.success).toBe(false);
            expect(result.error).toBe(equalWeightError);
            expect(result.errorCode).toBe('EQUAL_WEIGHTS');
            expect(result.distributionSegment).toBeUndefined();
            expect(result.selectedRuleId).toBeUndefined();
        });
        test('should handle database connection failure gracefully - Requirement 1.1', async () => {
            const dbError = new Error('DynamoDB connection timeout');
            mockRuleRepository.loadAllRules.mockRejectedValue(dbError);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result.success).toBe(false);
            expect(result.error).toBe('Erreur de base de données, veuillez réessayer');
            expect(result.errorCode).toBe('DATABASE_ERROR');
            expect(result.requestId).toBe('test-interaction-123');
            expect(result.timestamp).toBeDefined();
            expect(mockRuleEvaluator.evaluateRules).not.toHaveBeenCalled();
        });
        test('should handle rule evaluation failure gracefully', async () => {
            const evaluationError = new Error('Rule parsing failed');
            mockRuleRepository.loadAllRules.mockResolvedValue(sampleRules);
            mockRuleEvaluator.evaluateRules.mockImplementation(() => {
                throw evaluationError;
            });
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result.success).toBe(false);
            expect(result.error).toBe('Erreur lors de l\'évaluation des règles');
            expect(result.errorCode).toBe('EVALUATION_ERROR');
            expect(result.requestId).toBe('test-interaction-123');
        });
    });
    describe('Input Validation', () => {
        test('should reject request with missing interactionId', async () => {
            const invalidRequest = {
                interactionId: '',
                contactAttributes: { NouveauSinistre: true }
            };
            const result = await decisionEngine.processDecision(invalidRequest);
            expect(result.success).toBe(false);
            expect(result.error).toContain('validation');
            expect(result.errorCode).toBeDefined();
            expect(mockRuleRepository.loadAllRules).not.toHaveBeenCalled();
        });
        test('should reject request with invalid contact attributes', async () => {
            const invalidRequest = {
                interactionId: 'test-123',
                contactAttributes: null
            };
            const result = await decisionEngine.processDecision(invalidRequest);
            expect(result.success).toBe(false);
            expect(result.error).toContain('validation');
            expect(result.errorCode).toBeDefined();
            expect(mockRuleRepository.loadAllRules).not.toHaveBeenCalled();
        });
    });
    describe('Response Format Validation', () => {
        test('should return properly formatted success response', async () => {
            const evaluationResult = {
                eligibleRules: [sampleRules[0]],
                eliminatedRules: [],
                selectedRule: sampleRules[0],
                distributionSegment: 'vip-segment',
                eliminationTrace: []
            };
            mockRuleRepository.loadAllRules.mockResolvedValue(sampleRules);
            mockRuleEvaluator.evaluateRules.mockReturnValue(evaluationResult);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result).toMatchObject({
                success: true,
                distributionSegment: 'vip-segment',
                selectedRuleId: 'rule-1',
                timestamp: expect.any(String),
                requestId: 'test-interaction-123',
                eliminationTrace: expect.any(Array)
            });
            expect(result.error).toBeUndefined();
            expect(result.errorCode).toBeUndefined();
        });
        test('should return properly formatted error response', async () => {
            const evaluationResult = {
                eligibleRules: [],
                eliminatedRules: [],
                error: "Aucune règle ne correspond, vérifier le paramétrage"
            };
            mockRuleRepository.loadAllRules.mockResolvedValue(sampleRules);
            mockRuleEvaluator.evaluateRules.mockReturnValue(evaluationResult);
            const result = await decisionEngine.processDecision(sampleRequest);
            expect(result).toMatchObject({
                success: false,
                error: "Aucune règle ne correspond, vérifier le paramétrage",
                errorCode: 'NO_MATCHING_RULES',
                timestamp: expect.any(String),
                requestId: 'test-interaction-123'
            });
            expect(result.distributionSegment).toBeUndefined();
            expect(result.selectedRuleId).toBeUndefined();
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGVjaXNpb25FbmdpbmUudW5pdC50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3Rlc3RzL2RlY2lzaW9uLWVuZ2luZS9EZWNpc2lvbkVuZ2luZS51bml0LnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxrRkFBK0U7QUFDL0Usa0ZBQStFO0FBQy9FLGdGQUE2RTtBQUc3RSxvQkFBb0I7QUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO0FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsOENBQThDLENBQUMsQ0FBQztBQUUxRCxRQUFRLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxFQUFFO0lBQ3pDLElBQUksY0FBOEIsQ0FBQztJQUNuQyxJQUFJLGtCQUErQyxDQUFDO0lBQ3BELElBQUksaUJBQTZDLENBQUM7SUFFbEQsTUFBTSxhQUFhLEdBQXlCO1FBQzFDLGFBQWEsRUFBRSxzQkFBc0I7UUFDckMsaUJBQWlCLEVBQUU7WUFDakIsZUFBZSxFQUFFLElBQUk7WUFDckIsTUFBTSxFQUFFLEtBQUs7U0FDZDtLQUNGLENBQUM7SUFFRixNQUFNLFdBQVcsR0FBd0I7UUFDdkM7WUFDRSxFQUFFLEVBQUUsUUFBUTtZQUNaLElBQUksRUFBRSxxQkFBcUI7WUFDM0IsVUFBVSxFQUFFLDRDQUE0QztZQUN4RCxNQUFNLEVBQUUsRUFBRTtZQUNWLG1CQUFtQixFQUFFLGFBQWE7WUFDbEMsU0FBUyxFQUFFLHNCQUFzQjtZQUNqQyxTQUFTLEVBQUUsc0JBQXNCO1NBQ2xDO1FBQ0Q7WUFDRSxFQUFFLEVBQUUsUUFBUTtZQUNaLElBQUksRUFBRSx5QkFBeUI7WUFDL0IsVUFBVSxFQUFFLHlCQUF5QjtZQUNyQyxNQUFNLEVBQUUsRUFBRTtZQUNWLG1CQUFtQixFQUFFLGlCQUFpQjtZQUN0QyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLFNBQVMsRUFBRSxzQkFBc0I7U0FDbEM7S0FDRixDQUFDO0lBRUYsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQixrQkFBa0IsR0FBRyxJQUFJLCtCQUFjLEVBQWlDLENBQUM7UUFDekUsaUJBQWlCLEdBQUcsSUFBSSw2QkFBYSxFQUFnQyxDQUFDO1FBRXJFLCtCQUEwRCxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDeEcsNkJBQXdELENBQUMsa0JBQWtCLENBQUMsR0FBRyxFQUFFLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUV0RyxjQUFjLEdBQUcsSUFBSSwrQkFBYyxFQUFFLENBQUM7SUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsMkNBQTJDLEVBQUUsR0FBRyxFQUFFO1FBQ3pELElBQUksQ0FBQyxnRUFBZ0UsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNoRixNQUFNLFVBQVUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sZ0JBQWdCLEdBQXFCO2dCQUN6QyxhQUFhLEVBQUUsVUFBVTtnQkFDekIsZUFBZSxFQUFFLEVBQUU7Z0JBQ25CLFlBQVksRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixtQkFBbUIsRUFBRSxhQUFhO2dCQUNsQyxnQkFBZ0IsRUFBRSxFQUFFO2FBQ3JCLENBQUM7WUFFRixrQkFBa0IsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDOUQsaUJBQWlCLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBRWxFLE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUVuRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsQyxNQUFNLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFDdEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN2QyxNQUFNLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakUsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDLG9CQUFvQixDQUMxRCxhQUFhLENBQUMsaUJBQWlCLEVBQy9CLFVBQVUsQ0FDWCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsdUVBQXVFLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDdkYsTUFBTSxnQkFBZ0IsR0FBcUI7Z0JBQ3pDLGFBQWEsRUFBRSxXQUFXO2dCQUMxQixlQUFlLEVBQUUsRUFBRTtnQkFDbkIsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSw4QkFBOEI7Z0JBQzVELG1CQUFtQixFQUFFLGFBQWE7Z0JBQ2xDLGdCQUFnQixFQUFFLEVBQUU7YUFDckIsQ0FBQztZQUVGLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMvRCxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFbEUsTUFBTSxNQUFNLEdBQUcsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRW5FLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2xDLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDdkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0MsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUU7UUFDL0IsSUFBSSxDQUFDLG9FQUFvRSxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3BGLE1BQU0sZ0JBQWdCLEdBQXFCO2dCQUN6QyxhQUFhLEVBQUUsRUFBRTtnQkFDakIsZUFBZSxFQUFFLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxxREFBcUQ7YUFDN0QsQ0FBQztZQUVGLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMvRCxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFbEUsTUFBTSxNQUFNLEdBQUcsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRW5FLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25DLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLHFEQUFxRCxDQUFDLENBQUM7WUFDakYsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5QyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3RELE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsOEVBQThFLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDOUYsTUFBTSxnQkFBZ0IsR0FBRywrRUFBK0UsQ0FBQztZQUN6RyxNQUFNLGdCQUFnQixHQUFxQjtnQkFDekMsYUFBYSxFQUFFLFdBQVc7Z0JBQzFCLGVBQWUsRUFBRSxFQUFFO2dCQUNuQixLQUFLLEVBQUUsZ0JBQWdCO2FBQ3hCLENBQUM7WUFFRixrQkFBa0IsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDL0QsaUJBQWlCLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBRWxFLE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUVuRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQy9DLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLHdFQUF3RSxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3hGLE1BQU0sT0FBTyxHQUFHLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUM7WUFDekQsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRTNELE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUVuRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1lBQzNFLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDaEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUN0RCxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNqRSxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxrREFBa0QsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNsRSxNQUFNLGVBQWUsR0FBRyxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1lBQ3pELGtCQUFrQixDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMvRCxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsR0FBRyxFQUFFO2dCQUN0RCxNQUFNLGVBQWUsQ0FBQztZQUN4QixDQUFDLENBQUMsQ0FBQztZQUVILE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUVuRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1lBQ3JFLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDbEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUSxDQUFDLGtCQUFrQixFQUFFLEdBQUcsRUFBRTtRQUNoQyxJQUFJLENBQUMsa0RBQWtELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDbEUsTUFBTSxjQUFjLEdBQUc7Z0JBQ3JCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixpQkFBaUIsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUU7YUFDN0MsQ0FBQztZQUVGLE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUVwRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM3QyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNqRSxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyx1REFBdUQsRUFBRSxLQUFLLElBQUksRUFBRTtZQUN2RSxNQUFNLGNBQWMsR0FBRztnQkFDckIsYUFBYSxFQUFFLFVBQVU7Z0JBQ3pCLGlCQUFpQixFQUFFLElBQVc7YUFDL0IsQ0FBQztZQUVGLE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUVwRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM3QyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNqRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUSxDQUFDLDRCQUE0QixFQUFFLEdBQUcsRUFBRTtRQUMxQyxJQUFJLENBQUMsbURBQW1ELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDbkUsTUFBTSxnQkFBZ0IsR0FBcUI7Z0JBQ3pDLGFBQWEsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0IsZUFBZSxFQUFFLEVBQUU7Z0JBQ25CLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUM1QixtQkFBbUIsRUFBRSxhQUFhO2dCQUNsQyxnQkFBZ0IsRUFBRSxFQUFFO2FBQ3JCLENBQUM7WUFFRixrQkFBa0IsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDL0QsaUJBQWlCLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBRWxFLE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUVuRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUMzQixPQUFPLEVBQUUsSUFBSTtnQkFDYixtQkFBbUIsRUFBRSxhQUFhO2dCQUNsQyxjQUFjLEVBQUUsUUFBUTtnQkFDeEIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO2dCQUM3QixTQUFTLEVBQUUsc0JBQXNCO2dCQUNqQyxnQkFBZ0IsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQzthQUNwQyxDQUFDLENBQUM7WUFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsaURBQWlELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDakUsTUFBTSxnQkFBZ0IsR0FBcUI7Z0JBQ3pDLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixlQUFlLEVBQUUsRUFBRTtnQkFDbkIsS0FBSyxFQUFFLHFEQUFxRDthQUM3RCxDQUFDO1lBRUYsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQy9ELGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUVsRSxNQUFNLE1BQU0sR0FBRyxNQUFNLGNBQWMsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFbkUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQkFDM0IsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsS0FBSyxFQUFFLHFEQUFxRDtnQkFDNUQsU0FBUyxFQUFFLG1CQUFtQjtnQkFDOUIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO2dCQUM3QixTQUFTLEVBQUUsc0JBQXNCO2FBQ2xDLENBQUMsQ0FBQztZQUNILE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERlY2lzaW9uRW5naW5lIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL0RlY2lzaW9uRW5naW5lJztcclxuaW1wb3J0IHsgUnVsZVJlcG9zaXRvcnkgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZVJlcG9zaXRvcnknO1xyXG5pbXBvcnQgeyBSdWxlRXZhbHVhdG9yIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL1J1bGVFdmFsdWF0b3InO1xyXG5pbXBvcnQgeyBRdWFsaWZpY2F0aW9uUmVxdWVzdCwgUXVhbGlmaWNhdGlvblJ1bGUsIEV2YWx1YXRpb25SZXN1bHQgfSBmcm9tICcuLi8uLi90eXBlcy9kZWNpc2lvbi1lbmdpbmUnO1xyXG5cclxuLy8gTW9jayBkZXBlbmRlbmNpZXNcclxuamVzdC5tb2NrKCcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZVJlcG9zaXRvcnknKTtcclxuamVzdC5tb2NrKCcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZUV2YWx1YXRvcicpO1xyXG5cclxuZGVzY3JpYmUoJ0RlY2lzaW9uRW5naW5lIFVuaXQgVGVzdHMnLCAoKSA9PiB7XHJcbiAgbGV0IGRlY2lzaW9uRW5naW5lOiBEZWNpc2lvbkVuZ2luZTtcclxuICBsZXQgbW9ja1J1bGVSZXBvc2l0b3J5OiBqZXN0Lk1vY2tlZDxSdWxlUmVwb3NpdG9yeT47XHJcbiAgbGV0IG1vY2tSdWxlRXZhbHVhdG9yOiBqZXN0Lk1vY2tlZDxSdWxlRXZhbHVhdG9yPjtcclxuXHJcbiAgY29uc3Qgc2FtcGxlUmVxdWVzdDogUXVhbGlmaWNhdGlvblJlcXVlc3QgPSB7XHJcbiAgICBpbnRlcmFjdGlvbklkOiAndGVzdC1pbnRlcmFjdGlvbi0xMjMnLFxyXG4gICAgY29udGFjdEF0dHJpYnV0ZXM6IHtcclxuICAgICAgTm91dmVhdVNpbmlzdHJlOiB0cnVlLFxyXG4gICAgICBDbGllbnQ6ICdWSVAnXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2FtcGxlUnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiAncnVsZS0xJyxcclxuICAgICAgbmFtZTogJ1ZJUCBOZXcgQ2xhaW1zIFJ1bGUnLFxyXG4gICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUgJiYgQ2xpZW50ID09IFwiVklQXCInLFxyXG4gICAgICB3ZWlnaHQ6IDIwLFxyXG4gICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAndmlwLXNlZ21lbnQnLFxyXG4gICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwWicsXHJcbiAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDBaJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICdydWxlLTInLFxyXG4gICAgICBuYW1lOiAnR2VuZXJhbCBOZXcgQ2xhaW1zIFJ1bGUnLFxyXG4gICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgICB3ZWlnaHQ6IDEwLFxyXG4gICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnZ2VuZXJhbC1zZWdtZW50JyxcclxuICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMFonLFxyXG4gICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwWidcclxuICAgIH1cclxuICBdO1xyXG5cclxuICBiZWZvcmVFYWNoKCgpID0+IHtcclxuICAgIGplc3QuY2xlYXJBbGxNb2NrcygpO1xyXG4gICAgXHJcbiAgICBtb2NrUnVsZVJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoKSBhcyBqZXN0Lk1vY2tlZDxSdWxlUmVwb3NpdG9yeT47XHJcbiAgICBtb2NrUnVsZUV2YWx1YXRvciA9IG5ldyBSdWxlRXZhbHVhdG9yKCkgYXMgamVzdC5Nb2NrZWQ8UnVsZUV2YWx1YXRvcj47XHJcblxyXG4gICAgKFJ1bGVSZXBvc2l0b3J5IGFzIGplc3QuTW9ja2VkQ2xhc3M8dHlwZW9mIFJ1bGVSZXBvc2l0b3J5PikubW9ja0ltcGxlbWVudGF0aW9uKCgpID0+IG1vY2tSdWxlUmVwb3NpdG9yeSk7XHJcbiAgICAoUnVsZUV2YWx1YXRvciBhcyBqZXN0Lk1vY2tlZENsYXNzPHR5cGVvZiBSdWxlRXZhbHVhdG9yPikubW9ja0ltcGxlbWVudGF0aW9uKCgpID0+IG1vY2tSdWxlRXZhbHVhdG9yKTtcclxuXHJcbiAgICBkZWNpc2lvbkVuZ2luZSA9IG5ldyBEZWNpc2lvbkVuZ2luZSgpO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnRGVjaXNpb24gV29ya2Zsb3cgLSBSZXF1aXJlbWVudHMgMS4xLCAxLjInLCAoKSA9PiB7XHJcbiAgICB0ZXN0KCdzaG91bGQgcHJvY2VzcyBkZWNpc2lvbiBzdWNjZXNzZnVsbHkgd2l0aCBzaW5nbGUgbWF0Y2hpbmcgcnVsZScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3Qgc2luZ2xlUnVsZSA9IFtzYW1wbGVSdWxlc1swXV07XHJcbiAgICAgIGNvbnN0IGV2YWx1YXRpb25SZXN1bHQ6IEV2YWx1YXRpb25SZXN1bHQgPSB7XHJcbiAgICAgICAgZWxpZ2libGVSdWxlczogc2luZ2xlUnVsZSxcclxuICAgICAgICBlbGltaW5hdGVkUnVsZXM6IFtdLFxyXG4gICAgICAgIHNlbGVjdGVkUnVsZTogc2luZ2xlUnVsZVswXSxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAndmlwLXNlZ21lbnQnLFxyXG4gICAgICAgIGVsaW1pbmF0aW9uVHJhY2U6IFtdXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHNpbmdsZVJ1bGUpO1xyXG4gICAgICBtb2NrUnVsZUV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzLm1vY2tSZXR1cm5WYWx1ZShldmFsdWF0aW9uUmVzdWx0KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihzYW1wbGVSZXF1ZXN0KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3VjY2VzcykudG9CZSh0cnVlKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlKCd2aXAtc2VnbWVudCcpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LnNlbGVjdGVkUnVsZUlkKS50b0JlKCdydWxlLTEnKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5yZXF1ZXN0SWQpLnRvQmUoJ3Rlc3QtaW50ZXJhY3Rpb24tMTIzJyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QobW9ja1J1bGVSZXBvc2l0b3J5LmxvYWRBbGxSdWxlcykudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xyXG4gICAgICBleHBlY3QobW9ja1J1bGVFdmFsdWF0b3IuZXZhbHVhdGVSdWxlcykudG9IYXZlQmVlbkNhbGxlZFdpdGgoXHJcbiAgICAgICAgc2FtcGxlUmVxdWVzdC5jb250YWN0QXR0cmlidXRlcyxcclxuICAgICAgICBzaW5nbGVSdWxlXHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgcHJvY2VzcyBkZWNpc2lvbiB3aXRoIHdlaWdodC1iYXNlZCBzZWxlY3Rpb24gLSBSZXF1aXJlbWVudCAyLjInLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGV2YWx1YXRpb25SZXN1bHQ6IEV2YWx1YXRpb25SZXN1bHQgPSB7XHJcbiAgICAgICAgZWxpZ2libGVSdWxlczogc2FtcGxlUnVsZXMsXHJcbiAgICAgICAgZWxpbWluYXRlZFJ1bGVzOiBbXSxcclxuICAgICAgICBzZWxlY3RlZFJ1bGU6IHNhbXBsZVJ1bGVzWzBdLCAvLyBIaWdoZXIgd2VpZ2h0IHJ1bGUgc2VsZWN0ZWRcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAndmlwLXNlZ21lbnQnLFxyXG4gICAgICAgIGVsaW1pbmF0aW9uVHJhY2U6IFtdXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHNhbXBsZVJ1bGVzKTtcclxuICAgICAgbW9ja1J1bGVFdmFsdWF0b3IuZXZhbHVhdGVSdWxlcy5tb2NrUmV0dXJuVmFsdWUoZXZhbHVhdGlvblJlc3VsdCk7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24oc2FtcGxlUmVxdWVzdCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN1Y2Nlc3MpLnRvQmUodHJ1ZSk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZGlzdHJpYnV0aW9uU2VnbWVudCkudG9CZSgndmlwLXNlZ21lbnQnKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGVJZCkudG9CZSgncnVsZS0xJyk7XHJcbiAgICB9KTtcclxuICB9KTtcclxuXHJcbiAgZGVzY3JpYmUoJ0Vycm9yIFNjZW5hcmlvcycsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCByZXR1cm4gZXJyb3Igd2hlbiBubyBydWxlcyBtYXRjaCBjcml0ZXJpYSAtIFJlcXVpcmVtZW50IDIuNCcsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZXZhbHVhdGlvblJlc3VsdDogRXZhbHVhdGlvblJlc3VsdCA9IHtcclxuICAgICAgICBlbGlnaWJsZVJ1bGVzOiBbXSxcclxuICAgICAgICBlbGltaW5hdGVkUnVsZXM6IFtdLFxyXG4gICAgICAgIGVycm9yOiBcIkF1Y3VuZSByw6hnbGUgbmUgY29ycmVzcG9uZCwgdsOpcmlmaWVyIGxlIHBhcmFtw6l0cmFnZVwiXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHNhbXBsZVJ1bGVzKTtcclxuICAgICAgbW9ja1J1bGVFdmFsdWF0b3IuZXZhbHVhdGVSdWxlcy5tb2NrUmV0dXJuVmFsdWUoZXZhbHVhdGlvblJlc3VsdCk7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24oc2FtcGxlUmVxdWVzdCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlKFwiQXVjdW5lIHLDqGdsZSBuZSBjb3JyZXNwb25kLCB2w6lyaWZpZXIgbGUgcGFyYW3DqXRyYWdlXCIpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yQ29kZSkudG9CZSgnTk9fTUFUQ0hJTkdfUlVMRVMnKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc2VsZWN0ZWRSdWxlSWQpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5yZXF1ZXN0SWQpLnRvQmUoJ3Rlc3QtaW50ZXJhY3Rpb24tMTIzJyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIHJldHVybiBlcnJvciB3aGVuIG11bHRpcGxlIHJ1bGVzIGhhdmUgZXF1YWwgd2VpZ2h0cyAtIFJlcXVpcmVtZW50IDIuMycsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZXF1YWxXZWlnaHRFcnJvciA9IFwiTGVzIHLDqGdsZXMgcnVsZS0xIGV0IHJ1bGUtMiBvbnQgZGVzIHBvaWRzIGlkZW50aXF1ZXMsIHbDqXJpZmllciBsZSBwYXJhbcOpdHJhZ2VcIjtcclxuICAgICAgY29uc3QgZXZhbHVhdGlvblJlc3VsdDogRXZhbHVhdGlvblJlc3VsdCA9IHtcclxuICAgICAgICBlbGlnaWJsZVJ1bGVzOiBzYW1wbGVSdWxlcyxcclxuICAgICAgICBlbGltaW5hdGVkUnVsZXM6IFtdLFxyXG4gICAgICAgIGVycm9yOiBlcXVhbFdlaWdodEVycm9yXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHNhbXBsZVJ1bGVzKTtcclxuICAgICAgbW9ja1J1bGVFdmFsdWF0b3IuZXZhbHVhdGVSdWxlcy5tb2NrUmV0dXJuVmFsdWUoZXZhbHVhdGlvblJlc3VsdCk7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24oc2FtcGxlUmVxdWVzdCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlKGVxdWFsV2VpZ2h0RXJyb3IpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yQ29kZSkudG9CZSgnRVFVQUxfV0VJR0hUUycpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGVJZCkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIGhhbmRsZSBkYXRhYmFzZSBjb25uZWN0aW9uIGZhaWx1cmUgZ3JhY2VmdWxseSAtIFJlcXVpcmVtZW50IDEuMScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZGJFcnJvciA9IG5ldyBFcnJvcignRHluYW1vREIgY29ubmVjdGlvbiB0aW1lb3V0Jyk7XHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1JlamVjdGVkVmFsdWUoZGJFcnJvcik7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24oc2FtcGxlUmVxdWVzdCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlKCdFcnJldXIgZGUgYmFzZSBkZSBkb25uw6llcywgdmV1aWxsZXogcsOpZXNzYXllcicpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yQ29kZSkudG9CZSgnREFUQUJBU0VfRVJST1InKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5yZXF1ZXN0SWQpLnRvQmUoJ3Rlc3QtaW50ZXJhY3Rpb24tMTIzJyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QobW9ja1J1bGVFdmFsdWF0b3IuZXZhbHVhdGVSdWxlcykubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRlc3QoJ3Nob3VsZCBoYW5kbGUgcnVsZSBldmFsdWF0aW9uIGZhaWx1cmUgZ3JhY2VmdWxseScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZXZhbHVhdGlvbkVycm9yID0gbmV3IEVycm9yKCdSdWxlIHBhcnNpbmcgZmFpbGVkJyk7XHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1Jlc29sdmVkVmFsdWUoc2FtcGxlUnVsZXMpO1xyXG4gICAgICBtb2NrUnVsZUV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzLm1vY2tJbXBsZW1lbnRhdGlvbigoKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZXZhbHVhdGlvbkVycm9yO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihzYW1wbGVSZXF1ZXN0KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3IpLnRvQmUoJ0VycmV1ciBsb3JzIGRlIGxcXCfDqXZhbHVhdGlvbiBkZXMgcsOoZ2xlcycpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yQ29kZSkudG9CZSgnRVZBTFVBVElPTl9FUlJPUicpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LnJlcXVlc3RJZCkudG9CZSgndGVzdC1pbnRlcmFjdGlvbi0xMjMnKTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnSW5wdXQgVmFsaWRhdGlvbicsICgpID0+IHtcclxuICAgIHRlc3QoJ3Nob3VsZCByZWplY3QgcmVxdWVzdCB3aXRoIG1pc3NpbmcgaW50ZXJhY3Rpb25JZCcsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgaW52YWxpZFJlcXVlc3QgPSB7XHJcbiAgICAgICAgaW50ZXJhY3Rpb25JZDogJycsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IHsgTm91dmVhdVNpbmlzdHJlOiB0cnVlIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihpbnZhbGlkUmVxdWVzdCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0NvbnRhaW4oJ3ZhbGlkYXRpb24nKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvckNvZGUpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGVzdCgnc2hvdWxkIHJlamVjdCByZXF1ZXN0IHdpdGggaW52YWxpZCBjb250YWN0IGF0dHJpYnV0ZXMnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGludmFsaWRSZXF1ZXN0ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LTEyMycsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IG51bGwgYXMgYW55XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24oaW52YWxpZFJlcXVlc3QpO1xyXG5cclxuICAgICAgZXhwZWN0KHJlc3VsdC5zdWNjZXNzKS50b0JlKGZhbHNlKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5lcnJvcikudG9Db250YWluKCd2YWxpZGF0aW9uJyk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3JDb2RlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QobW9ja1J1bGVSZXBvc2l0b3J5LmxvYWRBbGxSdWxlcykubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnUmVzcG9uc2UgRm9ybWF0IFZhbGlkYXRpb24nLCAoKSA9PiB7XHJcbiAgICB0ZXN0KCdzaG91bGQgcmV0dXJuIHByb3Blcmx5IGZvcm1hdHRlZCBzdWNjZXNzIHJlc3BvbnNlJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICBjb25zdCBldmFsdWF0aW9uUmVzdWx0OiBFdmFsdWF0aW9uUmVzdWx0ID0ge1xyXG4gICAgICAgIGVsaWdpYmxlUnVsZXM6IFtzYW1wbGVSdWxlc1swXV0sXHJcbiAgICAgICAgZWxpbWluYXRlZFJ1bGVzOiBbXSxcclxuICAgICAgICBzZWxlY3RlZFJ1bGU6IHNhbXBsZVJ1bGVzWzBdLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICd2aXAtc2VnbWVudCcsXHJcbiAgICAgICAgZWxpbWluYXRpb25UcmFjZTogW11cclxuICAgICAgfTtcclxuXHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1Jlc29sdmVkVmFsdWUoc2FtcGxlUnVsZXMpO1xyXG4gICAgICBtb2NrUnVsZUV2YWx1YXRvci5ldmFsdWF0ZVJ1bGVzLm1vY2tSZXR1cm5WYWx1ZShldmFsdWF0aW9uUmVzdWx0KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihzYW1wbGVSZXF1ZXN0KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQpLnRvTWF0Y2hPYmplY3Qoe1xyXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ3ZpcC1zZWdtZW50JyxcclxuICAgICAgICBzZWxlY3RlZFJ1bGVJZDogJ3J1bGUtMScsXHJcbiAgICAgICAgdGltZXN0YW1wOiBleHBlY3QuYW55KFN0cmluZyksXHJcbiAgICAgICAgcmVxdWVzdElkOiAndGVzdC1pbnRlcmFjdGlvbi0xMjMnLFxyXG4gICAgICAgIGVsaW1pbmF0aW9uVHJhY2U6IGV4cGVjdC5hbnkoQXJyYXkpXHJcbiAgICAgIH0pO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmVycm9yKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuZXJyb3JDb2RlKS50b0JlVW5kZWZpbmVkKCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0ZXN0KCdzaG91bGQgcmV0dXJuIHByb3Blcmx5IGZvcm1hdHRlZCBlcnJvciByZXNwb25zZScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZXZhbHVhdGlvblJlc3VsdDogRXZhbHVhdGlvblJlc3VsdCA9IHtcclxuICAgICAgICBlbGlnaWJsZVJ1bGVzOiBbXSxcclxuICAgICAgICBlbGltaW5hdGVkUnVsZXM6IFtdLFxyXG4gICAgICAgIGVycm9yOiBcIkF1Y3VuZSByw6hnbGUgbmUgY29ycmVzcG9uZCwgdsOpcmlmaWVyIGxlIHBhcmFtw6l0cmFnZVwiXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHNhbXBsZVJ1bGVzKTtcclxuICAgICAgbW9ja1J1bGVFdmFsdWF0b3IuZXZhbHVhdGVSdWxlcy5tb2NrUmV0dXJuVmFsdWUoZXZhbHVhdGlvblJlc3VsdCk7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZWNpc2lvbkVuZ2luZS5wcm9jZXNzRGVjaXNpb24oc2FtcGxlUmVxdWVzdCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0KS50b01hdGNoT2JqZWN0KHtcclxuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogXCJBdWN1bmUgcsOoZ2xlIG5lIGNvcnJlc3BvbmQsIHbDqXJpZmllciBsZSBwYXJhbcOpdHJhZ2VcIixcclxuICAgICAgICBlcnJvckNvZGU6ICdOT19NQVRDSElOR19SVUxFUycsXHJcbiAgICAgICAgdGltZXN0YW1wOiBleHBlY3QuYW55KFN0cmluZyksXHJcbiAgICAgICAgcmVxdWVzdElkOiAndGVzdC1pbnRlcmFjdGlvbi0xMjMnXHJcbiAgICAgIH0pO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmVVbmRlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zZWxlY3RlZFJ1bGVJZCkudG9CZVVuZGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcbn0pOyJdfQ==
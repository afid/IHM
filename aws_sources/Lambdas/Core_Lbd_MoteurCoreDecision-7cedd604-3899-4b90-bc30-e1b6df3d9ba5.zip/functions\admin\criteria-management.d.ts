/**
 * Lambda Function pour gérer les critères secondaires via API
 * Endpoint: POST /admin/criteria
 *
 * Actions supportées :
 * - list: Liste tous les critères (primaires + secondaires)
 * - get: Récupère un critère spécifique
 * - add: Ajoute un nouveau critère secondaire
 * - update: Met à jour un critère secondaire existant
 * - delete: Supprime un critère secondaire
 * - toggle: Active/désactive un critère secondaire
 * - stats: Retourne les statistiques des critères
 * - invalidate-cache: Force le refresh du cache
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const handler_1 = require("../../functions/decision-engine/handler");
// Mock AWS SDK to avoid actual DynamoDB calls during integration tests
jest.mock('@aws-sdk/lib-dynamodb', () => ({
    DynamoDBDocumentClient: {
        from: jest.fn(() => ({
            send: jest.fn()
        }))
    },
    ScanCommand: jest.fn()
}));
// Mock the RuleRepository to provide controlled test data
jest.mock('../../services/decision-engine/RuleRepository', () => {
    return {
        RuleRepository: jest.fn().mockImplementation(() => ({
            loadAllRules: jest.fn()
        }))
    };
});
describe('Decision Engine Lambda Handler - Integration Tests', () => {
    let mockRuleRepository;
    beforeEach(() => {
        jest.clearAllMocks();
        // Get the mocked RuleRepository
        const { RuleRepository } = require('../../services/decision-engine/RuleRepository');
        mockRuleRepository = new RuleRepository();
    });
    const createAPIGatewayEvent = (httpMethod = 'POST', body = null, requestId = 'test-request-123') => ({
        httpMethod,
        body,
        headers: {},
        multiValueHeaders: {},
        isBase64Encoded: false,
        path: '/decision',
        pathParameters: null,
        queryStringParameters: null,
        multiValueQueryStringParameters: null,
        stageVariables: null,
        requestContext: {
            requestId,
            stage: 'test',
            resourceId: 'resource-id',
            resourcePath: '/decision',
            httpMethod,
            requestTime: '01/Jan/2023:00:00:00 +0000',
            requestTimeEpoch: 1672531200000,
            path: '/test/decision',
            accountId: '123456789012',
            protocol: 'HTTP/1.1',
            identity: {
                accessKey: null,
                accountId: null,
                apiKey: null,
                apiKeyId: null,
                caller: null,
                cognitoAuthenticationProvider: null,
                cognitoAuthenticationType: null,
                cognitoIdentityId: null,
                cognitoIdentityPoolId: null,
                principalOrgId: null,
                sourceIp: '127.0.0.1',
                user: null,
                userAgent: 'test-agent',
                userArn: null,
                clientCert: null
            },
            apiId: 'api-id',
            domainName: 'test.execute-api.region.amazonaws.com',
            domainPrefix: 'test',
            authorizer: null
        },
        resource: '/decision'
    });
    describe('End-to-End Decision Processing', () => {
        it('should process a complete decision workflow successfully', async () => {
            // Setup test rules
            const testRules = [
                {
                    id: 'rule-vip',
                    name: 'VIP Client Rule',
                    expression: 'NouveauSinistre == true && Client == "VIP"',
                    weight: 100,
                    distributionSegment: 'VIP_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                },
                {
                    id: 'rule-standard',
                    name: 'Standard Client Rule',
                    expression: 'NouveauSinistre == true',
                    weight: 50,
                    distributionSegment: 'STANDARD_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ];
            mockRuleRepository.loadAllRules.mockResolvedValue(testRules);
            const requestBody = {
                interactionId: 'test-interaction-123',
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP'
                }
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            // Verify response structure
            expect(result.statusCode).toBe(200);
            expect(result.headers).toMatchObject({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            });
            const responseBody = JSON.parse(result.body);
            expect(responseBody).toMatchObject({
                success: true,
                distributionSegment: 'VIP_SEGMENT',
                selectedRuleId: 'rule-vip',
                requestId: 'test-interaction-123'
            });
            expect(responseBody.timestamp).toBeDefined();
            expect(responseBody.eliminationTrace).toBeDefined();
        });
        it('should handle rule elimination correctly in end-to-end flow', async () => {
            // Setup test rules where only one should match
            const testRules = [
                {
                    id: 'rule-vip',
                    name: 'VIP Client Rule',
                    expression: 'NouveauSinistre == true && Client == "VIP"',
                    weight: 100,
                    distributionSegment: 'VIP_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                },
                {
                    id: 'rule-premium',
                    name: 'Premium Client Rule',
                    expression: 'NouveauSinistre == true && Client == "PREMIUM"',
                    weight: 80,
                    distributionSegment: 'PREMIUM_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ];
            mockRuleRepository.loadAllRules.mockResolvedValue(testRules);
            const requestBody = {
                interactionId: 'test-interaction-456',
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP'
                }
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(200);
            const responseBody = JSON.parse(result.body);
            // Should select VIP rule and eliminate PREMIUM rule
            expect(responseBody.success).toBe(true);
            expect(responseBody.distributionSegment).toBe('VIP_SEGMENT');
            expect(responseBody.selectedRuleId).toBe('rule-vip');
            expect(responseBody.eliminationTrace).toHaveLength(2); // Two attributes processed
        });
        it('should handle no matching rules scenario in end-to-end flow', async () => {
            // Setup test rules that won't match the criteria
            const testRules = [
                {
                    id: 'rule-vip',
                    name: 'VIP Client Rule',
                    expression: 'NouveauSinistre == true && Client == "VIP"',
                    weight: 100,
                    distributionSegment: 'VIP_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ];
            mockRuleRepository.loadAllRules.mockResolvedValue(testRules);
            const requestBody = {
                interactionId: 'test-interaction-789',
                contactAttributes: {
                    NouveauSinistre: false, // This will eliminate the rule
                    Client: 'VIP'
                }
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody.success).toBe(false);
            expect(responseBody.errorCode).toBe('NO_MATCHING_RULES');
            expect(responseBody.error).toContain('Aucune règle ne correspond');
        });
        it('should handle equal weights scenario in end-to-end flow', async () => {
            // Setup test rules with equal weights
            const testRules = [
                {
                    id: 'rule-vip-1',
                    name: 'VIP Client Rule 1',
                    expression: 'Client == "VIP"',
                    weight: 100,
                    distributionSegment: 'VIP_SEGMENT_1',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                },
                {
                    id: 'rule-vip-2',
                    name: 'VIP Client Rule 2',
                    expression: 'Client == "VIP"',
                    weight: 100, // Same weight
                    distributionSegment: 'VIP_SEGMENT_2',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ];
            mockRuleRepository.loadAllRules.mockResolvedValue(testRules);
            const requestBody = {
                interactionId: 'test-interaction-equal-weights',
                contactAttributes: {
                    Client: 'VIP'
                }
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody.success).toBe(false);
            expect(responseBody.errorCode).toBe('EQUAL_WEIGHTS');
            expect(responseBody.error).toContain('poids identiques');
        });
    });
    describe('API Gateway Integration', () => {
        it('should handle CORS preflight requests correctly', async () => {
            const event = createAPIGatewayEvent('OPTIONS');
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(200);
            expect(result.headers).toMatchObject({
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Access-Control-Max-Age': '86400'
            });
            expect(result.body).toBe('');
        });
        it('should reject non-POST methods with proper CORS headers', async () => {
            const event = createAPIGatewayEvent('GET');
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(405);
            expect(result.headers).toMatchObject({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            });
            const responseBody = JSON.parse(result.body);
            expect(responseBody).toMatchObject({
                success: false,
                error: 'Method not allowed',
                errorCode: 'METHOD_NOT_ALLOWED',
                requestId: 'test-request-123'
            });
            expect(responseBody.timestamp).toBeDefined();
        });
        it('should handle missing request body with proper error response', async () => {
            const event = createAPIGatewayEvent('POST', null);
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            expect(result.headers).toMatchObject({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            });
            const responseBody = JSON.parse(result.body);
            expect(responseBody).toMatchObject({
                success: false,
                error: 'Request body is required',
                errorCode: 'MISSING_BODY',
                requestId: 'test-request-123'
            });
        });
        it('should handle malformed JSON with proper error response', async () => {
            const event = createAPIGatewayEvent('POST', 'invalid json {');
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody).toMatchObject({
                success: false,
                error: 'Invalid JSON in request body',
                errorCode: 'INVALID_JSON',
                requestId: 'test-request-123'
            });
        });
        it('should handle database errors gracefully', async () => {
            // Mock database error
            mockRuleRepository.loadAllRules.mockRejectedValue(new Error('DynamoDB connection failed'));
            const requestBody = {
                interactionId: 'test-interaction-db-error',
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP'
                }
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody.success).toBe(false);
            expect(responseBody.errorCode).toBe('DATABASE_ERROR');
            expect(responseBody.error).toContain('Database operation failed');
        });
        it('should include request ID from API Gateway context', async () => {
            const testRules = [
                {
                    id: 'rule-test',
                    name: 'Test Rule',
                    expression: 'Client == "VIP"',
                    weight: 100,
                    distributionSegment: 'TEST_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ];
            mockRuleRepository.loadAllRules.mockResolvedValue(testRules);
            const requestBody = {
                interactionId: 'test-interaction-request-id',
                contactAttributes: {
                    Client: 'VIP'
                }
            };
            const customRequestId = 'custom-api-gateway-request-id';
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody), customRequestId);
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(200);
            const responseBody = JSON.parse(result.body);
            // The response should use the interactionId from the request body as requestId
            expect(responseBody.requestId).toBe('test-interaction-request-id');
        });
    });
    describe('Input Validation Integration', () => {
        beforeEach(() => {
            // Setup default rules for validation tests
            const testRules = [
                {
                    id: 'rule-test',
                    name: 'Test Rule',
                    expression: 'Client == "VIP"',
                    weight: 100,
                    distributionSegment: 'TEST_SEGMENT',
                    createdAt: '2023-01-01T00:00:00.000Z',
                    updatedAt: '2023-01-01T00:00:00.000Z'
                }
            ];
            mockRuleRepository.loadAllRules.mockResolvedValue(testRules);
        });
        it('should validate missing interactionId', async () => {
            const requestBody = {
                contactAttributes: {
                    Client: 'VIP'
                }
                // Missing interactionId
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody.success).toBe(false);
            expect(responseBody.errorCode).toBe('VALIDATION_ERROR');
            expect(responseBody.error).toContain('interactionId is required');
        });
        it('should validate missing contactAttributes', async () => {
            const requestBody = {
                interactionId: 'test-interaction'
                // Missing contactAttributes
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody.success).toBe(false);
            expect(responseBody.errorCode).toBe('VALIDATION_ERROR');
            expect(responseBody.error).toContain('contactAttributes is required');
        });
        it('should validate invalid contactAttributes type', async () => {
            const requestBody = {
                interactionId: 'test-interaction',
                contactAttributes: 'invalid-type' // Should be object
            };
            const event = createAPIGatewayEvent('POST', JSON.stringify(requestBody));
            const result = await (0, handler_1.handler)(event);
            expect(result.statusCode).toBe(400);
            const responseBody = JSON.parse(result.body);
            expect(responseBody.success).toBe(false);
            expect(responseBody.errorCode).toBe('VALIDATION_ERROR');
            expect(responseBody.error).toContain('contactAttributes must be an object');
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5pbnRlZ3JhdGlvbi50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3Rlc3RzL2RlY2lzaW9uLWVuZ2luZS9oYW5kbGVyLmludGVncmF0aW9uLnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSxxRUFBa0U7QUFHbEUsdUVBQXVFO0FBQ3ZFLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUN4QyxzQkFBc0IsRUFBRTtRQUN0QixJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1lBQ25CLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFO1NBQ2hCLENBQUMsQ0FBQztLQUNKO0lBQ0QsV0FBVyxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUU7Q0FDdkIsQ0FBQyxDQUFDLENBQUM7QUFFSiwwREFBMEQ7QUFDMUQsSUFBSSxDQUFDLElBQUksQ0FBQywrQ0FBK0MsRUFBRSxHQUFHLEVBQUU7SUFDOUQsT0FBTztRQUNMLGNBQWMsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsa0JBQWtCLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztZQUNsRCxZQUFZLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRTtTQUN4QixDQUFDLENBQUM7S0FDSixDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsb0RBQW9ELEVBQUUsR0FBRyxFQUFFO0lBQ2xFLElBQUksa0JBQXVCLENBQUM7SUFFNUIsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQixnQ0FBZ0M7UUFDaEMsTUFBTSxFQUFFLGNBQWMsRUFBRSxHQUFHLE9BQU8sQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1FBQ3BGLGtCQUFrQixHQUFHLElBQUksY0FBYyxFQUFFLENBQUM7SUFDNUMsQ0FBQyxDQUFDLENBQUM7SUFFSCxNQUFNLHFCQUFxQixHQUFHLENBQzVCLGFBQXFCLE1BQU0sRUFDM0IsT0FBc0IsSUFBSSxFQUMxQixZQUFvQixrQkFBa0IsRUFDaEIsRUFBRSxDQUFDLENBQUM7UUFDMUIsVUFBVTtRQUNWLElBQUk7UUFDSixPQUFPLEVBQUUsRUFBRTtRQUNYLGlCQUFpQixFQUFFLEVBQUU7UUFDckIsZUFBZSxFQUFFLEtBQUs7UUFDdEIsSUFBSSxFQUFFLFdBQVc7UUFDakIsY0FBYyxFQUFFLElBQUk7UUFDcEIscUJBQXFCLEVBQUUsSUFBSTtRQUMzQiwrQkFBK0IsRUFBRSxJQUFJO1FBQ3JDLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGNBQWMsRUFBRTtZQUNkLFNBQVM7WUFDVCxLQUFLLEVBQUUsTUFBTTtZQUNiLFVBQVUsRUFBRSxhQUFhO1lBQ3pCLFlBQVksRUFBRSxXQUFXO1lBQ3pCLFVBQVU7WUFDVixXQUFXLEVBQUUsNEJBQTRCO1lBQ3pDLGdCQUFnQixFQUFFLGFBQWE7WUFDL0IsSUFBSSxFQUFFLGdCQUFnQjtZQUN0QixTQUFTLEVBQUUsY0FBYztZQUN6QixRQUFRLEVBQUUsVUFBVTtZQUNwQixRQUFRLEVBQUU7Z0JBQ1IsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsTUFBTSxFQUFFLElBQUk7Z0JBQ1osUUFBUSxFQUFFLElBQUk7Z0JBQ2QsTUFBTSxFQUFFLElBQUk7Z0JBQ1osNkJBQTZCLEVBQUUsSUFBSTtnQkFDbkMseUJBQXlCLEVBQUUsSUFBSTtnQkFDL0IsaUJBQWlCLEVBQUUsSUFBSTtnQkFDdkIscUJBQXFCLEVBQUUsSUFBSTtnQkFDM0IsY0FBYyxFQUFFLElBQUk7Z0JBQ3BCLFFBQVEsRUFBRSxXQUFXO2dCQUNyQixJQUFJLEVBQUUsSUFBSTtnQkFDVixTQUFTLEVBQUUsWUFBWTtnQkFDdkIsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsVUFBVSxFQUFFLElBQUk7YUFDakI7WUFDRCxLQUFLLEVBQUUsUUFBUTtZQUNmLFVBQVUsRUFBRSx1Q0FBdUM7WUFDbkQsWUFBWSxFQUFFLE1BQU07WUFDcEIsVUFBVSxFQUFFLElBQUk7U0FDakI7UUFDRCxRQUFRLEVBQUUsV0FBVztLQUN0QixDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsZ0NBQWdDLEVBQUUsR0FBRyxFQUFFO1FBQzlDLEVBQUUsQ0FBQywwREFBMEQsRUFBRSxLQUFLLElBQUksRUFBRTtZQUN4RSxtQkFBbUI7WUFDbkIsTUFBTSxTQUFTLEdBQXdCO2dCQUNyQztvQkFDRSxFQUFFLEVBQUUsVUFBVTtvQkFDZCxJQUFJLEVBQUUsaUJBQWlCO29CQUN2QixVQUFVLEVBQUUsNENBQTRDO29CQUN4RCxNQUFNLEVBQUUsR0FBRztvQkFDWCxtQkFBbUIsRUFBRSxhQUFhO29CQUNsQyxTQUFTLEVBQUUsMEJBQTBCO29CQUNyQyxTQUFTLEVBQUUsMEJBQTBCO2lCQUN0QztnQkFDRDtvQkFDRSxFQUFFLEVBQUUsZUFBZTtvQkFDbkIsSUFBSSxFQUFFLHNCQUFzQjtvQkFDNUIsVUFBVSxFQUFFLHlCQUF5QjtvQkFDckMsTUFBTSxFQUFFLEVBQUU7b0JBQ1YsbUJBQW1CLEVBQUUsa0JBQWtCO29CQUN2QyxTQUFTLEVBQUUsMEJBQTBCO29CQUNyQyxTQUFTLEVBQUUsMEJBQTBCO2lCQUN0QzthQUNGLENBQUM7WUFFRixrQkFBa0IsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFN0QsTUFBTSxXQUFXLEdBQUc7Z0JBQ2xCLGFBQWEsRUFBRSxzQkFBc0I7Z0JBQ3JDLGlCQUFpQixFQUFFO29CQUNqQixlQUFlLEVBQUUsSUFBSTtvQkFDckIsTUFBTSxFQUFFLEtBQUs7aUJBQ2Q7YUFDRixDQUFDO1lBRUYsTUFBTSxLQUFLLEdBQUcscUJBQXFCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUN6RSxNQUFNLE1BQU0sR0FBMEIsTUFBTSxJQUFBLGlCQUFPLEVBQUMsS0FBSyxDQUFDLENBQUM7WUFFM0QsNEJBQTRCO1lBQzVCLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUNuQyxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2dCQUNsQyw4QkFBOEIsRUFBRSw2QkFBNkI7Z0JBQzdELDhCQUE4QixFQUFFLGNBQWM7YUFDL0MsQ0FBQyxDQUFDO1lBRUgsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDN0MsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQkFDakMsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsbUJBQW1CLEVBQUUsYUFBYTtnQkFDbEMsY0FBYyxFQUFFLFVBQVU7Z0JBQzFCLFNBQVMsRUFBRSxzQkFBc0I7YUFDbEMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM3QyxNQUFNLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdEQsQ0FBQyxDQUFDLENBQUM7UUFFSCxFQUFFLENBQUMsNkRBQTZELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDM0UsK0NBQStDO1lBQy9DLE1BQU0sU0FBUyxHQUF3QjtnQkFDckM7b0JBQ0UsRUFBRSxFQUFFLFVBQVU7b0JBQ2QsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsVUFBVSxFQUFFLDRDQUE0QztvQkFDeEQsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsbUJBQW1CLEVBQUUsYUFBYTtvQkFDbEMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLGNBQWM7b0JBQ2xCLElBQUksRUFBRSxxQkFBcUI7b0JBQzNCLFVBQVUsRUFBRSxnREFBZ0Q7b0JBQzVELE1BQU0sRUFBRSxFQUFFO29CQUNWLG1CQUFtQixFQUFFLGlCQUFpQjtvQkFDdEMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7YUFDRixDQUFDO1lBRUYsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTdELE1BQU0sV0FBVyxHQUFHO2dCQUNsQixhQUFhLEVBQUUsc0JBQXNCO2dCQUNyQyxpQkFBaUIsRUFBRTtvQkFDakIsZUFBZSxFQUFFLElBQUk7b0JBQ3JCLE1BQU0sRUFBRSxLQUFLO2lCQUNkO2FBQ0YsQ0FBQztZQUVGLE1BQU0sS0FBSyxHQUFHLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDekUsTUFBTSxNQUFNLEdBQTBCLE1BQU0sSUFBQSxpQkFBTyxFQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTdDLG9EQUFvRDtZQUNwRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4QyxNQUFNLENBQUMsWUFBWSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQzdELE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3JELE1BQU0sQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkI7UUFDcEYsQ0FBQyxDQUFDLENBQUM7UUFFSCxFQUFFLENBQUMsNkRBQTZELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDM0UsaURBQWlEO1lBQ2pELE1BQU0sU0FBUyxHQUF3QjtnQkFDckM7b0JBQ0UsRUFBRSxFQUFFLFVBQVU7b0JBQ2QsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsVUFBVSxFQUFFLDRDQUE0QztvQkFDeEQsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsbUJBQW1CLEVBQUUsYUFBYTtvQkFDbEMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7YUFDRixDQUFDO1lBRUYsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTdELE1BQU0sV0FBVyxHQUFHO2dCQUNsQixhQUFhLEVBQUUsc0JBQXNCO2dCQUNyQyxpQkFBaUIsRUFBRTtvQkFDakIsZUFBZSxFQUFFLEtBQUssRUFBRSwrQkFBK0I7b0JBQ3ZELE1BQU0sRUFBRSxLQUFLO2lCQUNkO2FBQ0YsQ0FBQztZQUVGLE1BQU0sS0FBSyxHQUFHLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDekUsTUFBTSxNQUFNLEdBQTBCLE1BQU0sSUFBQSxpQkFBTyxFQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTdDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pDLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDekQsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsNEJBQTRCLENBQUMsQ0FBQztRQUNyRSxDQUFDLENBQUMsQ0FBQztRQUVILEVBQUUsQ0FBQyx5REFBeUQsRUFBRSxLQUFLLElBQUksRUFBRTtZQUN2RSxzQ0FBc0M7WUFDdEMsTUFBTSxTQUFTLEdBQXdCO2dCQUNyQztvQkFDRSxFQUFFLEVBQUUsWUFBWTtvQkFDaEIsSUFBSSxFQUFFLG1CQUFtQjtvQkFDekIsVUFBVSxFQUFFLGlCQUFpQjtvQkFDN0IsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsbUJBQW1CLEVBQUUsZUFBZTtvQkFDcEMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLFlBQVk7b0JBQ2hCLElBQUksRUFBRSxtQkFBbUI7b0JBQ3pCLFVBQVUsRUFBRSxpQkFBaUI7b0JBQzdCLE1BQU0sRUFBRSxHQUFHLEVBQUUsY0FBYztvQkFDM0IsbUJBQW1CLEVBQUUsZUFBZTtvQkFDcEMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7YUFDRixDQUFDO1lBRUYsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTdELE1BQU0sV0FBVyxHQUFHO2dCQUNsQixhQUFhLEVBQUUsZ0NBQWdDO2dCQUMvQyxpQkFBaUIsRUFBRTtvQkFDakIsTUFBTSxFQUFFLEtBQUs7aUJBQ2Q7YUFDRixDQUFDO1lBRUYsTUFBTSxLQUFLLEdBQUcscUJBQXFCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUN6RSxNQUFNLE1BQU0sR0FBMEIsTUFBTSxJQUFBLGlCQUFPLEVBQUMsS0FBSyxDQUFDLENBQUM7WUFFM0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEMsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFN0MsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDekMsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDckQsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsRUFBRTtRQUN2QyxFQUFFLENBQUMsaURBQWlELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDL0QsTUFBTSxLQUFLLEdBQUcscUJBQXFCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDL0MsTUFBTSxNQUFNLEdBQTBCLE1BQU0sSUFBQSxpQkFBTyxFQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUNuQyw2QkFBNkIsRUFBRSxHQUFHO2dCQUNsQyw4QkFBOEIsRUFBRSw2QkFBNkI7Z0JBQzdELDhCQUE4QixFQUFFLGNBQWM7Z0JBQzlDLHdCQUF3QixFQUFFLE9BQU87YUFDbEMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7UUFFSCxFQUFFLENBQUMseURBQXlELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDdkUsTUFBTSxLQUFLLEdBQUcscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0MsTUFBTSxNQUFNLEdBQTBCLE1BQU0sSUFBQSxpQkFBTyxFQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUNuQyxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2FBQ25DLENBQUMsQ0FBQztZQUVILE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQ2pDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLEtBQUssRUFBRSxvQkFBb0I7Z0JBQzNCLFNBQVMsRUFBRSxvQkFBb0I7Z0JBQy9CLFNBQVMsRUFBRSxrQkFBa0I7YUFDOUIsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQztRQUVILEVBQUUsQ0FBQywrREFBK0QsRUFBRSxLQUFLLElBQUksRUFBRTtZQUM3RSxNQUFNLEtBQUssR0FBRyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbEQsTUFBTSxNQUFNLEdBQTBCLE1BQU0sSUFBQSxpQkFBTyxFQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUNuQyxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2FBQ25DLENBQUMsQ0FBQztZQUVILE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQ2pDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLEtBQUssRUFBRSwwQkFBMEI7Z0JBQ2pDLFNBQVMsRUFBRSxjQUFjO2dCQUN6QixTQUFTLEVBQUUsa0JBQWtCO2FBQzlCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsRUFBRSxDQUFDLHlEQUF5RCxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3ZFLE1BQU0sS0FBSyxHQUFHLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQzlELE1BQU0sTUFBTSxHQUEwQixNQUFNLElBQUEsaUJBQU8sRUFBQyxLQUFLLENBQUMsQ0FBQztZQUUzRCxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU3QyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUNqQyxPQUFPLEVBQUUsS0FBSztnQkFDZCxLQUFLLEVBQUUsOEJBQThCO2dCQUNyQyxTQUFTLEVBQUUsY0FBYztnQkFDekIsU0FBUyxFQUFFLGtCQUFrQjthQUM5QixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILEVBQUUsQ0FBQywwQ0FBMEMsRUFBRSxLQUFLLElBQUksRUFBRTtZQUN4RCxzQkFBc0I7WUFDdEIsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLElBQUksS0FBSyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztZQUUzRixNQUFNLFdBQVcsR0FBRztnQkFDbEIsYUFBYSxFQUFFLDJCQUEyQjtnQkFDMUMsaUJBQWlCLEVBQUU7b0JBQ2pCLGVBQWUsRUFBRSxJQUFJO29CQUNyQixNQUFNLEVBQUUsS0FBSztpQkFDZDthQUNGLENBQUM7WUFFRixNQUFNLEtBQUssR0FBRyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ3pFLE1BQU0sTUFBTSxHQUEwQixNQUFNLElBQUEsaUJBQU8sRUFBQyxLQUFLLENBQUMsQ0FBQztZQUUzRCxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU3QyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QyxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3RELE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLDJCQUEyQixDQUFDLENBQUM7UUFDcEUsQ0FBQyxDQUFDLENBQUM7UUFFSCxFQUFFLENBQUMsb0RBQW9ELEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDbEUsTUFBTSxTQUFTLEdBQXdCO2dCQUNyQztvQkFDRSxFQUFFLEVBQUUsV0FBVztvQkFDZixJQUFJLEVBQUUsV0FBVztvQkFDakIsVUFBVSxFQUFFLGlCQUFpQjtvQkFDN0IsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsbUJBQW1CLEVBQUUsY0FBYztvQkFDbkMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7YUFDRixDQUFDO1lBRUYsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTdELE1BQU0sV0FBVyxHQUFHO2dCQUNsQixhQUFhLEVBQUUsNkJBQTZCO2dCQUM1QyxpQkFBaUIsRUFBRTtvQkFDakIsTUFBTSxFQUFFLEtBQUs7aUJBQ2Q7YUFDRixDQUFDO1lBRUYsTUFBTSxlQUFlLEdBQUcsK0JBQStCLENBQUM7WUFDeEQsTUFBTSxLQUFLLEdBQUcscUJBQXFCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUM7WUFDMUYsTUFBTSxNQUFNLEdBQTBCLE1BQU0sSUFBQSxpQkFBTyxFQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTdDLCtFQUErRTtZQUMvRSxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRLENBQUMsOEJBQThCLEVBQUUsR0FBRyxFQUFFO1FBQzVDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCwyQ0FBMkM7WUFDM0MsTUFBTSxTQUFTLEdBQXdCO2dCQUNyQztvQkFDRSxFQUFFLEVBQUUsV0FBVztvQkFDZixJQUFJLEVBQUUsV0FBVztvQkFDakIsVUFBVSxFQUFFLGlCQUFpQjtvQkFDN0IsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsbUJBQW1CLEVBQUUsY0FBYztvQkFDbkMsU0FBUyxFQUFFLDBCQUEwQjtvQkFDckMsU0FBUyxFQUFFLDBCQUEwQjtpQkFDdEM7YUFDRixDQUFDO1lBQ0Ysa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELENBQUMsQ0FBQyxDQUFDO1FBRUgsRUFBRSxDQUFDLHVDQUF1QyxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3JELE1BQU0sV0FBVyxHQUFHO2dCQUNsQixpQkFBaUIsRUFBRTtvQkFDakIsTUFBTSxFQUFFLEtBQUs7aUJBQ2Q7Z0JBQ0Qsd0JBQXdCO2FBQ3pCLENBQUM7WUFFRixNQUFNLEtBQUssR0FBRyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ3pFLE1BQU0sTUFBTSxHQUEwQixNQUFNLElBQUEsaUJBQU8sRUFBQyxLQUFLLENBQUMsQ0FBQztZQUUzRCxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU3QyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QyxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ3hELE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLDJCQUEyQixDQUFDLENBQUM7UUFDcEUsQ0FBQyxDQUFDLENBQUM7UUFFSCxFQUFFLENBQUMsMkNBQTJDLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDekQsTUFBTSxXQUFXLEdBQUc7Z0JBQ2xCLGFBQWEsRUFBRSxrQkFBa0I7Z0JBQ2pDLDRCQUE0QjthQUM3QixDQUFDO1lBRUYsTUFBTSxLQUFLLEdBQUcscUJBQXFCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUN6RSxNQUFNLE1BQU0sR0FBMEIsTUFBTSxJQUFBLGlCQUFPLEVBQUMsS0FBSyxDQUFDLENBQUM7WUFFM0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEMsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFN0MsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDekMsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUN4RCxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1FBQ3hFLENBQUMsQ0FBQyxDQUFDO1FBRUgsRUFBRSxDQUFDLGdEQUFnRCxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzlELE1BQU0sV0FBVyxHQUFHO2dCQUNsQixhQUFhLEVBQUUsa0JBQWtCO2dCQUNqQyxpQkFBaUIsRUFBRSxjQUFjLENBQUMsbUJBQW1CO2FBQ3RELENBQUM7WUFFRixNQUFNLEtBQUssR0FBRyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ3pFLE1BQU0sTUFBTSxHQUEwQixNQUFNLElBQUEsaUJBQU8sRUFBQyxLQUFLLENBQUMsQ0FBQztZQUUzRCxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU3QyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QyxNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ3hELE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7UUFDOUUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQVBJR2F0ZXdheVByb3h5RXZlbnQsIEFQSUdhdGV3YXlQcm94eVJlc3VsdCB9IGZyb20gJ2F3cy1sYW1iZGEnO1xyXG5pbXBvcnQgeyBoYW5kbGVyIH0gZnJvbSAnLi4vLi4vZnVuY3Rpb25zL2RlY2lzaW9uLWVuZ2luZS9oYW5kbGVyJztcclxuaW1wb3J0IHsgUXVhbGlmaWNhdGlvblJ1bGUgfSBmcm9tICcuLi8uLi90eXBlcy9kZWNpc2lvbi1lbmdpbmUnO1xyXG5cclxuLy8gTW9jayBBV1MgU0RLIHRvIGF2b2lkIGFjdHVhbCBEeW5hbW9EQiBjYWxscyBkdXJpbmcgaW50ZWdyYXRpb24gdGVzdHNcclxuamVzdC5tb2NrKCdAYXdzLXNkay9saWItZHluYW1vZGInLCAoKSA9PiAoe1xyXG4gIER5bmFtb0RCRG9jdW1lbnRDbGllbnQ6IHtcclxuICAgIGZyb206IGplc3QuZm4oKCkgPT4gKHtcclxuICAgICAgc2VuZDogamVzdC5mbigpXHJcbiAgICB9KSlcclxuICB9LFxyXG4gIFNjYW5Db21tYW5kOiBqZXN0LmZuKClcclxufSkpO1xyXG5cclxuLy8gTW9jayB0aGUgUnVsZVJlcG9zaXRvcnkgdG8gcHJvdmlkZSBjb250cm9sbGVkIHRlc3QgZGF0YVxyXG5qZXN0Lm1vY2soJy4uLy4uL3NlcnZpY2VzL2RlY2lzaW9uLWVuZ2luZS9SdWxlUmVwb3NpdG9yeScsICgpID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgUnVsZVJlcG9zaXRvcnk6IGplc3QuZm4oKS5tb2NrSW1wbGVtZW50YXRpb24oKCkgPT4gKHtcclxuICAgICAgbG9hZEFsbFJ1bGVzOiBqZXN0LmZuKClcclxuICAgIH0pKVxyXG4gIH07XHJcbn0pO1xyXG5cclxuZGVzY3JpYmUoJ0RlY2lzaW9uIEVuZ2luZSBMYW1iZGEgSGFuZGxlciAtIEludGVncmF0aW9uIFRlc3RzJywgKCkgPT4ge1xyXG4gIGxldCBtb2NrUnVsZVJlcG9zaXRvcnk6IGFueTtcclxuXHJcbiAgYmVmb3JlRWFjaCgoKSA9PiB7XHJcbiAgICBqZXN0LmNsZWFyQWxsTW9ja3MoKTtcclxuICAgIFxyXG4gICAgLy8gR2V0IHRoZSBtb2NrZWQgUnVsZVJlcG9zaXRvcnlcclxuICAgIGNvbnN0IHsgUnVsZVJlcG9zaXRvcnkgfSA9IHJlcXVpcmUoJy4uLy4uL3NlcnZpY2VzL2RlY2lzaW9uLWVuZ2luZS9SdWxlUmVwb3NpdG9yeScpO1xyXG4gICAgbW9ja1J1bGVSZXBvc2l0b3J5ID0gbmV3IFJ1bGVSZXBvc2l0b3J5KCk7XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNyZWF0ZUFQSUdhdGV3YXlFdmVudCA9IChcclxuICAgIGh0dHBNZXRob2Q6IHN0cmluZyA9ICdQT1NUJyxcclxuICAgIGJvZHk6IHN0cmluZyB8IG51bGwgPSBudWxsLFxyXG4gICAgcmVxdWVzdElkOiBzdHJpbmcgPSAndGVzdC1yZXF1ZXN0LTEyMydcclxuICApOiBBUElHYXRld2F5UHJveHlFdmVudCA9PiAoe1xyXG4gICAgaHR0cE1ldGhvZCxcclxuICAgIGJvZHksXHJcbiAgICBoZWFkZXJzOiB7fSxcclxuICAgIG11bHRpVmFsdWVIZWFkZXJzOiB7fSxcclxuICAgIGlzQmFzZTY0RW5jb2RlZDogZmFsc2UsXHJcbiAgICBwYXRoOiAnL2RlY2lzaW9uJyxcclxuICAgIHBhdGhQYXJhbWV0ZXJzOiBudWxsLFxyXG4gICAgcXVlcnlTdHJpbmdQYXJhbWV0ZXJzOiBudWxsLFxyXG4gICAgbXVsdGlWYWx1ZVF1ZXJ5U3RyaW5nUGFyYW1ldGVyczogbnVsbCxcclxuICAgIHN0YWdlVmFyaWFibGVzOiBudWxsLFxyXG4gICAgcmVxdWVzdENvbnRleHQ6IHtcclxuICAgICAgcmVxdWVzdElkLFxyXG4gICAgICBzdGFnZTogJ3Rlc3QnLFxyXG4gICAgICByZXNvdXJjZUlkOiAncmVzb3VyY2UtaWQnLFxyXG4gICAgICByZXNvdXJjZVBhdGg6ICcvZGVjaXNpb24nLFxyXG4gICAgICBodHRwTWV0aG9kLFxyXG4gICAgICByZXF1ZXN0VGltZTogJzAxL0phbi8yMDIzOjAwOjAwOjAwICswMDAwJyxcclxuICAgICAgcmVxdWVzdFRpbWVFcG9jaDogMTY3MjUzMTIwMDAwMCxcclxuICAgICAgcGF0aDogJy90ZXN0L2RlY2lzaW9uJyxcclxuICAgICAgYWNjb3VudElkOiAnMTIzNDU2Nzg5MDEyJyxcclxuICAgICAgcHJvdG9jb2w6ICdIVFRQLzEuMScsXHJcbiAgICAgIGlkZW50aXR5OiB7XHJcbiAgICAgICAgYWNjZXNzS2V5OiBudWxsLFxyXG4gICAgICAgIGFjY291bnRJZDogbnVsbCxcclxuICAgICAgICBhcGlLZXk6IG51bGwsXHJcbiAgICAgICAgYXBpS2V5SWQ6IG51bGwsXHJcbiAgICAgICAgY2FsbGVyOiBudWxsLFxyXG4gICAgICAgIGNvZ25pdG9BdXRoZW50aWNhdGlvblByb3ZpZGVyOiBudWxsLFxyXG4gICAgICAgIGNvZ25pdG9BdXRoZW50aWNhdGlvblR5cGU6IG51bGwsXHJcbiAgICAgICAgY29nbml0b0lkZW50aXR5SWQ6IG51bGwsXHJcbiAgICAgICAgY29nbml0b0lkZW50aXR5UG9vbElkOiBudWxsLFxyXG4gICAgICAgIHByaW5jaXBhbE9yZ0lkOiBudWxsLFxyXG4gICAgICAgIHNvdXJjZUlwOiAnMTI3LjAuMC4xJyxcclxuICAgICAgICB1c2VyOiBudWxsLFxyXG4gICAgICAgIHVzZXJBZ2VudDogJ3Rlc3QtYWdlbnQnLFxyXG4gICAgICAgIHVzZXJBcm46IG51bGwsXHJcbiAgICAgICAgY2xpZW50Q2VydDogbnVsbFxyXG4gICAgICB9LFxyXG4gICAgICBhcGlJZDogJ2FwaS1pZCcsXHJcbiAgICAgIGRvbWFpbk5hbWU6ICd0ZXN0LmV4ZWN1dGUtYXBpLnJlZ2lvbi5hbWF6b25hd3MuY29tJyxcclxuICAgICAgZG9tYWluUHJlZml4OiAndGVzdCcsXHJcbiAgICAgIGF1dGhvcml6ZXI6IG51bGxcclxuICAgIH0sXHJcbiAgICByZXNvdXJjZTogJy9kZWNpc2lvbidcclxuICB9KTtcclxuXHJcbiAgZGVzY3JpYmUoJ0VuZC10by1FbmQgRGVjaXNpb24gUHJvY2Vzc2luZycsICgpID0+IHtcclxuICAgIGl0KCdzaG91bGQgcHJvY2VzcyBhIGNvbXBsZXRlIGRlY2lzaW9uIHdvcmtmbG93IHN1Y2Nlc3NmdWxseScsIGFzeW5jICgpID0+IHtcclxuICAgICAgLy8gU2V0dXAgdGVzdCBydWxlc1xyXG4gICAgICBjb25zdCB0ZXN0UnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdydWxlLXZpcCcsXHJcbiAgICAgICAgICBuYW1lOiAnVklQIENsaWVudCBSdWxlJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSAmJiBDbGllbnQgPT0gXCJWSVBcIicsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDEwMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdWSVBfU0VHTUVOVCcsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdydWxlLXN0YW5kYXJkJyxcclxuICAgICAgICAgIG5hbWU6ICdTdGFuZGFyZCBDbGllbnQgUnVsZScsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUnLFxyXG4gICAgICAgICAgd2VpZ2h0OiA1MCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdTVEFOREFSRF9TRUdNRU5UJyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWicsXHJcbiAgICAgICAgICB1cGRhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonXHJcbiAgICAgICAgfVxyXG4gICAgICBdO1xyXG5cclxuICAgICAgbW9ja1J1bGVSZXBvc2l0b3J5LmxvYWRBbGxSdWxlcy5tb2NrUmVzb2x2ZWRWYWx1ZSh0ZXN0UnVsZXMpO1xyXG5cclxuICAgICAgY29uc3QgcmVxdWVzdEJvZHkgPSB7XHJcbiAgICAgICAgaW50ZXJhY3Rpb25JZDogJ3Rlc3QtaW50ZXJhY3Rpb24tMTIzJyxcclxuICAgICAgICBjb250YWN0QXR0cmlidXRlczoge1xyXG4gICAgICAgICAgTm91dmVhdVNpbmlzdHJlOiB0cnVlLFxyXG4gICAgICAgICAgQ2xpZW50OiAnVklQJ1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlQVBJR2F0ZXdheUV2ZW50KCdQT1NUJywgSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpKTtcclxuICAgICAgY29uc3QgcmVzdWx0OiBBUElHYXRld2F5UHJveHlSZXN1bHQgPSBhd2FpdCBoYW5kbGVyKGV2ZW50KTtcclxuXHJcbiAgICAgIC8vIFZlcmlmeSByZXNwb25zZSBzdHJ1Y3R1cmVcclxuICAgICAgZXhwZWN0KHJlc3VsdC5zdGF0dXNDb2RlKS50b0JlKDIwMCk7XHJcbiAgICAgIGV4cGVjdChyZXN1bHQuaGVhZGVycykudG9NYXRjaE9iamVjdCh7XHJcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZSwgQXV0aG9yaXphdGlvbicsXHJcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnT1BUSU9OUyxQT1NUJ1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlQm9keSA9IEpTT04ucGFyc2UocmVzdWx0LmJvZHkpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5KS50b01hdGNoT2JqZWN0KHtcclxuICAgICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdWSVBfU0VHTUVOVCcsXHJcbiAgICAgICAgc2VsZWN0ZWRSdWxlSWQ6ICdydWxlLXZpcCcsXHJcbiAgICAgICAgcmVxdWVzdElkOiAndGVzdC1pbnRlcmFjdGlvbi0xMjMnXHJcbiAgICAgIH0pO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LnRpbWVzdGFtcCkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlQm9keS5lbGltaW5hdGlvblRyYWNlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaXQoJ3Nob3VsZCBoYW5kbGUgcnVsZSBlbGltaW5hdGlvbiBjb3JyZWN0bHkgaW4gZW5kLXRvLWVuZCBmbG93JywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAvLyBTZXR1cCB0ZXN0IHJ1bGVzIHdoZXJlIG9ubHkgb25lIHNob3VsZCBtYXRjaFxyXG4gICAgICBjb25zdCB0ZXN0UnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdydWxlLXZpcCcsXHJcbiAgICAgICAgICBuYW1lOiAnVklQIENsaWVudCBSdWxlJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSAmJiBDbGllbnQgPT0gXCJWSVBcIicsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDEwMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdWSVBfU0VHTUVOVCcsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdydWxlLXByZW1pdW0nLFxyXG4gICAgICAgICAgbmFtZTogJ1ByZW1pdW0gQ2xpZW50IFJ1bGUnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlICYmIENsaWVudCA9PSBcIlBSRU1JVU1cIicsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDgwLFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ1BSRU1JVU1fU0VHTUVOVCcsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICAgIH1cclxuICAgICAgXTtcclxuXHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1Jlc29sdmVkVmFsdWUodGVzdFJ1bGVzKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcXVlc3RCb2R5ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LWludGVyYWN0aW9uLTQ1NicsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IHtcclxuICAgICAgICAgIE5vdXZlYXVTaW5pc3RyZTogdHJ1ZSxcclxuICAgICAgICAgIENsaWVudDogJ1ZJUCdcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCBldmVudCA9IGNyZWF0ZUFQSUdhdGV3YXlFdmVudCgnUE9TVCcsIEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdDogQVBJR2F0ZXdheVByb3h5UmVzdWx0ID0gYXdhaXQgaGFuZGxlcihldmVudCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN0YXR1c0NvZGUpLnRvQmUoMjAwKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VCb2R5ID0gSlNPTi5wYXJzZShyZXN1bHQuYm9keSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBTaG91bGQgc2VsZWN0IFZJUCBydWxlIGFuZCBlbGltaW5hdGUgUFJFTUlVTSBydWxlXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuc3VjY2VzcykudG9CZSh0cnVlKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlQm9keS5kaXN0cmlidXRpb25TZWdtZW50KS50b0JlKCdWSVBfU0VHTUVOVCcpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LnNlbGVjdGVkUnVsZUlkKS50b0JlKCdydWxlLXZpcCcpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LmVsaW1pbmF0aW9uVHJhY2UpLnRvSGF2ZUxlbmd0aCgyKTsgLy8gVHdvIGF0dHJpYnV0ZXMgcHJvY2Vzc2VkXHJcbiAgICB9KTtcclxuXHJcbiAgICBpdCgnc2hvdWxkIGhhbmRsZSBubyBtYXRjaGluZyBydWxlcyBzY2VuYXJpbyBpbiBlbmQtdG8tZW5kIGZsb3cnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgIC8vIFNldHVwIHRlc3QgcnVsZXMgdGhhdCB3b24ndCBtYXRjaCB0aGUgY3JpdGVyaWFcclxuICAgICAgY29uc3QgdGVzdFJ1bGVzOiBRdWFsaWZpY2F0aW9uUnVsZVtdID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiAncnVsZS12aXAnLFxyXG4gICAgICAgICAgbmFtZTogJ1ZJUCBDbGllbnQgUnVsZScsXHJcbiAgICAgICAgICBleHByZXNzaW9uOiAnTm91dmVhdVNpbmlzdHJlID09IHRydWUgJiYgQ2xpZW50ID09IFwiVklQXCInLFxyXG4gICAgICAgICAgd2VpZ2h0OiAxMDAsXHJcbiAgICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnVklQX1NFR01FTlQnLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWidcclxuICAgICAgICB9XHJcbiAgICAgIF07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHRlc3RSdWxlcyk7XHJcblxyXG4gICAgICBjb25zdCByZXF1ZXN0Qm9keSA9IHtcclxuICAgICAgICBpbnRlcmFjdGlvbklkOiAndGVzdC1pbnRlcmFjdGlvbi03ODknLFxyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7XHJcbiAgICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IGZhbHNlLCAvLyBUaGlzIHdpbGwgZWxpbWluYXRlIHRoZSBydWxlXHJcbiAgICAgICAgICBDbGllbnQ6ICdWSVAnXHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVBUElHYXRld2F5RXZlbnQoJ1BPU1QnLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSkpO1xyXG4gICAgICBjb25zdCByZXN1bHQ6IEFQSUdhdGV3YXlQcm94eVJlc3VsdCA9IGF3YWl0IGhhbmRsZXIoZXZlbnQpO1xyXG5cclxuICAgICAgZXhwZWN0KHJlc3VsdC5zdGF0dXNDb2RlKS50b0JlKDQwMCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlQm9keSA9IEpTT04ucGFyc2UocmVzdWx0LmJvZHkpO1xyXG4gICAgICBcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlQm9keS5zdWNjZXNzKS50b0JlKGZhbHNlKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlQm9keS5lcnJvckNvZGUpLnRvQmUoJ05PX01BVENISU5HX1JVTEVTJyk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuZXJyb3IpLnRvQ29udGFpbignQXVjdW5lIHLDqGdsZSBuZSBjb3JyZXNwb25kJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBpdCgnc2hvdWxkIGhhbmRsZSBlcXVhbCB3ZWlnaHRzIHNjZW5hcmlvIGluIGVuZC10by1lbmQgZmxvdycsIGFzeW5jICgpID0+IHtcclxuICAgICAgLy8gU2V0dXAgdGVzdCBydWxlcyB3aXRoIGVxdWFsIHdlaWdodHNcclxuICAgICAgY29uc3QgdGVzdFJ1bGVzOiBRdWFsaWZpY2F0aW9uUnVsZVtdID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiAncnVsZS12aXAtMScsXHJcbiAgICAgICAgICBuYW1lOiAnVklQIENsaWVudCBSdWxlIDEnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ0NsaWVudCA9PSBcIlZJUFwiJyxcclxuICAgICAgICAgIHdlaWdodDogMTAwLFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ1ZJUF9TRUdNRU5UXzEnLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWidcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiAncnVsZS12aXAtMicsXHJcbiAgICAgICAgICBuYW1lOiAnVklQIENsaWVudCBSdWxlIDInLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ0NsaWVudCA9PSBcIlZJUFwiJyxcclxuICAgICAgICAgIHdlaWdodDogMTAwLCAvLyBTYW1lIHdlaWdodFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ1ZJUF9TRUdNRU5UXzInLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWidcclxuICAgICAgICB9XHJcbiAgICAgIF07XHJcblxyXG4gICAgICBtb2NrUnVsZVJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzLm1vY2tSZXNvbHZlZFZhbHVlKHRlc3RSdWxlcyk7XHJcblxyXG4gICAgICBjb25zdCByZXF1ZXN0Qm9keSA9IHtcclxuICAgICAgICBpbnRlcmFjdGlvbklkOiAndGVzdC1pbnRlcmFjdGlvbi1lcXVhbC13ZWlnaHRzJyxcclxuICAgICAgICBjb250YWN0QXR0cmlidXRlczoge1xyXG4gICAgICAgICAgQ2xpZW50OiAnVklQJ1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlQVBJR2F0ZXdheUV2ZW50KCdQT1NUJywgSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpKTtcclxuICAgICAgY29uc3QgcmVzdWx0OiBBUElHYXRld2F5UHJveHlSZXN1bHQgPSBhd2FpdCBoYW5kbGVyKGV2ZW50KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3RhdHVzQ29kZSkudG9CZSg0MDApO1xyXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKHJlc3VsdC5ib2R5KTtcclxuICAgICAgXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuZXJyb3JDb2RlKS50b0JlKCdFUVVBTF9XRUlHSFRTJyk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuZXJyb3IpLnRvQ29udGFpbigncG9pZHMgaWRlbnRpcXVlcycpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcblxyXG4gIGRlc2NyaWJlKCdBUEkgR2F0ZXdheSBJbnRlZ3JhdGlvbicsICgpID0+IHtcclxuICAgIGl0KCdzaG91bGQgaGFuZGxlIENPUlMgcHJlZmxpZ2h0IHJlcXVlc3RzIGNvcnJlY3RseScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVBUElHYXRld2F5RXZlbnQoJ09QVElPTlMnKTtcclxuICAgICAgY29uc3QgcmVzdWx0OiBBUElHYXRld2F5UHJveHlSZXN1bHQgPSBhd2FpdCBoYW5kbGVyKGV2ZW50KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3RhdHVzQ29kZSkudG9CZSgyMDApO1xyXG4gICAgICBleHBlY3QocmVzdWx0LmhlYWRlcnMpLnRvTWF0Y2hPYmplY3Qoe1xyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXHJcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnQ29udGVudC1UeXBlLCBBdXRob3JpemF0aW9uJyxcclxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kcyc6ICdPUFRJT05TLFBPU1QnLFxyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1NYXgtQWdlJzogJzg2NDAwJ1xyXG4gICAgICB9KTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5ib2R5KS50b0JlKCcnKTtcclxuICAgIH0pO1xyXG5cclxuICAgIGl0KCdzaG91bGQgcmVqZWN0IG5vbi1QT1NUIG1ldGhvZHMgd2l0aCBwcm9wZXIgQ09SUyBoZWFkZXJzJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICBjb25zdCBldmVudCA9IGNyZWF0ZUFQSUdhdGV3YXlFdmVudCgnR0VUJyk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdDogQVBJR2F0ZXdheVByb3h5UmVzdWx0ID0gYXdhaXQgaGFuZGxlcihldmVudCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN0YXR1c0NvZGUpLnRvQmUoNDA1KTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5oZWFkZXJzKS50b01hdGNoT2JqZWN0KHtcclxuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKidcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKHJlc3VsdC5ib2R5KTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlQm9keSkudG9NYXRjaE9iamVjdCh7XHJcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6ICdNZXRob2Qgbm90IGFsbG93ZWQnLFxyXG4gICAgICAgIGVycm9yQ29kZTogJ01FVEhPRF9OT1RfQUxMT1dFRCcsXHJcbiAgICAgICAgcmVxdWVzdElkOiAndGVzdC1yZXF1ZXN0LTEyMydcclxuICAgICAgfSk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaXQoJ3Nob3VsZCBoYW5kbGUgbWlzc2luZyByZXF1ZXN0IGJvZHkgd2l0aCBwcm9wZXIgZXJyb3IgcmVzcG9uc2UnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlQVBJR2F0ZXdheUV2ZW50KCdQT1NUJywgbnVsbCk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdDogQVBJR2F0ZXdheVByb3h5UmVzdWx0ID0gYXdhaXQgaGFuZGxlcihldmVudCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN0YXR1c0NvZGUpLnRvQmUoNDAwKTtcclxuICAgICAgZXhwZWN0KHJlc3VsdC5oZWFkZXJzKS50b01hdGNoT2JqZWN0KHtcclxuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKidcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKHJlc3VsdC5ib2R5KTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlQm9keSkudG9NYXRjaE9iamVjdCh7XHJcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6ICdSZXF1ZXN0IGJvZHkgaXMgcmVxdWlyZWQnLFxyXG4gICAgICAgIGVycm9yQ29kZTogJ01JU1NJTkdfQk9EWScsXHJcbiAgICAgICAgcmVxdWVzdElkOiAndGVzdC1yZXF1ZXN0LTEyMydcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBpdCgnc2hvdWxkIGhhbmRsZSBtYWxmb3JtZWQgSlNPTiB3aXRoIHByb3BlciBlcnJvciByZXNwb25zZScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVBUElHYXRld2F5RXZlbnQoJ1BPU1QnLCAnaW52YWxpZCBqc29uIHsnKTtcclxuICAgICAgY29uc3QgcmVzdWx0OiBBUElHYXRld2F5UHJveHlSZXN1bHQgPSBhd2FpdCBoYW5kbGVyKGV2ZW50KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3RhdHVzQ29kZSkudG9CZSg0MDApO1xyXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKHJlc3VsdC5ib2R5KTtcclxuICAgICAgXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkpLnRvTWF0Y2hPYmplY3Qoe1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiAnSW52YWxpZCBKU09OIGluIHJlcXVlc3QgYm9keScsXHJcbiAgICAgICAgZXJyb3JDb2RlOiAnSU5WQUxJRF9KU09OJyxcclxuICAgICAgICByZXF1ZXN0SWQ6ICd0ZXN0LXJlcXVlc3QtMTIzJ1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIGl0KCdzaG91bGQgaGFuZGxlIGRhdGFiYXNlIGVycm9ycyBncmFjZWZ1bGx5JywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAvLyBNb2NrIGRhdGFiYXNlIGVycm9yXHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1JlamVjdGVkVmFsdWUobmV3IEVycm9yKCdEeW5hbW9EQiBjb25uZWN0aW9uIGZhaWxlZCcpKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcXVlc3RCb2R5ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LWludGVyYWN0aW9uLWRiLWVycm9yJyxcclxuICAgICAgICBjb250YWN0QXR0cmlidXRlczoge1xyXG4gICAgICAgICAgTm91dmVhdVNpbmlzdHJlOiB0cnVlLFxyXG4gICAgICAgICAgQ2xpZW50OiAnVklQJ1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlQVBJR2F0ZXdheUV2ZW50KCdQT1NUJywgSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpKTtcclxuICAgICAgY29uc3QgcmVzdWx0OiBBUElHYXRld2F5UHJveHlSZXN1bHQgPSBhd2FpdCBoYW5kbGVyKGV2ZW50KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3RhdHVzQ29kZSkudG9CZSg0MDApO1xyXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKHJlc3VsdC5ib2R5KTtcclxuICAgICAgXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuZXJyb3JDb2RlKS50b0JlKCdEQVRBQkFTRV9FUlJPUicpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LmVycm9yKS50b0NvbnRhaW4oJ0RhdGFiYXNlIG9wZXJhdGlvbiBmYWlsZWQnKTtcclxuICAgIH0pO1xyXG5cclxuICAgIGl0KCdzaG91bGQgaW5jbHVkZSByZXF1ZXN0IElEIGZyb20gQVBJIEdhdGV3YXkgY29udGV4dCcsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgdGVzdFJ1bGVzOiBRdWFsaWZpY2F0aW9uUnVsZVtdID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiAncnVsZS10ZXN0JyxcclxuICAgICAgICAgIG5hbWU6ICdUZXN0IFJ1bGUnLFxyXG4gICAgICAgICAgZXhwcmVzc2lvbjogJ0NsaWVudCA9PSBcIlZJUFwiJyxcclxuICAgICAgICAgIHdlaWdodDogMTAwLFxyXG4gICAgICAgICAgZGlzdHJpYnV0aW9uU2VnbWVudDogJ1RFU1RfU0VHTUVOVCcsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6ICcyMDIzLTAxLTAxVDAwOjAwOjAwLjAwMFonLFxyXG4gICAgICAgICAgdXBkYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJ1xyXG4gICAgICAgIH1cclxuICAgICAgXTtcclxuXHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1Jlc29sdmVkVmFsdWUodGVzdFJ1bGVzKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcXVlc3RCb2R5ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6ICd0ZXN0LWludGVyYWN0aW9uLXJlcXVlc3QtaWQnLFxyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7XHJcbiAgICAgICAgICBDbGllbnQ6ICdWSVAnXHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgY3VzdG9tUmVxdWVzdElkID0gJ2N1c3RvbS1hcGktZ2F0ZXdheS1yZXF1ZXN0LWlkJztcclxuICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVBUElHYXRld2F5RXZlbnQoJ1BPU1QnLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSksIGN1c3RvbVJlcXVlc3RJZCk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdDogQVBJR2F0ZXdheVByb3h5UmVzdWx0ID0gYXdhaXQgaGFuZGxlcihldmVudCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN0YXR1c0NvZGUpLnRvQmUoMjAwKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VCb2R5ID0gSlNPTi5wYXJzZShyZXN1bHQuYm9keSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBUaGUgcmVzcG9uc2Ugc2hvdWxkIHVzZSB0aGUgaW50ZXJhY3Rpb25JZCBmcm9tIHRoZSByZXF1ZXN0IGJvZHkgYXMgcmVxdWVzdElkXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkucmVxdWVzdElkKS50b0JlKCd0ZXN0LWludGVyYWN0aW9uLXJlcXVlc3QtaWQnKTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG5cclxuICBkZXNjcmliZSgnSW5wdXQgVmFsaWRhdGlvbiBJbnRlZ3JhdGlvbicsICgpID0+IHtcclxuICAgIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgICAvLyBTZXR1cCBkZWZhdWx0IHJ1bGVzIGZvciB2YWxpZGF0aW9uIHRlc3RzXHJcbiAgICAgIGNvbnN0IHRlc3RSdWxlczogUXVhbGlmaWNhdGlvblJ1bGVbXSA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ3J1bGUtdGVzdCcsXHJcbiAgICAgICAgICBuYW1lOiAnVGVzdCBSdWxlJyxcclxuICAgICAgICAgIGV4cHJlc3Npb246ICdDbGllbnQgPT0gXCJWSVBcIicsXHJcbiAgICAgICAgICB3ZWlnaHQ6IDEwMCxcclxuICAgICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICdURVNUX1NFR01FTlQnLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiAnMjAyMy0wMS0wMVQwMDowMDowMC4wMDBaJyxcclxuICAgICAgICAgIHVwZGF0ZWRBdDogJzIwMjMtMDEtMDFUMDA6MDA6MDAuMDAwWidcclxuICAgICAgICB9XHJcbiAgICAgIF07XHJcbiAgICAgIG1vY2tSdWxlUmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMubW9ja1Jlc29sdmVkVmFsdWUodGVzdFJ1bGVzKTtcclxuICAgIH0pO1xyXG5cclxuICAgIGl0KCdzaG91bGQgdmFsaWRhdGUgbWlzc2luZyBpbnRlcmFjdGlvbklkJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICBjb25zdCByZXF1ZXN0Qm9keSA9IHtcclxuICAgICAgICBjb250YWN0QXR0cmlidXRlczoge1xyXG4gICAgICAgICAgQ2xpZW50OiAnVklQJ1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBNaXNzaW5nIGludGVyYWN0aW9uSWRcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlQVBJR2F0ZXdheUV2ZW50KCdQT1NUJywgSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpKTtcclxuICAgICAgY29uc3QgcmVzdWx0OiBBUElHYXRld2F5UHJveHlSZXN1bHQgPSBhd2FpdCBoYW5kbGVyKGV2ZW50KTtcclxuXHJcbiAgICAgIGV4cGVjdChyZXN1bHQuc3RhdHVzQ29kZSkudG9CZSg0MDApO1xyXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKHJlc3VsdC5ib2R5KTtcclxuICAgICAgXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuZXJyb3JDb2RlKS50b0JlKCdWQUxJREFUSU9OX0VSUk9SJyk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZUJvZHkuZXJyb3IpLnRvQ29udGFpbignaW50ZXJhY3Rpb25JZCBpcyByZXF1aXJlZCcpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaXQoJ3Nob3VsZCB2YWxpZGF0ZSBtaXNzaW5nIGNvbnRhY3RBdHRyaWJ1dGVzJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICBjb25zdCByZXF1ZXN0Qm9keSA9IHtcclxuICAgICAgICBpbnRlcmFjdGlvbklkOiAndGVzdC1pbnRlcmFjdGlvbidcclxuICAgICAgICAvLyBNaXNzaW5nIGNvbnRhY3RBdHRyaWJ1dGVzXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCBldmVudCA9IGNyZWF0ZUFQSUdhdGV3YXlFdmVudCgnUE9TVCcsIEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdDogQVBJR2F0ZXdheVByb3h5UmVzdWx0ID0gYXdhaXQgaGFuZGxlcihldmVudCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN0YXR1c0NvZGUpLnRvQmUoNDAwKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VCb2R5ID0gSlNPTi5wYXJzZShyZXN1bHQuYm9keSk7XHJcbiAgICAgIFxyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LmVycm9yQ29kZSkudG9CZSgnVkFMSURBVElPTl9FUlJPUicpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LmVycm9yKS50b0NvbnRhaW4oJ2NvbnRhY3RBdHRyaWJ1dGVzIGlzIHJlcXVpcmVkJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBpdCgnc2hvdWxkIHZhbGlkYXRlIGludmFsaWQgY29udGFjdEF0dHJpYnV0ZXMgdHlwZScsIGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVxdWVzdEJvZHkgPSB7XHJcbiAgICAgICAgaW50ZXJhY3Rpb25JZDogJ3Rlc3QtaW50ZXJhY3Rpb24nLFxyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiAnaW52YWxpZC10eXBlJyAvLyBTaG91bGQgYmUgb2JqZWN0XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCBldmVudCA9IGNyZWF0ZUFQSUdhdGV3YXlFdmVudCgnUE9TVCcsIEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdDogQVBJR2F0ZXdheVByb3h5UmVzdWx0ID0gYXdhaXQgaGFuZGxlcihldmVudCk7XHJcblxyXG4gICAgICBleHBlY3QocmVzdWx0LnN0YXR1c0NvZGUpLnRvQmUoNDAwKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VCb2R5ID0gSlNPTi5wYXJzZShyZXN1bHQuYm9keSk7XHJcbiAgICAgIFxyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LmVycm9yQ29kZSkudG9CZSgnVkFMSURBVElPTl9FUlJPUicpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2VCb2R5LmVycm9yKS50b0NvbnRhaW4oJ2NvbnRhY3RBdHRyaWJ1dGVzIG11c3QgYmUgYW4gb2JqZWN0Jyk7XHJcbiAgICB9KTtcclxuICB9KTtcclxufSk7Il19
"use strict";
/**
 * Manual Property Test Runner for Cache Refresh Consistency
 * **Feature: decision-engine, Property 5: Cache refresh consistency**
 * **Validates: Requirements 2.5, 4.3**
 *
 * This is a standalone test that can be run without Jest to verify the property
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.testCacheRefreshConsistencyProperty = testCacheRefreshConsistencyProperty;
const RuleRepository_1 = require("../../services/decision-engine/RuleRepository");
// Simple assertion function
function assert(condition, message) {
    if (!condition) {
        throw new Error(`Assertion failed: ${message}`);
    }
}
// Mock DynamoDB client
class MockDynamoClient {
    constructor() {
        this.mockResponses = [];
        this.mockErrors = [];
        this.callCount = 0;
    }
    setMockResponses(responses) {
        this.mockResponses = responses;
        this.mockErrors = [];
        this.callCount = 0;
    }
    setMockErrors(errors) {
        this.mockErrors = errors;
        this.mockResponses = [];
        this.callCount = 0;
    }
    async send(command) {
        if (this.mockErrors.length > 0) {
            const error = this.mockErrors[this.callCount % this.mockErrors.length];
            this.callCount++;
            throw error;
        }
        const response = this.mockResponses[this.callCount % this.mockResponses.length];
        this.callCount++;
        return response;
    }
    getCallCount() {
        return this.callCount;
    }
    reset() {
        this.callCount = 0;
    }
}
// Property test implementation
async function testCacheRefreshConsistencyProperty() {
    console.log('Running Property Test: Cache Refresh Consistency');
    const mockClient = new MockDynamoClient();
    const generateRule = (id, weight, segment) => ({
        id,
        name: `Test Rule ${id}`,
        expression: `Criterion${id} == true`,
        weight,
        distributionSegment: segment,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    });
    // Test scenarios representing different cache refresh situations
    const testScenarios = [
        // Scenario 1: Empty cache to populated cache
        {
            name: 'Empty to populated',
            initialRules: [],
            updatedRules: [generateRule('1', 10, 'segment-1')]
        },
        // Scenario 2: Single rule to multiple rules
        {
            name: 'Single to multiple',
            initialRules: [generateRule('1', 10, 'segment-1')],
            updatedRules: [
                generateRule('1', 10, 'segment-1'),
                generateRule('2', 20, 'segment-2'),
                generateRule('3', 15, 'segment-3')
            ]
        },
        // Scenario 3: Rule weight changes
        {
            name: 'Weight changes',
            initialRules: [generateRule('1', 10, 'segment-1'), generateRule('2', 20, 'segment-2')],
            updatedRules: [generateRule('1', 25, 'segment-1'), generateRule('2', 5, 'segment-2')]
        },
        // Scenario 4: Rule removal
        {
            name: 'Rule removal',
            initialRules: [
                generateRule('1', 10, 'segment-1'),
                generateRule('2', 20, 'segment-2'),
                generateRule('3', 15, 'segment-3')
            ],
            updatedRules: [generateRule('2', 20, 'segment-2')]
        },
        // Scenario 5: Complete rule replacement
        {
            name: 'Complete replacement',
            initialRules: [generateRule('old1', 10, 'old-segment')],
            updatedRules: [generateRule('new1', 30, 'new-segment')]
        }
    ];
    let testsPassed = 0;
    let totalTests = 0;
    console.log('\n=== Testing Cache Refresh Consistency ===');
    for (const scenario of testScenarios) {
        console.log(`\nTesting scenario: ${scenario.name}`);
        for (let iteration = 0; iteration < 20; iteration++) { // 20 iterations per scenario
            totalTests++;
            try {
                // Setup mock responses for initial load and refresh
                mockClient.setMockResponses([
                    { Items: scenario.initialRules },
                    { Items: scenario.updatedRules }
                ]);
                // Create repository with mocked client
                const repository = new RuleRepository_1.RuleRepository('test-table');
                repository.dynamoClient = mockClient;
                // Step 1: Load initial rules (populate cache)
                const initialLoadedRules = await repository.loadAllRules();
                // Property 1: Initial load should match initial rules (sorted by weight)
                const expectedInitialRules = [...scenario.initialRules].sort((a, b) => b.weight - a.weight);
                assert(initialLoadedRules.length === expectedInitialRules.length, `Initial load: Expected ${expectedInitialRules.length} rules, got ${initialLoadedRules.length}`);
                for (let i = 0; i < initialLoadedRules.length; i++) {
                    assert(initialLoadedRules[i].id === expectedInitialRules[i].id, `Initial load: Rule at index ${i} has wrong id`);
                    assert(initialLoadedRules[i].weight === expectedInitialRules[i].weight, `Initial load: Rule at index ${i} has wrong weight`);
                }
                // Step 2: Refresh cache (simulating rule updates in database)
                await repository.refreshCache();
                // Step 3: Load rules after refresh
                const refreshedLoadedRules = await repository.loadAllRules();
                // Property 2: Refreshed rules should match updated rules (sorted by weight)
                const expectedUpdatedRules = [...scenario.updatedRules].sort((a, b) => b.weight - a.weight);
                assert(refreshedLoadedRules.length === expectedUpdatedRules.length, `After refresh: Expected ${expectedUpdatedRules.length} rules, got ${refreshedLoadedRules.length}`);
                for (let i = 0; i < refreshedLoadedRules.length; i++) {
                    assert(refreshedLoadedRules[i].id === expectedUpdatedRules[i].id, `After refresh: Rule at index ${i} has wrong id`);
                    assert(refreshedLoadedRules[i].weight === expectedUpdatedRules[i].weight, `After refresh: Rule at index ${i} has wrong weight`);
                }
                // Property 3: Cache should reflect the updated state, not the initial state
                if (scenario.initialRules.length !== scenario.updatedRules.length) {
                    assert(refreshedLoadedRules.length !== initialLoadedRules.length, 'Cache should reflect updated state when rule count changes');
                }
                // Property 4: Database should be called twice (initial load + refresh)
                assert(mockClient.getCallCount() === 2, `Expected 2 database calls, got ${mockClient.getCallCount()}`);
                // Property 5: Rules should maintain proper ordering after refresh
                for (let i = 0; i < refreshedLoadedRules.length - 1; i++) {
                    assert(refreshedLoadedRules[i].weight >= refreshedLoadedRules[i + 1].weight, `Ordering violated after refresh at index ${i}`);
                }
                testsPassed++;
                mockClient.reset();
            }
            catch (error) {
                console.error(`  Test failed for scenario "${scenario.name}", iteration ${iteration}:`, error);
                mockClient.reset();
            }
        }
    }
    console.log('\n=== Testing Cache Invalidation Completeness ===');
    // Test cache invalidation completeness
    for (let iteration = 0; iteration < 25; iteration++) {
        totalTests++;
        try {
            const initialRules = [generateRule('rule1', 10, 'initial-segment')];
            // Setup mock responses
            mockClient.setMockResponses([
                { Items: initialRules },
                { Items: initialRules }
            ]);
            const repository = new RuleRepository_1.RuleRepository('test-table');
            repository.dynamoClient = mockClient;
            // Load rules to populate cache
            await repository.loadAllRules();
            // Verify cache is populated (second call should not hit database)
            await repository.loadAllRules();
            assert(mockClient.getCallCount() === 1, 'Cache should prevent second database call');
            // Refresh cache (should invalidate and reload)
            await repository.refreshCache();
            // Property: After refresh, cache should be populated with fresh data
            const cacheStats = repository.getCacheStats();
            assert(cacheStats.isCached === true, 'Cache should be populated after refresh');
            assert(cacheStats.lastRefresh !== null, 'Last refresh time should be set');
            // Property: Database should have been called twice (initial + refresh)
            assert(mockClient.getCallCount() === 2, 'Database should be called twice after refresh');
            testsPassed++;
            mockClient.reset();
        }
        catch (error) {
            console.error(`  Cache invalidation test failed, iteration ${iteration}:`, error);
            mockClient.reset();
        }
    }
    console.log('\n=== Testing Cache Refresh Error Handling ===');
    // Test error handling during refresh
    const errorTypes = [
        new Error('Network timeout during refresh'),
        new Error('Access denied on refresh'),
        new Error('Table not found during refresh')
    ];
    for (const error of errorTypes) {
        for (let iteration = 0; iteration < 5; iteration++) {
            totalTests++;
            try {
                const initialRules = [generateRule('rule1', 10, 'initial-segment')];
                // Setup successful initial load, then error on refresh
                mockClient.setMockResponses([{ Items: initialRules }]);
                const repository = new RuleRepository_1.RuleRepository('test-table');
                repository.dynamoClient = mockClient;
                // Load initial rules successfully
                const initialLoadedRules = await repository.loadAllRules();
                assert(initialLoadedRules.length === 1, 'Initial load should succeed');
                // Setup error for refresh
                mockClient.setMockErrors([error]);
                // Property: refreshCache() should throw meaningful error when database fails
                let errorThrown = false;
                try {
                    await repository.refreshCache();
                }
                catch (thrownError) {
                    errorThrown = true;
                    const err = thrownError;
                    assert(err.message.includes('Failed to load qualification rules'), `Expected error message to contain 'Failed to load qualification rules', got: ${err.message}`);
                }
                assert(errorThrown, 'Expected error to be thrown during refresh');
                // Property: System should remain stable after refresh error
                const cacheStats = repository.getCacheStats();
                assert(cacheStats.isCached === false, 'Cache should be cleared on error');
                testsPassed++;
                mockClient.reset();
            }
            catch (testError) {
                console.error(`  Error handling test failed for ${error.message}, iteration ${iteration}:`, testError);
                mockClient.reset();
            }
        }
    }
    console.log('\n=== Testing Rule Ordering Preservation ===');
    // Test ordering preservation after refresh
    for (let iteration = 0; iteration < 25; iteration++) {
        totalTests++;
        try {
            const ruleCount = Math.floor(Math.random() * 6) + 2; // 2-7 rules
            const unorderedRules = [];
            for (let i = 0; i < ruleCount; i++) {
                unorderedRules.push(generateRule(`rule-${i}`, Math.floor(Math.random() * 100) + 1, `segment-${i}`));
            }
            // Setup mock to return unordered rules
            mockClient.setMockResponses([{ Items: unorderedRules }]);
            const repository = new RuleRepository_1.RuleRepository('test-table');
            repository.dynamoClient = mockClient;
            // Refresh cache with unordered rules
            await repository.refreshCache();
            // Load rules after refresh
            const orderedRules = await repository.loadAllRules();
            // Property: Rules should be ordered by weight descending
            for (let i = 0; i < orderedRules.length - 1; i++) {
                assert(orderedRules[i].weight >= orderedRules[i + 1].weight, `Ordering violated at index ${i}: ${orderedRules[i].weight} < ${orderedRules[i + 1].weight}`);
            }
            // Property: All original rules should be present
            assert(orderedRules.length === unorderedRules.length, `Rule count mismatch: expected ${unorderedRules.length}, got ${orderedRules.length}`);
            // Property: Rule content should be preserved (only order changed)
            const originalIds = unorderedRules.map(r => r.id).sort();
            const orderedIds = orderedRules.map(r => r.id).sort();
            assert(JSON.stringify(originalIds) === JSON.stringify(orderedIds), 'Rule IDs should be preserved after ordering');
            testsPassed++;
            mockClient.reset();
        }
        catch (error) {
            console.error(`  Ordering preservation test failed, iteration ${iteration}:`, error);
            mockClient.reset();
        }
    }
    console.log(`\n=== Property Test Results ===`);
    console.log(`Tests passed: ${testsPassed}/${totalTests}`);
    console.log(`Success rate: ${((testsPassed / totalTests) * 100).toFixed(2)}%`);
    if (testsPassed === totalTests) {
        console.log('✅ All property tests passed!');
        console.log('\nProperty 5: Cache refresh consistency - VERIFIED');
        console.log('- Cache refresh correctly updates cached rules');
        console.log('- Cache invalidation works properly');
        console.log('- Error handling during refresh is robust');
        console.log('- Rule ordering is preserved after refresh');
        console.log('- System remains stable after refresh operations');
    }
    else {
        console.log('❌ Some property tests failed!');
        throw new Error(`Property test failed: ${totalTests - testsPassed} out of ${totalTests} tests failed`);
    }
}
if (typeof require !== 'undefined' && require.main === module) {
    testCacheRefreshConsistencyProperty()
        .then(() => {
        console.log('\n🎉 Cache refresh property test completed successfully!');
        if (typeof process !== 'undefined')
            process.exit(0);
    })
        .catch((error) => {
        console.error('\n💥 Cache refresh property test failed:', error);
        if (typeof process !== 'undefined')
            process.exit(1);
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFudWFsLWNhY2hlLXJlZnJlc2gtdGVzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy90ZXN0cy9kZWNpc2lvbi1lbmdpbmUvbWFudWFsLWNhY2hlLXJlZnJlc2gtdGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7OztHQU1HOztBQXFYTSxrRkFBbUM7QUFuWDVDLGtGQUErRTtBQUcvRSw0QkFBNEI7QUFDNUIsU0FBUyxNQUFNLENBQUMsU0FBa0IsRUFBRSxPQUFlO0lBQ2pELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMscUJBQXFCLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFDbEQsQ0FBQztBQUNILENBQUM7QUFFRCx1QkFBdUI7QUFDdkIsTUFBTSxnQkFBZ0I7SUFBdEI7UUFDVSxrQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUMxQixlQUFVLEdBQVksRUFBRSxDQUFDO1FBQ3pCLGNBQVMsR0FBRyxDQUFDLENBQUM7SUFpQ3hCLENBQUM7SUEvQkMsZ0JBQWdCLENBQUMsU0FBZ0I7UUFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDckIsQ0FBQztJQUVELGFBQWEsQ0FBQyxNQUFlO1FBQzNCLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQVk7UUFDckIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUMvQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDakIsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDO1FBRUQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDaEYsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxZQUFZO1FBQ1YsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3hCLENBQUM7SUFFRCxLQUFLO1FBQ0gsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDckIsQ0FBQztDQUNGO0FBRUQsK0JBQStCO0FBQy9CLEtBQUssVUFBVSxtQ0FBbUM7SUFDaEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO0lBRWhFLE1BQU0sVUFBVSxHQUFHLElBQUksZ0JBQWdCLEVBQUUsQ0FBQztJQUUxQyxNQUFNLFlBQVksR0FBRyxDQUFDLEVBQVUsRUFBRSxNQUFjLEVBQUUsT0FBZSxFQUFxQixFQUFFLENBQUMsQ0FBQztRQUN4RixFQUFFO1FBQ0YsSUFBSSxFQUFFLGFBQWEsRUFBRSxFQUFFO1FBQ3ZCLFVBQVUsRUFBRSxZQUFZLEVBQUUsVUFBVTtRQUNwQyxNQUFNO1FBQ04sbUJBQW1CLEVBQUUsT0FBTztRQUM1QixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7UUFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO0tBQ3BDLENBQUMsQ0FBQztJQUVILGlFQUFpRTtJQUNqRSxNQUFNLGFBQWEsR0FBRztRQUNwQiw2Q0FBNkM7UUFDN0M7WUFDRSxJQUFJLEVBQUUsb0JBQW9CO1lBQzFCLFlBQVksRUFBRSxFQUFFO1lBQ2hCLFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQ25EO1FBQ0QsNENBQTRDO1FBQzVDO1lBQ0UsSUFBSSxFQUFFLG9CQUFvQjtZQUMxQixZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUNsRCxZQUFZLEVBQUU7Z0JBQ1osWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxDQUFDO2dCQUNsQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUM7Z0JBQ2xDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQzthQUNuQztTQUNGO1FBQ0Qsa0NBQWtDO1FBQ2xDO1lBQ0UsSUFBSSxFQUFFLGdCQUFnQjtZQUN0QixZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUN0RixZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUN0RjtRQUNELDJCQUEyQjtRQUMzQjtZQUNFLElBQUksRUFBRSxjQUFjO1lBQ3BCLFlBQVksRUFBRTtnQkFDWixZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUM7Z0JBQ2xDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQztnQkFDbEMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxDQUFDO2FBQ25DO1lBQ0QsWUFBWSxFQUFFLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7U0FDbkQ7UUFDRCx3Q0FBd0M7UUFDeEM7WUFDRSxJQUFJLEVBQUUsc0JBQXNCO1lBQzVCLFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQ3ZELFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1NBQ3hEO0tBQ0YsQ0FBQztJQUVGLElBQUksV0FBVyxHQUFHLENBQUMsQ0FBQztJQUNwQixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFFbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO0lBRTNELEtBQUssTUFBTSxRQUFRLElBQUksYUFBYSxFQUFFLENBQUM7UUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFcEQsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsNkJBQTZCO1lBQ2xGLFVBQVUsRUFBRSxDQUFDO1lBRWIsSUFBSSxDQUFDO2dCQUNILG9EQUFvRDtnQkFDcEQsVUFBVSxDQUFDLGdCQUFnQixDQUFDO29CQUMxQixFQUFFLEtBQUssRUFBRSxRQUFRLENBQUMsWUFBWSxFQUFFO29CQUNoQyxFQUFFLEtBQUssRUFBRSxRQUFRLENBQUMsWUFBWSxFQUFFO2lCQUNqQyxDQUFDLENBQUM7Z0JBRUgsdUNBQXVDO2dCQUN2QyxNQUFNLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ25ELFVBQWtCLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztnQkFFOUMsOENBQThDO2dCQUM5QyxNQUFNLGtCQUFrQixHQUFHLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUUzRCx5RUFBeUU7Z0JBQ3pFLE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDNUYsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxvQkFBb0IsQ0FBQyxNQUFNLEVBQ3pELDBCQUEwQixvQkFBb0IsQ0FBQyxNQUFNLGVBQWUsa0JBQWtCLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztnQkFFeEcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO29CQUNuRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFDdkQsK0JBQStCLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ3hELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUMvRCwrQkFBK0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2dCQUM5RCxDQUFDO2dCQUVELDhEQUE4RDtnQkFDOUQsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBRWhDLG1DQUFtQztnQkFDbkMsTUFBTSxvQkFBb0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFFN0QsNEVBQTRFO2dCQUM1RSxNQUFNLG9CQUFvQixHQUFHLENBQUMsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzVGLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLEtBQUssb0JBQW9CLENBQUMsTUFBTSxFQUMzRCwyQkFBMkIsb0JBQW9CLENBQUMsTUFBTSxlQUFlLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7Z0JBRTNHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFDckQsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ3pELGdDQUFnQyxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUN6RCxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFDakUsZ0NBQWdDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDL0QsQ0FBQztnQkFFRCw0RUFBNEU7Z0JBQzVFLElBQUksUUFBUSxDQUFDLFlBQVksQ0FBQyxNQUFNLEtBQUssUUFBUSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDbEUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sS0FBSyxrQkFBa0IsQ0FBQyxNQUFNLEVBQ3pELDREQUE0RCxDQUFDLENBQUM7Z0JBQ3ZFLENBQUM7Z0JBRUQsdUVBQXVFO2dCQUN2RSxNQUFNLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsRUFDL0Isa0NBQWtDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBRXRFLGtFQUFrRTtnQkFDbEUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLG9CQUFvQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFDekQsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxvQkFBb0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUNwRSw0Q0FBNEMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDMUQsQ0FBQztnQkFFRCxXQUFXLEVBQUUsQ0FBQztnQkFDZCxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDckIsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsUUFBUSxDQUFDLElBQUksZ0JBQWdCLFNBQVMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUMvRixVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDckIsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtREFBbUQsQ0FBQyxDQUFDO0lBRWpFLHVDQUF1QztJQUN2QyxLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7UUFDcEQsVUFBVSxFQUFFLENBQUM7UUFFYixJQUFJLENBQUM7WUFDSCxNQUFNLFlBQVksR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLGlCQUFpQixDQUFDLENBQUMsQ0FBQztZQUVwRSx1QkFBdUI7WUFDdkIsVUFBVSxDQUFDLGdCQUFnQixDQUFDO2dCQUMxQixFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUU7Z0JBQ3ZCLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRTthQUN4QixDQUFDLENBQUM7WUFFSCxNQUFNLFVBQVUsR0FBRyxJQUFJLCtCQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbkQsVUFBa0IsQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO1lBRTlDLCtCQUErQjtZQUMvQixNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVoQyxrRUFBa0U7WUFDbEUsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDaEMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLEVBQUUsMkNBQTJDLENBQUMsQ0FBQztZQUVyRiwrQ0FBK0M7WUFDL0MsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFFaEMscUVBQXFFO1lBQ3JFLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5QyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsS0FBSyxJQUFJLEVBQUUseUNBQXlDLENBQUMsQ0FBQztZQUNoRixNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsS0FBSyxJQUFJLEVBQUUsaUNBQWlDLENBQUMsQ0FBQztZQUUzRSx1RUFBdUU7WUFDdkUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLEVBQUUsK0NBQStDLENBQUMsQ0FBQztZQUV6RixXQUFXLEVBQUUsQ0FBQztZQUNkLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNyQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0NBQStDLFNBQVMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2xGLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNyQixDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELENBQUMsQ0FBQztJQUU5RCxxQ0FBcUM7SUFDckMsTUFBTSxVQUFVLEdBQUc7UUFDakIsSUFBSSxLQUFLLENBQUMsZ0NBQWdDLENBQUM7UUFDM0MsSUFBSSxLQUFLLENBQUMsMEJBQTBCLENBQUM7UUFDckMsSUFBSSxLQUFLLENBQUMsZ0NBQWdDLENBQUM7S0FDNUMsQ0FBQztJQUVGLEtBQUssTUFBTSxLQUFLLElBQUksVUFBVSxFQUFFLENBQUM7UUFDL0IsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ25ELFVBQVUsRUFBRSxDQUFDO1lBRWIsSUFBSSxDQUFDO2dCQUNILE1BQU0sWUFBWSxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO2dCQUVwRSx1REFBdUQ7Z0JBQ3ZELFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFdkQsTUFBTSxVQUFVLEdBQUcsSUFBSSwrQkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUNuRCxVQUFrQixDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7Z0JBRTlDLGtDQUFrQztnQkFDbEMsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDM0QsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsNkJBQTZCLENBQUMsQ0FBQztnQkFFdkUsMEJBQTBCO2dCQUMxQixVQUFVLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFFbEMsNkVBQTZFO2dCQUM3RSxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7Z0JBQ3hCLElBQUksQ0FBQztvQkFDSCxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDbEMsQ0FBQztnQkFBQyxPQUFPLFdBQVcsRUFBRSxDQUFDO29CQUNyQixXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUNuQixNQUFNLEdBQUcsR0FBRyxXQUFvQixDQUFDO29CQUNqQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsb0NBQW9DLENBQUMsRUFDMUQsZ0ZBQWdGLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUN4RyxDQUFDO2dCQUVELE1BQU0sQ0FBQyxXQUFXLEVBQUUsNENBQTRDLENBQUMsQ0FBQztnQkFFbEUsNERBQTREO2dCQUM1RCxNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQzlDLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxLQUFLLEtBQUssRUFBRSxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUUxRSxXQUFXLEVBQUUsQ0FBQztnQkFDZCxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDckIsQ0FBQztZQUFDLE9BQU8sU0FBUyxFQUFFLENBQUM7Z0JBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0NBQW9DLEtBQUssQ0FBQyxPQUFPLGVBQWUsU0FBUyxHQUFHLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3ZHLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNyQixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLDhDQUE4QyxDQUFDLENBQUM7SUFFNUQsMkNBQTJDO0lBQzNDLEtBQUssSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztRQUNwRCxVQUFVLEVBQUUsQ0FBQztRQUViLElBQUksQ0FBQztZQUNILE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVk7WUFDakUsTUFBTSxjQUFjLEdBQXdCLEVBQUUsQ0FBQztZQUUvQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ25DLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3RHLENBQUM7WUFFRCx1Q0FBdUM7WUFDdkMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRXpELE1BQU0sVUFBVSxHQUFHLElBQUksK0JBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNuRCxVQUFrQixDQUFDLFlBQVksR0FBRyxVQUFVLENBQUM7WUFFOUMscUNBQXFDO1lBQ3JDLE1BQU0sVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRWhDLDJCQUEyQjtZQUMzQixNQUFNLFlBQVksR0FBRyxNQUFNLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVyRCx5REFBeUQ7WUFDekQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ2pELE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUNwRCw4QkFBOEIsQ0FBQyxLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLE1BQU0sWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZHLENBQUM7WUFFRCxpREFBaUQ7WUFDakQsTUFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLEtBQUssY0FBYyxDQUFDLE1BQU0sRUFDN0MsaUNBQWlDLGNBQWMsQ0FBQyxNQUFNLFNBQVMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFFN0Ysa0VBQWtFO1lBQ2xFLE1BQU0sV0FBVyxHQUFHLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDekQsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUN0RCxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxFQUMxRCw2Q0FBNkMsQ0FBQyxDQUFDO1lBRXRELFdBQVcsRUFBRSxDQUFDO1lBQ2QsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3JCLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxrREFBa0QsU0FBUyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDckYsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3JCLENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO0lBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFdBQVcsSUFBSSxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQzFELE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUUvRSxJQUFJLFdBQVcsS0FBSyxVQUFVLEVBQUUsQ0FBQztRQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7UUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO1FBQ2xFLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELENBQUMsQ0FBQztRQUM5RCxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDO1FBQ3pELE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztRQUMxRCxPQUFPLENBQUMsR0FBRyxDQUFDLGtEQUFrRCxDQUFDLENBQUM7SUFDbEUsQ0FBQztTQUFNLENBQUM7UUFDTixPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7UUFDN0MsTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsVUFBVSxHQUFHLFdBQVcsV0FBVyxVQUFVLGVBQWUsQ0FBQyxDQUFDO0lBQ3pHLENBQUM7QUFDSCxDQUFDO0FBT0QsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUUsQ0FBQztJQUM5RCxtQ0FBbUMsRUFBRTtTQUNsQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQywwREFBMEQsQ0FBQyxDQUFDO1FBQ3hFLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVztZQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEQsQ0FBQyxDQUFDO1NBQ0QsS0FBSyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUU7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pFLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVztZQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEQsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIE1hbnVhbCBQcm9wZXJ0eSBUZXN0IFJ1bm5lciBmb3IgQ2FjaGUgUmVmcmVzaCBDb25zaXN0ZW5jeVxyXG4gKiAqKkZlYXR1cmU6IGRlY2lzaW9uLWVuZ2luZSwgUHJvcGVydHkgNTogQ2FjaGUgcmVmcmVzaCBjb25zaXN0ZW5jeSoqXHJcbiAqICoqVmFsaWRhdGVzOiBSZXF1aXJlbWVudHMgMi41LCA0LjMqKlxyXG4gKiBcclxuICogVGhpcyBpcyBhIHN0YW5kYWxvbmUgdGVzdCB0aGF0IGNhbiBiZSBydW4gd2l0aG91dCBKZXN0IHRvIHZlcmlmeSB0aGUgcHJvcGVydHlcclxuICovXHJcblxyXG5pbXBvcnQgeyBSdWxlUmVwb3NpdG9yeSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2RlY2lzaW9uLWVuZ2luZS9SdWxlUmVwb3NpdG9yeSc7XHJcbmltcG9ydCB7IFF1YWxpZmljYXRpb25SdWxlIH0gZnJvbSAnLi4vLi4vdHlwZXMvZGVjaXNpb24tZW5naW5lJztcclxuXHJcbi8vIFNpbXBsZSBhc3NlcnRpb24gZnVuY3Rpb25cclxuZnVuY3Rpb24gYXNzZXJ0KGNvbmRpdGlvbjogYm9vbGVhbiwgbWVzc2FnZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgaWYgKCFjb25kaXRpb24pIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihgQXNzZXJ0aW9uIGZhaWxlZDogJHttZXNzYWdlfWApO1xyXG4gIH1cclxufVxyXG5cclxuLy8gTW9jayBEeW5hbW9EQiBjbGllbnRcclxuY2xhc3MgTW9ja0R5bmFtb0NsaWVudCB7XHJcbiAgcHJpdmF0ZSBtb2NrUmVzcG9uc2VzOiBhbnlbXSA9IFtdO1xyXG4gIHByaXZhdGUgbW9ja0Vycm9yczogRXJyb3JbXSA9IFtdO1xyXG4gIHByaXZhdGUgY2FsbENvdW50ID0gMDtcclxuXHJcbiAgc2V0TW9ja1Jlc3BvbnNlcyhyZXNwb25zZXM6IGFueVtdKTogdm9pZCB7XHJcbiAgICB0aGlzLm1vY2tSZXNwb25zZXMgPSByZXNwb25zZXM7XHJcbiAgICB0aGlzLm1vY2tFcnJvcnMgPSBbXTtcclxuICAgIHRoaXMuY2FsbENvdW50ID0gMDtcclxuICB9XHJcblxyXG4gIHNldE1vY2tFcnJvcnMoZXJyb3JzOiBFcnJvcltdKTogdm9pZCB7XHJcbiAgICB0aGlzLm1vY2tFcnJvcnMgPSBlcnJvcnM7XHJcbiAgICB0aGlzLm1vY2tSZXNwb25zZXMgPSBbXTtcclxuICAgIHRoaXMuY2FsbENvdW50ID0gMDtcclxuICB9XHJcblxyXG4gIGFzeW5jIHNlbmQoY29tbWFuZDogYW55KTogUHJvbWlzZTxhbnk+IHtcclxuICAgIGlmICh0aGlzLm1vY2tFcnJvcnMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb25zdCBlcnJvciA9IHRoaXMubW9ja0Vycm9yc1t0aGlzLmNhbGxDb3VudCAlIHRoaXMubW9ja0Vycm9ycy5sZW5ndGhdO1xyXG4gICAgICB0aGlzLmNhbGxDb3VudCsrO1xyXG4gICAgICB0aHJvdyBlcnJvcjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB0aGlzLm1vY2tSZXNwb25zZXNbdGhpcy5jYWxsQ291bnQgJSB0aGlzLm1vY2tSZXNwb25zZXMubGVuZ3RoXTtcclxuICAgIHRoaXMuY2FsbENvdW50Kys7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBnZXRDYWxsQ291bnQoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmNhbGxDb3VudDtcclxuICB9XHJcblxyXG4gIHJlc2V0KCk6IHZvaWQge1xyXG4gICAgdGhpcy5jYWxsQ291bnQgPSAwO1xyXG4gIH1cclxufVxyXG5cclxuLy8gUHJvcGVydHkgdGVzdCBpbXBsZW1lbnRhdGlvblxyXG5hc3luYyBmdW5jdGlvbiB0ZXN0Q2FjaGVSZWZyZXNoQ29uc2lzdGVuY3lQcm9wZXJ0eSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zb2xlLmxvZygnUnVubmluZyBQcm9wZXJ0eSBUZXN0OiBDYWNoZSBSZWZyZXNoIENvbnNpc3RlbmN5Jyk7XHJcbiAgXHJcbiAgY29uc3QgbW9ja0NsaWVudCA9IG5ldyBNb2NrRHluYW1vQ2xpZW50KCk7XHJcbiAgXHJcbiAgY29uc3QgZ2VuZXJhdGVSdWxlID0gKGlkOiBzdHJpbmcsIHdlaWdodDogbnVtYmVyLCBzZWdtZW50OiBzdHJpbmcpOiBRdWFsaWZpY2F0aW9uUnVsZSA9PiAoe1xyXG4gICAgaWQsXHJcbiAgICBuYW1lOiBgVGVzdCBSdWxlICR7aWR9YCxcclxuICAgIGV4cHJlc3Npb246IGBDcml0ZXJpb24ke2lkfSA9PSB0cnVlYCxcclxuICAgIHdlaWdodCxcclxuICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6IHNlZ21lbnQsXHJcbiAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgfSk7XHJcblxyXG4gIC8vIFRlc3Qgc2NlbmFyaW9zIHJlcHJlc2VudGluZyBkaWZmZXJlbnQgY2FjaGUgcmVmcmVzaCBzaXR1YXRpb25zXHJcbiAgY29uc3QgdGVzdFNjZW5hcmlvcyA9IFtcclxuICAgIC8vIFNjZW5hcmlvIDE6IEVtcHR5IGNhY2hlIHRvIHBvcHVsYXRlZCBjYWNoZVxyXG4gICAge1xyXG4gICAgICBuYW1lOiAnRW1wdHkgdG8gcG9wdWxhdGVkJyxcclxuICAgICAgaW5pdGlhbFJ1bGVzOiBbXSxcclxuICAgICAgdXBkYXRlZFJ1bGVzOiBbZ2VuZXJhdGVSdWxlKCcxJywgMTAsICdzZWdtZW50LTEnKV1cclxuICAgIH0sXHJcbiAgICAvLyBTY2VuYXJpbyAyOiBTaW5nbGUgcnVsZSB0byBtdWx0aXBsZSBydWxlc1xyXG4gICAge1xyXG4gICAgICBuYW1lOiAnU2luZ2xlIHRvIG11bHRpcGxlJyxcclxuICAgICAgaW5pdGlhbFJ1bGVzOiBbZ2VuZXJhdGVSdWxlKCcxJywgMTAsICdzZWdtZW50LTEnKV0sXHJcbiAgICAgIHVwZGF0ZWRSdWxlczogW1xyXG4gICAgICAgIGdlbmVyYXRlUnVsZSgnMScsIDEwLCAnc2VnbWVudC0xJyksXHJcbiAgICAgICAgZ2VuZXJhdGVSdWxlKCcyJywgMjAsICdzZWdtZW50LTInKSxcclxuICAgICAgICBnZW5lcmF0ZVJ1bGUoJzMnLCAxNSwgJ3NlZ21lbnQtMycpXHJcbiAgICAgIF1cclxuICAgIH0sXHJcbiAgICAvLyBTY2VuYXJpbyAzOiBSdWxlIHdlaWdodCBjaGFuZ2VzXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6ICdXZWlnaHQgY2hhbmdlcycsXHJcbiAgICAgIGluaXRpYWxSdWxlczogW2dlbmVyYXRlUnVsZSgnMScsIDEwLCAnc2VnbWVudC0xJyksIGdlbmVyYXRlUnVsZSgnMicsIDIwLCAnc2VnbWVudC0yJyldLFxyXG4gICAgICB1cGRhdGVkUnVsZXM6IFtnZW5lcmF0ZVJ1bGUoJzEnLCAyNSwgJ3NlZ21lbnQtMScpLCBnZW5lcmF0ZVJ1bGUoJzInLCA1LCAnc2VnbWVudC0yJyldXHJcbiAgICB9LFxyXG4gICAgLy8gU2NlbmFyaW8gNDogUnVsZSByZW1vdmFsXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6ICdSdWxlIHJlbW92YWwnLFxyXG4gICAgICBpbml0aWFsUnVsZXM6IFtcclxuICAgICAgICBnZW5lcmF0ZVJ1bGUoJzEnLCAxMCwgJ3NlZ21lbnQtMScpLFxyXG4gICAgICAgIGdlbmVyYXRlUnVsZSgnMicsIDIwLCAnc2VnbWVudC0yJyksXHJcbiAgICAgICAgZ2VuZXJhdGVSdWxlKCczJywgMTUsICdzZWdtZW50LTMnKVxyXG4gICAgICBdLFxyXG4gICAgICB1cGRhdGVkUnVsZXM6IFtnZW5lcmF0ZVJ1bGUoJzInLCAyMCwgJ3NlZ21lbnQtMicpXVxyXG4gICAgfSxcclxuICAgIC8vIFNjZW5hcmlvIDU6IENvbXBsZXRlIHJ1bGUgcmVwbGFjZW1lbnRcclxuICAgIHtcclxuICAgICAgbmFtZTogJ0NvbXBsZXRlIHJlcGxhY2VtZW50JyxcclxuICAgICAgaW5pdGlhbFJ1bGVzOiBbZ2VuZXJhdGVSdWxlKCdvbGQxJywgMTAsICdvbGQtc2VnbWVudCcpXSxcclxuICAgICAgdXBkYXRlZFJ1bGVzOiBbZ2VuZXJhdGVSdWxlKCduZXcxJywgMzAsICduZXctc2VnbWVudCcpXVxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIGxldCB0ZXN0c1Bhc3NlZCA9IDA7XHJcbiAgbGV0IHRvdGFsVGVzdHMgPSAwO1xyXG5cclxuICBjb25zb2xlLmxvZygnXFxuPT09IFRlc3RpbmcgQ2FjaGUgUmVmcmVzaCBDb25zaXN0ZW5jeSA9PT0nKTtcclxuXHJcbiAgZm9yIChjb25zdCBzY2VuYXJpbyBvZiB0ZXN0U2NlbmFyaW9zKSB7XHJcbiAgICBjb25zb2xlLmxvZyhgXFxuVGVzdGluZyBzY2VuYXJpbzogJHtzY2VuYXJpby5uYW1lfWApO1xyXG4gICAgXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAyMDsgaXRlcmF0aW9uKyspIHsgLy8gMjAgaXRlcmF0aW9ucyBwZXIgc2NlbmFyaW9cclxuICAgICAgdG90YWxUZXN0cysrO1xyXG4gICAgICBcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBTZXR1cCBtb2NrIHJlc3BvbnNlcyBmb3IgaW5pdGlhbCBsb2FkIGFuZCByZWZyZXNoXHJcbiAgICAgICAgbW9ja0NsaWVudC5zZXRNb2NrUmVzcG9uc2VzKFtcclxuICAgICAgICAgIHsgSXRlbXM6IHNjZW5hcmlvLmluaXRpYWxSdWxlcyB9LFxyXG4gICAgICAgICAgeyBJdGVtczogc2NlbmFyaW8udXBkYXRlZFJ1bGVzIH1cclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgLy8gQ3JlYXRlIHJlcG9zaXRvcnkgd2l0aCBtb2NrZWQgY2xpZW50XHJcbiAgICAgICAgY29uc3QgcmVwb3NpdG9yeSA9IG5ldyBSdWxlUmVwb3NpdG9yeSgndGVzdC10YWJsZScpO1xyXG4gICAgICAgIChyZXBvc2l0b3J5IGFzIGFueSkuZHluYW1vQ2xpZW50ID0gbW9ja0NsaWVudDtcclxuXHJcbiAgICAgICAgLy8gU3RlcCAxOiBMb2FkIGluaXRpYWwgcnVsZXMgKHBvcHVsYXRlIGNhY2hlKVxyXG4gICAgICAgIGNvbnN0IGluaXRpYWxMb2FkZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAgIC8vIFByb3BlcnR5IDE6IEluaXRpYWwgbG9hZCBzaG91bGQgbWF0Y2ggaW5pdGlhbCBydWxlcyAoc29ydGVkIGJ5IHdlaWdodClcclxuICAgICAgICBjb25zdCBleHBlY3RlZEluaXRpYWxSdWxlcyA9IFsuLi5zY2VuYXJpby5pbml0aWFsUnVsZXNdLnNvcnQoKGEsIGIpID0+IGIud2VpZ2h0IC0gYS53ZWlnaHQpO1xyXG4gICAgICAgIGFzc2VydChpbml0aWFsTG9hZGVkUnVsZXMubGVuZ3RoID09PSBleHBlY3RlZEluaXRpYWxSdWxlcy5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgIGBJbml0aWFsIGxvYWQ6IEV4cGVjdGVkICR7ZXhwZWN0ZWRJbml0aWFsUnVsZXMubGVuZ3RofSBydWxlcywgZ290ICR7aW5pdGlhbExvYWRlZFJ1bGVzLmxlbmd0aH1gKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbml0aWFsTG9hZGVkUnVsZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgIGFzc2VydChpbml0aWFsTG9hZGVkUnVsZXNbaV0uaWQgPT09IGV4cGVjdGVkSW5pdGlhbFJ1bGVzW2ldLmlkLFxyXG4gICAgICAgICAgICAgICAgIGBJbml0aWFsIGxvYWQ6IFJ1bGUgYXQgaW5kZXggJHtpfSBoYXMgd3JvbmcgaWRgKTtcclxuICAgICAgICAgIGFzc2VydChpbml0aWFsTG9hZGVkUnVsZXNbaV0ud2VpZ2h0ID09PSBleHBlY3RlZEluaXRpYWxSdWxlc1tpXS53ZWlnaHQsXHJcbiAgICAgICAgICAgICAgICAgYEluaXRpYWwgbG9hZDogUnVsZSBhdCBpbmRleCAke2l9IGhhcyB3cm9uZyB3ZWlnaHRgKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIFN0ZXAgMjogUmVmcmVzaCBjYWNoZSAoc2ltdWxhdGluZyBydWxlIHVwZGF0ZXMgaW4gZGF0YWJhc2UpXHJcbiAgICAgICAgYXdhaXQgcmVwb3NpdG9yeS5yZWZyZXNoQ2FjaGUoKTtcclxuXHJcbiAgICAgICAgLy8gU3RlcCAzOiBMb2FkIHJ1bGVzIGFmdGVyIHJlZnJlc2hcclxuICAgICAgICBjb25zdCByZWZyZXNoZWRMb2FkZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAgIC8vIFByb3BlcnR5IDI6IFJlZnJlc2hlZCBydWxlcyBzaG91bGQgbWF0Y2ggdXBkYXRlZCBydWxlcyAoc29ydGVkIGJ5IHdlaWdodClcclxuICAgICAgICBjb25zdCBleHBlY3RlZFVwZGF0ZWRSdWxlcyA9IFsuLi5zY2VuYXJpby51cGRhdGVkUnVsZXNdLnNvcnQoKGEsIGIpID0+IGIud2VpZ2h0IC0gYS53ZWlnaHQpO1xyXG4gICAgICAgIGFzc2VydChyZWZyZXNoZWRMb2FkZWRSdWxlcy5sZW5ndGggPT09IGV4cGVjdGVkVXBkYXRlZFJ1bGVzLmxlbmd0aCxcclxuICAgICAgICAgICAgICAgYEFmdGVyIHJlZnJlc2g6IEV4cGVjdGVkICR7ZXhwZWN0ZWRVcGRhdGVkUnVsZXMubGVuZ3RofSBydWxlcywgZ290ICR7cmVmcmVzaGVkTG9hZGVkUnVsZXMubGVuZ3RofWApO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlZnJlc2hlZExvYWRlZFJ1bGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICBhc3NlcnQocmVmcmVzaGVkTG9hZGVkUnVsZXNbaV0uaWQgPT09IGV4cGVjdGVkVXBkYXRlZFJ1bGVzW2ldLmlkLFxyXG4gICAgICAgICAgICAgICAgIGBBZnRlciByZWZyZXNoOiBSdWxlIGF0IGluZGV4ICR7aX0gaGFzIHdyb25nIGlkYCk7XHJcbiAgICAgICAgICBhc3NlcnQocmVmcmVzaGVkTG9hZGVkUnVsZXNbaV0ud2VpZ2h0ID09PSBleHBlY3RlZFVwZGF0ZWRSdWxlc1tpXS53ZWlnaHQsXHJcbiAgICAgICAgICAgICAgICAgYEFmdGVyIHJlZnJlc2g6IFJ1bGUgYXQgaW5kZXggJHtpfSBoYXMgd3Jvbmcgd2VpZ2h0YCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBQcm9wZXJ0eSAzOiBDYWNoZSBzaG91bGQgcmVmbGVjdCB0aGUgdXBkYXRlZCBzdGF0ZSwgbm90IHRoZSBpbml0aWFsIHN0YXRlXHJcbiAgICAgICAgaWYgKHNjZW5hcmlvLmluaXRpYWxSdWxlcy5sZW5ndGggIT09IHNjZW5hcmlvLnVwZGF0ZWRSdWxlcy5sZW5ndGgpIHtcclxuICAgICAgICAgIGFzc2VydChyZWZyZXNoZWRMb2FkZWRSdWxlcy5sZW5ndGggIT09IGluaXRpYWxMb2FkZWRSdWxlcy5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgJ0NhY2hlIHNob3VsZCByZWZsZWN0IHVwZGF0ZWQgc3RhdGUgd2hlbiBydWxlIGNvdW50IGNoYW5nZXMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIFByb3BlcnR5IDQ6IERhdGFiYXNlIHNob3VsZCBiZSBjYWxsZWQgdHdpY2UgKGluaXRpYWwgbG9hZCArIHJlZnJlc2gpXHJcbiAgICAgICAgYXNzZXJ0KG1vY2tDbGllbnQuZ2V0Q2FsbENvdW50KCkgPT09IDIsXHJcbiAgICAgICAgICAgICAgIGBFeHBlY3RlZCAyIGRhdGFiYXNlIGNhbGxzLCBnb3QgJHttb2NrQ2xpZW50LmdldENhbGxDb3VudCgpfWApO1xyXG5cclxuICAgICAgICAvLyBQcm9wZXJ0eSA1OiBSdWxlcyBzaG91bGQgbWFpbnRhaW4gcHJvcGVyIG9yZGVyaW5nIGFmdGVyIHJlZnJlc2hcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlZnJlc2hlZExvYWRlZFJ1bGVzLmxlbmd0aCAtIDE7IGkrKykge1xyXG4gICAgICAgICAgYXNzZXJ0KHJlZnJlc2hlZExvYWRlZFJ1bGVzW2ldLndlaWdodCA+PSByZWZyZXNoZWRMb2FkZWRSdWxlc1tpICsgMV0ud2VpZ2h0LFxyXG4gICAgICAgICAgICAgICAgIGBPcmRlcmluZyB2aW9sYXRlZCBhZnRlciByZWZyZXNoIGF0IGluZGV4ICR7aX1gKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRlc3RzUGFzc2VkKys7XHJcbiAgICAgICAgbW9ja0NsaWVudC5yZXNldCgpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYCAgVGVzdCBmYWlsZWQgZm9yIHNjZW5hcmlvIFwiJHtzY2VuYXJpby5uYW1lfVwiLCBpdGVyYXRpb24gJHtpdGVyYXRpb259OmAsIGVycm9yKTtcclxuICAgICAgICBtb2NrQ2xpZW50LnJlc2V0KCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnNvbGUubG9nKCdcXG49PT0gVGVzdGluZyBDYWNoZSBJbnZhbGlkYXRpb24gQ29tcGxldGVuZXNzID09PScpO1xyXG5cclxuICAvLyBUZXN0IGNhY2hlIGludmFsaWRhdGlvbiBjb21wbGV0ZW5lc3NcclxuICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAyNTsgaXRlcmF0aW9uKyspIHtcclxuICAgIHRvdGFsVGVzdHMrKztcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgaW5pdGlhbFJ1bGVzID0gW2dlbmVyYXRlUnVsZSgncnVsZTEnLCAxMCwgJ2luaXRpYWwtc2VnbWVudCcpXTtcclxuICAgICAgXHJcbiAgICAgIC8vIFNldHVwIG1vY2sgcmVzcG9uc2VzXHJcbiAgICAgIG1vY2tDbGllbnQuc2V0TW9ja1Jlc3BvbnNlcyhbXHJcbiAgICAgICAgeyBJdGVtczogaW5pdGlhbFJ1bGVzIH0sXHJcbiAgICAgICAgeyBJdGVtczogaW5pdGlhbFJ1bGVzIH1cclxuICAgICAgXSk7XHJcblxyXG4gICAgICBjb25zdCByZXBvc2l0b3J5ID0gbmV3IFJ1bGVSZXBvc2l0b3J5KCd0ZXN0LXRhYmxlJyk7XHJcbiAgICAgIChyZXBvc2l0b3J5IGFzIGFueSkuZHluYW1vQ2xpZW50ID0gbW9ja0NsaWVudDtcclxuXHJcbiAgICAgIC8vIExvYWQgcnVsZXMgdG8gcG9wdWxhdGUgY2FjaGVcclxuICAgICAgYXdhaXQgcmVwb3NpdG9yeS5sb2FkQWxsUnVsZXMoKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFZlcmlmeSBjYWNoZSBpcyBwb3B1bGF0ZWQgKHNlY29uZCBjYWxsIHNob3VsZCBub3QgaGl0IGRhdGFiYXNlKVxyXG4gICAgICBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG4gICAgICBhc3NlcnQobW9ja0NsaWVudC5nZXRDYWxsQ291bnQoKSA9PT0gMSwgJ0NhY2hlIHNob3VsZCBwcmV2ZW50IHNlY29uZCBkYXRhYmFzZSBjYWxsJyk7XHJcblxyXG4gICAgICAvLyBSZWZyZXNoIGNhY2hlIChzaG91bGQgaW52YWxpZGF0ZSBhbmQgcmVsb2FkKVxyXG4gICAgICBhd2FpdCByZXBvc2l0b3J5LnJlZnJlc2hDYWNoZSgpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IEFmdGVyIHJlZnJlc2gsIGNhY2hlIHNob3VsZCBiZSBwb3B1bGF0ZWQgd2l0aCBmcmVzaCBkYXRhXHJcbiAgICAgIGNvbnN0IGNhY2hlU3RhdHMgPSByZXBvc2l0b3J5LmdldENhY2hlU3RhdHMoKTtcclxuICAgICAgYXNzZXJ0KGNhY2hlU3RhdHMuaXNDYWNoZWQgPT09IHRydWUsICdDYWNoZSBzaG91bGQgYmUgcG9wdWxhdGVkIGFmdGVyIHJlZnJlc2gnKTtcclxuICAgICAgYXNzZXJ0KGNhY2hlU3RhdHMubGFzdFJlZnJlc2ggIT09IG51bGwsICdMYXN0IHJlZnJlc2ggdGltZSBzaG91bGQgYmUgc2V0Jyk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogRGF0YWJhc2Ugc2hvdWxkIGhhdmUgYmVlbiBjYWxsZWQgdHdpY2UgKGluaXRpYWwgKyByZWZyZXNoKVxyXG4gICAgICBhc3NlcnQobW9ja0NsaWVudC5nZXRDYWxsQ291bnQoKSA9PT0gMiwgJ0RhdGFiYXNlIHNob3VsZCBiZSBjYWxsZWQgdHdpY2UgYWZ0ZXIgcmVmcmVzaCcpO1xyXG5cclxuICAgICAgdGVzdHNQYXNzZWQrKztcclxuICAgICAgbW9ja0NsaWVudC5yZXNldCgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihgICBDYWNoZSBpbnZhbGlkYXRpb24gdGVzdCBmYWlsZWQsIGl0ZXJhdGlvbiAke2l0ZXJhdGlvbn06YCwgZXJyb3IpO1xyXG4gICAgICBtb2NrQ2xpZW50LnJlc2V0KCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zb2xlLmxvZygnXFxuPT09IFRlc3RpbmcgQ2FjaGUgUmVmcmVzaCBFcnJvciBIYW5kbGluZyA9PT0nKTtcclxuXHJcbiAgLy8gVGVzdCBlcnJvciBoYW5kbGluZyBkdXJpbmcgcmVmcmVzaFxyXG4gIGNvbnN0IGVycm9yVHlwZXMgPSBbXHJcbiAgICBuZXcgRXJyb3IoJ05ldHdvcmsgdGltZW91dCBkdXJpbmcgcmVmcmVzaCcpLFxyXG4gICAgbmV3IEVycm9yKCdBY2Nlc3MgZGVuaWVkIG9uIHJlZnJlc2gnKSxcclxuICAgIG5ldyBFcnJvcignVGFibGUgbm90IGZvdW5kIGR1cmluZyByZWZyZXNoJylcclxuICBdO1xyXG5cclxuICBmb3IgKGNvbnN0IGVycm9yIG9mIGVycm9yVHlwZXMpIHtcclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDU7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIHRvdGFsVGVzdHMrKztcclxuICAgICAgXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgaW5pdGlhbFJ1bGVzID0gW2dlbmVyYXRlUnVsZSgncnVsZTEnLCAxMCwgJ2luaXRpYWwtc2VnbWVudCcpXTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBTZXR1cCBzdWNjZXNzZnVsIGluaXRpYWwgbG9hZCwgdGhlbiBlcnJvciBvbiByZWZyZXNoXHJcbiAgICAgICAgbW9ja0NsaWVudC5zZXRNb2NrUmVzcG9uc2VzKFt7IEl0ZW1zOiBpbml0aWFsUnVsZXMgfV0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuICAgICAgICAocmVwb3NpdG9yeSBhcyBhbnkpLmR5bmFtb0NsaWVudCA9IG1vY2tDbGllbnQ7XHJcblxyXG4gICAgICAgIC8vIExvYWQgaW5pdGlhbCBydWxlcyBzdWNjZXNzZnVsbHlcclxuICAgICAgICBjb25zdCBpbml0aWFsTG9hZGVkUnVsZXMgPSBhd2FpdCByZXBvc2l0b3J5LmxvYWRBbGxSdWxlcygpO1xyXG4gICAgICAgIGFzc2VydChpbml0aWFsTG9hZGVkUnVsZXMubGVuZ3RoID09PSAxLCAnSW5pdGlhbCBsb2FkIHNob3VsZCBzdWNjZWVkJyk7XHJcblxyXG4gICAgICAgIC8vIFNldHVwIGVycm9yIGZvciByZWZyZXNoXHJcbiAgICAgICAgbW9ja0NsaWVudC5zZXRNb2NrRXJyb3JzKFtlcnJvcl0pO1xyXG5cclxuICAgICAgICAvLyBQcm9wZXJ0eTogcmVmcmVzaENhY2hlKCkgc2hvdWxkIHRocm93IG1lYW5pbmdmdWwgZXJyb3Igd2hlbiBkYXRhYmFzZSBmYWlsc1xyXG4gICAgICAgIGxldCBlcnJvclRocm93biA9IGZhbHNlO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCByZXBvc2l0b3J5LnJlZnJlc2hDYWNoZSgpO1xyXG4gICAgICAgIH0gY2F0Y2ggKHRocm93bkVycm9yKSB7XHJcbiAgICAgICAgICBlcnJvclRocm93biA9IHRydWU7XHJcbiAgICAgICAgICBjb25zdCBlcnIgPSB0aHJvd25FcnJvciBhcyBFcnJvcjtcclxuICAgICAgICAgIGFzc2VydChlcnIubWVzc2FnZS5pbmNsdWRlcygnRmFpbGVkIHRvIGxvYWQgcXVhbGlmaWNhdGlvbiBydWxlcycpLFxyXG4gICAgICAgICAgICAgICAgIGBFeHBlY3RlZCBlcnJvciBtZXNzYWdlIHRvIGNvbnRhaW4gJ0ZhaWxlZCB0byBsb2FkIHF1YWxpZmljYXRpb24gcnVsZXMnLCBnb3Q6ICR7ZXJyLm1lc3NhZ2V9YCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBhc3NlcnQoZXJyb3JUaHJvd24sICdFeHBlY3RlZCBlcnJvciB0byBiZSB0aHJvd24gZHVyaW5nIHJlZnJlc2gnKTtcclxuXHJcbiAgICAgICAgLy8gUHJvcGVydHk6IFN5c3RlbSBzaG91bGQgcmVtYWluIHN0YWJsZSBhZnRlciByZWZyZXNoIGVycm9yXHJcbiAgICAgICAgY29uc3QgY2FjaGVTdGF0cyA9IHJlcG9zaXRvcnkuZ2V0Q2FjaGVTdGF0cygpO1xyXG4gICAgICAgIGFzc2VydChjYWNoZVN0YXRzLmlzQ2FjaGVkID09PSBmYWxzZSwgJ0NhY2hlIHNob3VsZCBiZSBjbGVhcmVkIG9uIGVycm9yJyk7XHJcblxyXG4gICAgICAgIHRlc3RzUGFzc2VkKys7XHJcbiAgICAgICAgbW9ja0NsaWVudC5yZXNldCgpO1xyXG4gICAgICB9IGNhdGNoICh0ZXN0RXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGAgIEVycm9yIGhhbmRsaW5nIHRlc3QgZmFpbGVkIGZvciAke2Vycm9yLm1lc3NhZ2V9LCBpdGVyYXRpb24gJHtpdGVyYXRpb259OmAsIHRlc3RFcnJvcik7XHJcbiAgICAgICAgbW9ja0NsaWVudC5yZXNldCgpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zb2xlLmxvZygnXFxuPT09IFRlc3RpbmcgUnVsZSBPcmRlcmluZyBQcmVzZXJ2YXRpb24gPT09Jyk7XHJcblxyXG4gIC8vIFRlc3Qgb3JkZXJpbmcgcHJlc2VydmF0aW9uIGFmdGVyIHJlZnJlc2hcclxuICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAyNTsgaXRlcmF0aW9uKyspIHtcclxuICAgIHRvdGFsVGVzdHMrKztcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcnVsZUNvdW50ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNikgKyAyOyAvLyAyLTcgcnVsZXNcclxuICAgICAgY29uc3QgdW5vcmRlcmVkUnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXTtcclxuICAgICAgXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcnVsZUNvdW50OyBpKyspIHtcclxuICAgICAgICB1bm9yZGVyZWRSdWxlcy5wdXNoKGdlbmVyYXRlUnVsZShgcnVsZS0ke2l9YCwgTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwKSArIDEsIGBzZWdtZW50LSR7aX1gKSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFNldHVwIG1vY2sgdG8gcmV0dXJuIHVub3JkZXJlZCBydWxlc1xyXG4gICAgICBtb2NrQ2xpZW50LnNldE1vY2tSZXNwb25zZXMoW3sgSXRlbXM6IHVub3JkZXJlZFJ1bGVzIH1dKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcG9zaXRvcnkgPSBuZXcgUnVsZVJlcG9zaXRvcnkoJ3Rlc3QtdGFibGUnKTtcclxuICAgICAgKHJlcG9zaXRvcnkgYXMgYW55KS5keW5hbW9DbGllbnQgPSBtb2NrQ2xpZW50O1xyXG5cclxuICAgICAgLy8gUmVmcmVzaCBjYWNoZSB3aXRoIHVub3JkZXJlZCBydWxlc1xyXG4gICAgICBhd2FpdCByZXBvc2l0b3J5LnJlZnJlc2hDYWNoZSgpO1xyXG5cclxuICAgICAgLy8gTG9hZCBydWxlcyBhZnRlciByZWZyZXNoXHJcbiAgICAgIGNvbnN0IG9yZGVyZWRSdWxlcyA9IGF3YWl0IHJlcG9zaXRvcnkubG9hZEFsbFJ1bGVzKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eTogUnVsZXMgc2hvdWxkIGJlIG9yZGVyZWQgYnkgd2VpZ2h0IGRlc2NlbmRpbmdcclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvcmRlcmVkUnVsZXMubGVuZ3RoIC0gMTsgaSsrKSB7XHJcbiAgICAgICAgYXNzZXJ0KG9yZGVyZWRSdWxlc1tpXS53ZWlnaHQgPj0gb3JkZXJlZFJ1bGVzW2kgKyAxXS53ZWlnaHQsXHJcbiAgICAgICAgICAgICAgIGBPcmRlcmluZyB2aW9sYXRlZCBhdCBpbmRleCAke2l9OiAke29yZGVyZWRSdWxlc1tpXS53ZWlnaHR9IDwgJHtvcmRlcmVkUnVsZXNbaSArIDFdLndlaWdodH1gKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gUHJvcGVydHk6IEFsbCBvcmlnaW5hbCBydWxlcyBzaG91bGQgYmUgcHJlc2VudFxyXG4gICAgICBhc3NlcnQob3JkZXJlZFJ1bGVzLmxlbmd0aCA9PT0gdW5vcmRlcmVkUnVsZXMubGVuZ3RoLFxyXG4gICAgICAgICAgICAgYFJ1bGUgY291bnQgbWlzbWF0Y2g6IGV4cGVjdGVkICR7dW5vcmRlcmVkUnVsZXMubGVuZ3RofSwgZ290ICR7b3JkZXJlZFJ1bGVzLmxlbmd0aH1gKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5OiBSdWxlIGNvbnRlbnQgc2hvdWxkIGJlIHByZXNlcnZlZCAob25seSBvcmRlciBjaGFuZ2VkKVxyXG4gICAgICBjb25zdCBvcmlnaW5hbElkcyA9IHVub3JkZXJlZFJ1bGVzLm1hcChyID0+IHIuaWQpLnNvcnQoKTtcclxuICAgICAgY29uc3Qgb3JkZXJlZElkcyA9IG9yZGVyZWRSdWxlcy5tYXAociA9PiByLmlkKS5zb3J0KCk7XHJcbiAgICAgIGFzc2VydChKU09OLnN0cmluZ2lmeShvcmlnaW5hbElkcykgPT09IEpTT04uc3RyaW5naWZ5KG9yZGVyZWRJZHMpLFxyXG4gICAgICAgICAgICAgJ1J1bGUgSURzIHNob3VsZCBiZSBwcmVzZXJ2ZWQgYWZ0ZXIgb3JkZXJpbmcnKTtcclxuXHJcbiAgICAgIHRlc3RzUGFzc2VkKys7XHJcbiAgICAgIG1vY2tDbGllbnQucmVzZXQoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoYCAgT3JkZXJpbmcgcHJlc2VydmF0aW9uIHRlc3QgZmFpbGVkLCBpdGVyYXRpb24gJHtpdGVyYXRpb259OmAsIGVycm9yKTtcclxuICAgICAgbW9ja0NsaWVudC5yZXNldCgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc29sZS5sb2coYFxcbj09PSBQcm9wZXJ0eSBUZXN0IFJlc3VsdHMgPT09YCk7XHJcbiAgY29uc29sZS5sb2coYFRlc3RzIHBhc3NlZDogJHt0ZXN0c1Bhc3NlZH0vJHt0b3RhbFRlc3RzfWApO1xyXG4gIGNvbnNvbGUubG9nKGBTdWNjZXNzIHJhdGU6ICR7KCh0ZXN0c1Bhc3NlZCAvIHRvdGFsVGVzdHMpICogMTAwKS50b0ZpeGVkKDIpfSVgKTtcclxuICBcclxuICBpZiAodGVzdHNQYXNzZWQgPT09IHRvdGFsVGVzdHMpIHtcclxuICAgIGNvbnNvbGUubG9nKCfinIUgQWxsIHByb3BlcnR5IHRlc3RzIHBhc3NlZCEnKTtcclxuICAgIGNvbnNvbGUubG9nKCdcXG5Qcm9wZXJ0eSA1OiBDYWNoZSByZWZyZXNoIGNvbnNpc3RlbmN5IC0gVkVSSUZJRUQnKTtcclxuICAgIGNvbnNvbGUubG9nKCctIENhY2hlIHJlZnJlc2ggY29ycmVjdGx5IHVwZGF0ZXMgY2FjaGVkIHJ1bGVzJyk7XHJcbiAgICBjb25zb2xlLmxvZygnLSBDYWNoZSBpbnZhbGlkYXRpb24gd29ya3MgcHJvcGVybHknKTtcclxuICAgIGNvbnNvbGUubG9nKCctIEVycm9yIGhhbmRsaW5nIGR1cmluZyByZWZyZXNoIGlzIHJvYnVzdCcpO1xyXG4gICAgY29uc29sZS5sb2coJy0gUnVsZSBvcmRlcmluZyBpcyBwcmVzZXJ2ZWQgYWZ0ZXIgcmVmcmVzaCcpO1xyXG4gICAgY29uc29sZS5sb2coJy0gU3lzdGVtIHJlbWFpbnMgc3RhYmxlIGFmdGVyIHJlZnJlc2ggb3BlcmF0aW9ucycpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjb25zb2xlLmxvZygn4p2MIFNvbWUgcHJvcGVydHkgdGVzdHMgZmFpbGVkIScpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKGBQcm9wZXJ0eSB0ZXN0IGZhaWxlZDogJHt0b3RhbFRlc3RzIC0gdGVzdHNQYXNzZWR9IG91dCBvZiAke3RvdGFsVGVzdHN9IHRlc3RzIGZhaWxlZGApO1xyXG4gIH1cclxufVxyXG5cclxuLy8gUnVuIHRoZSB0ZXN0IGlmIHRoaXMgZmlsZSBpcyBleGVjdXRlZCBkaXJlY3RseVxyXG5kZWNsYXJlIGNvbnN0IHJlcXVpcmU6IGFueTtcclxuZGVjbGFyZSBjb25zdCBtb2R1bGU6IGFueTtcclxuZGVjbGFyZSBjb25zdCBwcm9jZXNzOiBhbnk7XHJcblxyXG5pZiAodHlwZW9mIHJlcXVpcmUgIT09ICd1bmRlZmluZWQnICYmIHJlcXVpcmUubWFpbiA9PT0gbW9kdWxlKSB7XHJcbiAgdGVzdENhY2hlUmVmcmVzaENvbnNpc3RlbmN5UHJvcGVydHkoKVxyXG4gICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygnXFxu8J+OiSBDYWNoZSByZWZyZXNoIHByb3BlcnR5IHRlc3QgY29tcGxldGVkIHN1Y2Nlc3NmdWxseSEnKTtcclxuICAgICAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJykgcHJvY2Vzcy5leGl0KDApO1xyXG4gICAgfSlcclxuICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgY29uc29sZS5lcnJvcignXFxu8J+SpSBDYWNoZSByZWZyZXNoIHByb3BlcnR5IHRlc3QgZmFpbGVkOicsIGVycm9yKTtcclxuICAgICAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJykgcHJvY2Vzcy5leGl0KDEpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCB7IHRlc3RDYWNoZVJlZnJlc2hDb25zaXN0ZW5jeVByb3BlcnR5IH07Il19
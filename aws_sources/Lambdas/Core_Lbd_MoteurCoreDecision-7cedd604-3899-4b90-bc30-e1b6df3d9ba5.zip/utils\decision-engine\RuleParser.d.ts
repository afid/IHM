export declare enum TokenType {
    IDENTIFIER = "IDENTIFIER",
    EQUALS = "EQUALS",
    NOT_EQUALS = "NOT_EQUALS",
    AND = "AND",
    OR = "OR",
    LEFT_PAREN = "LEFT_PAREN",
    RIGHT_PAREN = "RIGHT_PAREN",
    STRING_LITERAL = "STRING_LITERAL",
    BOOLEAN_LITERAL = "BOOLEAN_LITERAL",
    NUMBER_LITERAL = "NUMBER_LITERAL",
    EOF = "EOF"
}
export interface Token {
    type: TokenType;
    value: string;
    position: number;
}
export interface ASTNode {
    type: string;
}
export interface BinaryExpression extends ASTNode {
    type: 'BinaryExpression';
    operator: '==' | '!=' | '&&' | '||';
    left: ASTNode;
    right: ASTNode;
}
export interface ComparisonExpression extends ASTNode {
    type: 'ComparisonExpression';
    operator: '==' | '!=';
    left: Identifier;
    right: Literal;
}
export interface Identifier extends ASTNode {
    type: 'Identifier';
    name: string;
}
export interface Literal extends ASTNode {
    type: 'Literal';
    value: string | number | boolean;
    raw: string;
}
export declare class RuleParser {
    static validateRuleSyntax(expression: string): {
        isValid: boolean;
        error?: string;
    };
    static parseRuleExpression(expression: string): {
        isValid: boolean;
        ast?: ASTNode;
        tokens?: Token[];
        error?: string;
    };
    static evaluateExpression(ast: ASTNode, contactAttributes: Record<string, any>): boolean;
    private static evaluateBinaryExpression;
    private static evaluateComparisonExpression;
    private static compareValues;
    private static tokenize;
}

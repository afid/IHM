import { OptimizedRuleRepositoryV2 } from './OptimizedRuleRepositoryV2';
import { QualificationRule } from '../../types/decision-engine';
export declare class HybridRuleRepositoryV3 extends OptimizedRuleRepositoryV2 {
    /**
     * Méthode principale optimisée avec stratégie hybride
     */
    loadHybridOptimizedRules(contactAttributes: Record<string, any>): Promise<QualificationRule[]>;
    /**
     * Classifie les critères en primaires (GSI) et secondaires (Filter)
     */
    private classifyCriteria;
    /**
     * Détermine la stratégie hybride optimale
     */
    private determineHybridStrategy;
    /**
     * Sélectionne le meilleur critère primaire selon la priorité GSI
     */
    private selectBestPrimaryCriteria;
    /**
     * Construit l'expression de filtre pour les critères secondaires
     */
    private buildSecondaryFilterExpression;
    /**
     * Construit les valeurs d'attributs pour la requête
     */
    private buildAttributeValues;
    /**
     * Exécute la requête hybride
     */
    private executeHybridQuery;
    /**
     * Scan avec filtres secondaires uniquement
     */
    private scanWithSecondaryFilters;
    /**
     * Calcule la réduction estimée avec stratégie hybride
     */
    private calculateHybridReduction;
    /**
     * Calcule la réduction avec filtres uniquement
     */
    private calculateFilterOnlyReduction;
    /**
     * Obtient la sélectivité d'un GSI
     */
    private getGSISelectivity;
    /**
     * Génère une clé de cache hybride
     */
    private generateHybridCacheKey;
    /**
     * Statistiques de performance hybride
     */
    analyzeHybridPerformance(contactAttributes: Record<string, any>): Promise<{
        strategy: string;
        primaryReduction: number;
        secondaryReduction: number;
        totalReduction: number;
        rulesLoaded: number;
        estimatedDuration: string;
    }>;
}

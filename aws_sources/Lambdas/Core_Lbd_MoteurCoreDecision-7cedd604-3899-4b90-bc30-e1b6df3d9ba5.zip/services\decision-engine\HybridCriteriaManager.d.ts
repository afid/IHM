/**
 * Gestionnaire des critères hybrides pour l'architecture GSI + FilterExpression
 *
 * Ce gestionnaire permet de :
 * 1. Configurer facilement les critères primaires (GSI) - EN DUR dans le code
 * 2. Gérer les critères secondaires (FilterExpression) - DYNAMIQUES via Parameter Store
 * 3. Gérer la priorité et l'activation des critères
 *
 * ARCHITECTURE :
 * - Critères PRIMAIRES : restent en dur (nécessitent un redéploiement pour modification)
 * - Critères SECONDAIRES : stockés dans Parameter Store (modification sans redéploiement)
 */
export interface CriteriaConfig {
    name: string;
    type: 'primary' | 'secondary';
    enabled: boolean;
    priority?: number;
    selectivity?: 'high' | 'medium' | 'low';
    description?: string;
    businessJustification?: string;
    addedDate?: string;
}
export interface CriteriaStats {
    totalCriteria: number;
    primaryCount: number;
    secondaryCount: number;
    enabledPrimary: number;
    enabledSecondary: number;
    gsiCost: string;
    estimatedPerformance: string;
    cacheMetrics?: any;
}
export declare class HybridCriteriaManager {
    private static readonly PRIMARY_CRITERIA;
    private static readonly SECONDARY_CRITERIA_FALLBACK;
    /**
     * Initialise le gestionnaire (DEPRECATED - lazy loading préféré)
     *
     * ⚠️ Cette méthode n'est plus nécessaire avec le lazy loading.
     * Le cache Parameter Store sera chargé automatiquement au premier appel.
     *
     * Avantages du lazy loading :
     * - Pas de délai au cold start si aucun critère secondaire actif
     * - Cache réutilisé entre invocations Lambda warm
     * - Chargement uniquement quand nécessaire
     */
    static initialize(): Promise<void>;
    /**
     * Retourne tous les critères primaires actifs (pour GSI)
     * SYNCHRONE - Les critères primaires sont en dur
     */
    static getActivePrimaryCriteria(): string[];
    /**
     * Retourne tous les critères secondaires actifs (pour FilterExpression)
     * ASYNCHRONE - Les critères secondaires sont chargés depuis Parameter Store
     *
     * FALLBACK : Si Parameter Store retourne vide, utilise les critères en dur
     */
    static getActiveSecondaryCriteria(): Promise<string[]>;
    /**
     * Retourne TOUS les critères actifs (primaires + secondaires)
     * ASYNCHRONE - Combine les critères primaires (en dur) et secondaires (Parameter Store)
     */
    static getAllActiveCriteria(): Promise<string[]>;
    /**
     * Vérifie si un critère est primaire (GSI)
     * SYNCHRONE - Les critères primaires sont en dur
     */
    static isPrimaryCriteria(criteriaName: string): boolean;
    /**
     * Vérifie si un critère est secondaire (FilterExpression)
     * ASYNCHRONE - Les critères secondaires sont dans Parameter Store
     */
    static isSecondaryCriteria(criteriaName: string): Promise<boolean>;
    /**
     * Active/désactive un critère SECONDAIRE
     * ASYNCHRONE - Modifie le critère dans Parameter Store
     *
     * Note : Les critères primaires ne peuvent pas être modifiés dynamiquement
     */
    static toggleSecondaryCriteria(criteriaName: string, enabled: boolean): Promise<boolean>;
    /**
     * Ajoute un nouveau critère secondaire
     * ASYNCHRONE - Ajoute le critère dans Parameter Store
     */
    static addSecondaryCriteria(name: string, description: string, businessJustification: string): Promise<boolean>;
    /**
     * Supprime un critère secondaire
     * ASYNCHRONE - Supprime le critère de Parameter Store
     */
    static deleteSecondaryCriteria(criteriaName: string): Promise<boolean>;
    /**
     * Retourne les statistiques des critères
     * ASYNCHRONE - Inclut les critères secondaires depuis Parameter Store
     *
     * FALLBACK : Si Parameter Store retourne vide, utilise les critères en dur
     */
    static getCriteriaStats(): Promise<CriteriaStats>;
    /**
     * Retourne la configuration complète (primaires + secondaires)
     * ASYNCHRONE - Inclut les critères secondaires depuis Parameter Store
     *
     * FALLBACK : Si Parameter Store retourne vide, utilise les critères en dur
     */
    static getFullConfiguration(): Promise<CriteriaConfig[]>;
    /**
     * Valide qu'un ensemble d'attributs contient des critères connus
     * ASYNCHRONE - Vérifie contre les critères primaires et secondaires
     */
    static validateContactAttributes(contactAttributes: Record<string, any>): Promise<{
        knownCriteria: string[];
        unknownCriteria: string[];
        primaryCriteriaFound: string[];
        secondaryCriteriaFound: string[];
    }>;
    /**
     * Configure le TTL du cache Parameter Store
     */
    static setCacheTTL(ttl: number): void;
    /**
     * Invalide le cache Parameter Store (force un refresh)
     */
    static invalidateCache(): void;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DecisionEngine_1 = require("../../services/decision-engine/DecisionEngine");
/**
 * **Feature: decision-engine, Property 8: Error handling resilience**
 * **Validates: Requirements 3.3, 3.5**
 *
 * Property: For any error condition (database failures, malformed rules), the system
 * should handle errors gracefully and provide meaningful error messages
 */
// Mock DynamoDB for property testing
const mockSend = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => ({
    DynamoDBClient: jest.fn().mockImplementation(() => ({}))
}));
jest.mock('@aws-sdk/lib-dynamodb', () => ({
    DynamoDBDocumentClient: {
        from: jest.fn().mockReturnValue({ send: mockSend })
    },
    ScanCommand: jest.fn().mockImplementation((params) => params)
}));
// Mock console methods to capture log output
const mockConsoleLog = jest.spyOn(console, 'log').mockImplementation();
const mockConsoleError = jest.spyOn(console, 'error').mockImplementation();
describe('Property Test: Error Handling Resilience', () => {
    beforeEach(() => {
        // Reset mocks before each test
        jest.clearAllMocks();
        mockSend.mockReset();
        mockConsoleLog.mockClear();
        mockConsoleError.mockClear();
    });
    afterAll(() => {
        // Restore console methods
        mockConsoleLog.mockRestore();
        mockConsoleError.mockRestore();
    });
    /**
     * Property: Database failure resilience
     * For any database failure scenario, the system should handle errors gracefully
     * and provide meaningful error messages (Requirement 3.3)
     */
    test('should handle database failures gracefully with meaningful error messages', async () => {
        // Generate various database error scenarios (100 iterations)
        const databaseErrors = [
            new Error('Connection timeout'),
            new Error('Access denied'),
            new Error('Table not found'),
            new Error('Network error'),
            new Error('ResourceNotFoundException'),
            new Error('ThrottlingException'),
            new Error('ValidationException'),
            new Error('ServiceUnavailableException'),
            new Error('InternalServerError'),
            new Error('Database connection failed')
        ];
        for (let iteration = 0; iteration < 100; iteration++) {
            const errorIndex = iteration % databaseErrors.length;
            const databaseError = databaseErrors[errorIndex];
            // Generate random valid request
            const request = {
                interactionId: `db-error-test-${iteration}-${Date.now()}`,
                contactAttributes: {
                    NouveauSinistre: Math.random() > 0.5,
                    Client: ['VIP', 'Standard', 'Premium'][Math.floor(Math.random() * 3)],
                    Score: Math.floor(Math.random() * 100) + 1
                }
            };
            // Setup mock to throw database error
            mockSend.mockRejectedValueOnce(databaseError);
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 1: Response should indicate failure gracefully
            expect(response.success).toBe(false);
            expect(response.error).toBeDefined();
            expect(response.errorCode).toBeDefined();
            expect(response.requestId).toBe(request.interactionId);
            expect(response.timestamp).toBeDefined();
            // Property 2: Error message should be meaningful and user-friendly
            expect(response.error).toContain('base de données');
            expect(response.errorCode).toBe('DATABASE_ERROR');
            // Cast to ErrorResponse to access details
            const errorResponse = response;
            expect(errorResponse.details).toBeDefined();
            expect(errorResponse.details.category).toBe('DATABASE');
            expect(errorResponse.details.retryable).toBe(true);
            // Property 3: Error should be logged with detailed information
            const errorCalls = mockConsoleError.mock.calls;
            const errorEntries = errorCalls.map(call => {
                try {
                    return JSON.parse(call[0]);
                }
                catch (_a) {
                    return null;
                }
            }).filter(entry => entry !== null);
            const databaseErrorLog = errorEntries.find(entry => entry.level === 'ERROR' &&
                entry.requestId === request.interactionId &&
                entry.errorCode === 'DATABASE_ERROR');
            expect(databaseErrorLog).toBeDefined();
            expect(databaseErrorLog.message).toContain('Database operation');
            expect(databaseErrorLog.message).toContain('loadAllRules');
            expect(databaseErrorLog.errorDetails).toBeDefined();
            expect(databaseErrorLog.errorDetails.operation).toBe('loadAllRules');
            expect(databaseErrorLog.errorDetails.errorName).toBe(databaseError.name);
            expect(databaseErrorLog.errorDetails.errorMessage).toBe(databaseError.message);
            // Property 4: System should not crash or throw unhandled exceptions
            expect(response).toBeDefined();
            expect(typeof response).toBe('object');
            // Reset mocks for next iteration
            mockConsoleError.mockClear();
            mockSend.mockClear();
        }
    });
    /**
     * Property: Malformed rule expression resilience
     * For any malformed rule expression, the system should log the error and
     * continue processing other rules (Requirement 3.5)
     */
    test('should handle malformed rule expressions gracefully and continue processing', async () => {
        // Generate test cases with malformed rules mixed with valid rules (100 iterations)
        for (let iteration = 0; iteration < 100; iteration++) {
            const request = {
                interactionId: `malformed-rule-test-${iteration}-${Date.now()}`,
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'VIP',
                    Score: 85
                }
            };
            // Generate rules with some malformed expressions
            const malformedExpressions = [
                'NouveauSinistre ==', // Incomplete expression
                'Client = "VIP"', // Wrong operator
                'Score > ', // Missing value
                'InvalidField == true', // Non-existent field
                '&& Client == "VIP"', // Missing left operand
                'NouveauSinistre == true &&', // Missing right operand
                'Score > "invalid"', // Type mismatch
                '((NouveauSinistre == true)', // Unbalanced parentheses
                'Client == "VIP" OR Score > 80', // Unsupported operator
                'eval("malicious code")', // Potentially dangerous expression
            ];
            const rules = [];
            // Add some valid rules
            rules.push({
                id: `valid-rule-${iteration}-1`,
                name: 'Valid Rule 1',
                expression: 'NouveauSinistre == true',
                weight: 30,
                distributionSegment: 'valid-segment-1',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            });
            // Add malformed rule
            const malformedIndex = iteration % malformedExpressions.length;
            rules.push({
                id: `malformed-rule-${iteration}`,
                name: 'Malformed Rule',
                expression: malformedExpressions[malformedIndex],
                weight: 20,
                distributionSegment: 'malformed-segment',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            });
            // Add another valid rule
            rules.push({
                id: `valid-rule-${iteration}-2`,
                name: 'Valid Rule 2',
                expression: 'Client == "VIP"',
                weight: 10,
                distributionSegment: 'valid-segment-2',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            });
            // Setup mock to return rules with malformed expressions
            mockSend.mockResolvedValueOnce({
                Items: rules
            });
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 1: System should continue processing despite malformed rules
            // The decision should either succeed (if valid rules match) or fail gracefully
            expect(response).toBeDefined();
            expect(typeof response.success).toBe('boolean');
            expect(response.requestId).toBe(request.interactionId);
            // Property 2: If processing succeeds, it should select from valid rules only
            if (response.success) {
                expect(response.selectedRuleId).toBeDefined();
                expect(response.selectedRuleId).not.toBe(`malformed-rule-${iteration}`);
                expect(response.distributionSegment).toBeDefined();
                expect(['valid-segment-1', 'valid-segment-2']).toContain(response.distributionSegment);
            }
            // Property 3: Malformed rule errors should be logged
            const errorCalls = mockConsoleError.mock.calls;
            const logCalls = mockConsoleLog.mock.calls;
            const allLogEntries = [...errorCalls, ...logCalls].map(call => {
                try {
                    return JSON.parse(call[0]);
                }
                catch (_a) {
                    return null;
                }
            }).filter(entry => entry !== null);
            // Look for rule processing error logs
            const ruleErrorLogs = allLogEntries.filter(entry => {
                var _a, _b;
                return entry.requestId === request.interactionId &&
                    (entry.errorCode === 'RULE_PROCESSING_ERROR' ||
                        ((_a = entry.message) === null || _a === void 0 ? void 0 : _a.includes('Rule processing failed')) ||
                        ((_b = entry.message) === null || _b === void 0 ? void 0 : _b.includes('malformed')));
            });
            // Property 4: Error should be logged with detailed information about the malformed rule
            if (ruleErrorLogs.length > 0) {
                const ruleErrorLog = ruleErrorLogs[0];
                expect(ruleErrorLog.message).toContain('Rule processing failed');
                expect(ruleErrorLog.errorDetails).toBeDefined();
                expect(ruleErrorLog.errorDetails.ruleId).toBe(`malformed-rule-${iteration}`);
                expect(ruleErrorLog.errorDetails.expression).toBe(malformedExpressions[malformedIndex]);
            }
            // Property 5: System should not crash due to malformed expressions
            expect(response.timestamp).toBeDefined();
            expect(response.requestId).toBe(request.interactionId);
            // Reset mocks for next iteration
            mockConsoleError.mockClear();
            mockConsoleLog.mockClear();
            mockSend.mockClear();
        }
    });
    /**
     * Property: Infrastructure error resilience
     * For any infrastructure failure (timeouts, network issues), the system should
     * handle errors gracefully and provide appropriate error responses
     */
    test('should handle infrastructure errors gracefully', async () => {
        // Generate various infrastructure error scenarios (50 iterations)
        const infrastructureErrors = [
            new Error('Request timeout'),
            new Error('Network connection failed'),
            new Error('Service unavailable'),
            new Error('Lambda timeout'),
            new Error('Memory limit exceeded'),
            new Error('Connection reset by peer'),
            new Error('DNS resolution failed'),
            new Error('SSL handshake failed')
        ];
        for (let iteration = 0; iteration < 50; iteration++) {
            const errorIndex = iteration % infrastructureErrors.length;
            const infrastructureError = infrastructureErrors[errorIndex];
            const request = {
                interactionId: `infra-error-test-${iteration}-${Date.now()}`,
                contactAttributes: {
                    NouveauSinistre: true,
                    Client: 'Standard'
                }
            };
            // Setup mock to throw infrastructure error
            mockSend.mockRejectedValueOnce(infrastructureError);
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(request);
            // Property 1: Response should indicate failure gracefully
            expect(response.success).toBe(false);
            expect(response.error).toBeDefined();
            expect(response.errorCode).toBeDefined();
            expect(response.requestId).toBe(request.interactionId);
            // Property 2: Error should be categorized appropriately
            const errorResponse = response;
            expect(errorResponse.details).toBeDefined();
            expect(['DATABASE', 'INFRASTRUCTURE']).toContain(errorResponse.details.category);
            expect(errorResponse.details.retryable).toBe(true);
            // Property 3: Error message should be user-friendly
            expect(response.error).toMatch(/erreur|réessayer|temporaire/i);
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
    /**
     * Property: Input validation error resilience
     * For any invalid input, the system should reject gracefully with meaningful messages
     */
    test('should handle input validation errors gracefully', async () => {
        // Generate various invalid input scenarios (50 iterations)
        const invalidInputs = [
            // Missing interactionId
            { contactAttributes: { NouveauSinistre: true } },
            // Invalid interactionId type
            { interactionId: 123, contactAttributes: { NouveauSinistre: true } },
            // Missing contactAttributes
            { interactionId: 'test-id' },
            // Invalid contactAttributes type
            { interactionId: 'test-id', contactAttributes: 'invalid' },
            // Empty contactAttributes
            { interactionId: 'test-id', contactAttributes: {} },
            // Invalid attribute value types
            { interactionId: 'test-id', contactAttributes: { NouveauSinistre: { invalid: 'object' } } },
            // Null values
            { interactionId: 'test-id', contactAttributes: { NouveauSinistre: null } },
            // Array values
            { interactionId: 'test-id', contactAttributes: { NouveauSinistre: [true, false] } },
            // Function values
            { interactionId: 'test-id', contactAttributes: { NouveauSinistre: () => true } },
            // Extremely long strings
            { interactionId: 'test-id', contactAttributes: { LongString: 'x'.repeat(2000) } }
        ];
        for (let iteration = 0; iteration < 50; iteration++) {
            const inputIndex = iteration % invalidInputs.length;
            const invalidInput = invalidInputs[inputIndex];
            // Execute decision process with invalid input
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(invalidInput);
            // Property 1: Response should indicate validation failure
            expect(response.success).toBe(false);
            expect(response.error).toBeDefined();
            expect(response.errorCode).toBe('VALIDATION_ERROR');
            // Property 2: Error message should be meaningful and in French
            expect(response.error).toContain('Format de contact attributes invalide');
            // Property 3: Response should have proper structure
            expect(response.timestamp).toBeDefined();
            expect(response.requestId).toBeDefined();
            // Property 4: System should not crash on invalid input
            expect(response).toBeDefined();
            expect(typeof response).toBe('object');
        }
    });
    /**
     * Property: Error response consistency
     * For any error condition, the error response should have a consistent structure
     * with all required fields
     */
    test('should provide consistent error response structure for all error types', async () => {
        // Test various error scenarios to ensure consistent response structure (25 iterations)
        const errorScenarios = [
            {
                name: 'database_error',
                setup: () => mockSend.mockRejectedValueOnce(new Error('Database failed')),
                request: { interactionId: 'db-test', contactAttributes: { NouveauSinistre: true } }
            },
            {
                name: 'validation_error',
                setup: () => { },
                request: { interactionId: 'val-test', contactAttributes: 'invalid' }
            },
            {
                name: 'empty_rules',
                setup: () => mockSend.mockResolvedValueOnce({ Items: [] }),
                request: { interactionId: 'empty-test', contactAttributes: { NouveauSinistre: true } }
            }
        ];
        for (let iteration = 0; iteration < 25; iteration++) {
            const scenarioIndex = iteration % errorScenarios.length;
            const scenario = errorScenarios[scenarioIndex];
            // Setup scenario
            scenario.setup();
            // Execute decision process
            const decisionEngine = new DecisionEngine_1.DecisionEngine();
            const response = await decisionEngine.processDecision(scenario.request);
            // Property 1: All error responses should have consistent structure
            expect(response).toHaveProperty('success', false);
            expect(response).toHaveProperty('error');
            expect(response).toHaveProperty('errorCode');
            expect(response).toHaveProperty('timestamp');
            expect(response).toHaveProperty('requestId');
            expect(response).toHaveProperty('details');
            // Property 2: Error message should be a non-empty string
            expect(typeof response.error).toBe('string');
            expect(response.error.length).toBeGreaterThan(0);
            // Property 3: Error code should be a valid code
            expect(typeof response.errorCode).toBe('string');
            expect(['VALIDATION_ERROR', 'DATABASE_ERROR', 'EMPTY_RULE_SET', 'INFRASTRUCTURE_ERROR', 'RULE_PROCESSING_ERROR', 'NO_MATCHING_RULES', 'EQUAL_WEIGHTS', 'MISSING_DISTRIBUTION_SEGMENT']).toContain(response.errorCode);
            // Property 4: Timestamp should be valid ISO string
            expect(() => new Date(response.timestamp)).not.toThrow();
            // Property 5: Details should contain category and retryable flag
            const errorResponse = response;
            expect(errorResponse.details).toHaveProperty('category');
            expect(errorResponse.details).toHaveProperty('retryable');
            expect(typeof errorResponse.details.retryable).toBe('boolean');
            // Reset mocks for next iteration
            mockSend.mockClear();
        }
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3ItaGFuZGxpbmcucHJvcGVydHkudGVzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy90ZXN0cy9kZWNpc2lvbi1lbmdpbmUvZXJyb3ItaGFuZGxpbmcucHJvcGVydHkudGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGtGQUErRTtBQU0vRTs7Ozs7O0dBTUc7QUFFSCxxQ0FBcUM7QUFDckMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUMzQyxjQUFjLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Q0FDekQsQ0FBQyxDQUFDLENBQUM7QUFDSixJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDeEMsc0JBQXNCLEVBQUU7UUFDdEIsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxlQUFlLENBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUM7S0FDcEQ7SUFDRCxXQUFXLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUM7Q0FDOUQsQ0FBQyxDQUFDLENBQUM7QUFFSiw2Q0FBNkM7QUFDN0MsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztBQUN2RSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLGtCQUFrQixFQUFFLENBQUM7QUFFM0UsUUFBUSxDQUFDLDBDQUEwQyxFQUFFLEdBQUcsRUFBRTtJQUN4RCxVQUFVLENBQUMsR0FBRyxFQUFFO1FBQ2QsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDckIsY0FBYyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQzNCLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQy9CLENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUNaLDBCQUEwQjtRQUMxQixjQUFjLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDN0IsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDakMsQ0FBQyxDQUFDLENBQUM7SUFFSDs7OztPQUlHO0lBQ0gsSUFBSSxDQUFDLDJFQUEyRSxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQzNGLDZEQUE2RDtRQUM3RCxNQUFNLGNBQWMsR0FBRztZQUNyQixJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztZQUMvQixJQUFJLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDMUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDNUIsSUFBSSxLQUFLLENBQUMsZUFBZSxDQUFDO1lBQzFCLElBQUksS0FBSyxDQUFDLDJCQUEyQixDQUFDO1lBQ3RDLElBQUksS0FBSyxDQUFDLHFCQUFxQixDQUFDO1lBQ2hDLElBQUksS0FBSyxDQUFDLHFCQUFxQixDQUFDO1lBQ2hDLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDO1lBQ3hDLElBQUksS0FBSyxDQUFDLHFCQUFxQixDQUFDO1lBQ2hDLElBQUksS0FBSyxDQUFDLDRCQUE0QixDQUFDO1NBQ3hDLENBQUM7UUFFRixLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDckQsTUFBTSxVQUFVLEdBQUcsU0FBUyxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUM7WUFDckQsTUFBTSxhQUFhLEdBQUcsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRWpELGdDQUFnQztZQUNoQyxNQUFNLE9BQU8sR0FBeUI7Z0JBQ3BDLGFBQWEsRUFBRSxpQkFBaUIsU0FBUyxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDekQsaUJBQWlCLEVBQUU7b0JBQ2pCLGVBQWUsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRztvQkFDcEMsTUFBTSxFQUFFLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDckUsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUM7aUJBQzNDO2FBQ0YsQ0FBQztZQUVGLHFDQUFxQztZQUNyQyxRQUFRLENBQUMscUJBQXFCLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFOUMsMkJBQTJCO1lBQzNCLE1BQU0sY0FBYyxHQUFHLElBQUksK0JBQWMsRUFBRSxDQUFDO1lBQzVDLE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUUvRCwwREFBMEQ7WUFDMUQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDckMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN2RCxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBRXpDLG1FQUFtRTtZQUNuRSxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ3BELE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFbEQsMENBQTBDO1lBQzFDLE1BQU0sYUFBYSxHQUFHLFFBQXlCLENBQUM7WUFDaEQsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDeEQsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRW5ELCtEQUErRDtZQUMvRCxNQUFNLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQy9DLE1BQU0sWUFBWSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3pDLElBQUksQ0FBQztvQkFDSCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLENBQUM7Z0JBQUMsV0FBTSxDQUFDO29CQUNQLE9BQU8sSUFBSSxDQUFDO2dCQUNkLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLENBQUM7WUFFbkMsTUFBTSxnQkFBZ0IsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQ2pELEtBQUssQ0FBQyxLQUFLLEtBQUssT0FBTztnQkFDdkIsS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLENBQUMsYUFBYTtnQkFDekMsS0FBSyxDQUFDLFNBQVMsS0FBSyxnQkFBZ0IsQ0FDckMsQ0FBQztZQUVGLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNqRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzNELE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNwRCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNyRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDekUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRS9FLG9FQUFvRTtZQUNwRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDL0IsTUFBTSxDQUFDLE9BQU8sUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRXZDLGlDQUFpQztZQUNqQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUM3QixRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQyw2RUFBNkUsRUFBRSxLQUFLLElBQUksRUFBRTtRQUM3RixtRkFBbUY7UUFDbkYsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUcsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3JELE1BQU0sT0FBTyxHQUF5QjtnQkFDcEMsYUFBYSxFQUFFLHVCQUF1QixTQUFTLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUMvRCxpQkFBaUIsRUFBRTtvQkFDakIsZUFBZSxFQUFFLElBQUk7b0JBQ3JCLE1BQU0sRUFBRSxLQUFLO29CQUNiLEtBQUssRUFBRSxFQUFFO2lCQUNWO2FBQ0YsQ0FBQztZQUVGLGlEQUFpRDtZQUNqRCxNQUFNLG9CQUFvQixHQUFHO2dCQUMzQixvQkFBb0IsRUFBRSx3QkFBd0I7Z0JBQzlDLGdCQUFnQixFQUFFLGlCQUFpQjtnQkFDbkMsVUFBVSxFQUFFLGdCQUFnQjtnQkFDNUIsc0JBQXNCLEVBQUUscUJBQXFCO2dCQUM3QyxvQkFBb0IsRUFBRSx1QkFBdUI7Z0JBQzdDLDRCQUE0QixFQUFFLHdCQUF3QjtnQkFDdEQsbUJBQW1CLEVBQUUsZ0JBQWdCO2dCQUNyQyw0QkFBNEIsRUFBRSx5QkFBeUI7Z0JBQ3ZELCtCQUErQixFQUFFLHVCQUF1QjtnQkFDeEQsd0JBQXdCLEVBQUUsbUNBQW1DO2FBQzlELENBQUM7WUFFRixNQUFNLEtBQUssR0FBd0IsRUFBRSxDQUFDO1lBRXRDLHVCQUF1QjtZQUN2QixLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNULEVBQUUsRUFBRSxjQUFjLFNBQVMsSUFBSTtnQkFDL0IsSUFBSSxFQUFFLGNBQWM7Z0JBQ3BCLFVBQVUsRUFBRSx5QkFBeUI7Z0JBQ3JDLE1BQU0sRUFBRSxFQUFFO2dCQUNWLG1CQUFtQixFQUFFLGlCQUFpQjtnQkFDdEMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2dCQUNuQyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDcEMsQ0FBQyxDQUFDO1lBRUgscUJBQXFCO1lBQ3JCLE1BQU0sY0FBYyxHQUFHLFNBQVMsR0FBRyxvQkFBb0IsQ0FBQyxNQUFNLENBQUM7WUFDL0QsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDVCxFQUFFLEVBQUUsa0JBQWtCLFNBQVMsRUFBRTtnQkFDakMsSUFBSSxFQUFFLGdCQUFnQjtnQkFDdEIsVUFBVSxFQUFFLG9CQUFvQixDQUFDLGNBQWMsQ0FBQztnQkFDaEQsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsbUJBQW1CLEVBQUUsbUJBQW1CO2dCQUN4QyxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7Z0JBQ25DLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQyxDQUFDLENBQUM7WUFFSCx5QkFBeUI7WUFDekIsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDVCxFQUFFLEVBQUUsY0FBYyxTQUFTLElBQUk7Z0JBQy9CLElBQUksRUFBRSxjQUFjO2dCQUNwQixVQUFVLEVBQUUsaUJBQWlCO2dCQUM3QixNQUFNLEVBQUUsRUFBRTtnQkFDVixtQkFBbUIsRUFBRSxpQkFBaUI7Z0JBQ3RDLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtnQkFDbkMsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2FBQ3BDLENBQUMsQ0FBQztZQUVILHdEQUF3RDtZQUN4RCxRQUFRLENBQUMscUJBQXFCLENBQUM7Z0JBQzdCLEtBQUssRUFBRSxLQUFLO2FBQ2IsQ0FBQyxDQUFDO1lBRUgsMkJBQTJCO1lBQzNCLE1BQU0sY0FBYyxHQUFHLElBQUksK0JBQWMsRUFBRSxDQUFDO1lBQzVDLE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUUvRCx3RUFBd0U7WUFDeEUsK0VBQStFO1lBQy9FLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMvQixNQUFNLENBQUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2hELE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUV2RCw2RUFBNkU7WUFDN0UsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3JCLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzlDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsU0FBUyxFQUFFLENBQUMsQ0FBQztnQkFDeEUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuRCxNQUFNLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3pGLENBQUM7WUFFRCxxREFBcUQ7WUFDckQsTUFBTSxVQUFVLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUMvQyxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUUzQyxNQUFNLGFBQWEsR0FBRyxDQUFDLEdBQUcsVUFBVSxFQUFFLEdBQUcsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM1RCxJQUFJLENBQUM7b0JBQ0gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM3QixDQUFDO2dCQUFDLFdBQU0sQ0FBQztvQkFDUCxPQUFPLElBQUksQ0FBQztnQkFDZCxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDO1lBRW5DLHNDQUFzQztZQUN0QyxNQUFNLGFBQWEsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFOztnQkFDakQsT0FBQSxLQUFLLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FBQyxhQUFhO29CQUN6QyxDQUFDLEtBQUssQ0FBQyxTQUFTLEtBQUssdUJBQXVCO3lCQUMzQyxNQUFBLEtBQUssQ0FBQyxPQUFPLDBDQUFFLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO3lCQUNqRCxNQUFBLEtBQUssQ0FBQyxPQUFPLDBDQUFFLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQSxDQUFDLENBQUE7YUFBQSxDQUN2QyxDQUFDO1lBRUYsd0ZBQXdGO1lBQ3hGLElBQUksYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDN0IsTUFBTSxZQUFZLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0QyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2dCQUNqRSxNQUFNLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNoRCxNQUFNLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLFNBQVMsRUFBRSxDQUFDLENBQUM7Z0JBQzdFLE1BQU0sQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1lBQzFGLENBQUM7WUFFRCxtRUFBbUU7WUFDbkUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN6QyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFdkQsaUNBQWlDO1lBQ2pDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzdCLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUMzQixRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUg7Ozs7T0FJRztJQUNILElBQUksQ0FBQyxnREFBZ0QsRUFBRSxLQUFLLElBQUksRUFBRTtRQUNoRSxrRUFBa0U7UUFDbEUsTUFBTSxvQkFBb0IsR0FBRztZQUMzQixJQUFJLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztZQUM1QixJQUFJLEtBQUssQ0FBQywyQkFBMkIsQ0FBQztZQUN0QyxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztZQUNoQyxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztZQUMzQixJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQztZQUNsQyxJQUFJLEtBQUssQ0FBQywwQkFBMEIsQ0FBQztZQUNyQyxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQztZQUNsQyxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztTQUNsQyxDQUFDO1FBRUYsS0FBSyxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3BELE1BQU0sVUFBVSxHQUFHLFNBQVMsR0FBRyxvQkFBb0IsQ0FBQyxNQUFNLENBQUM7WUFDM0QsTUFBTSxtQkFBbUIsR0FBRyxvQkFBb0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUU3RCxNQUFNLE9BQU8sR0FBeUI7Z0JBQ3BDLGFBQWEsRUFBRSxvQkFBb0IsU0FBUyxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDNUQsaUJBQWlCLEVBQUU7b0JBQ2pCLGVBQWUsRUFBRSxJQUFJO29CQUNyQixNQUFNLEVBQUUsVUFBVTtpQkFDbkI7YUFDRixDQUFDO1lBRUYsMkNBQTJDO1lBQzNDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBRXBELDJCQUEyQjtZQUMzQixNQUFNLGNBQWMsR0FBRyxJQUFJLCtCQUFjLEVBQUUsQ0FBQztZQUM1QyxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFL0QsMERBQTBEO1lBQzFELE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN6QyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFdkQsd0RBQXdEO1lBQ3hELE1BQU0sYUFBYSxHQUFHLFFBQXlCLENBQUM7WUFDaEQsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2pGLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVuRCxvREFBb0Q7WUFDcEQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztZQUVoRSxpQ0FBaUM7WUFDakMsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVIOzs7T0FHRztJQUNILElBQUksQ0FBQyxrREFBa0QsRUFBRSxLQUFLLElBQUksRUFBRTtRQUNsRSwyREFBMkQ7UUFDM0QsTUFBTSxhQUFhLEdBQUc7WUFDcEIsd0JBQXdCO1lBQ3hCLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDaEQsNkJBQTZCO1lBQzdCLEVBQUUsYUFBYSxFQUFFLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNwRSw0QkFBNEI7WUFDNUIsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFO1lBQzVCLGlDQUFpQztZQUNqQyxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsU0FBUyxFQUFFO1lBQzFELDBCQUEwQjtZQUMxQixFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxFQUFFO1lBQ25ELGdDQUFnQztZQUNoQyxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxlQUFlLEVBQUUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRTtZQUMzRixjQUFjO1lBQ2QsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFFLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxFQUFFO1lBQzFFLGVBQWU7WUFDZixFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxlQUFlLEVBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRTtZQUNuRixrQkFBa0I7WUFDbEIsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFFLEVBQUUsZUFBZSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFO1lBQ2hGLHlCQUF5QjtZQUN6QixFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxVQUFVLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFO1NBQ2xGLENBQUM7UUFFRixLQUFLLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDcEQsTUFBTSxVQUFVLEdBQUcsU0FBUyxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUM7WUFDcEQsTUFBTSxZQUFZLEdBQUcsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRS9DLDhDQUE4QztZQUM5QyxNQUFNLGNBQWMsR0FBRyxJQUFJLCtCQUFjLEVBQUUsQ0FBQztZQUM1QyxNQUFNLFFBQVEsR0FBRyxNQUFNLGNBQWMsQ0FBQyxlQUFlLENBQUMsWUFBbUIsQ0FBQyxDQUFDO1lBRTNFLDBEQUEwRDtZQUMxRCxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3JDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFFcEQsK0RBQStEO1lBQy9ELE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7WUFFMUUsb0RBQW9EO1lBQ3BELE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDekMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUV6Qyx1REFBdUQ7WUFDdkQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQy9CLE1BQU0sQ0FBQyxPQUFPLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6QyxDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSDs7OztPQUlHO0lBQ0gsSUFBSSxDQUFDLHdFQUF3RSxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQ3hGLHVGQUF1RjtRQUN2RixNQUFNLGNBQWMsR0FBRztZQUNyQjtnQkFDRSxJQUFJLEVBQUUsZ0JBQWdCO2dCQUN0QixLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLElBQUksS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7Z0JBQ3pFLE9BQU8sRUFBRSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLEVBQUU7YUFDcEY7WUFDRDtnQkFDRSxJQUFJLEVBQUUsa0JBQWtCO2dCQUN4QixLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUUsQ0FBQztnQkFDZixPQUFPLEVBQUUsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRTthQUNyRTtZQUNEO2dCQUNFLElBQUksRUFBRSxhQUFhO2dCQUNuQixLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxDQUFDO2dCQUMxRCxPQUFPLEVBQUUsRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxFQUFFO2FBQ3ZGO1NBQ0YsQ0FBQztRQUVGLEtBQUssSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxNQUFNLGFBQWEsR0FBRyxTQUFTLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQztZQUN4RCxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFL0MsaUJBQWlCO1lBQ2pCLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUVqQiwyQkFBMkI7WUFDM0IsTUFBTSxjQUFjLEdBQUcsSUFBSSwrQkFBYyxFQUFFLENBQUM7WUFDNUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxPQUFjLENBQUMsQ0FBQztZQUUvRSxtRUFBbUU7WUFDbkUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDbEQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN6QyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDN0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM3QyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTNDLHlEQUF5RDtZQUN6RCxNQUFNLENBQUMsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVsRCxnREFBZ0Q7WUFDaEQsTUFBTSxDQUFDLE9BQU8sUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNqRCxNQUFNLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSxzQkFBc0IsRUFBRSx1QkFBdUIsRUFBRSxtQkFBbUIsRUFBRSxlQUFlLEVBQUUsOEJBQThCLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFdE4sbURBQW1EO1lBQ25ELE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7WUFFMUQsaUVBQWlFO1lBQ2pFLE1BQU0sYUFBYSxHQUFHLFFBQXlCLENBQUM7WUFDaEQsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDekQsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDMUQsTUFBTSxDQUFDLE9BQU8sYUFBYSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFL0QsaUNBQWlDO1lBQ2pDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERlY2lzaW9uRW5naW5lIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL0RlY2lzaW9uRW5naW5lJztcclxuaW1wb3J0IHsgUnVsZVJlcG9zaXRvcnkgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kZWNpc2lvbi1lbmdpbmUvUnVsZVJlcG9zaXRvcnknO1xyXG5pbXBvcnQgeyBSdWxlRXZhbHVhdG9yIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvZGVjaXNpb24tZW5naW5lL1J1bGVFdmFsdWF0b3InO1xyXG5pbXBvcnQgeyBRdWFsaWZpY2F0aW9uUmVxdWVzdCwgUXVhbGlmaWNhdGlvblJ1bGUsIENvbnRhY3RBdHRyaWJ1dGVzLCBEZWNpc2lvblJlc3BvbnNlLCBFcnJvclJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vdHlwZXMvZGVjaXNpb24tZW5naW5lJztcclxuaW1wb3J0IHsgRXJyb3JIYW5kbGluZ0ZyYW1ld29yayB9IGZyb20gJy4uLy4uL3V0aWxzL2RlY2lzaW9uLWVuZ2luZS9WYWxpZGF0aW9uVXRpbHMnO1xyXG5cclxuLyoqXHJcbiAqICoqRmVhdHVyZTogZGVjaXNpb24tZW5naW5lLCBQcm9wZXJ0eSA4OiBFcnJvciBoYW5kbGluZyByZXNpbGllbmNlKipcclxuICogKipWYWxpZGF0ZXM6IFJlcXVpcmVtZW50cyAzLjMsIDMuNSoqXHJcbiAqIFxyXG4gKiBQcm9wZXJ0eTogRm9yIGFueSBlcnJvciBjb25kaXRpb24gKGRhdGFiYXNlIGZhaWx1cmVzLCBtYWxmb3JtZWQgcnVsZXMpLCB0aGUgc3lzdGVtIFxyXG4gKiBzaG91bGQgaGFuZGxlIGVycm9ycyBncmFjZWZ1bGx5IGFuZCBwcm92aWRlIG1lYW5pbmdmdWwgZXJyb3IgbWVzc2FnZXNcclxuICovXHJcblxyXG4vLyBNb2NrIER5bmFtb0RCIGZvciBwcm9wZXJ0eSB0ZXN0aW5nXHJcbmNvbnN0IG1vY2tTZW5kID0gamVzdC5mbigpO1xyXG5qZXN0Lm1vY2soJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYicsICgpID0+ICh7XHJcbiAgRHluYW1vREJDbGllbnQ6IGplc3QuZm4oKS5tb2NrSW1wbGVtZW50YXRpb24oKCkgPT4gKHt9KSlcclxufSkpO1xyXG5qZXN0Lm1vY2soJ0Bhd3Mtc2RrL2xpYi1keW5hbW9kYicsICgpID0+ICh7XHJcbiAgRHluYW1vREJEb2N1bWVudENsaWVudDoge1xyXG4gICAgZnJvbTogamVzdC5mbigpLm1vY2tSZXR1cm5WYWx1ZSh7IHNlbmQ6IG1vY2tTZW5kIH0pXHJcbiAgfSxcclxuICBTY2FuQ29tbWFuZDogamVzdC5mbigpLm1vY2tJbXBsZW1lbnRhdGlvbigocGFyYW1zKSA9PiBwYXJhbXMpXHJcbn0pKTtcclxuXHJcbi8vIE1vY2sgY29uc29sZSBtZXRob2RzIHRvIGNhcHR1cmUgbG9nIG91dHB1dFxyXG5jb25zdCBtb2NrQ29uc29sZUxvZyA9IGplc3Quc3B5T24oY29uc29sZSwgJ2xvZycpLm1vY2tJbXBsZW1lbnRhdGlvbigpO1xyXG5jb25zdCBtb2NrQ29uc29sZUVycm9yID0gamVzdC5zcHlPbihjb25zb2xlLCAnZXJyb3InKS5tb2NrSW1wbGVtZW50YXRpb24oKTtcclxuXHJcbmRlc2NyaWJlKCdQcm9wZXJ0eSBUZXN0OiBFcnJvciBIYW5kbGluZyBSZXNpbGllbmNlJywgKCkgPT4ge1xyXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xyXG4gICAgLy8gUmVzZXQgbW9ja3MgYmVmb3JlIGVhY2ggdGVzdFxyXG4gICAgamVzdC5jbGVhckFsbE1vY2tzKCk7XHJcbiAgICBtb2NrU2VuZC5tb2NrUmVzZXQoKTtcclxuICAgIG1vY2tDb25zb2xlTG9nLm1vY2tDbGVhcigpO1xyXG4gICAgbW9ja0NvbnNvbGVFcnJvci5tb2NrQ2xlYXIoKTtcclxuICB9KTtcclxuXHJcbiAgYWZ0ZXJBbGwoKCkgPT4ge1xyXG4gICAgLy8gUmVzdG9yZSBjb25zb2xlIG1ldGhvZHNcclxuICAgIG1vY2tDb25zb2xlTG9nLm1vY2tSZXN0b3JlKCk7XHJcbiAgICBtb2NrQ29uc29sZUVycm9yLm1vY2tSZXN0b3JlKCk7XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBEYXRhYmFzZSBmYWlsdXJlIHJlc2lsaWVuY2VcclxuICAgKiBGb3IgYW55IGRhdGFiYXNlIGZhaWx1cmUgc2NlbmFyaW8sIHRoZSBzeXN0ZW0gc2hvdWxkIGhhbmRsZSBlcnJvcnMgZ3JhY2VmdWxseSBcclxuICAgKiBhbmQgcHJvdmlkZSBtZWFuaW5nZnVsIGVycm9yIG1lc3NhZ2VzIChSZXF1aXJlbWVudCAzLjMpXHJcbiAgICovXHJcbiAgdGVzdCgnc2hvdWxkIGhhbmRsZSBkYXRhYmFzZSBmYWlsdXJlcyBncmFjZWZ1bGx5IHdpdGggbWVhbmluZ2Z1bCBlcnJvciBtZXNzYWdlcycsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIEdlbmVyYXRlIHZhcmlvdXMgZGF0YWJhc2UgZXJyb3Igc2NlbmFyaW9zICgxMDAgaXRlcmF0aW9ucylcclxuICAgIGNvbnN0IGRhdGFiYXNlRXJyb3JzID0gW1xyXG4gICAgICBuZXcgRXJyb3IoJ0Nvbm5lY3Rpb24gdGltZW91dCcpLFxyXG4gICAgICBuZXcgRXJyb3IoJ0FjY2VzcyBkZW5pZWQnKSxcclxuICAgICAgbmV3IEVycm9yKCdUYWJsZSBub3QgZm91bmQnKSxcclxuICAgICAgbmV3IEVycm9yKCdOZXR3b3JrIGVycm9yJyksXHJcbiAgICAgIG5ldyBFcnJvcignUmVzb3VyY2VOb3RGb3VuZEV4Y2VwdGlvbicpLFxyXG4gICAgICBuZXcgRXJyb3IoJ1Rocm90dGxpbmdFeGNlcHRpb24nKSxcclxuICAgICAgbmV3IEVycm9yKCdWYWxpZGF0aW9uRXhjZXB0aW9uJyksXHJcbiAgICAgIG5ldyBFcnJvcignU2VydmljZVVuYXZhaWxhYmxlRXhjZXB0aW9uJyksXHJcbiAgICAgIG5ldyBFcnJvcignSW50ZXJuYWxTZXJ2ZXJFcnJvcicpLFxyXG4gICAgICBuZXcgRXJyb3IoJ0RhdGFiYXNlIGNvbm5lY3Rpb24gZmFpbGVkJylcclxuICAgIF07XHJcblxyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgMTAwOyBpdGVyYXRpb24rKykge1xyXG4gICAgICBjb25zdCBlcnJvckluZGV4ID0gaXRlcmF0aW9uICUgZGF0YWJhc2VFcnJvcnMubGVuZ3RoO1xyXG4gICAgICBjb25zdCBkYXRhYmFzZUVycm9yID0gZGF0YWJhc2VFcnJvcnNbZXJyb3JJbmRleF07XHJcbiAgICAgIFxyXG4gICAgICAvLyBHZW5lcmF0ZSByYW5kb20gdmFsaWQgcmVxdWVzdFxyXG4gICAgICBjb25zdCByZXF1ZXN0OiBRdWFsaWZpY2F0aW9uUmVxdWVzdCA9IHtcclxuICAgICAgICBpbnRlcmFjdGlvbklkOiBgZGItZXJyb3ItdGVzdC0ke2l0ZXJhdGlvbn0tJHtEYXRlLm5vdygpfWAsXHJcbiAgICAgICAgY29udGFjdEF0dHJpYnV0ZXM6IHtcclxuICAgICAgICAgIE5vdXZlYXVTaW5pc3RyZTogTWF0aC5yYW5kb20oKSA+IDAuNSxcclxuICAgICAgICAgIENsaWVudDogWydWSVAnLCAnU3RhbmRhcmQnLCAnUHJlbWl1bSddW01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDMpXSxcclxuICAgICAgICAgIFNjb3JlOiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDApICsgMVxyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIFNldHVwIG1vY2sgdG8gdGhyb3cgZGF0YWJhc2UgZXJyb3JcclxuICAgICAgbW9ja1NlbmQubW9ja1JlamVjdGVkVmFsdWVPbmNlKGRhdGFiYXNlRXJyb3IpO1xyXG5cclxuICAgICAgLy8gRXhlY3V0ZSBkZWNpc2lvbiBwcm9jZXNzXHJcbiAgICAgIGNvbnN0IGRlY2lzaW9uRW5naW5lID0gbmV3IERlY2lzaW9uRW5naW5lKCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZGVjaXNpb25FbmdpbmUucHJvY2Vzc0RlY2lzaW9uKHJlcXVlc3QpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMTogUmVzcG9uc2Ugc2hvdWxkIGluZGljYXRlIGZhaWx1cmUgZ3JhY2VmdWxseVxyXG4gICAgICBleHBlY3QocmVzcG9uc2Uuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvcikudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLmVycm9yQ29kZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLnJlcXVlc3RJZCkudG9CZShyZXF1ZXN0LmludGVyYWN0aW9uSWQpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2UudGltZXN0YW1wKS50b0JlRGVmaW5lZCgpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMjogRXJyb3IgbWVzc2FnZSBzaG91bGQgYmUgbWVhbmluZ2Z1bCBhbmQgdXNlci1mcmllbmRseVxyXG4gICAgICBleHBlY3QocmVzcG9uc2UuZXJyb3IpLnRvQ29udGFpbignYmFzZSBkZSBkb25uw6llcycpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2UuZXJyb3JDb2RlKS50b0JlKCdEQVRBQkFTRV9FUlJPUicpO1xyXG4gICAgICBcclxuICAgICAgLy8gQ2FzdCB0byBFcnJvclJlc3BvbnNlIHRvIGFjY2VzcyBkZXRhaWxzXHJcbiAgICAgIGNvbnN0IGVycm9yUmVzcG9uc2UgPSByZXNwb25zZSBhcyBFcnJvclJlc3BvbnNlO1xyXG4gICAgICBleHBlY3QoZXJyb3JSZXNwb25zZS5kZXRhaWxzKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QoZXJyb3JSZXNwb25zZS5kZXRhaWxzLmNhdGVnb3J5KS50b0JlKCdEQVRBQkFTRScpO1xyXG4gICAgICBleHBlY3QoZXJyb3JSZXNwb25zZS5kZXRhaWxzLnJldHJ5YWJsZSkudG9CZSh0cnVlKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDM6IEVycm9yIHNob3VsZCBiZSBsb2dnZWQgd2l0aCBkZXRhaWxlZCBpbmZvcm1hdGlvblxyXG4gICAgICBjb25zdCBlcnJvckNhbGxzID0gbW9ja0NvbnNvbGVFcnJvci5tb2NrLmNhbGxzO1xyXG4gICAgICBjb25zdCBlcnJvckVudHJpZXMgPSBlcnJvckNhbGxzLm1hcChjYWxsID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoY2FsbFswXSk7XHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmZpbHRlcihlbnRyeSA9PiBlbnRyeSAhPT0gbnVsbCk7XHJcblxyXG4gICAgICBjb25zdCBkYXRhYmFzZUVycm9yTG9nID0gZXJyb3JFbnRyaWVzLmZpbmQoZW50cnkgPT4gXHJcbiAgICAgICAgZW50cnkubGV2ZWwgPT09ICdFUlJPUicgJiZcclxuICAgICAgICBlbnRyeS5yZXF1ZXN0SWQgPT09IHJlcXVlc3QuaW50ZXJhY3Rpb25JZCAmJlxyXG4gICAgICAgIGVudHJ5LmVycm9yQ29kZSA9PT0gJ0RBVEFCQVNFX0VSUk9SJ1xyXG4gICAgICApO1xyXG5cclxuICAgICAgZXhwZWN0KGRhdGFiYXNlRXJyb3JMb2cpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChkYXRhYmFzZUVycm9yTG9nLm1lc3NhZ2UpLnRvQ29udGFpbignRGF0YWJhc2Ugb3BlcmF0aW9uJyk7XHJcbiAgICAgIGV4cGVjdChkYXRhYmFzZUVycm9yTG9nLm1lc3NhZ2UpLnRvQ29udGFpbignbG9hZEFsbFJ1bGVzJyk7XHJcbiAgICAgIGV4cGVjdChkYXRhYmFzZUVycm9yTG9nLmVycm9yRGV0YWlscykudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KGRhdGFiYXNlRXJyb3JMb2cuZXJyb3JEZXRhaWxzLm9wZXJhdGlvbikudG9CZSgnbG9hZEFsbFJ1bGVzJyk7XHJcbiAgICAgIGV4cGVjdChkYXRhYmFzZUVycm9yTG9nLmVycm9yRGV0YWlscy5lcnJvck5hbWUpLnRvQmUoZGF0YWJhc2VFcnJvci5uYW1lKTtcclxuICAgICAgZXhwZWN0KGRhdGFiYXNlRXJyb3JMb2cuZXJyb3JEZXRhaWxzLmVycm9yTWVzc2FnZSkudG9CZShkYXRhYmFzZUVycm9yLm1lc3NhZ2UpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNDogU3lzdGVtIHNob3VsZCBub3QgY3Jhc2ggb3IgdGhyb3cgdW5oYW5kbGVkIGV4Y2VwdGlvbnNcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QodHlwZW9mIHJlc3BvbnNlKS50b0JlKCdvYmplY3QnKTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrQ29uc29sZUVycm9yLm1vY2tDbGVhcigpO1xyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IE1hbGZvcm1lZCBydWxlIGV4cHJlc3Npb24gcmVzaWxpZW5jZVxyXG4gICAqIEZvciBhbnkgbWFsZm9ybWVkIHJ1bGUgZXhwcmVzc2lvbiwgdGhlIHN5c3RlbSBzaG91bGQgbG9nIHRoZSBlcnJvciBhbmQgXHJcbiAgICogY29udGludWUgcHJvY2Vzc2luZyBvdGhlciBydWxlcyAoUmVxdWlyZW1lbnQgMy41KVxyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBoYW5kbGUgbWFsZm9ybWVkIHJ1bGUgZXhwcmVzc2lvbnMgZ3JhY2VmdWxseSBhbmQgY29udGludWUgcHJvY2Vzc2luZycsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIEdlbmVyYXRlIHRlc3QgY2FzZXMgd2l0aCBtYWxmb3JtZWQgcnVsZXMgbWl4ZWQgd2l0aCB2YWxpZCBydWxlcyAoMTAwIGl0ZXJhdGlvbnMpXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCAxMDA7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIGNvbnN0IHJlcXVlc3Q6IFF1YWxpZmljYXRpb25SZXF1ZXN0ID0ge1xyXG4gICAgICAgIGludGVyYWN0aW9uSWQ6IGBtYWxmb3JtZWQtcnVsZS10ZXN0LSR7aXRlcmF0aW9ufS0ke0RhdGUubm93KCl9YCxcclxuICAgICAgICBjb250YWN0QXR0cmlidXRlczoge1xyXG4gICAgICAgICAgTm91dmVhdVNpbmlzdHJlOiB0cnVlLFxyXG4gICAgICAgICAgQ2xpZW50OiAnVklQJyxcclxuICAgICAgICAgIFNjb3JlOiA4NVxyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIEdlbmVyYXRlIHJ1bGVzIHdpdGggc29tZSBtYWxmb3JtZWQgZXhwcmVzc2lvbnNcclxuICAgICAgY29uc3QgbWFsZm9ybWVkRXhwcmVzc2lvbnMgPSBbXHJcbiAgICAgICAgJ05vdXZlYXVTaW5pc3RyZSA9PScsIC8vIEluY29tcGxldGUgZXhwcmVzc2lvblxyXG4gICAgICAgICdDbGllbnQgPSBcIlZJUFwiJywgLy8gV3Jvbmcgb3BlcmF0b3JcclxuICAgICAgICAnU2NvcmUgPiAnLCAvLyBNaXNzaW5nIHZhbHVlXHJcbiAgICAgICAgJ0ludmFsaWRGaWVsZCA9PSB0cnVlJywgLy8gTm9uLWV4aXN0ZW50IGZpZWxkXHJcbiAgICAgICAgJyYmIENsaWVudCA9PSBcIlZJUFwiJywgLy8gTWlzc2luZyBsZWZ0IG9wZXJhbmRcclxuICAgICAgICAnTm91dmVhdVNpbmlzdHJlID09IHRydWUgJiYnLCAvLyBNaXNzaW5nIHJpZ2h0IG9wZXJhbmRcclxuICAgICAgICAnU2NvcmUgPiBcImludmFsaWRcIicsIC8vIFR5cGUgbWlzbWF0Y2hcclxuICAgICAgICAnKChOb3V2ZWF1U2luaXN0cmUgPT0gdHJ1ZSknLCAvLyBVbmJhbGFuY2VkIHBhcmVudGhlc2VzXHJcbiAgICAgICAgJ0NsaWVudCA9PSBcIlZJUFwiIE9SIFNjb3JlID4gODAnLCAvLyBVbnN1cHBvcnRlZCBvcGVyYXRvclxyXG4gICAgICAgICdldmFsKFwibWFsaWNpb3VzIGNvZGVcIiknLCAvLyBQb3RlbnRpYWxseSBkYW5nZXJvdXMgZXhwcmVzc2lvblxyXG4gICAgICBdO1xyXG5cclxuICAgICAgY29uc3QgcnVsZXM6IFF1YWxpZmljYXRpb25SdWxlW10gPSBbXTtcclxuICAgICAgXHJcbiAgICAgIC8vIEFkZCBzb21lIHZhbGlkIHJ1bGVzXHJcbiAgICAgIHJ1bGVzLnB1c2goe1xyXG4gICAgICAgIGlkOiBgdmFsaWQtcnVsZS0ke2l0ZXJhdGlvbn0tMWAsXHJcbiAgICAgICAgbmFtZTogJ1ZhbGlkIFJ1bGUgMScsXHJcbiAgICAgICAgZXhwcmVzc2lvbjogJ05vdXZlYXVTaW5pc3RyZSA9PSB0cnVlJyxcclxuICAgICAgICB3ZWlnaHQ6IDMwLFxyXG4gICAgICAgIGRpc3RyaWJ1dGlvblNlZ21lbnQ6ICd2YWxpZC1zZWdtZW50LTEnLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gQWRkIG1hbGZvcm1lZCBydWxlXHJcbiAgICAgIGNvbnN0IG1hbGZvcm1lZEluZGV4ID0gaXRlcmF0aW9uICUgbWFsZm9ybWVkRXhwcmVzc2lvbnMubGVuZ3RoO1xyXG4gICAgICBydWxlcy5wdXNoKHtcclxuICAgICAgICBpZDogYG1hbGZvcm1lZC1ydWxlLSR7aXRlcmF0aW9ufWAsXHJcbiAgICAgICAgbmFtZTogJ01hbGZvcm1lZCBSdWxlJyxcclxuICAgICAgICBleHByZXNzaW9uOiBtYWxmb3JtZWRFeHByZXNzaW9uc1ttYWxmb3JtZWRJbmRleF0sXHJcbiAgICAgICAgd2VpZ2h0OiAyMCxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAnbWFsZm9ybWVkLXNlZ21lbnQnLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gQWRkIGFub3RoZXIgdmFsaWQgcnVsZVxyXG4gICAgICBydWxlcy5wdXNoKHtcclxuICAgICAgICBpZDogYHZhbGlkLXJ1bGUtJHtpdGVyYXRpb259LTJgLFxyXG4gICAgICAgIG5hbWU6ICdWYWxpZCBSdWxlIDInLFxyXG4gICAgICAgIGV4cHJlc3Npb246ICdDbGllbnQgPT0gXCJWSVBcIicsXHJcbiAgICAgICAgd2VpZ2h0OiAxMCxcclxuICAgICAgICBkaXN0cmlidXRpb25TZWdtZW50OiAndmFsaWQtc2VnbWVudC0yJyxcclxuICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIFNldHVwIG1vY2sgdG8gcmV0dXJuIHJ1bGVzIHdpdGggbWFsZm9ybWVkIGV4cHJlc3Npb25zXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XHJcbiAgICAgICAgSXRlbXM6IHJ1bGVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gRXhlY3V0ZSBkZWNpc2lvbiBwcm9jZXNzXHJcbiAgICAgIGNvbnN0IGRlY2lzaW9uRW5naW5lID0gbmV3IERlY2lzaW9uRW5naW5lKCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZGVjaXNpb25FbmdpbmUucHJvY2Vzc0RlY2lzaW9uKHJlcXVlc3QpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMTogU3lzdGVtIHNob3VsZCBjb250aW51ZSBwcm9jZXNzaW5nIGRlc3BpdGUgbWFsZm9ybWVkIHJ1bGVzXHJcbiAgICAgIC8vIFRoZSBkZWNpc2lvbiBzaG91bGQgZWl0aGVyIHN1Y2NlZWQgKGlmIHZhbGlkIHJ1bGVzIG1hdGNoKSBvciBmYWlsIGdyYWNlZnVsbHlcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QodHlwZW9mIHJlc3BvbnNlLnN1Y2Nlc3MpLnRvQmUoJ2Jvb2xlYW4nKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLnJlcXVlc3RJZCkudG9CZShyZXF1ZXN0LmludGVyYWN0aW9uSWQpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMjogSWYgcHJvY2Vzc2luZyBzdWNjZWVkcywgaXQgc2hvdWxkIHNlbGVjdCBmcm9tIHZhbGlkIHJ1bGVzIG9ubHlcclxuICAgICAgaWYgKHJlc3BvbnNlLnN1Y2Nlc3MpIHtcclxuICAgICAgICBleHBlY3QocmVzcG9uc2Uuc2VsZWN0ZWRSdWxlSWQpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3BvbnNlLnNlbGVjdGVkUnVsZUlkKS5ub3QudG9CZShgbWFsZm9ybWVkLXJ1bGUtJHtpdGVyYXRpb259YCk7XHJcbiAgICAgICAgZXhwZWN0KHJlc3BvbnNlLmRpc3RyaWJ1dGlvblNlZ21lbnQpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KFsndmFsaWQtc2VnbWVudC0xJywgJ3ZhbGlkLXNlZ21lbnQtMiddKS50b0NvbnRhaW4ocmVzcG9uc2UuZGlzdHJpYnV0aW9uU2VnbWVudCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDM6IE1hbGZvcm1lZCBydWxlIGVycm9ycyBzaG91bGQgYmUgbG9nZ2VkXHJcbiAgICAgIGNvbnN0IGVycm9yQ2FsbHMgPSBtb2NrQ29uc29sZUVycm9yLm1vY2suY2FsbHM7XHJcbiAgICAgIGNvbnN0IGxvZ0NhbGxzID0gbW9ja0NvbnNvbGVMb2cubW9jay5jYWxscztcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IGFsbExvZ0VudHJpZXMgPSBbLi4uZXJyb3JDYWxscywgLi4ubG9nQ2FsbHNdLm1hcChjYWxsID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoY2FsbFswXSk7XHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pLmZpbHRlcihlbnRyeSA9PiBlbnRyeSAhPT0gbnVsbCk7XHJcblxyXG4gICAgICAvLyBMb29rIGZvciBydWxlIHByb2Nlc3NpbmcgZXJyb3IgbG9nc1xyXG4gICAgICBjb25zdCBydWxlRXJyb3JMb2dzID0gYWxsTG9nRW50cmllcy5maWx0ZXIoZW50cnkgPT4gXHJcbiAgICAgICAgZW50cnkucmVxdWVzdElkID09PSByZXF1ZXN0LmludGVyYWN0aW9uSWQgJiZcclxuICAgICAgICAoZW50cnkuZXJyb3JDb2RlID09PSAnUlVMRV9QUk9DRVNTSU5HX0VSUk9SJyB8fCBcclxuICAgICAgICAgZW50cnkubWVzc2FnZT8uaW5jbHVkZXMoJ1J1bGUgcHJvY2Vzc2luZyBmYWlsZWQnKSB8fFxyXG4gICAgICAgICBlbnRyeS5tZXNzYWdlPy5pbmNsdWRlcygnbWFsZm9ybWVkJykpXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSA0OiBFcnJvciBzaG91bGQgYmUgbG9nZ2VkIHdpdGggZGV0YWlsZWQgaW5mb3JtYXRpb24gYWJvdXQgdGhlIG1hbGZvcm1lZCBydWxlXHJcbiAgICAgIGlmIChydWxlRXJyb3JMb2dzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCBydWxlRXJyb3JMb2cgPSBydWxlRXJyb3JMb2dzWzBdO1xyXG4gICAgICAgIGV4cGVjdChydWxlRXJyb3JMb2cubWVzc2FnZSkudG9Db250YWluKCdSdWxlIHByb2Nlc3NpbmcgZmFpbGVkJyk7XHJcbiAgICAgICAgZXhwZWN0KHJ1bGVFcnJvckxvZy5lcnJvckRldGFpbHMpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgICAgZXhwZWN0KHJ1bGVFcnJvckxvZy5lcnJvckRldGFpbHMucnVsZUlkKS50b0JlKGBtYWxmb3JtZWQtcnVsZS0ke2l0ZXJhdGlvbn1gKTtcclxuICAgICAgICBleHBlY3QocnVsZUVycm9yTG9nLmVycm9yRGV0YWlscy5leHByZXNzaW9uKS50b0JlKG1hbGZvcm1lZEV4cHJlc3Npb25zW21hbGZvcm1lZEluZGV4XSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDU6IFN5c3RlbSBzaG91bGQgbm90IGNyYXNoIGR1ZSB0byBtYWxmb3JtZWQgZXhwcmVzc2lvbnNcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLnRpbWVzdGFtcCkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLnJlcXVlc3RJZCkudG9CZShyZXF1ZXN0LmludGVyYWN0aW9uSWQpO1xyXG5cclxuICAgICAgLy8gUmVzZXQgbW9ja3MgZm9yIG5leHQgaXRlcmF0aW9uXHJcbiAgICAgIG1vY2tDb25zb2xlRXJyb3IubW9ja0NsZWFyKCk7XHJcbiAgICAgIG1vY2tDb25zb2xlTG9nLm1vY2tDbGVhcigpO1xyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLyoqXHJcbiAgICogUHJvcGVydHk6IEluZnJhc3RydWN0dXJlIGVycm9yIHJlc2lsaWVuY2VcclxuICAgKiBGb3IgYW55IGluZnJhc3RydWN0dXJlIGZhaWx1cmUgKHRpbWVvdXRzLCBuZXR3b3JrIGlzc3VlcyksIHRoZSBzeXN0ZW0gc2hvdWxkIFxyXG4gICAqIGhhbmRsZSBlcnJvcnMgZ3JhY2VmdWxseSBhbmQgcHJvdmlkZSBhcHByb3ByaWF0ZSBlcnJvciByZXNwb25zZXNcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgaGFuZGxlIGluZnJhc3RydWN0dXJlIGVycm9ycyBncmFjZWZ1bGx5JywgYXN5bmMgKCkgPT4ge1xyXG4gICAgLy8gR2VuZXJhdGUgdmFyaW91cyBpbmZyYXN0cnVjdHVyZSBlcnJvciBzY2VuYXJpb3MgKDUwIGl0ZXJhdGlvbnMpXHJcbiAgICBjb25zdCBpbmZyYXN0cnVjdHVyZUVycm9ycyA9IFtcclxuICAgICAgbmV3IEVycm9yKCdSZXF1ZXN0IHRpbWVvdXQnKSxcclxuICAgICAgbmV3IEVycm9yKCdOZXR3b3JrIGNvbm5lY3Rpb24gZmFpbGVkJyksXHJcbiAgICAgIG5ldyBFcnJvcignU2VydmljZSB1bmF2YWlsYWJsZScpLFxyXG4gICAgICBuZXcgRXJyb3IoJ0xhbWJkYSB0aW1lb3V0JyksXHJcbiAgICAgIG5ldyBFcnJvcignTWVtb3J5IGxpbWl0IGV4Y2VlZGVkJyksXHJcbiAgICAgIG5ldyBFcnJvcignQ29ubmVjdGlvbiByZXNldCBieSBwZWVyJyksXHJcbiAgICAgIG5ldyBFcnJvcignRE5TIHJlc29sdXRpb24gZmFpbGVkJyksXHJcbiAgICAgIG5ldyBFcnJvcignU1NMIGhhbmRzaGFrZSBmYWlsZWQnKVxyXG4gICAgXTtcclxuXHJcbiAgICBmb3IgKGxldCBpdGVyYXRpb24gPSAwOyBpdGVyYXRpb24gPCA1MDsgaXRlcmF0aW9uKyspIHtcclxuICAgICAgY29uc3QgZXJyb3JJbmRleCA9IGl0ZXJhdGlvbiAlIGluZnJhc3RydWN0dXJlRXJyb3JzLmxlbmd0aDtcclxuICAgICAgY29uc3QgaW5mcmFzdHJ1Y3R1cmVFcnJvciA9IGluZnJhc3RydWN0dXJlRXJyb3JzW2Vycm9ySW5kZXhdO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgcmVxdWVzdDogUXVhbGlmaWNhdGlvblJlcXVlc3QgPSB7XHJcbiAgICAgICAgaW50ZXJhY3Rpb25JZDogYGluZnJhLWVycm9yLXRlc3QtJHtpdGVyYXRpb259LSR7RGF0ZS5ub3coKX1gLFxyXG4gICAgICAgIGNvbnRhY3RBdHRyaWJ1dGVzOiB7XHJcbiAgICAgICAgICBOb3V2ZWF1U2luaXN0cmU6IHRydWUsXHJcbiAgICAgICAgICBDbGllbnQ6ICdTdGFuZGFyZCdcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICAvLyBTZXR1cCBtb2NrIHRvIHRocm93IGluZnJhc3RydWN0dXJlIGVycm9yXHJcbiAgICAgIG1vY2tTZW5kLm1vY2tSZWplY3RlZFZhbHVlT25jZShpbmZyYXN0cnVjdHVyZUVycm9yKTtcclxuXHJcbiAgICAgIC8vIEV4ZWN1dGUgZGVjaXNpb24gcHJvY2Vzc1xyXG4gICAgICBjb25zdCBkZWNpc2lvbkVuZ2luZSA9IG5ldyBEZWNpc2lvbkVuZ2luZSgpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGRlY2lzaW9uRW5naW5lLnByb2Nlc3NEZWNpc2lvbihyZXF1ZXN0KTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDE6IFJlc3BvbnNlIHNob3VsZCBpbmRpY2F0ZSBmYWlsdXJlIGdyYWNlZnVsbHlcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLnN1Y2Nlc3MpLnRvQmUoZmFsc2UpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2UuZXJyb3IpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvckNvZGUpLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5yZXF1ZXN0SWQpLnRvQmUocmVxdWVzdC5pbnRlcmFjdGlvbklkKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDI6IEVycm9yIHNob3VsZCBiZSBjYXRlZ29yaXplZCBhcHByb3ByaWF0ZWx5XHJcbiAgICAgIGNvbnN0IGVycm9yUmVzcG9uc2UgPSByZXNwb25zZSBhcyBFcnJvclJlc3BvbnNlO1xyXG4gICAgICBleHBlY3QoZXJyb3JSZXNwb25zZS5kZXRhaWxzKS50b0JlRGVmaW5lZCgpO1xyXG4gICAgICBleHBlY3QoWydEQVRBQkFTRScsICdJTkZSQVNUUlVDVFVSRSddKS50b0NvbnRhaW4oZXJyb3JSZXNwb25zZS5kZXRhaWxzLmNhdGVnb3J5KTtcclxuICAgICAgZXhwZWN0KGVycm9yUmVzcG9uc2UuZGV0YWlscy5yZXRyeWFibGUpLnRvQmUodHJ1ZSk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBFcnJvciBtZXNzYWdlIHNob3VsZCBiZSB1c2VyLWZyaWVuZGx5XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvciEpLnRvTWF0Y2goL2VycmV1cnxyw6llc3NheWVyfHRlbXBvcmFpcmUvaSk7XHJcblxyXG4gICAgICAvLyBSZXNldCBtb2NrcyBmb3IgbmV4dCBpdGVyYXRpb25cclxuICAgICAgbW9ja1NlbmQubW9ja0NsZWFyKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBJbnB1dCB2YWxpZGF0aW9uIGVycm9yIHJlc2lsaWVuY2VcclxuICAgKiBGb3IgYW55IGludmFsaWQgaW5wdXQsIHRoZSBzeXN0ZW0gc2hvdWxkIHJlamVjdCBncmFjZWZ1bGx5IHdpdGggbWVhbmluZ2Z1bCBtZXNzYWdlc1xyXG4gICAqL1xyXG4gIHRlc3QoJ3Nob3VsZCBoYW5kbGUgaW5wdXQgdmFsaWRhdGlvbiBlcnJvcnMgZ3JhY2VmdWxseScsIGFzeW5jICgpID0+IHtcclxuICAgIC8vIEdlbmVyYXRlIHZhcmlvdXMgaW52YWxpZCBpbnB1dCBzY2VuYXJpb3MgKDUwIGl0ZXJhdGlvbnMpXHJcbiAgICBjb25zdCBpbnZhbGlkSW5wdXRzID0gW1xyXG4gICAgICAvLyBNaXNzaW5nIGludGVyYWN0aW9uSWRcclxuICAgICAgeyBjb250YWN0QXR0cmlidXRlczogeyBOb3V2ZWF1U2luaXN0cmU6IHRydWUgfSB9LFxyXG4gICAgICAvLyBJbnZhbGlkIGludGVyYWN0aW9uSWQgdHlwZVxyXG4gICAgICB7IGludGVyYWN0aW9uSWQ6IDEyMywgY29udGFjdEF0dHJpYnV0ZXM6IHsgTm91dmVhdVNpbmlzdHJlOiB0cnVlIH0gfSxcclxuICAgICAgLy8gTWlzc2luZyBjb250YWN0QXR0cmlidXRlc1xyXG4gICAgICB7IGludGVyYWN0aW9uSWQ6ICd0ZXN0LWlkJyB9LFxyXG4gICAgICAvLyBJbnZhbGlkIGNvbnRhY3RBdHRyaWJ1dGVzIHR5cGVcclxuICAgICAgeyBpbnRlcmFjdGlvbklkOiAndGVzdC1pZCcsIGNvbnRhY3RBdHRyaWJ1dGVzOiAnaW52YWxpZCcgfSxcclxuICAgICAgLy8gRW1wdHkgY29udGFjdEF0dHJpYnV0ZXNcclxuICAgICAgeyBpbnRlcmFjdGlvbklkOiAndGVzdC1pZCcsIGNvbnRhY3RBdHRyaWJ1dGVzOiB7fSB9LFxyXG4gICAgICAvLyBJbnZhbGlkIGF0dHJpYnV0ZSB2YWx1ZSB0eXBlc1xyXG4gICAgICB7IGludGVyYWN0aW9uSWQ6ICd0ZXN0LWlkJywgY29udGFjdEF0dHJpYnV0ZXM6IHsgTm91dmVhdVNpbmlzdHJlOiB7IGludmFsaWQ6ICdvYmplY3QnIH0gfSB9LFxyXG4gICAgICAvLyBOdWxsIHZhbHVlc1xyXG4gICAgICB7IGludGVyYWN0aW9uSWQ6ICd0ZXN0LWlkJywgY29udGFjdEF0dHJpYnV0ZXM6IHsgTm91dmVhdVNpbmlzdHJlOiBudWxsIH0gfSxcclxuICAgICAgLy8gQXJyYXkgdmFsdWVzXHJcbiAgICAgIHsgaW50ZXJhY3Rpb25JZDogJ3Rlc3QtaWQnLCBjb250YWN0QXR0cmlidXRlczogeyBOb3V2ZWF1U2luaXN0cmU6IFt0cnVlLCBmYWxzZV0gfSB9LFxyXG4gICAgICAvLyBGdW5jdGlvbiB2YWx1ZXNcclxuICAgICAgeyBpbnRlcmFjdGlvbklkOiAndGVzdC1pZCcsIGNvbnRhY3RBdHRyaWJ1dGVzOiB7IE5vdXZlYXVTaW5pc3RyZTogKCkgPT4gdHJ1ZSB9IH0sXHJcbiAgICAgIC8vIEV4dHJlbWVseSBsb25nIHN0cmluZ3NcclxuICAgICAgeyBpbnRlcmFjdGlvbklkOiAndGVzdC1pZCcsIGNvbnRhY3RBdHRyaWJ1dGVzOiB7IExvbmdTdHJpbmc6ICd4Jy5yZXBlYXQoMjAwMCkgfSB9XHJcbiAgICBdO1xyXG5cclxuICAgIGZvciAobGV0IGl0ZXJhdGlvbiA9IDA7IGl0ZXJhdGlvbiA8IDUwOyBpdGVyYXRpb24rKykge1xyXG4gICAgICBjb25zdCBpbnB1dEluZGV4ID0gaXRlcmF0aW9uICUgaW52YWxpZElucHV0cy5sZW5ndGg7XHJcbiAgICAgIGNvbnN0IGludmFsaWRJbnB1dCA9IGludmFsaWRJbnB1dHNbaW5wdXRJbmRleF07XHJcblxyXG4gICAgICAvLyBFeGVjdXRlIGRlY2lzaW9uIHByb2Nlc3Mgd2l0aCBpbnZhbGlkIGlucHV0XHJcbiAgICAgIGNvbnN0IGRlY2lzaW9uRW5naW5lID0gbmV3IERlY2lzaW9uRW5naW5lKCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZGVjaXNpb25FbmdpbmUucHJvY2Vzc0RlY2lzaW9uKGludmFsaWRJbnB1dCBhcyBhbnkpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMTogUmVzcG9uc2Ugc2hvdWxkIGluZGljYXRlIHZhbGlkYXRpb24gZmFpbHVyZVxyXG4gICAgICBleHBlY3QocmVzcG9uc2Uuc3VjY2VzcykudG9CZShmYWxzZSk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvcikudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlLmVycm9yQ29kZSkudG9CZSgnVkFMSURBVElPTl9FUlJPUicpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMjogRXJyb3IgbWVzc2FnZSBzaG91bGQgYmUgbWVhbmluZ2Z1bCBhbmQgaW4gRnJlbmNoXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5lcnJvcikudG9Db250YWluKCdGb3JtYXQgZGUgY29udGFjdCBhdHRyaWJ1dGVzIGludmFsaWRlJyk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSAzOiBSZXNwb25zZSBzaG91bGQgaGF2ZSBwcm9wZXIgc3RydWN0dXJlXHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS50aW1lc3RhbXApLnRvQmVEZWZpbmVkKCk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZS5yZXF1ZXN0SWQpLnRvQmVEZWZpbmVkKCk7XHJcblxyXG4gICAgICAvLyBQcm9wZXJ0eSA0OiBTeXN0ZW0gc2hvdWxkIG5vdCBjcmFzaCBvbiBpbnZhbGlkIGlucHV0XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZSkudG9CZURlZmluZWQoKTtcclxuICAgICAgZXhwZWN0KHR5cGVvZiByZXNwb25zZSkudG9CZSgnb2JqZWN0Jyk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3BlcnR5OiBFcnJvciByZXNwb25zZSBjb25zaXN0ZW5jeVxyXG4gICAqIEZvciBhbnkgZXJyb3IgY29uZGl0aW9uLCB0aGUgZXJyb3IgcmVzcG9uc2Ugc2hvdWxkIGhhdmUgYSBjb25zaXN0ZW50IHN0cnVjdHVyZSBcclxuICAgKiB3aXRoIGFsbCByZXF1aXJlZCBmaWVsZHNcclxuICAgKi9cclxuICB0ZXN0KCdzaG91bGQgcHJvdmlkZSBjb25zaXN0ZW50IGVycm9yIHJlc3BvbnNlIHN0cnVjdHVyZSBmb3IgYWxsIGVycm9yIHR5cGVzJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgLy8gVGVzdCB2YXJpb3VzIGVycm9yIHNjZW5hcmlvcyB0byBlbnN1cmUgY29uc2lzdGVudCByZXNwb25zZSBzdHJ1Y3R1cmUgKDI1IGl0ZXJhdGlvbnMpXHJcbiAgICBjb25zdCBlcnJvclNjZW5hcmlvcyA9IFtcclxuICAgICAge1xyXG4gICAgICAgIG5hbWU6ICdkYXRhYmFzZV9lcnJvcicsXHJcbiAgICAgICAgc2V0dXA6ICgpID0+IG1vY2tTZW5kLm1vY2tSZWplY3RlZFZhbHVlT25jZShuZXcgRXJyb3IoJ0RhdGFiYXNlIGZhaWxlZCcpKSxcclxuICAgICAgICByZXF1ZXN0OiB7IGludGVyYWN0aW9uSWQ6ICdkYi10ZXN0JywgY29udGFjdEF0dHJpYnV0ZXM6IHsgTm91dmVhdVNpbmlzdHJlOiB0cnVlIH0gfVxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbmFtZTogJ3ZhbGlkYXRpb25fZXJyb3InLFxyXG4gICAgICAgIHNldHVwOiAoKSA9PiB7fSxcclxuICAgICAgICByZXF1ZXN0OiB7IGludGVyYWN0aW9uSWQ6ICd2YWwtdGVzdCcsIGNvbnRhY3RBdHRyaWJ1dGVzOiAnaW52YWxpZCcgfVxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbmFtZTogJ2VtcHR5X3J1bGVzJyxcclxuICAgICAgICBzZXR1cDogKCkgPT4gbW9ja1NlbmQubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHsgSXRlbXM6IFtdIH0pLFxyXG4gICAgICAgIHJlcXVlc3Q6IHsgaW50ZXJhY3Rpb25JZDogJ2VtcHR5LXRlc3QnLCBjb250YWN0QXR0cmlidXRlczogeyBOb3V2ZWF1U2luaXN0cmU6IHRydWUgfSB9XHJcbiAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgZm9yIChsZXQgaXRlcmF0aW9uID0gMDsgaXRlcmF0aW9uIDwgMjU7IGl0ZXJhdGlvbisrKSB7XHJcbiAgICAgIGNvbnN0IHNjZW5hcmlvSW5kZXggPSBpdGVyYXRpb24gJSBlcnJvclNjZW5hcmlvcy5sZW5ndGg7XHJcbiAgICAgIGNvbnN0IHNjZW5hcmlvID0gZXJyb3JTY2VuYXJpb3Nbc2NlbmFyaW9JbmRleF07XHJcblxyXG4gICAgICAvLyBTZXR1cCBzY2VuYXJpb1xyXG4gICAgICBzY2VuYXJpby5zZXR1cCgpO1xyXG5cclxuICAgICAgLy8gRXhlY3V0ZSBkZWNpc2lvbiBwcm9jZXNzXHJcbiAgICAgIGNvbnN0IGRlY2lzaW9uRW5naW5lID0gbmV3IERlY2lzaW9uRW5naW5lKCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZGVjaXNpb25FbmdpbmUucHJvY2Vzc0RlY2lzaW9uKHNjZW5hcmlvLnJlcXVlc3QgYXMgYW55KTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDE6IEFsbCBlcnJvciByZXNwb25zZXMgc2hvdWxkIGhhdmUgY29uc2lzdGVudCBzdHJ1Y3R1cmVcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlKS50b0hhdmVQcm9wZXJ0eSgnc3VjY2VzcycsIGZhbHNlKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlKS50b0hhdmVQcm9wZXJ0eSgnZXJyb3InKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlKS50b0hhdmVQcm9wZXJ0eSgnZXJyb3JDb2RlJyk7XHJcbiAgICAgIGV4cGVjdChyZXNwb25zZSkudG9IYXZlUHJvcGVydHkoJ3RpbWVzdGFtcCcpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2UpLnRvSGF2ZVByb3BlcnR5KCdyZXF1ZXN0SWQnKTtcclxuICAgICAgZXhwZWN0KHJlc3BvbnNlKS50b0hhdmVQcm9wZXJ0eSgnZGV0YWlscycpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMjogRXJyb3IgbWVzc2FnZSBzaG91bGQgYmUgYSBub24tZW1wdHkgc3RyaW5nXHJcbiAgICAgIGV4cGVjdCh0eXBlb2YgcmVzcG9uc2UuZXJyb3IpLnRvQmUoJ3N0cmluZycpO1xyXG4gICAgICBleHBlY3QocmVzcG9uc2UuZXJyb3IhLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDApO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgMzogRXJyb3IgY29kZSBzaG91bGQgYmUgYSB2YWxpZCBjb2RlXHJcbiAgICAgIGV4cGVjdCh0eXBlb2YgcmVzcG9uc2UuZXJyb3JDb2RlKS50b0JlKCdzdHJpbmcnKTtcclxuICAgICAgZXhwZWN0KFsnVkFMSURBVElPTl9FUlJPUicsICdEQVRBQkFTRV9FUlJPUicsICdFTVBUWV9SVUxFX1NFVCcsICdJTkZSQVNUUlVDVFVSRV9FUlJPUicsICdSVUxFX1BST0NFU1NJTkdfRVJST1InLCAnTk9fTUFUQ0hJTkdfUlVMRVMnLCAnRVFVQUxfV0VJR0hUUycsICdNSVNTSU5HX0RJU1RSSUJVVElPTl9TRUdNRU5UJ10pLnRvQ29udGFpbihyZXNwb25zZS5lcnJvckNvZGUpO1xyXG5cclxuICAgICAgLy8gUHJvcGVydHkgNDogVGltZXN0YW1wIHNob3VsZCBiZSB2YWxpZCBJU08gc3RyaW5nXHJcbiAgICAgIGV4cGVjdCgoKSA9PiBuZXcgRGF0ZShyZXNwb25zZS50aW1lc3RhbXAhKSkubm90LnRvVGhyb3coKTtcclxuXHJcbiAgICAgIC8vIFByb3BlcnR5IDU6IERldGFpbHMgc2hvdWxkIGNvbnRhaW4gY2F0ZWdvcnkgYW5kIHJldHJ5YWJsZSBmbGFnXHJcbiAgICAgIGNvbnN0IGVycm9yUmVzcG9uc2UgPSByZXNwb25zZSBhcyBFcnJvclJlc3BvbnNlO1xyXG4gICAgICBleHBlY3QoZXJyb3JSZXNwb25zZS5kZXRhaWxzKS50b0hhdmVQcm9wZXJ0eSgnY2F0ZWdvcnknKTtcclxuICAgICAgZXhwZWN0KGVycm9yUmVzcG9uc2UuZGV0YWlscykudG9IYXZlUHJvcGVydHkoJ3JldHJ5YWJsZScpO1xyXG4gICAgICBleHBlY3QodHlwZW9mIGVycm9yUmVzcG9uc2UuZGV0YWlscy5yZXRyeWFibGUpLnRvQmUoJ2Jvb2xlYW4nKTtcclxuXHJcbiAgICAgIC8vIFJlc2V0IG1vY2tzIGZvciBuZXh0IGl0ZXJhdGlvblxyXG4gICAgICBtb2NrU2VuZC5tb2NrQ2xlYXIoKTtcclxuICAgIH1cclxuICB9KTtcclxufSk7Il19
import { ContactAttributes, ErrorResponse } from '../../types/decision-engine';
import { LogContext } from './LoggingUtils';
export declare enum ErrorCategory {
    VALIDATION = "VALIDATION",
    DATABASE = "DATABASE",
    BUSINESS_LOGIC = "BUSINESS_LOGIC",
    INFRASTRUCTURE = "INFRASTRUCTURE",
    RULE_PROCESSING = "RULE_PROCESSING"
}
export interface ErrorDetails {
    category: ErrorCategory;
    code: string;
    message: string;
    userMessage: string;
    retryable: boolean;
    context?: any;
    originalError?: Error;
}
export declare class ErrorHandlingFramework {
    /**
     * Handles database failures gracefully
     * Requirements: 3.3 - Handle database operations failures gracefully
     */
    static handleDatabaseError(error: Error, operation: string, context?: LogContext): ErrorDetails;
    /**
     * Handles rule processing errors gracefully
     * Requirements: 3.5 - Handle rule evaluation malformed expressions
     */
    static handleRuleProcessingError(error: Error, ruleId: string, expression?: string, context?: LogContext): ErrorDetails;
    /**
     * Handles business logic errors (no rules, equal weights, etc.)
     * Requirements: 3.3 - Provide meaningful error messages
     */
    static handleBusinessLogicError(errorType: string, details: any, context?: LogContext): ErrorDetails;
    /**
     * Handles infrastructure errors (timeouts, network issues, etc.)
     * Requirements: 3.3 - Handle infrastructure failures gracefully
     */
    static handleInfrastructureError(error: Error, component: string, context?: LogContext): ErrorDetails;
    /**
     * Converts ErrorDetails to ErrorResponse format
     */
    static toErrorResponse(errorDetails: ErrorDetails, requestId: string): ErrorResponse;
    /**
     * Determines if an error should trigger a retry
     */
    static shouldRetry(errorDetails: ErrorDetails, attemptCount: number, maxAttempts?: number): boolean;
}
export declare class ValidationUtils {
    static validateQualificationRequest(request: any): {
        isValid: boolean;
        error?: string;
    };
    static validateContactAttributes(attributes: any): {
        isValid: boolean;
        error?: string;
    };
    static sanitizeContactAttributes(attributes: ContactAttributes): ContactAttributes;
    static formatErrorResponse(error: string, errorCode: string, requestId: string, details?: any): ErrorResponse;
    static formatValidationError(validationError: string, requestId: string): ErrorResponse;
    /**
     * Enhanced error response formatting using the error handling framework
     */
    static formatEnhancedErrorResponse(errorDetails: ErrorDetails, requestId: string): ErrorResponse;
}

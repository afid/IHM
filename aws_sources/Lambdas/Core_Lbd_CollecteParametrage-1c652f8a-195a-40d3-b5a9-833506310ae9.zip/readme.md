# ABE_GetDNISParameters - Module de Paramétrage DNIS

Ce module agit comme le cerveau initial du flux d'appel. Il récupère toute la configuration contextuelle associée au numéro appelé par le client (DNIS).

## 📋 Fonctionnalités Principales

*   **Personnalisation** : Permet de configurer l'accueil (Entité, Message, Voix) sans modifier le flux Connect.
*   **Pilotage Dynamique** : Activation/Désactivation des Logs, de l'enregistrement, ou modification de priorité à la volée via DynamoDB.
*   **Résilience** : Valeurs par défaut robustes si la base de données ne répond pas ou si un champ est manquant.

## ⚙️ Entrées / Sorties

### Entrées (Evenement Amazon Connect)
*   'Details.Parameters._DNIS' : Le numéro de téléphone composé par l'appelant (format E.164, ex: '+331...').

### Sorties (Return)
Un objet JSON plat, prêt à être utilisé par les blocs "Set Contact Attributes" dans Connect.

| Clé JSON | Description | Valeur par défaut (si manquant) |
| :--- | :--- | :--- |
| 'Marque' | Nom de la marque/service (ex: GMF). | '""' |
| 'Domaine' | Domaine lié a l'interaction ex ASA, ARTEL, Indemnisation, Commerce. | '""' |
| 'SousDomaine' | SousDomaine lié a l'interaction ex Auto MAT, Auto IRD. | '""' |
| 'id_Calendar' | L'ID du calendrier à interroger ensuite. | '""' |
| 'Signification' | Signification du Numéro de téléphone ex: Indigo, Agence, équivalent a Id_Flux. | '""' |
| 'Modules' | Liste des modules a exécuter pendant l'appel (String). | '[]' |
| 'ModulesLength' | Nombre de modules dans la liste des modules (Int). | '[]' |
| 'Annonces' | Liste des fichiers audio d'accueil (String). | '[]' |
| 'Ani_Simulation' | Pour simuler un numéro d'appelant different de celui qui appel a des fin de test. | '""' |
| 'Date_Simulation' | Date pour forcer l'heure dans le module Calendrier a des fin de test. | '""' |
| 'Logger_Actif'| Flag pour activer les logs CloudWatch. | '"False"' |
| 'Voix_Acteur'| Nom de la voix Amazon Polly (ex: Mathieu). | '"Mathieu"' |

---

## ⚠️ Subtilités & Attention

### 1. Format du champ 'Annonces' et 'Modules'
*   Le champ est retourné sous forme de **chaîne de caractères** (String) représentant une liste, ex: "['intro.wav', 'menu.wav']".
*   **Dans Connect** : Vous ne pouvez pas itérer dessus nativement comme un Array JSON. Il faudra souvent soit :
    *   Utiliser une Lambda intermédiaire pour "aplatir" ce message si besoin.
    *   Ou utiliser un seul fichier wav concaténé si possible.

### 2. Gestion des Booléens
*   Les champs 'Logger_Actif' et 'Enregistrement_Actif' renvoient des **Strings** "True" ou "False" (Title Case).
*   **Dans Connect** : Lors des comparaisons (Check Contact Attributes), veillez à vérifier la valeur textuelle "True" (et non le booléen 'true').

### 3. Gestion des Erreurs
*   Si le DNIS est inconnu dans la table, la Lambda lève une **Exception**.
*   Cela est volontaire pour déclencher la branche "Error" dans le flux Amazon Connect et router vers une logique de secours (ex: numéro Secours par défaut défini dans le flux).

## ☁️ Configuration AWS Lambda

Cette fonction dépend d'une configuration spécifique dans la console AWS Lambda.

### Variables d'Environnement
| Clé | Valeur Exemple | Description |
| :--- | :--- | :--- |
| `PARAM_DNIS_TABLE_NAME` | `ABE_DnisParameters` | Nom de la table DynamoDB contenant les paramétrages DNIS. |
| `LOGGER_LEVEL` | `INFO` | Niveau de détail des logs CloudWatch (INFO ou DEBUG). |

### Layers (Code Partagé)
Cette Lambda utilise la Layer **`ABE_Layers`** qui contient les dépendances partagées :
*   `constants.py`
*   `utils.py`

> [!IMPORTANT]
> **Gestion des Versions Layer** : Si vous modifiez le code dans `ABE_Layers`, vous devez publier une nouvelle version de la Layer **ET** mettre à jour la configuration de cette Lambda pour qu'elle pointe vers cette nouvelle version (numéro de version incrémenté).
>
> **Structure du ZIP** : Pour que les imports fonctionnent (`from utils import ...`), l'archive ZIP de la Layer doit impérativement contenir un dossier `python/` à la racine :
> ```text
> mon-archive-layer.zip
> └── python/
>     ├── constants.py
>     └── utils.py
> ```
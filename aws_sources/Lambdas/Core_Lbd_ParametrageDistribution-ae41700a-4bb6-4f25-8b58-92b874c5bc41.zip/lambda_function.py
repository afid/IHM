import json
import boto3
import os
import logging
from botocore.exceptions import ClientError

# Configuration du logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialisation des clients AWS
dynamodb = boto3.resource('dynamodb')
connect_client = boto3.client('connect')

def lambda_handler(event, context):
    """
    Fonction Lambda pour récupérer la queue associée à un parcours théorique
    depuis la table DynamoDB Core_Parcours.
    
    Args:
        event: Événement contenant les attributs Amazon Connect
        context: Contexte d'exécution Lambda
        
    Returns:
        dict: Réponse formatée pour Amazon Connect avec la queue trouvée
    """
    
    try:
        # Récupération du nom de la table depuis les variables d'environnement
        table_name = os.environ.get('DYNAMODB_TABLE_NAME', 'Core_Ddb_CiblageParametrageParcours')
        connect_instance_id = os.environ.get('CONNECT_INSTANCE_ID')
        
        if not connect_instance_id:
            logger.error("Variable d'environnement CONNECT_INSTANCE_ID non définie")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': 'Configuration manquante',
                    'message': 'CONNECT_INSTANCE_ID non configuré'
                }, ensure_ascii=False)
            }
        
        logger.info(f"Utilisation de la table DynamoDB: {table_name}")
        logger.info(f"Instance Amazon Connect: {connect_instance_id}")
        
        # Récupération de l'attribut UC_ParcoursTheorique depuis l'événement Connect
        parcours_theorique = None
        
        # Amazon Connect peut passer les attributs de différentes façons
        if 'Details' in event and 'ContactData' in event['Details']:
            contact_data = event['Details']['ContactData']
            if 'Attributes' in contact_data:
                parcours_theorique = contact_data['Attributes'].get('UC_ParcoursTheorique')
        
        # Fallback: vérifier directement dans l'événement
        if not parcours_theorique and 'UC_ParcoursTheorique' in event:
            parcours_theorique = event['UC_ParcoursTheorique']
            
        # Fallback: vérifier dans les attributs à la racine
        if not parcours_theorique and 'Attributes' in event:
            parcours_theorique = event['Attributes'].get('UC_ParcoursTheorique')
        
        if not parcours_theorique:
            logger.error("Attribut UC_ParcoursTheorique non trouvé dans l'événement")
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'UC_ParcoursTheorique manquant',
                    'message': 'L\'attribut UC_ParcoursTheorique est requis'
                }, ensure_ascii=False)
            }
        
        logger.info(f"Recherche des variables pour le parcours: {parcours_theorique}")
        
        # Accès à la table DynamoDB
        table = dynamodb.Table(table_name)
        
        # Récupération de l'élément avec la clé primaire "Parcours"
        response = table.get_item(
            Key={
                'Parcours': parcours_theorique
            }
        )
        
        # Vérification si l'élèment parcours_theorique existe 
        if 'Item' not in response:
            logger.warning(f"Aucun parcours trouvé pour: {parcours_theorique}")
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'error': 'Parcours non trouvé',
                    'message': f'Aucun parcours trouvé pour UC_ParcoursTheorique: {parcours_theorique}'
                }, ensure_ascii=False)
            }
        

        item = response['Item']

        # ---------------------------------------------------------
        # Vérification des champs obligatoires en base
        # ---------------------------------------------------------
        required_fields = ["GuidesAttente", "GuideDissuasion", "DureeAttenteMax"]

        missing_fields = [
            f for f in required_fields
            if item.get(f) is None or str(item.get(f)).strip() == ""
        ]

        if missing_fields:
            logger.warning(f"Champs manquants pour le parcours {parcours_theorique}: {missing_fields}")
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'error': 'Champs obligatoires manquants',
                    'missing_fields': missing_fields,
                    'message': f"Certains champs requis sont absents pour le parcours {parcours_theorique}"
                }, ensure_ascii=False)
            }

        # ---------------------------------------------------------
        # Récupération des valeurs
        # ---------------------------------------------------------
        GuidesAttente_name = str(item.get("GuidesAttente")).strip()
        GuideDissuasion_name = str(item.get("GuideDissuasion")).strip()
        GuidesMiseEnRelation_name = item.get("GuidesMiseEnRelation")  # optionnel
        DureeAttenteMax_raw = item.get("DureeAttenteMax")
        logger.info(f"GuidesMiseEnRelation raw: {GuidesAttente_name!r}")
        # ---------------------------------------------------------
        # Validation DureeAttenteMax
        # ---------------------------------------------------------
        try:
            DureeAttenteMax = int(DureeAttenteMax_raw)
            if DureeAttenteMax <= 0:
                raise ValueError()
        except Exception:
            logger.warning(f"DureeAttenteMax invalide pour le parcours {parcours_theorique}: {DureeAttenteMax_raw}")
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'DureeAttenteMax invalide',
                    'message': 'La valeur DureeAttenteMax doit être un entier positif'
                }, ensure_ascii=False)
            }

        # Flag si GuidesMiseEnRelation vide
        is_empty_gmr = (GuidesMiseEnRelation_name is None) or (str(GuidesMiseEnRelation_name).strip() == "")

        # ---------------------------------------------------------
        # Recherche des ARN des prompts via list_prompts
        # ---------------------------------------------------------
        try:
            logger.info("Recherche des ARN des prompts dans l'instance Connect")

            prompts_response = connect_client.list_prompts(
                InstanceId=connect_instance_id
            ) 

            # --- Split GuidesMiseEnRelation: "prompt1"
            gmr_names = []
            if not is_empty_gmr:
                gmr_names = [
                    n.strip()
                    for n in str(GuidesMiseEnRelation_name).split(",")
                    if n.strip()
                ][:5]

            # --- Init des ARN
            GuidesAttente_arn = None
            GuideDissuasion_arn = None
            GuidesMiseEnRelation_arn_0 = None
            GuidesMiseEnRelation_arn_1 = None
            GuidesMiseEnRelation_arn_2 = None
            GuidesMiseEnRelation_arn_3 = None
            GuidesMiseEnRelation_arn_4 = None
            # On utilise une liste pour simplifier l'affectation
            gmr_arns = [None, None, None, None, None]

            # --- Construire un mapping Name -> ARN à partir du retour list_prompts
            prompt_map = {}
            for prompt_summary in prompts_response.get('PromptSummaryList', []):
                name = prompt_summary.get("Name")
                arn = prompt_summary.get("Arn")
                if name and arn : 
                    prompt_map[name] = arn
            logger.info(f"NB pormpts chargés via list_prompts : {len(prompt_map)}")

            # résolution des N prompts GuidesMiseEnRelation
            for i, pname in enumerate(gmr_names):
                gmr_arns[i] = prompt_map.get(pname)
            logger.info(f"GuidesMiseEnRelation split names: {gmr_arns}")

            # --- Déplier dans les 5 variables : 
            GuidesMiseEnRelation_arn_0 = gmr_arns[0]
            GuidesMiseEnRelation_arn_1 = gmr_arns[1]
            GuidesMiseEnRelation_arn_2 = gmr_arns[2]
            GuidesMiseEnRelation_arn_3 = gmr_arns[3]
            GuidesMiseEnRelation_arn_4 = gmr_arns[4]

            # --- Count réellement trouvées (uniquement les ARN non vides)
            PromptCount = str(len([a for a in gmr_arns if a]))

            # résolution GuideAttente + GuideDissuasion 
            GuidesAttente_arn = prompt_map.get(GuidesAttente_name)
            GuideDissuasion_arn = prompt_map.get(GuideDissuasion_name)
            # Vérification obligatoires (prompts)
            missing_prompts = []
            if not GuidesAttente_arn:
                missing_prompts.append({"field": "GuidesAttente", "name": GuidesAttente_name})
            if not GuideDissuasion_arn:
                missing_prompts.append({"field": "GuideDissuasion", "name": GuideDissuasion_name})

            if missing_prompts:
                logger.warning(f"Prompts introuvables dans Connect: {missing_prompts}")
                return {
                    'statusCode': 404,
                    'body': json.dumps({
                        'error': 'Prompt(s) introuvable(s)',
                        'missing_prompts': missing_prompts,
                        'message': "Un ou plusieurs prompts référencés en base n'existent pas dans Amazon Connect."
                    }, ensure_ascii=False)
                }

        except ClientError as connect_error:
            logger.error(f"Erreur Amazon Connect: {connect_error}")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': 'Erreur Amazon Connect',
                    'message': str(connect_error)
                }, ensure_ascii=False)
            }

       
        # Réponse formatée pour Amazon Connect
        # Amazon Connect attend généralement les attributs dans un format spécifique
        return {
            'statusCode': 200,
            'GuidesMiseEnRelation_0': GuidesMiseEnRelation_arn_0 or "",
            'GuidesMiseEnRelation_1': GuidesMiseEnRelation_arn_1 or "",  
            'GuidesMiseEnRelation_2': GuidesMiseEnRelation_arn_2 or "",
            'GuidesMiseEnRelation_3': GuidesMiseEnRelation_arn_3 or "",
            'GuidesMiseEnRelation_4': GuidesMiseEnRelation_arn_4 or "",
            'PromptCount' : PromptCount or "",
            'isEmptyGuidesMiseEnRelation' : "true" if is_empty_gmr else "false",
            'GuidesAttente': GuidesAttente_arn,
            'GuideDissuasion': GuideDissuasion_arn,
            'DureeAttenteMax': str(DureeAttenteMax_raw),
            'Parcours': parcours_theorique,
            'body': json.dumps({
                'success': True,
                'GuidesMiseEnRelation_0': GuidesMiseEnRelation_arn_0 or "",
                'GuidesMiseEnRelation_1': GuidesMiseEnRelation_arn_1 or "",  
                'GuidesMiseEnRelation_2': GuidesMiseEnRelation_arn_2 or "",
                'GuidesMiseEnRelation_3': GuidesMiseEnRelation_arn_3 or "",
                'GuidesMiseEnRelation_4': GuidesMiseEnRelation_arn_4 or "",
                'PromptCount' : PromptCount or "",
                'isEmptyGuidesMiseEnRelation' : "true" if is_empty_gmr else "false",
                'GuidesAttente': GuidesAttente_arn,
                'GuideDissuasion': GuideDissuasion_arn,
                'DureeAttenteMax': str(DureeAttenteMax_raw),
                'Parcours': parcours_theorique
            }, ensure_ascii=False)
        }
        
    except ClientError as e:
        logger.error(f"Erreur DynamoDB: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Erreur base de données',
                'message': f'Erreur lors de l\'accès à DynamoDB: {str(e)}'
            }, ensure_ascii=False)
        }
        
    except Exception as e:
        logger.error(f"Erreur inattendue: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Erreur interne',
                'message': f'Erreur inattendue: {str(e)}'
            }, ensure_ascii=False)
        }
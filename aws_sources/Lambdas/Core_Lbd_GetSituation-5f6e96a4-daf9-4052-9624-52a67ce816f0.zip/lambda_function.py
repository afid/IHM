# CRED : Marie DUMBO
# SEE : https://confluence.covea.priv/display/DF/03-Determiner+les+situations+-+Core_Mod_DeterminSituation

import logging
import boto3
import os
import json
from datetime import date
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

# Config log
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Init DynamoDB
nom_table = os.environ.get("CENTRALISE_TABLE_NAME")
dynamodb = boto3.resource("dynamodb")

def get_situation(marque, domaine, sous_domaine) :
    
    # Init UC_Situation
    uc_situation = {}

    # Interrogation de la dynamo pour chaque structure
    for structure in filter(None, [marque, domaine, sous_domaine]):

        logger.info(f"Recherche dans la table {nom_table} la strucure {structure}")

        try:
            table_ddb = dynamodb.Table(nom_table)
            response = table_ddb.get_item(Key={"Structure": structure}, AttributesToGet=["Situations"])

            if response.get("Item") :
                
                if response["Item"].get("Situations") :

                    # Filtre les situations actives
                    situation_active = get_active_situation(response["Item"]["Situations"])

                    # Si plusieurs structures ont la même situation, on garde la preponderance minimum (la plus importante)
                    uc_situation.update(
                        {
                            key: min(uc_situation[key], situation_active[key]) if key in situation_active else uc_situation[key] for key in uc_situation
                        })
                    uc_situation.update({key: situation_active[key] for key in situation_active if key not in uc_situation})

                else :
                    logger.info(f"Aucune situation pour la structure {structure} dans la dynamo {nom_table}")
                                
            else :
                logger.info(f"Aucune structure ou situation pour la clès {structure} dans la dynamo {nom_table}")

        except ClientError as cli_err:
            logger.error(f"Erreur DynamoDB : {cli_err}")
            raise Exception("Erreur technique avec traitement de la Dynamo DB")

    # Vérif preponderances toutes différentes   
    if len(uc_situation.values()) != len(set(uc_situation.values())) :
        logger.info("Plusieurs situations avec la même préponderance")

    # Ajout situation par défaut avec la prépondérance la plus élevée (la moins importante)
    uc_situation["NORMALE"] =  max(uc_situation.values()) + 1
    
    return uc_situation

def get_active_situation(situation_ddb):

    # Init 
    active_situation = {}
    today = date.today()

    # Verif si situations actvie, cad, date du jour entre date de début et date de fin de la situation
    for situation in situation_ddb :

        logger.info(f"Recherche des situation actives pour la situation {situation}")

        date_debut_str = situation_ddb[situation].get("DateDebut")

        if date_debut_str :
            date_debut = date(int(date_debut_str[6:]), int(date_debut_str[3:5]) , int(date_debut_str[:2]))

            if date_debut <= today :

                date_fin_str = situation_ddb[situation].get("DateFin") 
                
                if not date_fin_str :
                    # Pas de date de fin = situation toujours active
                    active_situation[situation] = int(situation_ddb[situation].get("Preponderance",99))

                else :
                    date_fin = date(int(date_fin_str[6:]), int(date_fin_str[3:5]) , int(date_fin_str[:2]))

                    if today <= date_fin :
                        active_situation[situation] = int(situation_ddb[situation].get("Preponderance",99))

    return active_situation

def lambda_handler(event, context):

    # Init resultat par défaut
    default_result = {"NORMALE" : 1}

    try :
        # Extraction des paramètres d"entrée dans les contacts attributes
        uc_marque = event["Details"]["ContactData"]["Attributes"].get("UC_Marque")
        uc_domaine = event["Details"]["ContactData"]["Attributes"].get("UC_Domaine")
        uc_sous_domaine = event["Details"]["ContactData"]["Attributes"].get("UC_SousDomaine")

        # Vérif données en entrée
        if not uc_marque and not uc_domaine and not uc_sous_domaine :

            logger.warning("Aucune structure en entrée. Retourne situation par défaut")

            return {
                "UC_Situation": json.dumps(default_result),
                "error" : "Marque, domaine et sous-domaine null"
            }

        logger.info(f"Paramétres en entrée : UC_Marque : {uc_marque}, UC_Domaine : {uc_domaine}, UC_SousDomaine : {uc_sous_domaine}")

        # Recherche des situations
        uc_situation = get_situation(uc_marque, uc_domaine, uc_sous_domaine)

        logger.info(f"Succès récuppération des situations : UC_Situation = {uc_situation}")

        return {
            "UC_Situation": json.dumps(uc_situation)
        }
    
    except Exception as exc :

        return {
            "UC_Situation" : json.dumps(default_result),
            "error" : str(exc)
        }
